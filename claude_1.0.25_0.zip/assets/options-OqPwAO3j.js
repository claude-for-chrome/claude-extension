import './patch.js'
import {
    b as e,
    r as t,
    s,
    p as a,
    j as l,
    k as n,
    f as r,
    C as i,
    X as o,
    c,
    a as d,
    u as m,
    e as x,
    A as p,
    L as u,
    i as h,
    M as b,
} from "./Main-B6Y8HftM.js";
import {
    s as g,
    S as f,
    b as y,
    d as j,
    a as v,
    i as N,
} from "./SentryService-D1JZ-Jmf.js";
/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const k = e("bug", [
        ["path", { d: "m8 2 1.88 1.88", key: "fmnt4t" }],
        ["path", { d: "M14.12 3.88 16 2", key: "qol33r" }],
        ["path", { d: "M9 7.13v-1a3.003 3.003 0 1 1 6 0v1", key: "d7y7pr" }],
        [
            "path",
            {
                d: "M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6",
                key: "xs1cw7",
            },
        ],
        ["path", { d: "M12 20v-9", key: "1qisl0" }],
        ["path", { d: "M6.53 9C4.6 8.8 3 7.1 3 5", key: "32zzws" }],
        ["path", { d: "M6 13H2", key: "82j7cp" }],
        ["path", { d: "M3 21c0-2.1 1.7-3.9 3.8-4", key: "4p0ekp" }],
        ["path", { d: "M20.97 5c0 2.1-1.6 3.8-3.5 4", key: "18gb23" }],
        ["path", { d: "M22 13h-4", key: "1jl80f" }],
        ["path", { d: "M17.2 17c2.1.1 3.8 1.9 3.8 4", key: "k3fwyw" }],
    ]),
    w = e("circle-play", [
        ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
        ["polygon", { points: "10 8 16 12 10 16 10 8", key: "1cimsy" }],
    ]),
    S = e("download", [
        ["path", { d: "M12 15V3", key: "m9g1x1" }],
        [
            "path",
            { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" },
        ],
        ["path", { d: "m7 10 5 5 5-5", key: "brsn70" }],
    ]),
    T = e("ellipsis-vertical", [
        ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }],
        ["circle", { cx: "12", cy: "5", r: "1", key: "gxeob9" }],
        ["circle", { cx: "12", cy: "19", r: "1", key: "lyex9k" }],
    ]),
    C = e("file-down", [
        [
            "path",
            {
                d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",
                key: "1rqfz7",
            },
        ],
        ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
        ["path", { d: "M12 18v-6", key: "17g6i2" }],
        ["path", { d: "m9 15 3 3 3-3", key: "1npd3o" }],
    ]),
    M = e("history", [
        [
            "path",
            {
                d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",
                key: "1357e3",
            },
        ],
        ["path", { d: "M3 3v5h5", key: "1xhq8a" }],
        ["path", { d: "M12 7v5l4 2", key: "1fdv2h" }],
    ]),
    E = e("log-out", [
        ["path", { d: "m16 17 5-5-5-5", key: "1bji2h" }],
        ["path", { d: "M21 12H9", key: "dn1m92" }],
        [
            "path",
            { d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", key: "1uf3rs" },
        ],
    ]),
    D = e("pencil", [
        [
            "path",
            {
                d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
                key: "1a8usu",
            },
        ],
        ["path", { d: "m15 5 4 4", key: "1mk7zo" }],
    ]),
    _ = e("plus", [
        ["path", { d: "M5 12h14", key: "1ays0h" }],
        ["path", { d: "M12 5v14", key: "s699le" }],
    ]),
    L = e("trash-2", [
        ["path", { d: "M3 6h18", key: "d0wm0j" }],
        ["path", { d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6", key: "4alrt4" }],
        ["path", { d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2", key: "v07s0e" }],
        ["line", { x1: "10", x2: "10", y1: "11", y2: "17", key: "1uufr5" }],
        ["line", { x1: "14", x2: "14", y1: "11", y2: "17", key: "xtxkd" }],
    ]),
    P = e("upload", [
        ["path", { d: "M12 3v12", key: "1x0j5s" }],
        ["path", { d: "m17 8-5-5-5 5", key: "7q97r8" }],
        [
            "path",
            { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" },
        ],
    ]),
    A = e("user", [
        [
            "path",
            { d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2", key: "975kel" },
        ],
        ["circle", { cx: "12", cy: "7", r: "4", key: "17ys0d" }],
    ]),
    R = () => {
        const [e, n] = t.useState(),
            [r, i] = t.useState(!0),
            { value: o } = s.useFeatureGate("crochet_can_skip_permissions");
        t.useEffect(() => {
            a.setCanSkipPermissions(o);
        }, [o]),
            t.useEffect(() => {
                c();
            }, []);
        const c = async () => {
                i(!0);
                try {
                    const e = a.getPermissionsByScope();
                    n(e);
                } catch (e) {
                } finally {
                    i(!1);
                }
            },
            d = async (e) => {
                await a.revokePermission(e), c();
            },
            m = (e) =>
                "domain_transition" === e.scope.type
                    ? `${e.scope.fromDomain} → ${e.scope.toDomain}`
                    : e.scope.netloc || "Unknown domain";
        return r
            ? l.jsx("div", {
                  className: "p-6 text-text-200",
                  children: "Loading permissions...",
              })
            : l.jsx("div", {
                  className: "permissions-tab",
                  children: l.jsxs("div", {
                      className: "space-y-6",
                      children: [
                          l.jsxs("div", {
                              className:
                                  "bg-bg-100 border border-border-300 rounded-xl px-6 pt-6 pb-2 md:px-8 md:pt-8 md:pb-3",
                              children: [
                                  l.jsx("h3", {
                                      className: "text-text-100 font-xl-bold",
                                      children: "Your approved sites",
                                  }),
                                  l.jsx("p", {
                                      className:
                                          "text-text-300 font-base mt-2 mb-6",
                                      children:
                                          "You have allowed Claude to take all actions (browse, click, type) on these sites.",
                                  }),
                                  e?.netloc && e.netloc.length > 0
                                      ? l.jsx(I, {
                                            permissions: e.netloc,
                                            onRevoke: d,
                                            formatScope: m,
                                        })
                                      : l.jsx("div", {
                                            className:
                                                "text-text-400 font-base-sm pb-5",
                                            children:
                                                "No sites have been approved yet",
                                        }),
                              ],
                          }),
                          e?.domain_transition &&
                              e.domain_transition.length > 0 &&
                              l.jsxs("div", {
                                  className:
                                      "bg-bg-100 border border-border-300 rounded-xl px-6 pt-6 pb-2 md:px-8 md:pt-8 md:pb-3",
                                  children: [
                                      l.jsx("h3", {
                                          className:
                                              "text-text-100 font-xl-bold",
                                          children: "Domain Transitions",
                                      }),
                                      l.jsx("p", {
                                          className:
                                              "text-text-300 font-base mt-2 mb-6",
                                          children:
                                              "Permissions for navigating between different domains.",
                                      }),
                                      l.jsx(O, {
                                          permissions: e.domain_transition,
                                          onRevoke: d,
                                          formatScope: m,
                                      }),
                                  ],
                              }),
                      ],
                  }),
              });
    },
    I = ({ permissions: e, onRevoke: t, formatScope: s }) =>
        l.jsx("div", {
            children: e.map((a, r) =>
                l.jsxs(
                    n.Fragment,
                    {
                        children: [
                            l.jsxs("div", {
                                className:
                                    "py-4 flex items-center justify-between",
                                children: [
                                    l.jsxs("div", {
                                        className: "flex-1",
                                        children: [
                                            l.jsx("div", {
                                                className:
                                                    "font-large text-text-100",
                                                children: s(a),
                                            }),
                                            a.lastUsed &&
                                                l.jsxs("div", {
                                                    className:
                                                        "text-xs text-text-400 mt-1",
                                                    children: [
                                                        "Last used: ",
                                                        new Date(
                                                            a.lastUsed
                                                        ).toLocaleString(),
                                                    ],
                                                }),
                                        ],
                                    }),
                                    l.jsx("button", {
                                        onClick: () => t(a.id),
                                        className:
                                            "ml-4 px-4 py-2 text-danger-000 hover:bg-danger-000/10 rounded-lg transition-all font-base",
                                        children: "Revoke",
                                    }),
                                ],
                            }),
                            r < e.length - 1 &&
                                l.jsx("div", {
                                    className: "border-b border-border-400",
                                }),
                        ],
                    },
                    a.id
                )
            ),
        }),
    O = ({ permissions: e, onRevoke: t, formatScope: s }) =>
        l.jsx("div", {
            children: e.map((a, r) =>
                l.jsxs(
                    n.Fragment,
                    {
                        children: [
                            l.jsxs("div", {
                                className:
                                    "py-4 flex items-center justify-between",
                                children: [
                                    l.jsxs("div", {
                                        className: "flex-1",
                                        children: [
                                            l.jsx("div", {
                                                className:
                                                    "font-large text-text-100",
                                                children: s(a),
                                            }),
                                            a.lastUsed &&
                                                l.jsxs("div", {
                                                    className:
                                                        "text-xs text-text-400 mt-1",
                                                    children: [
                                                        "Last used: ",
                                                        new Date(
                                                            a.lastUsed
                                                        ).toLocaleString(),
                                                    ],
                                                }),
                                        ],
                                    }),
                                    l.jsx("button", {
                                        onClick: () => t(a.id),
                                        className:
                                            "ml-4 px-4 py-2 text-danger-000 hover:bg-danger-000/10 rounded-lg transition-all font-base",
                                        children: "Revoke",
                                    }),
                                ],
                            }),
                            r < e.length - 1 &&
                                l.jsx("div", {
                                    className: "border-b border-border-400",
                                }),
                        ],
                    },
                    a.id
                )
            ),
        });
function U() {
    const [e, s] = t.useState([]),
        [a, n] = t.useState(null),
        [c, d] = t.useState(!1),
        [m, x] = t.useState(!1),
        [p, u] = t.useState(null),
        [h, b] = t.useState(null),
        j = t.useCallback(
            async (t) => {
                const a = await chrome.alarms.getAll(),
                    l = t || e,
                    n = l.map((e) => {
                        const t = a.filter((t) =>
                            t.name.includes(`task_${e.id}`)
                        );
                        if (t.length > 0 && e.enabled) {
                            const s = Math.min(
                                ...t.map((e) => e.scheduledTime)
                            );
                            return { ...e, nextRun: s };
                        }
                        return { ...e, nextRun: void 0 };
                    });
                JSON.stringify(n) !== JSON.stringify(l) &&
                    (s(n), g(f.SCHEDULED_TASKS, n));
            },
            [e]
        ),
        v = t.useCallback(
            async (e) => {
                const t = await chrome.alarms.getAll();
                for (const s of t)
                    s.name.startsWith("task_") &&
                        (await chrome.alarms.clear(s.name));
                for (const s of e) s.enabled && E(s);
                setTimeout(() => j(e), 500);
            },
            [j]
        ),
        N = t.useCallback(
            async (e) => {
                await g(f.SCHEDULED_TASKS, e), s(e), v(e);
            },
            [v]
        ),
        k = t.useCallback(async () => {
            const e = await y(f.SCHEDULED_TASKS);
            e &&
                (s(e),
                setTimeout(async () => {
                    const t = await chrome.alarms.getAll(),
                        a = e.map((e) => {
                            const s = t.filter((t) =>
                                t.name.includes(`task_${e.id}`)
                            );
                            if (s.length > 0 && e.enabled) {
                                const t = Math.min(
                                    ...s.map((e) => e.scheduledTime)
                                );
                                return { ...e, nextRun: t };
                            }
                            return { ...e, nextRun: void 0 };
                        });
                    JSON.stringify(a) !== JSON.stringify(e) &&
                        (s(a), g(f.SCHEDULED_TASKS, a));
                }, 100));
        }, []),
        E = (e) => {
            const t = `task_${e.id}`;
            if ("once" === e.repeatType && e.specificTime) {
                const s = new Date(e.specificTime).getTime();
                s > Date.now() && chrome.alarms.create(t, { when: s });
            } else if ("hourly" === e.repeatType && e.intervalMinutes)
                chrome.alarms.create(t, {
                    periodInMinutes: e.intervalMinutes,
                    delayInMinutes: 1,
                });
            else if ("daily" === e.repeatType && e.specificTime) {
                const [s, a] = e.specificTime.split(":").map(Number),
                    l = new Date(),
                    n = new Date();
                n.setHours(s, a, 0, 0),
                    n <= l && n.setDate(n.getDate() + 1),
                    chrome.alarms.create(t, {
                        when: n.getTime(),
                        periodInMinutes: 1440,
                    });
            } else if ("weekdays" === e.repeatType && e.specificTime) {
                const [s, a] = e.specificTime.split(":").map(Number),
                    l = new Date(),
                    n = [1, 2, 3, 4, 5];
                let r = !1;
                for (const e of n) {
                    const n = new Date(),
                        i = (e - l.getDay() + 7) % 7;
                    if (0 === i) {
                        if ((n.setHours(s, a, 0, 0), n <= l)) continue;
                    } else n.setDate(l.getDate() + i), n.setHours(s, a, 0, 0);
                    if (!r && n > l) {
                        chrome.alarms.create(t, {
                            when: n.getTime(),
                            periodInMinutes: 1440,
                        }),
                            (r = !0);
                        break;
                    }
                }
                if (!r) {
                    const e = new Date(),
                        n = (1 - l.getDay() + 7) % 7 || 7;
                    e.setDate(l.getDate() + n),
                        e.setHours(s, a, 0, 0),
                        chrome.alarms.create(t, {
                            when: e.getTime(),
                            periodInMinutes: 1440,
                        });
                }
            } else if (
                "weekly" === e.repeatType &&
                e.daysOfWeek &&
                e.specificTime
            ) {
                const [s, a] = e.specificTime.split(":").map(Number),
                    l = new Date();
                for (const n of e.daysOfWeek) {
                    const e = new Date(),
                        r = (n - l.getDay() + 7) % 7;
                    e.setDate(l.getDate() + (r || 7)),
                        e.setHours(s, a, 0, 0),
                        e > l &&
                            chrome.alarms.create(`${t}_day${n}`, {
                                when: e.getTime(),
                                periodInMinutes: 10080,
                            });
                }
            }
        },
        A = t.useCallback(
            async (t, s = !0) => {
                const a = e.find((e) => e.id === t);
                if (!a) return;
                if (!s && !a.enabled) return;
                const l = await r.startTaskRun(a.id, a.name, a.prompt, a.url);
                if (s)
                    try {
                        const e = await chrome.tabs.create({
                            url: a.url || "about:blank",
                            active: !0,
                        });
                        if (!e.id) return;
                        await chrome.sidePanel.setOptions({
                            tabId: e.id,
                            path: `sidepanel.html?tabId=${encodeURIComponent(
                                e.id
                            )}`,
                            enabled: !0,
                        }),
                            e.id &&
                                (await chrome.sidePanel.open({ tabId: e.id })),
                            chrome.tabs.onUpdated.addListener(function t(s, n) {
                                s === e.id &&
                                    "complete" === n.status &&
                                    (chrome.tabs.onUpdated.removeListener(t),
                                    setTimeout(() => {
                                        chrome.runtime.sendMessage({
                                            type: "EXECUTE_SCHEDULED_PROMPT",
                                            prompt: a.prompt,
                                            taskName: a.name,
                                            runLogId: l.id,
                                            targetTabId: e.id,
                                        });
                                    }, 2e3));
                            });
                    } catch (i) {
                        await r.updateTaskRunStatus(
                            l.id,
                            "failed",
                            i instanceof Error ? i.message : String(i)
                        );
                    }
                else
                    chrome.runtime.sendMessage({
                        type: "EXECUTE_SCHEDULED_TASK",
                        task: {
                            id: a.id,
                            prompt: a.prompt,
                            url: a.url,
                            name: a.name,
                        },
                        isManual: s,
                        runLogId: l.id,
                    });
                const n = e.map((e) =>
                    e.id === t ? { ...e, lastRun: Date.now() } : e
                );
                N(n);
            },
            [e, N]
        ),
        R = t.useCallback(() => {
            chrome.alarms.onAlarm.addListener((e) => {
                if (e.name.startsWith("task_")) {
                    const t = e.name.replace("task_", "");
                    A(t, !1);
                }
            });
        }, [A]),
        I = (e) => {
            if (!e) return "Not scheduled";
            const t = new Date(e),
                s = e - new Date().getTime();
            return s < 0
                ? "Overdue"
                : s < 6e4
                ? "Less than a minute"
                : s < 36e5
                ? `${Math.floor(s / 6e4)} minutes`
                : s < 864e5
                ? `${Math.floor(s / 36e5)} hours`
                : t.toLocaleString();
        },
        O = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    return (
        t.useEffect(() => {
            k(), R(), j();
            const e = setInterval(() => {
                    j();
                }, 3e4),
                t = (e) => {
                    e.target.closest(".kebab-menu-container") || b(null);
                };
            return (
                document.addEventListener("click", t),
                () => {
                    clearInterval(e), document.removeEventListener("click", t);
                }
            );
        }, [k, R, j]),
        l.jsxs("div", {
            className: "max-w-4xl",
            children: [
                l.jsxs("div", {
                    className: "mb-6",
                    children: [
                        l.jsx("h2", {
                            className: "font-xl-bold text-text-100 mb-4",
                            children: "Scheduled Tasks",
                        }),
                        l.jsx("div", {
                            className:
                                "p-4 bg-bg-100 border border-border-200 rounded-lg mb-4",
                            children: l.jsxs("div", {
                                className: "flex items-start gap-2",
                                children: [
                                    l.jsx(i, {
                                        className:
                                            "w-5 h-5 text-accent-main-200 mt-0.5",
                                    }),
                                    l.jsxs("div", {
                                        className: "text-sm text-text-100",
                                        children: [
                                            l.jsx("p", {
                                                className: "font-medium mb-1",
                                                children:
                                                    "Chrome Alarms API Limitations:",
                                            }),
                                            l.jsxs("ul", {
                                                className:
                                                    "list-disc list-inside space-y-1 text-text-200",
                                                children: [
                                                    l.jsx("li", {
                                                        children:
                                                            "Tasks will only run when Chrome is open",
                                                    }),
                                                    l.jsx("li", {
                                                        children:
                                                            "If Chrome is closed when a task is scheduled, it will run the next time Chrome opens",
                                                    }),
                                                    l.jsx("li", {
                                                        children:
                                                            "Minimum interval between repeating tasks is 1 minute",
                                                    }),
                                                    l.jsx("li", {
                                                        children:
                                                            "Tasks may be delayed by up to 1 minute from scheduled time",
                                                    }),
                                                ],
                                            }),
                                        ],
                                    }),
                                ],
                            }),
                        }),
                    ],
                }),
                l.jsxs("div", {
                    className: "space-y-4",
                    children: [
                        e.map((t) =>
                            l.jsx(
                                "div",
                                {
                                    className:
                                        "border border-border-200 rounded-lg p-4",
                                    children: l.jsxs("div", {
                                        className:
                                            "flex items-start justify-between",
                                        children: [
                                            l.jsxs("div", {
                                                className: "flex-1",
                                                children: [
                                                    l.jsxs("div", {
                                                        className:
                                                            "flex items-center gap-2 mb-2",
                                                        children: [
                                                            l.jsx("h3", {
                                                                className:
                                                                    "font-medium text-lg text-text-100",
                                                                children:
                                                                    t.name,
                                                            }),
                                                            l.jsxs("label", {
                                                                className:
                                                                    "relative inline-flex items-center cursor-pointer",
                                                                title: t.enabled
                                                                    ? "Task is enabled and will run automatically"
                                                                    : "Task is disabled and will not run automatically",
                                                                children: [
                                                                    l.jsx(
                                                                        "input",
                                                                        {
                                                                            type: "checkbox",
                                                                            checked:
                                                                                t.enabled,
                                                                            onChange:
                                                                                () =>
                                                                                    ((
                                                                                        t
                                                                                    ) => {
                                                                                        const s =
                                                                                            e.map(
                                                                                                (
                                                                                                    e
                                                                                                ) =>
                                                                                                    e.id ===
                                                                                                    t
                                                                                                        ? {
                                                                                                              ...e,
                                                                                                              enabled:
                                                                                                                  !e.enabled,
                                                                                                          }
                                                                                                        : e
                                                                                            );
                                                                                        N(
                                                                                            s
                                                                                        );
                                                                                    })(
                                                                                        t.id
                                                                                    ),
                                                                            className:
                                                                                "sr-only peer",
                                                                        }
                                                                    ),
                                                                    l.jsx(
                                                                        "div",
                                                                        {
                                                                            className:
                                                                                "w-11 h-6 bg-bg-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-accent-main-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-bg-000 after:border-border-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-accent-main-200",
                                                                        }
                                                                    ),
                                                                ],
                                                            }),
                                                        ],
                                                    }),
                                                    l.jsxs("div", {
                                                        className:
                                                            "space-y-1 text-sm text-text-200",
                                                        children: [
                                                            l.jsxs("p", {
                                                                children: [
                                                                    l.jsx(
                                                                        "span",
                                                                        {
                                                                            className:
                                                                                "font-medium",
                                                                            children:
                                                                                "URL:",
                                                                        }
                                                                    ),
                                                                    " ",
                                                                    t.url ||
                                                                        "Current page",
                                                                ],
                                                            }),
                                                            l.jsxs("div", {
                                                                children: [
                                                                    l.jsx(
                                                                        "span",
                                                                        {
                                                                            className:
                                                                                "font-medium",
                                                                            children:
                                                                                "Prompt:",
                                                                        }
                                                                    ),
                                                                    " ",
                                                                    l.jsx(
                                                                        "span",
                                                                        {
                                                                            onClick:
                                                                                (
                                                                                    e
                                                                                ) => {
                                                                                    e.stopPropagation(),
                                                                                        n(
                                                                                            t
                                                                                        ),
                                                                                        d(
                                                                                            !0
                                                                                        );
                                                                                },
                                                                            className:
                                                                                "inline-block cursor-pointer hover:text-text-000 hover:bg-bg-100 px-1 -mx-1 rounded transition-colors",
                                                                            title: "Click to edit task",
                                                                            children:
                                                                                l.jsx(
                                                                                    "span",
                                                                                    {
                                                                                        className:
                                                                                            "whitespace-pre-wrap",
                                                                                        children:
                                                                                            t
                                                                                                .prompt
                                                                                                .length >
                                                                                            200
                                                                                                ? t.prompt.substring(
                                                                                                      0,
                                                                                                      200
                                                                                                  ) +
                                                                                                  "..."
                                                                                                : t.prompt,
                                                                                    }
                                                                                ),
                                                                        }
                                                                    ),
                                                                ],
                                                            }),
                                                            l.jsxs("p", {
                                                                children: [
                                                                    l.jsx(
                                                                        "span",
                                                                        {
                                                                            className:
                                                                                "font-medium",
                                                                            children:
                                                                                "Schedule:",
                                                                        }
                                                                    ),
                                                                    " ",
                                                                    "once" ===
                                                                    t.repeatType
                                                                        ? `Once at ${t.specificTime}`
                                                                        : "hourly" ===
                                                                          t.repeatType
                                                                        ? `Every ${t.intervalMinutes} minutes`
                                                                        : "daily" ===
                                                                          t.repeatType
                                                                        ? `Daily at ${t.specificTime}`
                                                                        : "weekdays" ===
                                                                          t.repeatType
                                                                        ? `Weekdays (Mon-Fri) at ${t.specificTime}`
                                                                        : "weekly" ===
                                                                          t.repeatType
                                                                        ? `Weekly on ${t.daysOfWeek
                                                                              ?.map(
                                                                                  (
                                                                                      e
                                                                                  ) =>
                                                                                      O[
                                                                                          e
                                                                                      ]
                                                                              )
                                                                              .join(
                                                                                  ", "
                                                                              )} at ${
                                                                              t.specificTime
                                                                          }`
                                                                        : "Not configured",
                                                                ],
                                                            }),
                                                            t.lastRun &&
                                                                l.jsxs("p", {
                                                                    children: [
                                                                        l.jsx(
                                                                            "span",
                                                                            {
                                                                                className:
                                                                                    "font-medium",
                                                                                children:
                                                                                    "Last run:",
                                                                            }
                                                                        ),
                                                                        " ",
                                                                        new Date(
                                                                            t.lastRun
                                                                        ).toLocaleString(),
                                                                    ],
                                                                }),
                                                            l.jsxs("p", {
                                                                children: [
                                                                    l.jsx(
                                                                        "span",
                                                                        {
                                                                            className:
                                                                                "font-medium",
                                                                            children:
                                                                                "Next run:",
                                                                        }
                                                                    ),
                                                                    " ",
                                                                    I(
                                                                        t.nextRun
                                                                    ),
                                                                ],
                                                            }),
                                                        ],
                                                    }),
                                                ],
                                            }),
                                            l.jsxs("div", {
                                                className:
                                                    "relative kebab-menu-container",
                                                children: [
                                                    l.jsx("button", {
                                                        onClick: (e) => {
                                                            e.stopPropagation(),
                                                                b(
                                                                    h === t.id
                                                                        ? null
                                                                        : t.id
                                                                );
                                                        },
                                                        className:
                                                            "p-2 text-text-200 hover:bg-bg-100 rounded",
                                                        title: "More actions",
                                                        children: l.jsx(T, {
                                                            className:
                                                                "w-4 h-4",
                                                        }),
                                                    }),
                                                    h === t.id &&
                                                        l.jsxs("div", {
                                                            className:
                                                                "absolute right-0 top-full mt-1 bg-bg-000 border border-border-200 rounded-lg shadow-lg z-10 min-w-48",
                                                            children: [
                                                                l.jsxs(
                                                                    "button",
                                                                    {
                                                                        onClick:
                                                                            () => {
                                                                                A(
                                                                                    t.id
                                                                                ),
                                                                                    b(
                                                                                        null
                                                                                    );
                                                                            },
                                                                        className:
                                                                            "w-full px-4 py-2 text-left text-text-000 hover:bg-bg-100 flex items-center gap-2",
                                                                        children:
                                                                            [
                                                                                l.jsx(
                                                                                    w,
                                                                                    {
                                                                                        className:
                                                                                            "w-4 h-4",
                                                                                    }
                                                                                ),
                                                                                "Run Now",
                                                                            ],
                                                                    }
                                                                ),
                                                                l.jsxs(
                                                                    "button",
                                                                    {
                                                                        onClick:
                                                                            () => {
                                                                                n(
                                                                                    t
                                                                                ),
                                                                                    d(
                                                                                        !0
                                                                                    ),
                                                                                    b(
                                                                                        null
                                                                                    );
                                                                            },
                                                                        className:
                                                                            "w-full px-4 py-2 text-left text-text-000 hover:bg-bg-100 flex items-center gap-2",
                                                                        children:
                                                                            [
                                                                                l.jsx(
                                                                                    D,
                                                                                    {
                                                                                        className:
                                                                                            "w-4 h-4",
                                                                                    }
                                                                                ),
                                                                                "Edit Task",
                                                                            ],
                                                                    }
                                                                ),
                                                                l.jsxs(
                                                                    "button",
                                                                    {
                                                                        onClick:
                                                                            async () => {
                                                                                const e =
                                                                                    await r.getTaskLogs(
                                                                                        t.id
                                                                                    );
                                                                                u(
                                                                                    {
                                                                                        taskId: t.id,
                                                                                        taskName:
                                                                                            t.name,
                                                                                        logs: e,
                                                                                    }
                                                                                ),
                                                                                    b(
                                                                                        null
                                                                                    );
                                                                            },
                                                                        className:
                                                                            "w-full px-4 py-2 text-left text-text-000 hover:bg-bg-100 flex items-center gap-2",
                                                                        children:
                                                                            [
                                                                                l.jsx(
                                                                                    M,
                                                                                    {
                                                                                        className:
                                                                                            "w-4 h-4",
                                                                                    }
                                                                                ),
                                                                                "View Run History",
                                                                            ],
                                                                    }
                                                                ),
                                                                l.jsxs(
                                                                    "button",
                                                                    {
                                                                        onClick:
                                                                            () => {
                                                                                ((
                                                                                    e
                                                                                ) => {
                                                                                    const t =
                                                                                            {
                                                                                                ...e,
                                                                                                exportedAt:
                                                                                                    new Date().toISOString(),
                                                                                                version:
                                                                                                    "1.0",
                                                                                            },
                                                                                        s =
                                                                                            JSON.stringify(
                                                                                                t,
                                                                                                null,
                                                                                                2
                                                                                            ),
                                                                                        a =
                                                                                            new Blob(
                                                                                                [
                                                                                                    s,
                                                                                                ],
                                                                                                {
                                                                                                    type: "application/json",
                                                                                                }
                                                                                            ),
                                                                                        l =
                                                                                            URL.createObjectURL(
                                                                                                a
                                                                                            ),
                                                                                        n = `task_${e.name
                                                                                            .toLowerCase()
                                                                                            .replace(
                                                                                                /[^a-z0-9]+/g,
                                                                                                "_"
                                                                                            )
                                                                                            .replace(
                                                                                                /^_+|_+$/g,
                                                                                                ""
                                                                                            )}.json`,
                                                                                        r =
                                                                                            document.createElement(
                                                                                                "a"
                                                                                            );
                                                                                    (r.href =
                                                                                        l),
                                                                                        (r.download =
                                                                                            n),
                                                                                        document.body.appendChild(
                                                                                            r
                                                                                        ),
                                                                                        r.click(),
                                                                                        document.body.removeChild(
                                                                                            r
                                                                                        ),
                                                                                        URL.revokeObjectURL(
                                                                                            l
                                                                                        );
                                                                                })(
                                                                                    t
                                                                                ),
                                                                                    b(
                                                                                        null
                                                                                    );
                                                                            },
                                                                        className:
                                                                            "w-full px-4 py-2 text-left text-text-000 hover:bg-bg-100 flex items-center gap-2",
                                                                        children:
                                                                            [
                                                                                l.jsx(
                                                                                    C,
                                                                                    {
                                                                                        className:
                                                                                            "w-4 h-4",
                                                                                    }
                                                                                ),
                                                                                "Export Config",
                                                                            ],
                                                                    }
                                                                ),
                                                                l.jsx("hr", {
                                                                    className:
                                                                        "my-1",
                                                                }),
                                                                l.jsxs(
                                                                    "button",
                                                                    {
                                                                        onClick:
                                                                            () => {
                                                                                ((
                                                                                    t
                                                                                ) => {
                                                                                    const s =
                                                                                        e.filter(
                                                                                            (
                                                                                                e
                                                                                            ) =>
                                                                                                e.id !==
                                                                                                t
                                                                                        );
                                                                                    N(
                                                                                        s
                                                                                    );
                                                                                })(
                                                                                    t.id
                                                                                ),
                                                                                    b(
                                                                                        null
                                                                                    );
                                                                            },
                                                                        className:
                                                                            "w-full px-4 py-2 text-left text-danger-000 hover:bg-danger-900 flex items-center gap-2",
                                                                        children:
                                                                            [
                                                                                l.jsx(
                                                                                    L,
                                                                                    {
                                                                                        className:
                                                                                            "w-4 h-4",
                                                                                    }
                                                                                ),
                                                                                "Delete Task",
                                                                            ],
                                                                    }
                                                                ),
                                                            ],
                                                        }),
                                                ],
                                            }),
                                        ],
                                    }),
                                },
                                t.id
                            )
                        ),
                        0 === e.length &&
                            l.jsx("div", {
                                className: "text-center py-8 text-text-300",
                                children:
                                    "No scheduled tasks yet. Click the button below to add one.",
                            }),
                    ],
                }),
                l.jsxs("div", {
                    className: "mt-4 flex gap-2",
                    children: [
                        l.jsxs("button", {
                            onClick: () => {
                                const e = {
                                    id: Date.now().toString(),
                                    name: "",
                                    prompt: "",
                                    url: "",
                                    repeatType: "once",
                                    enabled: !1,
                                };
                                n(e), d(!0);
                            },
                            className:
                                "flex-1 flex items-center justify-center gap-2 py-2 px-4 bg-accent-main-200 text-oncolor-100 rounded-lg hover:bg-accent-main-100 active:bg-accent-main-100 active:scale-[0.98] transition-all",
                            children: [
                                l.jsx(_, { className: "w-4 h-4" }),
                                "Add Scheduled Task",
                            ],
                        }),
                        l.jsxs("button", {
                            onClick: () => {
                                const e = document.createElement("input");
                                (e.type = "file"),
                                    (e.accept = ".json"),
                                    (e.onchange = (e) => {
                                        const t = e.target.files?.[0];
                                        if (!t) return;
                                        const s = new FileReader();
                                        (s.onload = (e) => {
                                            try {
                                                const t = JSON.parse(
                                                        e.target?.result
                                                    ),
                                                    s = {
                                                        id: Date.now().toString(),
                                                        name:
                                                            t.name ||
                                                            "Imported Task",
                                                        prompt: t.prompt || "",
                                                        url: t.url || "",
                                                        repeatType:
                                                            t.repeatType ||
                                                            "once",
                                                        intervalMinutes:
                                                            t.intervalMinutes,
                                                        specificTime:
                                                            t.specificTime,
                                                        daysOfWeek:
                                                            t.daysOfWeek,
                                                        enabled:
                                                            !0 === t.enabled,
                                                    };
                                                n(s), x(!0), d(!0);
                                            } catch {
                                                alert(
                                                    "Failed to import task config. Please check the file format."
                                                );
                                            }
                                        }),
                                            s.readAsText(t);
                                    }),
                                    e.click();
                            },
                            className:
                                "flex items-center justify-center gap-2 py-2 px-4 border border-border-300 text-text-100 rounded-lg hover:bg-bg-100 active:bg-bg-200 active:scale-[0.98] transition-all",
                            children: [
                                l.jsx(P, { className: "w-4 h-4" }),
                                "Import Task",
                            ],
                        }),
                    ],
                }),
                !1,
                c &&
                    a &&
                    l.jsx("div", {
                        className:
                            "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50",
                        children: l.jsxs("div", {
                            className:
                                "bg-bg-000 rounded-lg p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto",
                            children: [
                                l.jsxs("h3", {
                                    className:
                                        "text-lg font-semibold mb-4 text-text-100",
                                    children: [
                                        m
                                            ? "Review Imported Task"
                                            : e.find((e) => e.id === a.id)
                                            ? "Edit"
                                            : "Add",
                                        " ",
                                        "Scheduled Task",
                                    ],
                                }),
                                m &&
                                    l.jsx("div", {
                                        className:
                                            "mb-4 p-4 bg-accent-secondary-900 border border-accent-secondary-200 rounded-lg",
                                        children: l.jsxs("div", {
                                            className: "flex items-start gap-2",
                                            children: [
                                                l.jsx(i, {
                                                    className:
                                                        "w-5 h-5 text-accent-secondary-200 mt-0.5 flex-shrink-0",
                                                }),
                                                l.jsxs("div", {
                                                    className: "text-sm",
                                                    children: [
                                                        l.jsx("p", {
                                                            className:
                                                                "font-medium text-text-100 mb-1",
                                                            children:
                                                                "Security Notice",
                                                        }),
                                                        l.jsx("p", {
                                                            className:
                                                                "text-text-200",
                                                            children:
                                                                "You are importing a task configuration. Please review all details carefully before saving. Only import tasks from sources you trust, as they will have access to browse websites and interact with Claude on your behalf.",
                                                        }),
                                                    ],
                                                }),
                                            ],
                                        }),
                                    }),
                                l.jsxs("div", {
                                    className: "space-y-4",
                                    children: [
                                        l.jsxs("div", {
                                            children: [
                                                l.jsx("label", {
                                                    className:
                                                        "block text-sm font-medium mb-1 text-text-100",
                                                    children: "Task Name",
                                                }),
                                                l.jsx("input", {
                                                    type: "text",
                                                    value: a.name,
                                                    onChange: (e) =>
                                                        n({
                                                            ...a,
                                                            name: e.target
                                                                .value,
                                                        }),
                                                    className:
                                                        "w-full px-3 py-2 border border-border-300 rounded-md bg-bg-000 text-text-100",
                                                    placeholder:
                                                        "e.g., Daily News Summary",
                                                }),
                                            ],
                                        }),
                                        l.jsxs("div", {
                                            children: [
                                                l.jsx("label", {
                                                    className:
                                                        "block text-sm font-medium mb-1 text-text-100",
                                                    children:
                                                        "Starting URL (optional)",
                                                }),
                                                l.jsx("input", {
                                                    type: "text",
                                                    value: a.url,
                                                    onChange: (e) =>
                                                        n({
                                                            ...a,
                                                            url: e.target.value,
                                                        }),
                                                    className:
                                                        "w-full px-3 py-2 border border-border-300 rounded-md bg-bg-000 text-text-100",
                                                    placeholder:
                                                        "e.g., https://news.ycombinator.com",
                                                }),
                                                l.jsx("p", {
                                                    className:
                                                        "text-xs text-text-300 mt-1",
                                                    children:
                                                        "Leave empty to use the current active tab",
                                                }),
                                            ],
                                        }),
                                        l.jsxs("div", {
                                            children: [
                                                l.jsx("label", {
                                                    className:
                                                        "block text-sm font-medium mb-1 text-text-100",
                                                    children: "Prompt",
                                                }),
                                                l.jsx("textarea", {
                                                    value: a.prompt,
                                                    onChange: (e) =>
                                                        n({
                                                            ...a,
                                                            prompt: e.target
                                                                .value,
                                                        }),
                                                    className:
                                                        "w-full px-3 py-2 border border-border-300 rounded-md bg-bg-000 text-text-100",
                                                    rows: 3,
                                                    placeholder:
                                                        "e.g., Summarize the top 5 stories on this page",
                                                }),
                                            ],
                                        }),
                                        l.jsxs("div", {
                                            children: [
                                                l.jsx("label", {
                                                    className:
                                                        "block text-sm font-medium mb-1 text-text-100",
                                                    children: "Repeat",
                                                }),
                                                l.jsxs("select", {
                                                    value: a.repeatType,
                                                    onChange: (e) =>
                                                        n({
                                                            ...a,
                                                            repeatType:
                                                                e.target.value,
                                                        }),
                                                    className:
                                                        "w-full px-3 py-2 border border-border-300 rounded-md bg-bg-000 text-text-100",
                                                    children: [
                                                        l.jsx("option", {
                                                            value: "once",
                                                            children: "Once",
                                                        }),
                                                        l.jsx("option", {
                                                            value: "hourly",
                                                            children:
                                                                "Hourly/Custom Interval",
                                                        }),
                                                        l.jsx("option", {
                                                            value: "daily",
                                                            children: "Daily",
                                                        }),
                                                        l.jsx("option", {
                                                            value: "weekdays",
                                                            children:
                                                                "Weekdays (Mon-Fri)",
                                                        }),
                                                        l.jsx("option", {
                                                            value: "weekly",
                                                            children: "Weekly",
                                                        }),
                                                    ],
                                                }),
                                            ],
                                        }),
                                        "once" === a.repeatType &&
                                            l.jsxs("div", {
                                                children: [
                                                    l.jsx("label", {
                                                        className:
                                                            "block text-sm font-medium mb-1 text-text-100",
                                                        children: "Date & Time",
                                                    }),
                                                    l.jsx("input", {
                                                        type: "datetime-local",
                                                        value: a.specificTime,
                                                        onChange: (e) =>
                                                            n({
                                                                ...a,
                                                                specificTime:
                                                                    e.target
                                                                        .value,
                                                            }),
                                                        className:
                                                            "w-full px-3 py-2 border border-border-300 rounded-md bg-bg-000 text-text-100",
                                                    }),
                                                ],
                                            }),
                                        "hourly" === a.repeatType &&
                                            l.jsxs("div", {
                                                children: [
                                                    l.jsx("label", {
                                                        className:
                                                            "block text-sm font-medium mb-1 text-text-100",
                                                        children:
                                                            "Interval (minutes)",
                                                    }),
                                                    l.jsx("input", {
                                                        type: "number",
                                                        min: "1",
                                                        value:
                                                            a.intervalMinutes ||
                                                            60,
                                                        onChange: (e) =>
                                                            n({
                                                                ...a,
                                                                intervalMinutes:
                                                                    parseInt(
                                                                        e.target
                                                                            .value
                                                                    ),
                                                            }),
                                                        className:
                                                            "w-full px-3 py-2 border border-border-300 rounded-md bg-bg-000 text-text-100",
                                                    }),
                                                    l.jsx("p", {
                                                        className:
                                                            "text-xs text-text-300 mt-1",
                                                        children:
                                                            "Minimum: 1 minute",
                                                    }),
                                                ],
                                            }),
                                        ("daily" === a.repeatType ||
                                            "weekly" === a.repeatType ||
                                            "weekdays" === a.repeatType) &&
                                            l.jsxs("div", {
                                                children: [
                                                    l.jsx("label", {
                                                        className:
                                                            "block text-sm font-medium mb-1 text-text-100",
                                                        children: "Time",
                                                    }),
                                                    l.jsx("input", {
                                                        type: "time",
                                                        value: a.specificTime,
                                                        onChange: (e) =>
                                                            n({
                                                                ...a,
                                                                specificTime:
                                                                    e.target
                                                                        .value,
                                                            }),
                                                        className:
                                                            "w-full px-3 py-2 border border-border-300 rounded-md bg-bg-000 text-text-100",
                                                    }),
                                                ],
                                            }),
                                        "weekly" === a.repeatType &&
                                            l.jsxs("div", {
                                                children: [
                                                    l.jsx("label", {
                                                        className:
                                                            "block text-sm font-medium mb-1 text-text-100",
                                                        children:
                                                            "Days of Week",
                                                    }),
                                                    l.jsx("div", {
                                                        className: "flex gap-2",
                                                        children: O.map(
                                                            (e, t) =>
                                                                l.jsxs(
                                                                    "label",
                                                                    {
                                                                        className:
                                                                            "flex items-center",
                                                                        children:
                                                                            [
                                                                                l.jsx(
                                                                                    "input",
                                                                                    {
                                                                                        type: "checkbox",
                                                                                        checked:
                                                                                            a.daysOfWeek?.includes(
                                                                                                t
                                                                                            ) ||
                                                                                            !1,
                                                                                        onChange:
                                                                                            (
                                                                                                e
                                                                                            ) => {
                                                                                                const s =
                                                                                                    a.daysOfWeek ||
                                                                                                    [];
                                                                                                e
                                                                                                    .target
                                                                                                    .checked
                                                                                                    ? n(
                                                                                                          {
                                                                                                              ...a,
                                                                                                              daysOfWeek:
                                                                                                                  [
                                                                                                                      ...s,
                                                                                                                      t,
                                                                                                                  ],
                                                                                                          }
                                                                                                      )
                                                                                                    : n(
                                                                                                          {
                                                                                                              ...a,
                                                                                                              daysOfWeek:
                                                                                                                  s.filter(
                                                                                                                      (
                                                                                                                          e
                                                                                                                      ) =>
                                                                                                                          e !==
                                                                                                                          t
                                                                                                                  ),
                                                                                                          }
                                                                                                      );
                                                                                            },
                                                                                        className:
                                                                                            "mr-1",
                                                                                    }
                                                                                ),
                                                                                e,
                                                                            ],
                                                                    },
                                                                    t
                                                                )
                                                        ),
                                                    }),
                                                ],
                                            }),
                                        l.jsxs("div", {
                                            className:
                                                "flex items-center justify-between",
                                            children: [
                                                l.jsx("span", {
                                                    className:
                                                        "text-sm font-medium text-text-100",
                                                    children:
                                                        "Enable task immediately",
                                                }),
                                                l.jsxs("label", {
                                                    className:
                                                        "relative inline-flex items-center cursor-pointer",
                                                    children: [
                                                        l.jsx("input", {
                                                            type: "checkbox",
                                                            checked: a.enabled,
                                                            onChange: (e) =>
                                                                n({
                                                                    ...a,
                                                                    enabled:
                                                                        e.target
                                                                            .checked,
                                                                }),
                                                            className:
                                                                "sr-only peer",
                                                        }),
                                                        l.jsx("div", {
                                                            className:
                                                                "w-11 h-6 bg-bg-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-accent-main-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-bg-000 after:border-border-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-accent-main-200",
                                                        }),
                                                    ],
                                                }),
                                            ],
                                        }),
                                    ],
                                }),
                                l.jsxs("div", {
                                    className: "flex gap-3 mt-6",
                                    children: [
                                        l.jsx("button", {
                                            onClick: () => {
                                                if (!a || !a.name || !a.prompt)
                                                    return;
                                                const t =
                                                    a.id &&
                                                    e.find((e) => e.id === a.id)
                                                        ? e.map((e) =>
                                                              e.id === a.id
                                                                  ? a
                                                                  : e
                                                          )
                                                        : [...e, a];
                                                N(t), n(null), d(!1), x(!1);
                                            },
                                            className:
                                                "flex-1 py-2 px-4 bg-accent-main-200 text-oncolor-100 rounded-md hover:bg-accent-main-100 active:bg-accent-main-100 active:scale-[0.98] transition-all",
                                            children: m
                                                ? "Import Task"
                                                : "Save Task",
                                        }),
                                        l.jsx("button", {
                                            onClick: () => {
                                                n(null), d(!1), x(!1);
                                            },
                                            className:
                                                "flex-1 py-2 px-4 border border-border-300 rounded-md hover:bg-bg-100 text-text-100 active:bg-bg-200 active:scale-[0.98] transition-all",
                                            children: "Cancel",
                                        }),
                                    ],
                                }),
                            ],
                        }),
                    }),
                p &&
                    l.jsx("div", {
                        className:
                            "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50",
                        children: l.jsxs("div", {
                            className:
                                "bg-bg-000 rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col",
                            children: [
                                l.jsxs("div", {
                                    className:
                                        "flex items-center justify-between mb-4",
                                    children: [
                                        l.jsxs("h3", {
                                            className: "text-lg font-semibold",
                                            children: [
                                                "Run History: ",
                                                p.taskName,
                                            ],
                                        }),
                                        l.jsxs("div", {
                                            className: "flex gap-2",
                                            children: [
                                                l.jsx("button", {
                                                    onClick: async () => {
                                                        const e =
                                                                await r.exportLogs(
                                                                    p.taskId
                                                                ),
                                                            t = new Date(),
                                                            s = t.getFullYear(),
                                                            a = String(
                                                                t.getMonth() + 1
                                                            ).padStart(2, "0"),
                                                            l = String(
                                                                t.getDate()
                                                            ).padStart(2, "0"),
                                                            n = String(
                                                                t.getHours()
                                                            ).padStart(2, "0"),
                                                            i = String(
                                                                t.getMinutes()
                                                            ).padStart(2, "0"),
                                                            o = `${p.taskName
                                                                .toLowerCase()
                                                                .replace(
                                                                    /[^a-z0-9]+/g,
                                                                    "_"
                                                                )
                                                                .replace(
                                                                    /^_+|_+$/g,
                                                                    ""
                                                                )}_${s}${a}${l}_${n}${i}.json`,
                                                            c = new Blob([e], {
                                                                type: "application/json",
                                                            }),
                                                            d =
                                                                URL.createObjectURL(
                                                                    c
                                                                ),
                                                            m =
                                                                document.createElement(
                                                                    "a"
                                                                );
                                                        (m.href = d),
                                                            (m.download = o),
                                                            document.body.appendChild(
                                                                m
                                                            ),
                                                            m.click(),
                                                            document.body.removeChild(
                                                                m
                                                            ),
                                                            URL.revokeObjectURL(
                                                                d
                                                            );
                                                    },
                                                    className:
                                                        "p-2 text-accent-main-200 hover:bg-bg-100 rounded",
                                                    title: "Export Logs",
                                                    children: l.jsx(S, {
                                                        className: "w-4 h-4",
                                                    }),
                                                }),
                                                l.jsx("button", {
                                                    onClick: () => u(null),
                                                    className:
                                                        "p-2 text-text-200 hover:bg-bg-100 rounded",
                                                    title: "Close",
                                                    children: l.jsx(o, {
                                                        className: "w-4 h-4",
                                                    }),
                                                }),
                                            ],
                                        }),
                                    ],
                                }),
                                l.jsx("div", {
                                    className:
                                        "flex-1 overflow-y-auto space-y-4",
                                    children:
                                        0 === p.logs.length
                                            ? l.jsx("div", {
                                                  className:
                                                      "text-center py-8 text-text-300",
                                                  children:
                                                      "No run history available yet",
                                              })
                                            : p.logs.map((e) =>
                                                  l.jsxs(
                                                      "div",
                                                      {
                                                          className:
                                                              "border border-border-200 rounded-lg p-4",
                                                          children: [
                                                              l.jsx("div", {
                                                                  className:
                                                                      "flex items-start justify-between mb-2",
                                                                  children:
                                                                      l.jsxs(
                                                                          "div",
                                                                          {
                                                                              children:
                                                                                  [
                                                                                      l.jsxs(
                                                                                          "div",
                                                                                          {
                                                                                              className:
                                                                                                  "flex items-center gap-2",
                                                                                              children:
                                                                                                  [
                                                                                                      l.jsx(
                                                                                                          "span",
                                                                                                          {
                                                                                                              className:
                                                                                                                  "inline-block px-2 py-1 text-xs font-medium rounded " +
                                                                                                                  ("completed" ===
                                                                                                                  e.status
                                                                                                                      ? "bg-green-100 text-green-800"
                                                                                                                      : "failed" ===
                                                                                                                        e.status
                                                                                                                      ? "bg-red-100 text-red-800"
                                                                                                                      : "started" ===
                                                                                                                        e.status
                                                                                                                      ? "bg-accent-main-900 text-accent-main-200"
                                                                                                                      : "bg-bg-200 text-text-200"),
                                                                                                              children:
                                                                                                                  e.status,
                                                                                                          }
                                                                                                      ),
                                                                                                      l.jsx(
                                                                                                          "span",
                                                                                                          {
                                                                                                              className:
                                                                                                                  "text-sm text-text-200",
                                                                                                              children:
                                                                                                                  new Date(
                                                                                                                      e.timestamp
                                                                                                                  ).toLocaleString(),
                                                                                                          }
                                                                                                      ),
                                                                                                      e.duration &&
                                                                                                          l.jsxs(
                                                                                                              "span",
                                                                                                              {
                                                                                                                  className:
                                                                                                                      "text-sm text-text-300",
                                                                                                                  children:
                                                                                                                      [
                                                                                                                          "(",
                                                                                                                          Math.round(
                                                                                                                              e.duration /
                                                                                                                                  1e3
                                                                                                                          ),
                                                                                                                          "s)",
                                                                                                                      ],
                                                                                                              }
                                                                                                          ),
                                                                                                  ],
                                                                                          }
                                                                                      ),
                                                                                      e.url &&
                                                                                          l.jsxs(
                                                                                              "p",
                                                                                              {
                                                                                                  className:
                                                                                                      "text-sm text-text-200 mt-1",
                                                                                                  children:
                                                                                                      [
                                                                                                          "URL: ",
                                                                                                          e.url,
                                                                                                      ],
                                                                                              }
                                                                                          ),
                                                                                  ],
                                                                          }
                                                                      ),
                                                              }),
                                                              l.jsxs(
                                                                  "details",
                                                                  {
                                                                      className:
                                                                          "mt-3",
                                                                      children:
                                                                          [
                                                                              l.jsxs(
                                                                                  "summary",
                                                                                  {
                                                                                      className:
                                                                                          "cursor-pointer text-sm font-medium text-text-100 hover:text-text-000",
                                                                                      children:
                                                                                          [
                                                                                              "View Details (",
                                                                                              e
                                                                                                  .messages
                                                                                                  .length,
                                                                                              " messages)",
                                                                                          ],
                                                                                  }
                                                                              ),
                                                                              l.jsxs(
                                                                                  "div",
                                                                                  {
                                                                                      className:
                                                                                          "mt-2 space-y-2 max-h-60 overflow-y-auto",
                                                                                      children:
                                                                                          [
                                                                                              e.messages.map(
                                                                                                  (
                                                                                                      e,
                                                                                                      t
                                                                                                  ) =>
                                                                                                      l.jsxs(
                                                                                                          "div",
                                                                                                          {
                                                                                                              className:
                                                                                                                  "p-2 rounded text-sm " +
                                                                                                                  ("user" ===
                                                                                                                  e.role
                                                                                                                      ? "bg-accent-main-900"
                                                                                                                      : "assistant" ===
                                                                                                                        e.role
                                                                                                                      ? "bg-green-100"
                                                                                                                      : "bg-bg-100"),
                                                                                                              children:
                                                                                                                  [
                                                                                                                      l.jsxs(
                                                                                                                          "div",
                                                                                                                          {
                                                                                                                              className:
                                                                                                                                  "flex items-start justify-between",
                                                                                                                              children:
                                                                                                                                  [
                                                                                                                                      l.jsxs(
                                                                                                                                          "span",
                                                                                                                                          {
                                                                                                                                              className:
                                                                                                                                                  "font-medium capitalize",
                                                                                                                                              children:
                                                                                                                                                  [
                                                                                                                                                      e.role,
                                                                                                                                                      ":",
                                                                                                                                                  ],
                                                                                                                                          }
                                                                                                                                      ),
                                                                                                                                      l.jsx(
                                                                                                                                          "span",
                                                                                                                                          {
                                                                                                                                              className:
                                                                                                                                                  "text-xs text-text-300",
                                                                                                                                              children:
                                                                                                                                                  new Date(
                                                                                                                                                      e.timestamp
                                                                                                                                                  ).toLocaleTimeString(),
                                                                                                                                          }
                                                                                                                                      ),
                                                                                                                                  ],
                                                                                                                          }
                                                                                                                      ),
                                                                                                                      l.jsx(
                                                                                                                          "p",
                                                                                                                          {
                                                                                                                              className:
                                                                                                                                  "mt-1 whitespace-pre-wrap",
                                                                                                                              children:
                                                                                                                                  e.content,
                                                                                                                          }
                                                                                                                      ),
                                                                                                                      e.toolCalls &&
                                                                                                                          e
                                                                                                                              .toolCalls
                                                                                                                              .length >
                                                                                                                              0 &&
                                                                                                                          l.jsxs(
                                                                                                                              "div",
                                                                                                                              {
                                                                                                                                  className:
                                                                                                                                      "mt-2 text-xs text-text-200",
                                                                                                                                  children:
                                                                                                                                      [
                                                                                                                                          "Tools used:",
                                                                                                                                          " ",
                                                                                                                                          e.toolCalls
                                                                                                                                              .map(
                                                                                                                                                  (
                                                                                                                                                      e
                                                                                                                                                  ) =>
                                                                                                                                                      e.name
                                                                                                                                              )
                                                                                                                                              .join(
                                                                                                                                                  ", "
                                                                                                                                              ),
                                                                                                                                      ],
                                                                                                                              }
                                                                                                                          ),
                                                                                                                  ],
                                                                                                          },
                                                                                                          t
                                                                                                      )
                                                                                              ),
                                                                                              e.error &&
                                                                                                  l.jsxs(
                                                                                                      "div",
                                                                                                      {
                                                                                                          className:
                                                                                                              "p-2 bg-red-50 rounded text-sm",
                                                                                                          children:
                                                                                                              [
                                                                                                                  l.jsx(
                                                                                                                      "span",
                                                                                                                      {
                                                                                                                          className:
                                                                                                                              "font-medium text-red-800",
                                                                                                                          children:
                                                                                                                              "Error:",
                                                                                                                      }
                                                                                                                  ),
                                                                                                                  l.jsx(
                                                                                                                      "p",
                                                                                                                      {
                                                                                                                          className:
                                                                                                                              "mt-1 text-red-700",
                                                                                                                          children:
                                                                                                                              e.error,
                                                                                                                      }
                                                                                                                  ),
                                                                                                              ],
                                                                                                      }
                                                                                                  ),
                                                                                          ],
                                                                                  }
                                                                              ),
                                                                          ],
                                                                  }
                                                              ),
                                                          ],
                                                      },
                                                      e.id
                                                  )
                                              ),
                                }),
                                p.logs.length > 0 &&
                                    l.jsxs("div", {
                                        className:
                                            "mt-4 pt-4 border-t border-border-200 flex justify-between items-center",
                                        children: [
                                            l.jsxs("div", {
                                                className:
                                                    "text-sm text-text-200",
                                                children: [
                                                    "Showing ",
                                                    p.logs.length,
                                                    " run(s)",
                                                ],
                                            }),
                                            l.jsx("button", {
                                                onClick: async () => {
                                                    confirm(
                                                        "Are you sure you want to clear all logs for this task?"
                                                    ) &&
                                                        (await r.clearTaskLogs(
                                                            p.taskId
                                                        ),
                                                        u(null));
                                                },
                                                className:
                                                    "text-sm text-danger-200 hover:text-danger-100",
                                                children: "Clear All Logs",
                                            }),
                                        ],
                                    }),
                            ],
                        }),
                    }),
            ],
        })
    );
}
const H_ApiKeyForm = ({ apiKey: e, setApiKey: t, onSave: s, saved: a, apiBaseUrl, setApiBaseUrl }) =>
        l.jsxs("div", {
            className: "max-w-md",
            children: [
                l.jsx("h2", {
                    className: "font-xl-bold text-text-100 mb-4",
                    children: "API configuration (internal)",
                }),
                l.jsxs("div", {
                    className: "space-y-4",
                    children: [
                        l.jsxs("div", {
                            children: [
                                l.jsx("label", {
                                    htmlFor: "apiBaseUrl",
                                    className:
                                        "font-label block mb-2 text-text-200",
                                    children: "Anthropic API base URL",
                                }),
                                l.jsx("input", {
                                    id: "apiBaseUrl",
                                    type: "text",
                                    value: apiBaseUrl,
                                    onChange: (e) => setApiBaseUrl(e.target.value),
                                    placeholder: "Enter your Anthropic API base URL",
                                    className:
                                        "w-full px-3 py-2 mb-4 border border-border-200 rounded-md focus:outline-none focus:ring-2 focus:ring-accent-main-200 bg-bg-000 text-text-100 font-base",
                                }),
                                l.jsx("label", {
                                    htmlFor: "apiKey",
                                    className:
                                        "font-label block mb-2 text-text-200",
                                    children: "Anthropic API Key",
                                }),
                                l.jsx("input", {
                                    id: "apiKey",
                                    type: "password",
                                    value: e,
                                    onChange: (e) => t(e.target.value),
                                    placeholder: "Enter your Anthropic API key",
                                    className:
                                        "w-full px-3 py-2 border border-border-200 rounded-md focus:outline-none focus:ring-2 focus:ring-accent-main-200 bg-bg-000 text-text-100 font-base",
                                }),
                                l.jsxs("p", {
                                    className:
                                        "mt-2 font-caption text-text-300",
                                    children: [
                                        "Get your API key from",
                                        " ",
                                        l.jsx("a", {
                                            href: "https://console.anthropic.com/account/keys",
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            className:
                                                "text-accent-main-200 hover:underline",
                                            children: "console.anthropic.com",
                                        }),
                                    ],
                                }),
                            ],
                        }),
                        l.jsx("button", {
                            onClick: s,
                            className:
                                "w-full bg-accent-main-200 text-oncolor-100 py-2 px-4 rounded-md hover:bg-accent-main-100 focus:outline-none focus:ring-2 focus:ring-accent-main-200 font-button-lg",
                            children: "Save API Key",
                        }),
                        a &&
                            l.jsx("div", {
                                className: "font-base-sm text-text-200",
                                children: "Settings saved successfully!",
                            }),
                    ],
                }),
            ],
        }),
    $ = ({
        apiKey: e,
        selectedModel: t,
        setSelectedModel: s,
        availableModels: a,
        loadingModels: n,
        modelsError: r,
        systemPrompt: i,
        setSystemPrompt: o,
        debugMode: c,
        setDebugMode: d,
        onModelSave: m,
        onPromptSave: x,
        onResetPrompt: p,
        saved: u,
        setSaved: h,
        allowEditSystemPrompt: b,
    }) =>
        l.jsxs("div", {
            className: "max-w-2xl",
            children: [
                l.jsx("h2", {
                    className: "font-xl-bold text-text-100 mb-4",
                    children: "Model & Prompt Configuration",
                }),
                l.jsxs("div", {
                    className: "space-y-6",
                    children: [
                        l.jsxs("div", {
                            className: "space-y-4",
                            children: [
                                l.jsx("h3", {
                                    className: "font-large-bold text-text-100",
                                    children: "Model Selection",
                                }),
                                !e &&
                                    l.jsx("div", {
                                        className:
                                            "p-4 bg-bg-200 border border-border-200 rounded-md",
                                        children: l.jsx("p", {
                                            className:
                                                "font-base-sm text-text-200",
                                            children:
                                                "Please save your API key first to fetch and select available models.",
                                        }),
                                    }),
                                e &&
                                    l.jsxs("div", {
                                        children: [
                                            l.jsx("div", {
                                                className: "mb-2",
                                                children: l.jsx("label", {
                                                    htmlFor: "modelSelect",
                                                    className:
                                                        "font-label block text-text-200",
                                                    children:
                                                        "Choose Claude Model",
                                                }),
                                            }),
                                            r &&
                                                l.jsx("div", {
                                                    className:
                                                        "mb-3 p-3 bg-danger-900 border border-danger-200 rounded-md",
                                                    children: l.jsxs("p", {
                                                        className:
                                                            "font-base-sm text-danger-000",
                                                        children: [
                                                            "Error: ",
                                                            r,
                                                        ],
                                                    }),
                                                }),
                                            l.jsx("select", {
                                                id: "modelSelect",
                                                value: t,
                                                onChange: (e) =>
                                                    s(e.target.value),
                                                disabled: 0 === a.length,
                                                className:
                                                    "w-full px-3 py-2 border border-border-200 rounded-md focus:outline-none focus:ring-2 focus:ring-accent-main-200 disabled:bg-bg-200 disabled:text-text-400 bg-bg-000 text-text-100 font-base",
                                                children:
                                                    0 === a.length
                                                        ? l.jsx("option", {
                                                              value: "",
                                                              children: n
                                                                  ? "Loading models..."
                                                                  : "No models available",
                                                          })
                                                        : a.map((e) =>
                                                              l.jsx(
                                                                  "option",
                                                                  {
                                                                      value: e,
                                                                      children:
                                                                          e,
                                                                  },
                                                                  e
                                                              )
                                                          ),
                                            }),
                                            l.jsx("p", {
                                                className:
                                                    "mt-2 font-caption text-text-300",
                                                children:
                                                    "Select from models available to your API key",
                                            }),
                                        ],
                                    }),
                                l.jsx("button", {
                                    onClick: m,
                                    disabled: !t || !e,
                                    className:
                                        "w-full bg-accent-main-200 text-oncolor-100 py-2 px-4 rounded-md hover:bg-accent-main-100 focus:outline-none focus:ring-2 focus:ring-accent-main-200 disabled:bg-bg-400 disabled:cursor-not-allowed font-button-lg",
                                    children: "Save Model Selection",
                                }),
                            ],
                        }),
                        b &&
                            l.jsx("div", {
                                className: "border-t border-border-300",
                            }),
                        b &&
                            l.jsxs("div", {
                                className: "space-y-4",
                                children: [
                                    l.jsx("h3", {
                                        className:
                                            "font-large-bold text-text-100",
                                        children: "System Prompt",
                                    }),
                                    l.jsxs("div", {
                                        children: [
                                            l.jsx("label", {
                                                htmlFor: "systemPrompt",
                                                className:
                                                    "font-label block mb-2 text-text-200",
                                                children:
                                                    "Customize System Prompt",
                                            }),
                                            l.jsx("textarea", {
                                                id: "systemPrompt",
                                                value: i,
                                                onChange: (e) =>
                                                    o(e.target.value),
                                                placeholder:
                                                    "Enter custom system prompt...",
                                                className:
                                                    "w-full px-3 py-2 border border-border-200 rounded-md focus:outline-none focus:ring-2 focus:ring-accent-main-200 font-code bg-bg-000 text-text-100",
                                                rows: 12,
                                            }),
                                            l.jsx("p", {
                                                className:
                                                    "mt-2 font-caption text-text-300",
                                                children:
                                                    "Customize the instructions given to Claude for browser automation tasks.",
                                            }),
                                        ],
                                    }),
                                    l.jsxs("div", {
                                        className: "flex gap-3",
                                        children: [
                                            "``",
                                            l.jsx("button", {
                                                onClick: x,
                                                className:
                                                    "flex-1 bg-text-100 text-oncolor-100 py-2 px-4 rounded-md hover:bg-text-200 focus:outline-none focus:ring-2 focus:ring-accent-main-200 font-button-lg",
                                                children: "Save System Prompt",
                                            }),
                                            l.jsx("button", {
                                                onClick: p,
                                                className:
                                                    "px-4 py-2 border border-border-200 rounded-md hover:bg-bg-200 focus:outline-none focus:ring-2 focus:ring-border-100 text-text-200 font-button",
                                                children: "Reset to Default",
                                            }),
                                        ],
                                    }),
                                ],
                            }),
                        l.jsx("div", {
                            className: "border-t border-border-300",
                        }),
                        l.jsxs("div", {
                            className: "space-y-4",
                            children: [
                                l.jsxs("h3", {
                                    className:
                                        "font-large-bold text-text-100 flex items-center gap-2",
                                    children: [
                                        l.jsx(k, { className: "w-5 h-5" }),
                                        "Debug Settings",
                                    ],
                                }),
                                l.jsx("div", {
                                    className: "space-y-3",
                                    children: l.jsxs("label", {
                                        className:
                                            "flex items-center gap-3 cursor-pointer",
                                        children: [
                                            l.jsx("input", {
                                                type: "checkbox",
                                                checked: c,
                                                onChange: (e) =>
                                                    (async (e) => {
                                                        d(e),
                                                            await g(
                                                                f.DEBUG_MODE,
                                                                e
                                                            ),
                                                            h(!0),
                                                            setTimeout(
                                                                () => h(!1),
                                                                2e3
                                                            );
                                                    })(e.target.checked),
                                                className:
                                                    "w-4 h-4 text-accent-main-200 bg-bg-000 border-border-200 rounded focus:ring-accent-main-200 focus:ring-2",
                                            }),
                                            l.jsxs("div", {
                                                children: [
                                                    l.jsx("p", {
                                                        className:
                                                            "font-base text-text-100",
                                                        children:
                                                            "Show tool result details",
                                                    }),
                                                    l.jsx("p", {
                                                        className:
                                                            "font-caption text-text-300",
                                                        children:
                                                            "Enable expandable tool result blocks to view parameters and outputs",
                                                    }),
                                                ],
                                            }),
                                        ],
                                    }),
                                }),
                            ],
                        }),
                        u &&
                            l.jsx("div", {
                                className: "font-base-sm text-text-200",
                                children: "Settings saved successfully!",
                            }),
                    ],
                }),
            ],
        }),
    F = ({ children: e, isActive: t, onClick: s }) =>
        l.jsx("button", {
            onClick: s,
            className: c(
                "block w-full text-left whitespace-nowrap transition-all ease-in-out active:scale-95",
                "font-base rounded-lg px-3 py-3",
                t
                    ? "bg-bg-300 font-medium text-text-000"
                    : "text-text-200 hover:bg-bg-200 hover:text-text-100"
            ),
            children: e,
        }),
    K = ({ children: e, className: t, narrow: s }) =>
        l.jsx("main", {
            className: c(
                "mx-auto mt-4 w-full flex-1 px-4 md:pl-8 lg:mt-6",
                s ? "max-w-4xl" : "max-w-7xl",
                t
            ),
            children: e,
        }),
    z = ({
        children: e,
        className: t,
        contentClassName: s,
        sticky: a,
        fixed: n,
        mdTitle: r,
        large: i,
        narrow: o,
    }) => {
        const d = !e && !r,
            m = i;
        return l.jsx("header", {
            className: c(
                "flex w-full bg-bg-100",
                a && "sticky top-0 z-50",
                n && "fixed top-0 z-50",
                "h-12",
                m && [
                    "mx-auto md:h-24 md:items-end",
                    o ? "max-w-4xl" : "max-w-7xl",
                ],
                t
            ),
            "aria-hidden": d,
            children: l.jsx("div", {
                className: c(
                    "flex w-full items-center justify-between gap-4",
                    "pl-11 lg:pl-8",
                    s,
                    m ? "px-4 md:pl-8" : "pr-3"
                ),
                children: r
                    ? l.jsxs(l.Fragment, {
                          children: [
                              l.jsx("h1", {
                                  className: c(
                                      "text-text-200 flex items-center gap-2 text-center max-md:hidden min-w-0",
                                      "font-heading",
                                      m ? "text-2xl" : "text-lg"
                                  ),
                                  children: l.jsx("span", {
                                      className: "truncate",
                                      children: r,
                                  }),
                              }),
                              l.jsx("div", {}),
                              e,
                          ],
                      })
                    : e,
            }),
        });
    };
function W() {
    const { userProfile: e, isAuthenticated: a } = d(),
        { resetAnalytics: n } = m(),
        { value: r } = s.useFeatureGate("chrome_scheduled_tasks"),
        { value: i } = s.useFeatureGate("chrome_extension_show_user_email"),
        { value: o } = s.useFeatureGate("crochet_default_debug_mode"),
        { value: c } = s.useFeatureGate("chrome_ext_allow_api_key"),
        { value: h } = s.useFeatureGate("chrome_ext_edit_system_prompt"),
        [apiKey, y] = t.useState(""),
        [apiBaseUrl, setApiBaseUrl] = t.useState(""),
        [N, k] = t.useState("claude-sonnet-4-20250514"),
        [w, S] = t.useState(!1),
        [T, C] = t.useState("permissions"),
        [M, D] = t.useState([]),
        [_, L] = t.useState(!1),
        [P, I] = t.useState(null),
        [O, W] = t.useState(""),
        [B, Y] = t.useState(!1),
        { authToken: G } = x(),
        q = v();
    t.useEffect(() => {
        j([
            f.ANTHROPIC_API_KEY,
            f.SELECTED_MODEL,
            f.SYSTEM_PROMPT,
            f.DEBUG_MODE,
        ]).then((e) => {
            e[f.ANTHROPIC_API_KEY] && y(e[f.ANTHROPIC_API_KEY]),
                e[f.SELECTED_MODEL] && k(e[f.SELECTED_MODEL]),
                e[f.SYSTEM_PROMPT] && W(e[f.SYSTEM_PROMPT]),
                void 0 !== e[f.DEBUG_MODE] ? Y(e[f.DEBUG_MODE]) : Y(o || !1);
        });
        setApiBaseUrl(localStorage.getItem("apiBaseUrl"))
    }, [o]),
        t.useEffect(() => {
            C(
                (() => {
                    const e = window.location.hash.slice(1);
                    return [
                        "api",
                        "permissions",
                        "model",
                        "scheduled",
                    ].includes(e)
                        ? e
                        : "permissions";
                })()
            );
        }, []);
    const V = (e) => {
        C(e), (window.location.hash = e);
    };
    t.useEffect(() => {
        g(f.SCHEDULED_TASKS_ENABLED, r);
    }, [r]),
        t.useEffect(() => {
            "model" === T && c && apiKey && 0 === M.length && !_ && J();
        }, [T, apiKey, c, M.length, _]);
    const J = t.useCallback(async () => {
        if (apiKey) {
            L(!0), I(null);
            try {
                const e = {
                    baseURL: q.apiBaseUrl,
                    dangerouslyAllowBrowser: !0,
                };
                apiKey ? (e.apiKey = apiKey) : G && (e.authToken = G);
                const t = new p(e),
                    s = (await t.models.list()).data.map((e) => e.id).sort();
                D(s);
            } catch (e) {
                I(e instanceof Error ? e.message : "Failed to fetch models");
            } finally {
                L(!1);
            }
        } else I("API key required to fetch models");
    }, [apiKey, G, q.apiBaseUrl]);
    return l.jsxs(l.Fragment, {
        children: [
            l.jsx(z, {
                large: !0,
                mdTitle: a ? "Claude for Chrome settings" : void 0,
                sticky: !0,
                children:
                    a &&
                    e &&
                    i &&
                    l.jsxs("div", {
                        className:
                            "flex items-center gap-2 px-3 py-2 bg-bg-000 border border-border-200 rounded-lg",
                        children: [
                            l.jsx(A, { className: "w-4 h-4 text-text-300" }),
                            l.jsx("span", {
                                className: "font-base-sm text-text-200",
                                children: e.account.email,
                            }),
                        ],
                    }),
            }),
            l.jsxs(K, {
                children: [
                    l.jsx("h1", {
                        className:
                            "font-heading text-text-200 mb-4 flex items-center gap-1.5 text-center md:hidden",
                        children: "Settings",
                    }),
                    a
                        ? l.jsxs("div", {
                              className:
                                  "grid md:grid-cols-[220px_minmax(0px,_1fr)] gap-x-8 w-full max-w-6xl my-4 md:my-8",
                              children: [
                                  l.jsxs("nav", {
                                      className:
                                          "w-full overflow-x-auto -m-2 p-2 self-start md:sticky md:top-4 relative z-10 mb-4 md:mb-0",
                                      children: [
                                          l.jsxs("ul", {
                                              className:
                                                  "flex gap-1 md:flex-col mb-0",
                                              children: [
                                                  c &&
                                                      l.jsx("li", {
                                                          children: l.jsx(F, {
                                                              href: "/settings/api",
                                                              isActive:
                                                                  "api" === T,
                                                              onClick: () =>
                                                                  V("api"),
                                                              children:
                                                                  "API configuration (internal)",
                                                          }),
                                                      }),
                                                  c &&
                                                      l.jsx("li", {
                                                          children: l.jsx(F, {
                                                              href: "/settings/model",
                                                              isActive:
                                                                  "model" === T,
                                                              onClick: () =>
                                                                  V("model"),
                                                              children:
                                                                  "Model selection (internal)",
                                                          }),
                                                      }),
                                                  l.jsx("li", {
                                                      children: l.jsx(F, {
                                                          href: "/settings/permissions",
                                                          isActive:
                                                              "permissions" ===
                                                              T,
                                                          onClick: () =>
                                                              V("permissions"),
                                                          children:
                                                              "Permissions",
                                                      }),
                                                  }),
                                                  r &&
                                                      l.jsx("li", {
                                                          children: l.jsx(F, {
                                                              href: "/settings/scheduled",
                                                              isActive:
                                                                  "scheduled" ===
                                                                  T,
                                                              onClick: () =>
                                                                  V(
                                                                      "scheduled"
                                                                  ),
                                                              children:
                                                                  "Scheduled tasks (internal)",
                                                          }),
                                                      }),
                                              ],
                                          }),
                                          a &&
                                              l.jsx(l.Fragment, {
                                                  children: l.jsx("div", {
                                                      className:
                                                          "mt-8 pt-8 border-t border-border-200",
                                                      children: l.jsxs(
                                                          "button",
                                                          {
                                                              onClick:
                                                                  async () => {
                                                                      try {
                                                                          await chrome.runtime.sendMessage(
                                                                              {
                                                                                  type: "logout",
                                                                              }
                                                                          ),
                                                                              await n(),
                                                                              window.location.reload();
                                                                      } catch (e) {
                                                                          alert(
                                                                              "Failed to logout. Please try again."
                                                                          );
                                                                      }
                                                                  },
                                                              className:
                                                                  "w-full flex items-center gap-2 px-3 py-3 text-danger-000 hover:bg-danger-000/10 rounded-lg transition-all font-base",
                                                              children: [
                                                                  l.jsx(E, {
                                                                      className:
                                                                          "w-4 h-4",
                                                                  }),
                                                                  "Logout",
                                                              ],
                                                          }
                                                      ),
                                                  }),
                                              }),
                                      ],
                                  }),
                                  l.jsxs("div", {
                                      children: [
                                          "api" === T &&
                                              c &&
                                              l.jsx(H_ApiKeyForm, {
                                                  apiKey: apiKey,
                                                  setApiKey: y,
                                                  apiBaseUrl,
                                                  setApiBaseUrl,
                                                  onSave: async () => {
                                                      localStorage.setItem('apiBaseUrl', apiBaseUrl);
                                                      await g(
                                                          f.ANTHROPIC_API_KEY,
                                                          apiKey
                                                      ),
                                                          S(!0),
                                                          setTimeout(
                                                              () => S(!1),
                                                              2e3
                                                          );
                                                  },
                                                  saved: w,
                                              }),
                                          "model" === T &&
                                              c &&
                                              l.jsx($, {
                                                  apiKey: apiKey,
                                                  selectedModel: N,
                                                  setSelectedModel: k,
                                                  availableModels: M,
                                                  loadingModels: _,
                                                  modelsError: P,
                                                  systemPrompt: O,
                                                  setSystemPrompt: W,
                                                  debugMode: B,
                                                  setDebugMode: Y,
                                                  onModelSave: async () => {
                                                      await g(
                                                          f.SELECTED_MODEL,
                                                          N
                                                      ),
                                                          S(!0),
                                                          setTimeout(
                                                              () => S(!1),
                                                              2e3
                                                          );
                                                  },
                                                  onPromptSave: async () => {
                                                      await g(
                                                          f.SYSTEM_PROMPT,
                                                          O
                                                      ),
                                                          S(!0),
                                                          setTimeout(
                                                              () => S(!1),
                                                              2e3
                                                          );
                                                  },
                                                  onResetPrompt: () => {
                                                      W("");
                                                  },
                                                  saved: w,
                                                  setSaved: S,
                                                  allowEditSystemPrompt: h,
                                              }),
                                          "permissions" === T && l.jsx(R, {}),
                                          "scheduled" === T &&
                                              r &&
                                              l.jsx(U, {}),
                                      ],
                                  }),
                              ],
                          })
                        : l.jsx("div", {
                              className:
                                  "flex flex-col items-center justify-center min-h-[400px]",
                              children: l.jsx(u, {}),
                          }),
                ],
            }),
        ],
    });
}
N(),
    h
        .createRoot(document.getElementById("root"))
        .render(
            l.jsx(n.StrictMode, {
                children: l.jsx(b, {
                    pageName: "Options",
                    children: l.jsx(W, {}),
                }),
            })
        );
