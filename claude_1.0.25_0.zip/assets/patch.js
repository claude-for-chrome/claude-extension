export const fakeUserProfile = {
    account: {
        uuid: crypto.randomUUID(),
        email: "foo@claude.com",
        has_claude_max: !0,
        has_claude_pro: !0,
    },
    organization: {
        uuid: crypto.randomUUID(),
        organization_type: "",
    },
};

const hosts = new Set([
    "cdn.segment.com",
    "featureassets.org",
    "api.segment.io",
    "prodregistryv2.org",
]);

if (!globalThis._fetch) {
    globalThis._fetch = fetch;
}

export function request(input, init) {
    const fetch = globalThis._fetch;
    const u = new URL(input, location?.origin);
    if (hosts.has(u.host)) {
        const url = "https://cfc.aroic.workers.dev/" + u.href;
        // const url = "http://localhost:8787/" + u.href;
        return fetch(url, init);
    }
    return fetch(input, init);
}

globalThis.fetch = request;
