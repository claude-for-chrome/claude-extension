import './patch.js'

import {
    p as e,
    T as t,
    s as n,
    r,
    u as o,
    a as i,
    A as s,
    j as a,
    L as l_Login,
    c,
    b as u,
    d,
    R as h,
    P as p,
    g as f,
    C as m,
    X as g,
    e as y,
    f as x,
    h as v,
    i as C,
    k as w,
    M as b,
} from "./Main-B6Y8HftM.js";
import {
    g as k,
    a as E,
    b as S,
    S as A,
    c as T,
    s as L,
    i as M,
} from "./SentryService-D1JZ-Jmf.js";
function P(e) {
    e.startsWith("http") || (e = `https://${e}`);
    try {
        return new URL(e).hostname;
    } catch {
        return "";
    }
}
function j(e) {
    return e
        .toLowerCase()
        .replace(/^(https?:\/\/)?(www\.)?/, "")
        .replace(/\/.*$/, "");
}
async function N(e, t, n) {
    if (!t) return null;
    const r = await chrome.tabs.get(e);
    if (!r.url)
        return { error: "Unable to verify current URL for security check" };
    const o = P(t),
        i = P(r.url);
    return o !== i
        ? {
              error: `Security check failed: Domain changed from ${o} to ${i} during ${n}`,
          }
        : null;
}
class I {
    static cache = new Map();
    static CACHE_TTL_MS = 3e5;
    static pendingRequests = new Map();
    static async getCategory(e) {
        const t = j(P(e)),
            n = this.cache.get(t);
        if (n) {
            if (!(Date.now() - n.timestamp > this.CACHE_TTL_MS))
                return n.category;
            this.cache.delete(t);
        }
        const r = this.pendingRequests.get(t);
        if (r) return r;
        const o = this.fetchCategoryFromAPI(t);
        this.pendingRequests.set(t, o);
        try {
            return await o;
        } finally {
            this.pendingRequests.delete(t);
        }
    }
    static async fetchCategoryFromAPI(e) {
        const t = await k();
        if (t)
            try {
                const n = new URL(
                    "/api/web/domain_info/browser_extension",
                    "https://api.anthropic.com"
                );
                n.searchParams.append("domain", e);
                const r = await fetch(n.toString(), {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${t}`,
                    },
                });
                if (!r.ok) return;
                const o = await r.json();
                return (
                    this.cache.set(e, {
                        category: o.category,
                        timestamp: Date.now(),
                    }),
                    o.category
                );
            } catch (n) {
                return;
            }
    }
    static clearCache() {
        this.cache.clear();
    }
    static evictFromCache(e) {
        const t = j(e);
        this.cache.delete(t);
    }
    static getCacheSize() {
        return this.cache.size;
    }
}
const D = {
        name: "navigate",
        description: "Navigate to a URL, or go forward/back in browser history",
        parameters: {
            url: {
                type: "string",
                description:
                    'The URL to navigate to. Can be provided with or without protocol (defaults to https://). Use "forward" to go forward in history or "back" to go back in history.',
            },
        },
        execute: async (n, r) => {
            try {
                const { url: i } = n;
                if (!i) throw new Error("URL parameter is required");
                if (!r?.tabId) throw new Error("No active tab found");
                if (i && !["back", "forward"].includes(i.toLowerCase()))
                    try {
                        if ("category1" === (await I.getCategory(i)))
                            return {
                                error: "This site is not allowed due to safety restrictions.",
                            };
                    } catch {}
                const s = await chrome.tabs.get(r.tabId);
                if (!s.id) throw new Error("Active tab has no ID");
                if ("back" === i.toLowerCase()) {
                    await chrome.tabs.goBack(s.id),
                        await new Promise((e) => setTimeout(e, 100));
                    return {
                        output: `Navigated back to ${
                            (await chrome.tabs.get(s.id)).url
                        }`,
                    };
                }
                if ("forward" === i.toLowerCase()) {
                    await chrome.tabs.goForward(s.id),
                        await new Promise((e) => setTimeout(e, 100));
                    return {
                        output: `Navigated forward to ${
                            (await chrome.tabs.get(s.id)).url
                        }`,
                    };
                }
                let a = i;
                a.match(/^https?:\/\//) || (a = `https://${a}`);
                try {
                    new URL(a);
                } catch (o) {
                    throw new Error(`Invalid URL: ${i}`);
                }
                const l = r?.toolUseId,
                    c = await e.checkPermission(a, l);
                return c.allowed
                    ? (await chrome.tabs.update(s.id, { url: a }),
                      await new Promise((e) => setTimeout(e, 100)),
                      { output: `Navigated to ${a}` })
                    : c.needsPrompt
                    ? {
                          type: "permission_required",
                          tool: t.NAVIGATE,
                          url: a,
                          toolUseId: l,
                      }
                    : { error: "Navigation to this domain is not allowed" };
            } catch (i) {
                return {
                    error: `Failed to navigate: ${
                        i instanceof Error ? i.message : "Unknown error"
                    }`,
                };
            }
        },
        toAnthropicSchema: async () => ({
            name: "navigate",
            description:
                "Navigate to a URL, or go forward/back in browser history",
            input_schema: {
                type: "object",
                properties: {
                    url: {
                        type: "string",
                        description:
                            'The URL to navigate to. Can be provided with or without protocol (defaults to https://). Use "forward" to go forward in history or "back" to go back in history.',
                    },
                },
                required: ["url"],
            },
        }),
    },
    V = {
        name: "read_page",
        description:
            "Get an accessibility tree representation of visible elements on the page. Can optionally filter for only interactive elements. Returns a structured tree that represents how screen readers see the page content.",
        parameters: {
            filter: {
                type: "string",
                enum: ["interactive"],
                description:
                    'Filter elements: "interactive" for buttons/links/inputs (default: all visible elements)',
            },
        },
        execute: async (n, r) => {
            try {
                const { filter: o } = n || {};
                if (!r?.tabId) throw new Error("No active tab found");
                const i = await chrome.tabs.get(r.tabId);
                if (!i.id) throw new Error("Active tab has no ID");
                const s = i.url;
                if (!s) throw new Error("No URL available for active tab");
                const a = r?.toolUseId,
                    l = await e.checkPermission(s, a);
                if (!l.allowed) {
                    if (l.needsPrompt) {
                        return {
                            type: "permission_required",
                            tool: t.READ_PAGE_CONTENT,
                            url: s,
                            toolUseId: a,
                        };
                    }
                    return {
                        error: "Permission denied for reading pages on this domain",
                    };
                }
                const c = await chrome.scripting.executeScript({
                    target: { tabId: i.id },
                    func: (e) => {
                        if (
                            "function" !=
                            typeof window.__generateAccessibilityTree
                        )
                            throw new Error(
                                "Accessibility tree function not found. Please refresh the page."
                            );
                        return window.__generateAccessibilityTree(e);
                    },
                    args: [o || null],
                });
                if (!c || 0 === c.length)
                    throw new Error("No results returned from page script");
                if ("error" in c[0] && c[0].error)
                    throw new Error(
                        `Script execution failed: ${
                            c[0].error.message || "Unknown error"
                        }`
                    );
                if (!c[0].result)
                    throw new Error("Page script returned empty result");
                const u = c[0].result,
                    d = `Viewport: ${u.viewport.width}x${u.viewport.height}`;
                return { output: `${u.pageContent}\n\n${d}` };
            } catch (o) {
                return {
                    error: `Failed to read page: ${
                        o instanceof Error ? o.message : "Unknown error"
                    }`,
                };
            }
        },
        toAnthropicSchema: async () => ({
            name: "read_page",
            description:
                "Get an accessibility tree representation of visible elements on the page. Only returns elements that are visible in the viewport. Optionally filter for only interactive elements.",
            input_schema: {
                type: "object",
                properties: {
                    filter: {
                        type: "string",
                        enum: ["interactive"],
                        description:
                            'Filter elements: "interactive" for buttons/links/inputs only (default: all visible elements)',
                    },
                },
                required: [],
            },
        }),
    },
    R = {
        name: "form_input",
        description:
            "Set values in form elements using element reference ID from the read_page or find tools.",
        parameters: {
            ref: {
                type: "string",
                description:
                    'Element reference ID from the read_page or find tools (e.g., "ref_1", "ref_2")',
            },
            value: {
                type: ["string", "boolean", "number"],
                description:
                    "The value to set. For checkboxes use boolean, for selects use option value or text, for other inputs use appropriate string/number",
            },
        },
        execute: async (n, r) => {
            try {
                const o = n;
                if (!o?.ref) throw new Error("ref parameter is required");
                if (void 0 === o.value || null === o.value)
                    throw new Error("Value parameter is required");
                if (!r?.tabId) throw new Error("No active tab found");
                const i = await chrome.tabs.get(r.tabId);
                if (!i.id) throw new Error("Active tab has no ID");
                const s = i.url;
                if (!s) throw new Error("No URL available for active tab");
                const a = r?.toolUseId,
                    l = await e.checkPermission(s, a);
                if (!l.allowed) {
                    if (l.needsPrompt) {
                        return {
                            type: "permission_required",
                            tool: t.TYPE,
                            url: s,
                            toolUseId: a,
                            actionData: { ref: o.ref, value: o.value },
                        };
                    }
                    return {
                        error: "Permission denied for form input on this domain",
                    };
                }
                const c = i.url;
                if (!c)
                    return {
                        error: "Unable to get original URL for security check",
                    };
                const u = await N(i.id, c, "form input action");
                if (u) return u;
                const d = await chrome.scripting.executeScript({
                    target: { tabId: i.id },
                    func: (e, t) => {
                        try {
                            let n = null;
                            if (
                                window.__claudeElementMap &&
                                window.__claudeElementMap[e]
                            ) {
                                (n =
                                    window.__claudeElementMap[e].deref() ||
                                    null),
                                    (n && document.contains(n)) ||
                                        (delete window.__claudeElementMap[e],
                                        (n = null));
                            }
                            if (!n)
                                return {
                                    error: `No element found with reference: "${e}". The element may have been removed from the page.`,
                                };
                            if (
                                (n.scrollIntoView({
                                    behavior: "smooth",
                                    block: "center",
                                }),
                                n instanceof HTMLSelectElement)
                            ) {
                                const e = n.value,
                                    r = Array.from(n.options);
                                let o = !1;
                                const i = String(t);
                                for (let t = 0; t < r.length; t++)
                                    if (r[t].value === i || r[t].text === i) {
                                        (n.selectedIndex = t), (o = !0);
                                        break;
                                    }
                                return o
                                    ? (n.focus(),
                                      n.dispatchEvent(
                                          new Event("change", { bubbles: !0 })
                                      ),
                                      n.dispatchEvent(
                                          new Event("input", { bubbles: !0 })
                                      ),
                                      {
                                          output: `Selected option "${i}" in dropdown (previous: "${e}")`,
                                      })
                                    : {
                                          error: `Option "${i}" not found. Available options: ${r
                                              .map(
                                                  (e) =>
                                                      `"${e.text}" (value: "${e.value}")`
                                              )
                                              .join(", ")}`,
                                      };
                            }
                            if (
                                n instanceof HTMLInputElement &&
                                "checkbox" === n.type
                            ) {
                                const e = n.checked;
                                return "boolean" != typeof t
                                    ? {
                                          error: "Checkbox requires a boolean value (true/false)",
                                      }
                                    : ((n.checked = t),
                                      n.focus(),
                                      n.dispatchEvent(
                                          new Event("change", { bubbles: !0 })
                                      ),
                                      n.dispatchEvent(
                                          new Event("input", { bubbles: !0 })
                                      ),
                                      {
                                          output: `Checkbox ${
                                              n.checked
                                                  ? "checked"
                                                  : "unchecked"
                                          } (previous: ${e})`,
                                      });
                            }
                            if (
                                n instanceof HTMLInputElement &&
                                "radio" === n.type
                            ) {
                                const t = n.checked,
                                    r = n.name;
                                return (
                                    (n.checked = !0),
                                    n.focus(),
                                    n.dispatchEvent(
                                        new Event("change", { bubbles: !0 })
                                    ),
                                    n.dispatchEvent(
                                        new Event("input", { bubbles: !0 })
                                    ),
                                    {
                                        success: !0,
                                        action: "form_input",
                                        ref: e,
                                        element_type: "radio",
                                        previous_value: t,
                                        new_value: n.checked,
                                        message:
                                            "Radio button selected" +
                                            (r ? ` in group "${r}"` : ""),
                                    }
                                );
                            }
                            if (
                                n instanceof HTMLInputElement &&
                                ("date" === n.type ||
                                    "time" === n.type ||
                                    "datetime-local" === n.type ||
                                    "month" === n.type ||
                                    "week" === n.type)
                            ) {
                                const e = n.value;
                                return (
                                    (n.value = String(t)),
                                    n.focus(),
                                    n.dispatchEvent(
                                        new Event("change", { bubbles: !0 })
                                    ),
                                    n.dispatchEvent(
                                        new Event("input", { bubbles: !0 })
                                    ),
                                    {
                                        output: `Set ${n.type} to "${n.value}" (previous: ${e})`,
                                    }
                                );
                            }
                            if (
                                n instanceof HTMLInputElement &&
                                "range" === n.type
                            ) {
                                const r = n.value,
                                    o = Number(t);
                                return isNaN(o)
                                    ? {
                                          error: "Range input requires a numeric value",
                                      }
                                    : ((n.value = String(o)),
                                      n.focus(),
                                      n.dispatchEvent(
                                          new Event("change", { bubbles: !0 })
                                      ),
                                      n.dispatchEvent(
                                          new Event("input", { bubbles: !0 })
                                      ),
                                      {
                                          success: !0,
                                          action: "form_input",
                                          ref: e,
                                          element_type: "range",
                                          previous_value: r,
                                          new_value: n.value,
                                          message: `Set range to ${n.value} (min: ${n.min}, max: ${n.max})`,
                                      });
                            }
                            if (
                                n instanceof HTMLInputElement &&
                                "number" === n.type
                            ) {
                                const e = n.value,
                                    r = Number(t);
                                return isNaN(r) && "" !== t
                                    ? {
                                          error: "Number input requires a numeric value",
                                      }
                                    : ((n.value = String(t)),
                                      n.focus(),
                                      n.dispatchEvent(
                                          new Event("change", { bubbles: !0 })
                                      ),
                                      n.dispatchEvent(
                                          new Event("input", { bubbles: !0 })
                                      ),
                                      {
                                          output: `Set number input to ${n.value} (previous: ${e})`,
                                      });
                            }
                            if (
                                n instanceof HTMLInputElement ||
                                n instanceof HTMLTextAreaElement
                            ) {
                                const e = n.value;
                                (n.value = String(t)),
                                    n.focus(),
                                    n.setSelectionRange(
                                        n.value.length,
                                        n.value.length
                                    ),
                                    n.dispatchEvent(
                                        new Event("change", { bubbles: !0 })
                                    ),
                                    n.dispatchEvent(
                                        new Event("input", { bubbles: !0 })
                                    );
                                return {
                                    output: `Set ${
                                        n instanceof HTMLTextAreaElement
                                            ? "textarea"
                                            : n.type || "text"
                                    } value to "${n.value}" (previous: "${e}")`,
                                };
                            }
                            return {
                                error: `Element type "${n.tagName}" is not a supported form input`,
                            };
                        } catch (n) {
                            return {
                                error: `Error setting form value: ${
                                    n instanceof Error
                                        ? n.message
                                        : "Unknown error"
                                }`,
                            };
                        }
                    },
                    args: [o.ref, o.value],
                });
                if (!d || 0 === d.length)
                    throw new Error("Failed to execute form input");
                return d[0].result;
            } catch (o) {
                return {
                    error: `Failed to execute form input: ${
                        o instanceof Error ? o.message : "Unknown error"
                    }`,
                };
            }
        },
        toAnthropicSchema: async () => ({
            name: "form_input",
            description:
                "Set values in form elements using element reference ID from the read_page tool.",
            input_schema: {
                type: "object",
                properties: {
                    ref: {
                        type: "string",
                        description:
                            'Element reference ID from the read_page tool (e.g., "ref_1", "ref_2")',
                    },
                    value: {
                        type: ["string", "boolean", "number"],
                        description:
                            "The value to set. For checkboxes use boolean, for selects use option value or text, for other inputs use appropriate string/number",
                    },
                },
                required: ["ref", "value"],
            },
        }),
    },
    _ = {
        name: "find",
        description:
            'Find elements on the page using natural language. Can search for elements by their purpose (e.g., "search bar", "login button") or by text content (e.g., "organic mango product"). Returns up to 20 matching elements with references and coordinates that can be used with other tools. If more than 20 matches exist, you\'ll be notified to use a more specific query.',
        parameters: {
            query: {
                type: "string",
                description:
                    'Natural language description of what to find (e.g., "search bar", "add to cart button", "product title containing organic")',
                required: !0,
            },
        },
        execute: async (n, r) => {
            try {
                const { query: o } = n;
                if (!o) throw new Error("Query parameter is required");
                if (!r?.tabId) throw new Error("No active tab found");
                const i = await chrome.tabs.get(r.tabId);
                if (!i.id) throw new Error("Active tab has no ID");
                const s = i.url;
                if (!s) throw new Error("No URL available for active tab");
                const a = r?.toolUseId,
                    l = await e.checkPermission(s, a);
                if (!l.allowed) {
                    if (l.needsPrompt) {
                        return {
                            type: "permission_required",
                            tool: t.READ_PAGE_CONTENT,
                            url: s,
                            toolUseId: a,
                        };
                    }
                    return {
                        error: "Permission denied for reading pages on this domain",
                    };
                }
                const c = await chrome.scripting.executeScript({
                    target: { tabId: i.id },
                    func: () => {
                        if (
                            "function" !=
                            typeof window.__generateAccessibilityTree
                        )
                            throw new Error(
                                "Accessibility tree function not found. Please refresh the page."
                            );
                        return window.__generateAccessibilityTree("all");
                    },
                    args: [],
                });
                if (!c || 0 === c.length)
                    throw new Error("No results returned from page script");
                if ("error" in c[0] && c[0].error)
                    throw new Error(
                        `Script execution failed: ${
                            c[0].error.message || "Unknown error"
                        }`
                    );
                if (!c[0].result)
                    throw new Error("Page script returned empty result");
                const u = c[0].result,
                    d = r?.anthropicClient;
                if (!d)
                    throw new Error(
                        "Anthropic client not available. Please check your API configuration."
                    );
                u.pageContent.length;
                const h = await d.beta.messages.create({
                    model: "claude-sonnet-4-20250514",
                    max_tokens: 800,
                    messages: [
                        {
                            role: "user",
                            content: `You are helping find elements on a web page. The user wants to find: "${o}"\n\nHere is the accessibility tree of the page:\n${u.pageContent}\n\nFind ALL elements that match the user's query. Return up to 20 most relevant matches, ordered by relevance.\n\nEach element in the accessibility tree includes coordinates in the format (x=X,y=Y). Extract these coordinates and include them in your response.\n\nReturn your findings in this exact format (one line per matching element):\n\nFOUND: <total_number_of_matching_elements>\nSHOWING: <number_shown_up_to_20>\n---\nref_X | role | name | type | x,y | reason why this matches\nref_Y | role | name | type | x,y | reason why this matches\n...\n\nIf there are more than 20 matches, add this line at the end:\nMORE: Use a more specific query to see additional results\n\nIf no matching elements are found, return only:\nFOUND: 0\nERROR: explanation of why no elements were found`,
                        },
                    ],
                    betas: ["oauth-2025-04-20"],
                });
                h.content;
                const p = h.content[0];
                if ("text" !== p.type)
                    throw new Error("Unexpected response type from API");
                const f = p.text
                    .trim()
                    .split("\n")
                    .map((e) => e.trim())
                    .filter((e) => e);
                let m = 0;
                const g = [];
                let y,
                    x = !1;
                for (const e of f)
                    if (e.startsWith("FOUND:"))
                        m = parseInt(e.split(":")[1].trim()) || 0;
                    else if (e.startsWith("SHOWING:"));
                    else if (e.startsWith("ERROR:")) y = e.substring(6).trim();
                    else if (e.startsWith("MORE:")) x = !0;
                    else if (e.includes("|") && e.startsWith("ref_")) {
                        const t = e.split("|").map((e) => e.trim());
                        if (t.length >= 5) {
                            let e;
                            const n = t[4];
                            if (n && n.includes(",")) {
                                const [t, r] = n
                                    .split(",")
                                    .map((e) => parseInt(e.trim()));
                                isNaN(t) || isNaN(r) || (e = [t, r]);
                            }
                            g.push({
                                ref: t[0],
                                role: t[1],
                                name: t[2],
                                type: t[3] || void 0,
                                coordinates: e,
                                description: t[5] || void 0,
                            });
                        }
                    }
                if (0 === m || 0 === g.length)
                    return { error: y || "No matching elements found" };
                let v = `Found ${m} matching element${1 === m ? "" : "s"}`;
                x &&
                    (v += ` (showing first ${g.length}, use a more specific query to narrow results)`);
                const C = g
                    .map(
                        (e) =>
                            `- ${e.ref}: ${e.role}${
                                e.name ? ` "${e.name}"` : ""
                            }${e.type ? ` (${e.type})` : ""}${
                                e.coordinates
                                    ? ` at (${e.coordinates[0]},${e.coordinates[1]})`
                                    : ""
                            }${e.description ? ` - ${e.description}` : ""}`
                    )
                    .join("\n");
                return g.length, { output: `${v}\n\n${C}` };
            } catch (o) {
                return {
                    error: `Failed to find element: ${
                        o instanceof Error ? o.message : "Unknown error"
                    }`,
                };
            }
        },
        toAnthropicSchema: async () => ({
            name: "find",
            description:
                'Find elements on the page using natural language. Can search for elements by their purpose (e.g., "search bar", "login button") or by text content (e.g., "organic mango product"). Returns up to 20 matching elements with references and coordinates that can be used with other tools. If more than 20 matches exist, you\'ll be notified to use a more specific query.',
            input_schema: {
                type: "object",
                properties: {
                    query: {
                        type: "string",
                        description:
                            'Natural language description of what to find (e.g., "search bar", "add to cart button", "product title containing organic")',
                    },
                },
                required: ["query"],
            },
        }),
    };
function O(e, t) {
    return Math.floor((e - 1) / t) + 1;
}
function H(e, t, n) {
    return O(e, n) * O(t, n);
}
function F(e, t, n) {
    const { pxPerToken: r, maxTargetPx: o, maxTargetTokens: i } = n;
    if (e <= o && t <= o && H(e, t, r) <= i) return [e, t];
    if (t > e) {
        const [r, o] = F(t, e, n);
        return [o, r];
    }
    const s = e / t;
    let a = e,
        l = 1;
    for (;;) {
        if (l + 1 === a) return [l, Math.max(Math.round(l / s), 1)];
        const e = Math.floor((l + a) / 2),
            t = Math.max(Math.round(e / s), 1);
        e <= o && H(e, t, r) <= i ? (l = e) : (a = e);
    }
}
const B = new (class {
        contexts = new Map();
        setContext(e, t) {
            if (t.viewportWidth && t.viewportHeight) {
                const n = {
                    viewportWidth: t.viewportWidth,
                    viewportHeight: t.viewportHeight,
                    screenshotWidth: t.width,
                    screenshotHeight: t.height,
                };
                this.contexts.set(e, n);
            }
        }
        getContext(e) {
            return this.contexts.get(e);
        }
        clearContext(e) {
            this.contexts.delete(e);
        }
        clearAllContexts() {
            this.contexts.clear();
        }
    })(),
    U = {
        backspace: "deleteBackward",
        enter: "insertNewline",
        numpadenter: "insertNewline",
        kp_enter: "insertNewline",
        escape: "cancelOperation",
        arrowup: "moveUp",
        arrowdown: "moveDown",
        arrowleft: "moveLeft",
        arrowRight: "moveRight",
        up: "moveUp",
        down: "moveDown",
        left: "moveLeft",
        right: "moveRight",
        f5: "complete",
        delete: "deleteForward",
        home: "scrollToBeginningOfDocument",
        end: "scrollToEndOfDocument",
        pageup: "scrollPageUp",
        pagedown: "scrollPageDown",
        "shift+backspace": "deleteBackward",
        "shift+enter": "insertNewline",
        "shift+escape": "cancelOperation",
        "shift+arrowup": "moveUpAndModifySelection",
        "shift+arrowdown": "moveDownAndModifySelection",
        "shift+arrowleft": "moveLeftAndModifySelection",
        "shift+arrowright": "moveRightAndModifySelection",
        "shift+up": "moveUpAndModifySelection",
        "shift+down": "moveDownAndModifySelection",
        "shift+left": "moveLeftAndModifySelection",
        "shift+right": "moveRightAndModifySelection",
        "shift+f5": "complete",
        "shift+delete": "deleteForward",
        "shift+home": "moveToBeginningOfDocumentAndModifySelection",
        "shift+end": "moveToEndOfDocumentAndModifySelection",
        "shift+pageup": "pageUpAndModifySelection",
        "shift+pagedown": "pageDownAndModifySelection",
        "shift+numpad5": "delete",
        "ctrl+tab": "selectNextKeyView",
        "ctrl+enter": "insertLineBreak",
        "ctrl+numpadenter": "insertLineBreak",
        "ctrl+kp_enter": "insertLineBreak",
        "ctrl+quote": "insertSingleQuoteIgnoringSubstitution",
        "ctrl+'": "insertSingleQuoteIgnoringSubstitution",
        "ctrl+a": "moveToBeginningOfParagraph",
        "ctrl+b": "moveBackward",
        "ctrl+d": "deleteForward",
        "ctrl+e": "moveToEndOfParagraph",
        "ctrl+f": "moveForward",
        "ctrl+h": "deleteBackward",
        "ctrl+k": "deleteToEndOfParagraph",
        "ctrl+l": "centerSelectionInVisibleArea",
        "ctrl+n": "moveDown",
        "ctrl+p": "moveUp",
        "ctrl+t": "transpose",
        "ctrl+v": "moveUp",
        "ctrl+y": "yank",
        "ctrl+o": ["insertNewlineIgnoringFieldEditor", "moveBackward"],
        "ctrl+backspace": "deleteBackwardByDecomposingPreviousCharacter",
        "ctrl+arrowup": "scrollPageUp",
        "ctrl+arrowdown": "scrollPageDown",
        "ctrl+arrowleft": "moveToLeftEndOfLine",
        "ctrl+arrowright": "moveToRightEndOfLine",
        "ctrl+up": "scrollPageUp",
        "ctrl+down": "scrollPageDown",
        "ctrl+left": "moveToLeftEndOfLine",
        "ctrl+right": "moveToRightEndOfLine",
        "shift+ctrl+enter": "insertLineBreak",
        "shift+control+numpadenter": "insertLineBreak",
        "shift+control+kp_enter": "insertLineBreak",
        "shift+ctrl+tab": "selectPreviousKeyView",
        "shift+ctrl+quote": "insertDoubleQuoteIgnoringSubstitution",
        "shift+ctrl+'": "insertDoubleQuoteIgnoringSubstitution",
        'ctrl+"': "insertDoubleQuoteIgnoringSubstitution",
        "shift+ctrl+a": "moveToBeginningOfParagraphAndModifySelection",
        "shift+ctrl+b": "moveBackwardAndModifySelection",
        "shift+ctrl+e": "moveToEndOfParagraphAndModifySelection",
        "shift+ctrl+f": "moveForwardAndModifySelection",
        "shift+ctrl+n": "moveDownAndModifySelection",
        "shift+ctrl+p": "moveUpAndModifySelection",
        "shift+ctrl+v": "pageDownAndModifySelection",
        "shift+ctrl+backspace": "deleteBackwardByDecomposingPreviousCharacter",
        "shift+ctrl+arrowup": "scrollPageUp",
        "shift+ctrl+arrowdown": "scrollPageDown",
        "shift+ctrl+arrowleft": "moveToLeftEndOfLineAndModifySelection",
        "shift+ctrl+arrowright": "moveToRightEndOfLineAndModifySelection",
        "shift+ctrl+up": "scrollPageUp",
        "shift+ctrl+down": "scrollPageDown",
        "shift+ctrl+left": "moveToLeftEndOfLineAndModifySelection",
        "shift+ctrl+right": "moveToRightEndOfLineAndModifySelection",
        "alt+backspace": "deleteWordBackward",
        "alt+enter": "insertNewlineIgnoringFieldEditor",
        "alt+numpadenter": "insertNewlineIgnoringFieldEditor",
        "alt+kp_enter": "insertNewlineIgnoringFieldEditor",
        "alt+escape": "complete",
        "alt+arrowup": ["moveBackward", "moveToBeginningOfParagraph"],
        "alt+arrowdown": ["moveForward", "moveToEndOfParagraph"],
        "alt+arrowleft": "moveWordLeft",
        "alt+arrowright": "moveWordRight",
        "alt+up": ["moveBackward", "moveToBeginningOfParagraph"],
        "alt+down": ["moveForward", "moveToEndOfParagraph"],
        "alt+left": "moveWordLeft",
        "alt+right": "moveWordRight",
        "alt+delete": "deleteWordForward",
        "alt+pageup": "pageUp",
        "alt+pagedown": "pageDown",
        "shift+alt+backspace": "deleteWordBackward",
        "shift+alt+enter": "insertNewlineIgnoringFieldEditor",
        "shift+alt+numpadenter": "insertNewlineIgnoringFieldEditor",
        "shift+alt+kp_enter": "insertNewlineIgnoringFieldEditor",
        "shift+alt+escape": "complete",
        "shift+alt+arrowup": "moveParagraphBackwardAndModifySelection",
        "shift+alt+arrowdown": "moveParagraphForwardAndModifySelection",
        "shift+alt+arrowleft": "moveWordLeftAndModifySelection",
        "shift+alt+arrowright": "moveWordRightAndModifySelection",
        "shift+alt+up": "moveParagraphBackwardAndModifySelection",
        "shift+alt+down": "moveParagraphForwardAndModifySelection",
        "shift+alt+left": "moveWordLeftAndModifySelection",
        "shift+alt+right": "moveWordRightAndModifySelection",
        "shift+alt+delete": "deleteWordForward",
        "shift+alt+pageup": "pageUp",
        "shift+alt+pagedown": "pageDown",
        "ctrl+alt+b": "moveWordBackward",
        "ctrl+alt+f": "moveWordForward",
        "ctrl+alt+backspace": "deleteWordBackward",
        "shift+ctrl+alt+b": "moveWordBackwardAndModifySelection",
        "shift+ctrl+alt+f": "moveWordForwardAndModifySelection",
        "shift+ctrl+alt+backspace": "deleteWordBackward",
        "cmd+numpadsubtract": "cancel",
        "cmd+backspace": "deleteToBeginningOfLine",
        "cmd+arrowup": "moveToBeginningOfDocument",
        "cmd+arrowdown": "moveToEndOfDocument",
        "cmd+arrowleft": "moveToLeftEndOfLine",
        "cmd+arrowright": "moveToRightEndOfLine",
        "cmd+home": "moveToBeginningOfDocument",
        "cmd+up": "moveToBeginningOfDocument",
        "cmd+down": "moveToEndOfDocument",
        "cmd+left": "moveToLeftEndOfLine",
        "cmd+right": "moveToRightEndOfLine",
        "shift+cmd+numpadsubtract": "cancel",
        "shift+cmd+backspace": "deleteToBeginningOfLine",
        "shift+cmd+arrowup": "moveToBeginningOfDocumentAndModifySelection",
        "shift+cmd+arrowdown": "moveToEndOfDocumentAndModifySelection",
        "shift+cmd+arrowleft": "moveToLeftEndOfLineAndModifySelection",
        "shift+cmd+arrowright": "moveToRightEndOfLineAndModifySelection",
        "cmd+a": "selectAll",
        "cmd+c": "copy",
        "cmd+x": "cut",
        "cmd+v": "paste",
        "cmd+z": "undo",
        "shift+cmd+z": "redo",
    },
    Z = {
        enter: { key: "Enter", code: "Enter", keyCode: 13, text: "\r" },
        return: { key: "Enter", code: "Enter", keyCode: 13, text: "\r" },
        kp_enter: {
            key: "Enter",
            code: "Enter",
            keyCode: 13,
            text: "\r",
            isKeypad: !0,
        },
        tab: { key: "Tab", code: "Tab", keyCode: 9 },
        delete: { key: "Delete", code: "Delete", keyCode: 46 },
        backspace: { key: "Backspace", code: "Backspace", keyCode: 8 },
        escape: { key: "Escape", code: "Escape", keyCode: 27 },
        esc: { key: "Escape", code: "Escape", keyCode: 27 },
        space: { key: " ", code: "Space", keyCode: 32, text: " " },
        " ": { key: " ", code: "Space", keyCode: 32, text: " " },
        arrowup: { key: "ArrowUp", code: "ArrowUp", keyCode: 38 },
        arrowdown: { key: "ArrowDown", code: "ArrowDown", keyCode: 40 },
        arrowleft: { key: "ArrowLeft", code: "ArrowLeft", keyCode: 37 },
        arrowright: { key: "ArrowRight", code: "ArrowRight", keyCode: 39 },
        up: { key: "ArrowUp", code: "ArrowUp", keyCode: 38 },
        down: { key: "ArrowDown", code: "ArrowDown", keyCode: 40 },
        left: { key: "ArrowLeft", code: "ArrowLeft", keyCode: 37 },
        right: { key: "ArrowRight", code: "ArrowRight", keyCode: 39 },
        home: { key: "Home", code: "Home", keyCode: 36 },
        end: { key: "End", code: "End", keyCode: 35 },
        pageup: { key: "PageUp", code: "PageUp", keyCode: 33 },
        pagedown: { key: "PageDown", code: "PageDown", keyCode: 34 },
        f1: { key: "F1", code: "F1", keyCode: 112 },
        f2: { key: "F2", code: "F2", keyCode: 113 },
        f3: { key: "F3", code: "F3", keyCode: 114 },
        f4: { key: "F4", code: "F4", keyCode: 115 },
        f5: { key: "F5", code: "F5", keyCode: 116 },
        f6: { key: "F6", code: "F6", keyCode: 117 },
        f7: { key: "F7", code: "F7", keyCode: 118 },
        f8: { key: "F8", code: "F8", keyCode: 119 },
        f9: { key: "F9", code: "F9", keyCode: 120 },
        f10: { key: "F10", code: "F10", keyCode: 121 },
        f11: { key: "F11", code: "F11", keyCode: 122 },
        f12: { key: "F12", code: "F12", keyCode: 123 },
        ";": { key: ";", code: "Semicolon", keyCode: 186, text: ";" },
        "=": { key: "=", code: "Equal", keyCode: 187, text: "=" },
        ",": { key: ",", code: "Comma", keyCode: 188, text: "," },
        "-": { key: "-", code: "Minus", keyCode: 189, text: "-" },
        ".": { key: ".", code: "Period", keyCode: 190, text: "." },
        "/": { key: "/", code: "Slash", keyCode: 191, text: "/" },
        "`": { key: "`", code: "Backquote", keyCode: 192, text: "`" },
        "[": { key: "[", code: "BracketLeft", keyCode: 219, text: "[" },
        "\\": { key: "\\", code: "Backslash", keyCode: 220, text: "\\" },
        "]": { key: "]", code: "BracketRight", keyCode: 221, text: "]" },
        "'": { key: "'", code: "Quote", keyCode: 222, text: "'" },
        "!": { key: "!", code: "Digit1", keyCode: 49, text: "!" },
        "@": { key: "@", code: "Digit2", keyCode: 50, text: "@" },
        "#": { key: "#", code: "Digit3", keyCode: 51, text: "#" },
        $: { key: "$", code: "Digit4", keyCode: 52, text: "$" },
        "%": { key: "%", code: "Digit5", keyCode: 53, text: "%" },
        "^": { key: "^", code: "Digit6", keyCode: 54, text: "^" },
        "&": { key: "&", code: "Digit7", keyCode: 55, text: "&" },
        "*": { key: "*", code: "Digit8", keyCode: 56, text: "*" },
        "(": { key: "(", code: "Digit9", keyCode: 57, text: "(" },
        ")": { key: ")", code: "Digit0", keyCode: 48, text: ")" },
        _: { key: "_", code: "Minus", keyCode: 189, text: "_" },
        "+": { key: "+", code: "Equal", keyCode: 187, text: "+" },
        "{": { key: "{", code: "BracketLeft", keyCode: 219, text: "{" },
        "}": { key: "}", code: "BracketRight", keyCode: 221, text: "}" },
        "|": { key: "|", code: "Backslash", keyCode: 220, text: "|" },
        ":": { key: ":", code: "Semicolon", keyCode: 186, text: ":" },
        '"': { key: '"', code: "Quote", keyCode: 222, text: '"' },
        "<": { key: "<", code: "Comma", keyCode: 188, text: "<" },
        ">": { key: ">", code: "Period", keyCode: 190, text: ">" },
        "?": { key: "?", code: "Slash", keyCode: 191, text: "?" },
        "~": { key: "~", code: "Backquote", keyCode: 192, text: "~" },
        capslock: { key: "CapsLock", code: "CapsLock", keyCode: 20 },
        numlock: { key: "NumLock", code: "NumLock", keyCode: 144 },
        scrolllock: { key: "ScrollLock", code: "ScrollLock", keyCode: 145 },
        pause: { key: "Pause", code: "Pause", keyCode: 19 },
        insert: { key: "Insert", code: "Insert", keyCode: 45 },
        printscreen: { key: "PrintScreen", code: "PrintScreen", keyCode: 44 },
        numpad0: { key: "0", code: "Numpad0", keyCode: 96, isKeypad: !0 },
        numpad1: { key: "1", code: "Numpad1", keyCode: 97, isKeypad: !0 },
        numpad2: { key: "2", code: "Numpad2", keyCode: 98, isKeypad: !0 },
        numpad3: { key: "3", code: "Numpad3", keyCode: 99, isKeypad: !0 },
        numpad4: { key: "4", code: "Numpad4", keyCode: 100, isKeypad: !0 },
        numpad5: { key: "5", code: "Numpad5", keyCode: 101, isKeypad: !0 },
        numpad6: { key: "6", code: "Numpad6", keyCode: 102, isKeypad: !0 },
        numpad7: { key: "7", code: "Numpad7", keyCode: 103, isKeypad: !0 },
        numpad8: { key: "8", code: "Numpad8", keyCode: 104, isKeypad: !0 },
        numpad9: { key: "9", code: "Numpad9", keyCode: 105, isKeypad: !0 },
        numpadmultiply: {
            key: "*",
            code: "NumpadMultiply",
            keyCode: 106,
            isKeypad: !0,
        },
        numpadadd: { key: "+", code: "NumpadAdd", keyCode: 107, isKeypad: !0 },
        numpadsubtract: {
            key: "-",
            code: "NumpadSubtract",
            keyCode: 109,
            isKeypad: !0,
        },
        numpaddecimal: {
            key: ".",
            code: "NumpadDecimal",
            keyCode: 110,
            isKeypad: !0,
        },
        numpaddivide: {
            key: "/",
            code: "NumpadDivide",
            keyCode: 111,
            isKeypad: !0,
        },
    };
const z = new (class {
    debuggerAttached = new Map();
    pendingAttachments = new Map();
    isMac = !1;
    constructor() {
        this.isMac =
            navigator.platform.toUpperCase().indexOf("MAC") >= 0 ||
            navigator.userAgent.toUpperCase().indexOf("MAC") >= 0;
    }
    defaultResizeParams = {
        pxPerToken: 28,
        maxTargetPx: 1568,
        maxTargetTokens: 1568,
    };
    async attachDebugger(e) {
        if (this.debuggerAttached.get(e)) return;
        try {
            const t = await new Promise((e) => {
                chrome.debugger.getTargets(e);
            });
            if (t.find((t) => t.tabId === e && t.attached))
                return void this.debuggerAttached.set(e, !0);
        } catch (r) {}
        const t = this.pendingAttachments.get(e);
        if (t) return t;
        const n = this.performAttachment(e);
        this.pendingAttachments.set(e, n);
        try {
            await n;
        } finally {
            this.pendingAttachments.delete(e);
        }
    }
    async performAttachment(e) {
        return new Promise((t, n) => {
            chrome.debugger.attach({ tabId: e }, "1.3", () => {
                chrome.runtime.lastError
                    ? n(new Error(chrome.runtime.lastError.message))
                    : (this.debuggerAttached.set(e, !0),
                      chrome.debugger.onDetach.addListener((t) => {
                          t.tabId === e && this.debuggerAttached.delete(e);
                      }),
                      t());
            });
        });
    }
    async detachDebugger(e) {
        if (this.debuggerAttached.get(e))
            return new Promise((t) => {
                chrome.debugger.detach({ tabId: e }, () => {
                    this.debuggerAttached.delete(e), t();
                });
            });
    }
    async sendCommand(e, t, n) {
        return (
            await this.attachDebugger(e),
            new Promise((r, o) => {
                chrome.debugger.sendCommand({ tabId: e }, t, n, (e) => {
                    chrome.runtime.lastError
                        ? o(new Error(chrome.runtime.lastError.message))
                        : r(e);
                });
            })
        );
    }
    async dispatchMouseEvent(e, t) {
        const n = {
            type: t.type,
            x: Math.round(t.x),
            y: Math.round(t.y),
            modifiers: t.modifiers || 0,
        };
        ("mousePressed" !== t.type &&
            "mouseReleased" !== t.type &&
            "mouseMoved" !== t.type) ||
            ((n.button = t.button || "none"),
            ("mousePressed" !== t.type && "mouseReleased" !== t.type) ||
                (n.clickCount = t.clickCount || 1)),
            "mouseWheel" !== t.type &&
                (n.buttons = void 0 !== t.buttons ? t.buttons : 0),
            "mouseWheel" !== t.type ||
                (void 0 === t.deltaX && void 0 === t.deltaY) ||
                Object.assign(n, {
                    deltaX: t.deltaX || 0,
                    deltaY: t.deltaY || 0,
                }),
            await this.sendCommand(e, "Input.dispatchMouseEvent", n);
    }
    async dispatchKeyEvent(e, t) {
        const n = { modifiers: 0, ...t };
        await this.sendCommand(e, "Input.dispatchKeyEvent", n);
    }
    async insertText(e, t) {
        await this.sendCommand(e, "Input.insertText", { text: t });
    }
    async click(e, t, n, r = "left", o = 1) {
        try {
            await chrome.tabs.sendMessage(e, { type: "HIDE_FOR_TOOL_USE" }),
                await new Promise((e) => setTimeout(e, 50));
        } catch (i) {}
        try {
            let i = 0;
            "left" === r
                ? (i = 1)
                : "right" === r
                ? (i = 2)
                : "middle" === r && (i = 4),
                await this.dispatchMouseEvent(e, {
                    type: "mouseMoved",
                    x: t,
                    y: n,
                    button: "none",
                    buttons: 0,
                }),
                await new Promise((e) => setTimeout(e, 100));
            for (let s = 1; s <= o; s++)
                await this.dispatchMouseEvent(e, {
                    type: "mousePressed",
                    x: t,
                    y: n,
                    button: r,
                    buttons: i,
                    clickCount: s,
                }),
                    await new Promise((e) => setTimeout(e, 12)),
                    await this.dispatchMouseEvent(e, {
                        type: "mouseReleased",
                        x: t,
                        y: n,
                        button: r,
                        buttons: 0,
                        clickCount: s,
                    }),
                    s < o && (await new Promise((e) => setTimeout(e, 100)));
        } finally {
            try {
                await chrome.tabs.sendMessage(e, {
                    type: "SHOW_AFTER_TOOL_USE",
                });
            } catch (i) {}
        }
    }
    async type(e, t) {
        for (const n of t) {
            let t = n;
            ("\n" !== n && "\r" !== n) || (t = "Enter");
            const r = this.getKeyCode(t);
            if (r) {
                const t = this.requiresShift(n) ? 8 : 0;
                await this.pressKey(e, r, t);
            } else await this.insertText(e, n);
        }
    }
    async keyDown(e, t, n = 0, r) {
        await this.dispatchKeyEvent(e, {
            type: t.text ? "keyDown" : "rawKeyDown",
            key: t.key,
            code: t.code,
            windowsVirtualKeyCode: t.windowsVirtualKeyCode || t.keyCode,
            modifiers: n,
            text: t.text ?? "",
            unmodifiedText: t.text ?? "",
            location: t.location ?? 0,
            commands: r ?? [],
            isKeypad: t.isKeypad ?? !1,
        });
    }
    async keyUp(e, t, n = 0) {
        await this.dispatchKeyEvent(e, {
            type: "keyUp",
            key: t.key,
            modifiers: n,
            windowsVirtualKeyCode: t.windowsVirtualKeyCode || t.keyCode,
            code: t.code,
            location: t.location ?? 0,
        });
    }
    async pressKey(e, t, n = 0, r) {
        await this.keyDown(e, t, n, r), await this.keyUp(e, t, n);
    }
    async pressKeyChord(e, t) {
        const n = t.toLowerCase().split("+"),
            r = [];
        let o = "";
        for (const l of n)
            [
                "ctrl",
                "control",
                "alt",
                "shift",
                "cmd",
                "meta",
                "command",
                "win",
                "windows",
            ].includes(l)
                ? r.push(l)
                : (o = l);
        let i = 0;
        const s = {
            alt: 1,
            ctrl: 2,
            control: 2,
            meta: 4,
            cmd: 4,
            command: 4,
            win: 4,
            windows: 4,
            shift: 8,
        };
        for (const l of r) i |= s[l] || 0;
        const a = [];
        if (this.isMac) {
            const e = U[t.toLowerCase()];
            e && Array.isArray(e) ? a.push(...e) : e && a.push(e);
        }
        if (o) {
            const n = this.getKeyCode(o);
            if (!n) throw new Error(`Unknown key: ${t}`);
            await this.pressKey(e, n, i, a);
        }
    }
    async scrollWheel(e, t, n, r, o) {
        await this.dispatchMouseEvent(e, {
            type: "mouseWheel",
            x: t,
            y: n,
            deltaX: r,
            deltaY: o,
        });
    }
    getKeyCode(e) {
        const t = e.toLowerCase(),
            n = Z[t];
        if (n) return n;
        if (1 === e.length) {
            const t = e.toUpperCase();
            let n;
            if (t >= "A" && t <= "Z") n = `Key${t}`;
            else {
                if (!(e >= "0" && e <= "9")) return;
                n = `Digit${e}`;
            }
            return { key: e, code: n, keyCode: t.charCodeAt(0), text: e };
        }
    }
    isAttached(e) {
        return this.debuggerAttached.get(e) || !1;
    }
    async detachAllDebuggers() {
        const e = Array.from(this.debuggerAttached.keys());
        await Promise.all(e.map((e) => this.detachDebugger(e)));
    }
    requiresShift(e) {
        return '~!@#$%^&*()_+{}|:"<>?'.includes(e) || (e >= "A" && e <= "Z");
    }
    async screenshot(e, t) {
        const n = t || this.defaultResizeParams;
        try {
            await chrome.tabs.sendMessage(e, { type: "HIDE_FOR_TOOL_USE" }),
                await new Promise((e) => setTimeout(e, 50));
        } catch (r) {}
        try {
            const t = await chrome.scripting.executeScript({
                target: { tabId: e },
                func: () => ({
                    width: window.innerWidth,
                    height: window.innerHeight,
                    devicePixelRatio: window.devicePixelRatio,
                }),
            });
            if (!t || !t[0]?.result)
                throw new Error("Failed to get viewport information");
            const { width: r, height: o, devicePixelRatio: i } = t[0].result,
                s = await this.sendCommand(e, "Page.captureScreenshot", {
                    format: "png",
                    captureBeyondViewport: !1,
                    fromSurface: !0,
                });
            if (!s || !s.data)
                throw new Error("Failed to capture screenshot via CDP");
            const a = `data:image/png;base64,${s.data}`,
                l = await new Promise((e, t) => {
                    const s = new Image();
                    (s.onload = () => {
                        let a = s.width,
                            l = s.height;
                        const c = document.createElement("canvas"),
                            u = c.getContext("2d");
                        if (!u)
                            return void t(
                                new Error(
                                    "Failed to create 2D context for screenshot processing"
                                )
                            );
                        i > 1
                            ? ((a = Math.round(s.width / i)),
                              (l = Math.round(s.height / i)),
                              (c.width = a),
                              (c.height = l),
                              u.drawImage(
                                  s,
                                  0,
                                  0,
                                  s.width,
                                  s.height,
                                  0,
                                  0,
                                  a,
                                  l
                              ))
                            : ((c.width = a),
                              (c.height = l),
                              u.drawImage(s, 0, 0));
                        const [d, h] = F(a, l, n);
                        if (!(a !== d || l !== h)) {
                            const t = c.toDataURL("image/png").split(",")[1];
                            return void e({
                                base64: t,
                                width: a,
                                height: l,
                                format: "png",
                                viewportWidth: r,
                                viewportHeight: o,
                            });
                        }
                        const p = document.createElement("canvas"),
                            f = p.getContext("2d");
                        if (!f)
                            return void t(
                                new Error(
                                    "Failed to create 2D context for target resizing"
                                )
                            );
                        (p.width = d),
                            (p.height = h),
                            f.drawImage(c, 0, 0, a, l, 0, 0, d, h);
                        const m = p.toDataURL("image/png").split(",")[1];
                        e({
                            base64: m,
                            width: d,
                            height: h,
                            format: "png",
                            viewportWidth: r,
                            viewportHeight: o,
                        });
                    }),
                        (s.onerror = () => {
                            t(new Error("Failed to load screenshot image"));
                        }),
                        (s.src = a);
                });
            return B.setContext(e, l), l;
        } finally {
            try {
                await chrome.tabs.sendMessage(e, {
                    type: "SHOW_AFTER_TOOL_USE",
                });
            } catch (r) {}
        }
    }
})();
function $(e, t, n) {
    const r = n.viewportWidth / n.screenshotWidth,
        o = n.viewportHeight / n.screenshotHeight;
    return [Math.round(e * r), Math.round(t * o)];
}
const W = {
    name: "computer",
    description:
        "Use a mouse and keyboard to interact with a computer, and take screenshots.",
    parameters: {
        action: {
            type: "string",
            enum: [
                "left_click",
                "right_click",
                "type",
                "screenshot",
                "wait",
                "scroll",
                "key",
                "left_click_drag",
                "double_click",
                "triple_click",
            ],
            description:
                "The action to perform:\n* `left_click`: Click the left mouse button at the specified coordinates.\n* `right_click`: Click the right mouse button at the specified coordinates to open context menus.\n* `double_click`: Double-click the left mouse button at the specified coordinates.\n* `triple_click`: Triple-click the left mouse button at the specified coordinates.\n* `type`: Type a string of text.\n* `screenshot`: Take a screenshot of the screen.\n* `wait`: Wait for a specified number of seconds.\n* `scroll`: Scroll up, down, left, or right at the specified coordinates.\n* `key`: Press a specific keyboard key.\n* `left_click_drag`: Drag from start_coordinate to coordinate.",
        },
        coordinate: {
            type: "array",
            items: { type: "number" },
            minItems: 2,
            maxItems: 2,
            description:
                "(x, y): The x (pixels from the left edge) and y (pixels from the top edge) coordinates. Required for `left_click`, `right_click`, `double_click`, `triple_click`, and `scroll`. For `left_click_drag`, this is the end position.",
        },
        text: {
            type: "string",
            description:
                'The text to type (for `type` action) or the key(s) to press (for `key` action). For `key` action: Provide space-separated keys (e.g., "Backspace Backspace Delete"). Supports keyboard shortcuts using the platform\'s modifier key (use "cmd" on Mac, "ctrl" on Windows/Linux, e.g., "cmd+a" or "ctrl+a" for select all).',
        },
        duration: {
            type: "number",
            minimum: 0,
            maximum: 30,
            description:
                "The number of seconds to wait. Required for `wait`. Maximum 30 seconds.",
        },
        scroll_direction: {
            type: "string",
            enum: ["up", "down", "left", "right"],
            description: "The direction to scroll. Required for `scroll`.",
        },
        scroll_amount: {
            type: "number",
            minimum: 1,
            maximum: 10,
            description:
                "The number of scroll wheel ticks. Optional for `scroll`, defaults to 3.",
        },
        start_coordinate: {
            type: "array",
            items: { type: "number" },
            minItems: 2,
            maxItems: 2,
            description:
                "(x, y): The starting coordinates for `left_click_drag`.",
        },
    },
    execute: async (n, r) => {
        try {
            const i = n || {};
            if (!i.action) throw new Error("Action parameter is required");
            if (!r?.tabId) throw new Error("No active tab found");
            const s = await chrome.tabs.get(r.tabId);
            if (!s.id) throw new Error("Active tab has no ID");
            if (!["wait"].includes(i.action)) {
                const n = s.url;
                if (!n) throw new Error("No URL available for active tab");
                const a = (function (e) {
                        const n = {
                            screenshot: t.READ_PAGE_CONTENT,
                            scroll: t.READ_PAGE_CONTENT,
                            left_click: t.CLICK,
                            right_click: t.CLICK,
                            double_click: t.CLICK,
                            triple_click: t.CLICK,
                            left_click_drag: t.CLICK,
                            type: t.TYPE,
                            key: t.TYPE,
                        };
                        if (!n[e]) throw new Error(`Unsupported action: ${e}`);
                        return n[e];
                    })(i.action),
                    l = r?.toolUseId,
                    c = await e.checkPermission(n, l);
                if (!c.allowed) {
                    if (c.needsPrompt) {
                        const e = {
                            type: "permission_required",
                            tool: a,
                            url: n,
                            toolUseId: l,
                        };
                        if (
                            "left_click" === i.action ||
                            "right_click" === i.action ||
                            "double_click" === i.action ||
                            "triple_click" === i.action
                        )
                            try {
                                const t = await z.screenshot(s.id);
                                (e.actionData = {
                                    screenshot: `data:image/png;base64,${t.base64}`,
                                }),
                                    i.coordinate &&
                                        (e.actionData.coordinate =
                                            i.coordinate);
                            } catch (o) {
                                (e.actionData = {}),
                                    i.coordinate &&
                                        (e.actionData.coordinate =
                                            i.coordinate);
                            }
                        else
                            "type" === i.action && i.text
                                ? (e.actionData = { text: i.text })
                                : "left_click_drag" === i.action &&
                                  i.start_coordinate &&
                                  i.coordinate &&
                                  (e.actionData = {
                                      start_coordinate: i.start_coordinate,
                                      coordinate: i.coordinate,
                                  });
                        return e;
                    }
                    return {
                        error: "Permission denied for this action on this domain",
                    };
                }
            }
            const a = s.url;
            switch (i.action) {
                case "left_click":
                case "right_click":
                    return await q(s.id, i, 1, a);
                case "type":
                    return await (async function (e, t, n) {
                        if (!t.text)
                            throw new Error(
                                "Text parameter is required for type action"
                            );
                        try {
                            const r = await N(e, n, "type action");
                            return (
                                r ||
                                (await z.type(e, t.text),
                                { output: `Typed "${t.text}"` })
                            );
                        } catch (o) {
                            return {
                                error: `Failed to type: ${
                                    o instanceof Error
                                        ? o.message
                                        : "Unknown error"
                                }`,
                            };
                        }
                    })(s.id, i, a);
                case "screenshot":
                    return await K(s.id);
                case "wait":
                    return await (async function (e) {
                        if (!e.duration || e.duration <= 0)
                            throw new Error(
                                "Duration parameter is required and must be positive"
                            );
                        if (e.duration > 30)
                            throw new Error(
                                "Duration cannot exceed 30 seconds"
                            );
                        const t = Math.round(1e3 * e.duration);
                        return (
                            await new Promise((e) => setTimeout(e, t)),
                            {
                                output: `Waited for ${e.duration} second${
                                    1 === e.duration ? "" : "s"
                                }`,
                            }
                        );
                    })(i);
                case "scroll":
                    return await (async function (t, n) {
                        if (!n.coordinate || 2 !== n.coordinate.length)
                            throw new Error(
                                "Coordinate parameter is required for scroll action"
                            );
                        let [r, i] = n.coordinate;
                        const s = B.getContext(t);
                        if (s) {
                            const [e, t] = $(r, i, s);
                            (r = e), (i = t);
                        }
                        const a = n.scroll_direction || "down",
                            l = n.scroll_amount || 3;
                        try {
                            let n = 0,
                                s = 0;
                            const c = 100;
                            switch (a) {
                                case "up":
                                    s = -l * c;
                                    break;
                                case "down":
                                    s = l * c;
                                    break;
                                case "left":
                                    n = -l * c;
                                    break;
                                case "right":
                                    n = l * c;
                                    break;
                                default:
                                    throw new Error(
                                        `Invalid scroll direction: ${a}`
                                    );
                            }
                            await z.scrollWheel(t, r, i, n, s),
                                await new Promise((e) => setTimeout(e, 100));
                            const u = await (async function (t) {
                                try {
                                    const r = await chrome.tabs.get(t);
                                    if (!r?.url) return;
                                    if (
                                        (await e.checkPermission(r.url, void 0))
                                            .allowed
                                    )
                                        try {
                                            return (await K(t)).base64Image;
                                        } catch (n) {
                                            return;
                                        }
                                    return;
                                } catch (o) {
                                    return;
                                }
                            })(t);
                            return {
                                output: `Scrolled ${a} by ${l} ticks at (${r}, ${i})`,
                                ...(u && { base64Image: u }),
                            };
                        } catch (o) {
                            return {
                                error: `Error scrolling: ${
                                    o instanceof Error
                                        ? o.message
                                        : "Unknown error"
                                }`,
                            };
                        }
                    })(s.id, i);
                case "key":
                    return await (async function (e, t, n) {
                        if (!t.text)
                            throw new Error(
                                "Text parameter is required for key action"
                            );
                        try {
                            const r = await N(e, n, "key action");
                            if (r) return r;
                            const o = t.text
                                .trim()
                                .split(/\s+/)
                                .filter((e) => e.length > 0);
                            for (const t of o)
                                if (t.includes("+"))
                                    await z.pressKeyChord(e, t);
                                else {
                                    const n = z.getKeyCode(t);
                                    n
                                        ? await z.pressKey(e, n)
                                        : await z.insertText(e, t);
                                }
                            return {
                                output: `Pressed ${o.length} key${
                                    1 === o.length ? "" : "s"
                                }: ${o.join(" ")}`,
                            };
                        } catch (o) {
                            return {
                                error: `Error pressing key: ${
                                    o instanceof Error
                                        ? o.message
                                        : "Unknown error"
                                }`,
                            };
                        }
                    })(s.id, i, a);
                case "left_click_drag":
                    return await (async function (e, t, n) {
                        if (
                            !t.start_coordinate ||
                            2 !== t.start_coordinate.length
                        )
                            throw new Error(
                                "start_coordinate parameter is required for left_click_drag action"
                            );
                        if (!t.coordinate || 2 !== t.coordinate.length)
                            throw new Error(
                                "coordinate parameter (end position) is required for left_click_drag action"
                            );
                        let [r, i] = t.start_coordinate,
                            [s, a] = t.coordinate;
                        const l = B.getContext(e);
                        if (l) {
                            const [e, t] = $(r, i, l),
                                [n, o] = $(s, a, l);
                            (r = e), (i = t), (s = n), (a = o);
                        }
                        try {
                            const t = await N(e, n, "drag action");
                            return (
                                t ||
                                (await z.dispatchMouseEvent(e, {
                                    type: "mouseMoved",
                                    x: r,
                                    y: i,
                                    button: "none",
                                    buttons: 0,
                                    modifiers: 0,
                                }),
                                await z.dispatchMouseEvent(e, {
                                    type: "mousePressed",
                                    x: r,
                                    y: i,
                                    button: "left",
                                    buttons: 1,
                                    clickCount: 1,
                                    modifiers: 0,
                                }),
                                await z.dispatchMouseEvent(e, {
                                    type: "mouseMoved",
                                    x: s,
                                    y: a,
                                    button: "left",
                                    buttons: 1,
                                    modifiers: 0,
                                }),
                                await z.dispatchMouseEvent(e, {
                                    type: "mouseReleased",
                                    x: s,
                                    y: a,
                                    button: "left",
                                    buttons: 0,
                                    clickCount: 1,
                                    modifiers: 0,
                                }),
                                {
                                    output: `Dragged from (${r}, ${i}) to (${s}, ${a})`,
                                })
                            );
                        } catch (o) {
                            return {
                                error: `Error performing drag: ${
                                    o instanceof Error
                                        ? o.message
                                        : "Unknown error"
                                }`,
                            };
                        }
                    })(s.id, i, a);
                case "double_click":
                    return await q(s.id, i, 2, a);
                case "triple_click":
                    return await q(s.id, i, 3, a);
                default:
                    throw new Error(`Unsupported action: ${i.action}`);
            }
        } catch (o) {
            return {
                error: `Failed to execute action: ${
                    o instanceof Error ? o.message : "Unknown error"
                }`,
            };
        }
    },
    toAnthropicSchema: async (e) => {
        await z.attachDebugger(e.tabId);
        const t = await chrome.scripting.executeScript({
            target: { tabId: e.tabId },
            func: () => ({
                width:
                    document.documentElement.clientWidth || window.innerWidth,
                height:
                    document.documentElement.clientHeight || window.innerHeight,
            }),
        });
        if (!t || !t[0]?.result)
            throw new Error("Failed to retrieve viewport dimensions");
        const { width: n, height: r } = t[0].result;
        return {
            name: "computer",
            type: "computer_20250124",
            display_width_px: n,
            display_height_px: r,
            display_number: 1,
        };
    },
};
async function q(e, t, n = 1, r) {
    if (!t.coordinate)
        throw new Error("Coordinate parameter is required for click action");
    let [o, i] = t.coordinate;
    const s = B.getContext(e);
    if (s) {
        const [e, t] = $(o, i, s);
        (o = e), (i = t);
    }
    const a = "right_click" === t.action ? "right" : "left";
    try {
        const t = await N(e, r, "click action");
        if (t) return t;
        await z.click(e, o, i, a, n);
        return {
            output: `${
                1 === n
                    ? "Clicked"
                    : 2 === n
                    ? "Double-clicked"
                    : "Triple-clicked"
            } at (${o}, ${i})`,
        };
    } catch (l) {
        return {
            error: `Error clicking: ${
                l instanceof Error ? l.message : "Unknown error"
            }`,
        };
    }
}
async function K(e) {
    try {
        const t = await z.screenshot(e);
        return {
            output: `Successfully captured screenshot (${t.width}x${t.height}, png) scaled to viewport dimensions`,
            base64Image: t.base64,
        };
    } catch (t) {
        return {
            error: `Error capturing screenshot: ${
                t instanceof Error ? t.message : "Unknown error"
            }`,
        };
    }
}
const Y = {
        name: "get_page_text",
        description:
            "Extract raw text content from the page, prioritizing article content. Ideal for reading articles, blog posts, or other text-heavy pages. Returns plain text without HTML formatting.",
        parameters: {},
        execute: async (n, r) => {
            try {
                if (!r?.tabId) throw new Error("No active tab found");
                const n = (await chrome.tabs.get(r.tabId)).url;
                if (!n) throw new Error("No URL available for active tab");
                const o = r?.toolUseId,
                    i = await e.checkPermission(n, o);
                if (!i.allowed) {
                    if (i.needsPrompt) {
                        return {
                            type: "permission_required",
                            tool: t.READ_PAGE_CONTENT,
                            url: n,
                            toolUseId: o,
                        };
                    }
                    return {
                        error: "Permission denied for reading page content on this domain",
                    };
                }
                const s = await chrome.scripting.executeScript({
                    target: { tabId: r.tabId },
                    func: () =>
                        (function () {
                            const e = [
                                "article",
                                "main",
                                '[class*="articleBody"]',
                                '[class*="article-body"]',
                                '[class*="post-content"]',
                                '[class*="entry-content"]',
                                '[class*="content-body"]',
                                '[role="main"]',
                                ".content",
                                "#content",
                            ];
                            let t = null;
                            for (const n of e) {
                                const e = document.querySelectorAll(n);
                                if (e.length > 0) {
                                    let n = e[0],
                                        r = 0;
                                    e.forEach((e) => {
                                        const t = e.textContent?.length || 0;
                                        t > r && ((r = t), (n = e));
                                    }),
                                        (t = n);
                                    break;
                                }
                            }
                            if (!t) return;
                            return {
                                text: (t.textContent || "")
                                    .replace(/\s+/g, " ")
                                    .replace(/\n{3,}/g, "\n\n")
                                    .trim(),
                                source: t.tagName.toLowerCase(),
                                title: document.title,
                                url: window.location.href,
                            };
                        })(),
                });
                if (!s || 0 === s.length)
                    throw new Error(
                        "No main text content found. The content might be visual content only, or rendered in a canvas element."
                    );
                if ("error" in s[0] && s[0].error)
                    throw new Error(
                        `Script execution failed: ${
                            s[0].error.message || "Unknown error"
                        }`
                    );
                if (!s[0].result)
                    throw new Error("Page script returned empty result");
                const a = s[0].result;
                return {
                    output: `Title: ${a.title}\nURL: ${a.url}\nSource element: <${a.source}>\n---\n${a.text}`,
                };
            } catch (o) {
                return {
                    error: `Failed to extract page text: ${
                        o instanceof Error ? o.message : "Unknown error"
                    }`,
                };
            }
        },
        toAnthropicSchema: async () => ({
            name: "get_page_text",
            description:
                "Extract raw text content from the page, prioritizing article content. Ideal for reading articles, blog posts, or other text-heavy pages. Returns plain text without HTML formatting.",
            input_schema: { type: "object", properties: {}, required: [] },
        }),
    },
    X = async (e, t) => await Promise.all(e.map((e) => e.toAnthropicSchema(t)));
function G(e = !1) {
    const t = "0123456789abcdef",
        n = Array.from(
            { length: 32 },
            () => t[Math.floor(16 * Math.random())]
        ).join(""),
        r = Array.from(
            { length: 16 },
            () => t[Math.floor(16 * Math.random())]
        ).join(""),
        o = {
            traceparent: `00-${n}-${r}-0${e ? "1" : "0"}`,
            "x-cloud-trace-context": `${n}/${parseInt(r, 16).toString()};o=${
                e ? "1" : "0"
            }`,
        };
    return (
        e &&
            ((o.baggage = "forceTrace=true"),
            (o["x-refinery-force-trace"] = "true")),
        { traceId: n, headers: o }
    );
}
const Q = (e, t) => {};
function J_useChat({
    apiKey: t,
    authToken: a,
    refreshTokenIfNeeded: l,
    sessionId: c,
    model: u,
    onPermissionRequired: d,
    tabId: h,
    currentDomain: p,
    skipAllPermissions: f,
}) {
    const [m, g] = r.useState([]),
        [y, x] = r.useState(!1),
        [v, C] = r.useState(null),
        { analytics: w } = o(),
        [b, k] = r.useState([]),
        T = (() => {
            const { value: e } = n.useDynamicConfig(
                "chrome_ext_default_system_prompt"
            );
            return e;
        })(),
        L = r.useRef(null),
        M = r.useRef(null),
        P = r.useRef(!1),
        j = r.useRef([V, _, R, W, D, Y]),
        { userProfile: N } = i(),
        I = (() => {
            const { value: e } = n.useFeatureGate("chrome_ext_trace_headers");
            return e || !1;
        })(),
        O = E(),
        H = r.useCallback(
            (e) =>
                e
                    ? e.startsWith("chrome://") ||
                      e.startsWith("chrome-extension://") ||
                      "about:blank" === e
                        ? "system"
                        : e.startsWith("https://chromewebstore.google.com/")
                        ? "non-script"
                        : "regular"
                    : "regular",
            []
        ),
        F = r.useCallback(
            (e) =>
                "system" === e || "non-script" === e
                    ? j.current.filter((e) => ["navigate"].includes(e.name))
                    : j.current,
            []
        );
    r.useEffect(() => {
        t || a
            ? (C(null),
              t
                  ? (L.current = new s({
                        baseURL: O.apiBaseUrl,
                        apiKey: t,
                        dangerouslyAllowBrowser: !0,
                    }))
                  : a &&
                    (L.current = new s({
                        baseURL: O.apiBaseUrl,
                        authToken: a,
                        dangerouslyAllowBrowser: !0,
                    })))
            : C("No API key or Auth Token provided.");
    }, [t, a, O.apiBaseUrl]),
        r.useEffect(() => {
            w?.track("claude_chrome.chat.session_started", { model: u });
        }, [w, u]);
    const B = r.useCallback(async () => {
            if (!h) return;
            const e =
                f && T.skipPermissionsSystemPrompt
                    ? T.skipPermissionsSystemPrompt
                    : T.systemPrompt;
            if (!e)
                throw (
                    (k(null),
                    new Error(
                        "Unable to initialize the chat session. Please check your connection and try again."
                    ))
                );
            const t = await chrome.tabs.get(h),
                n =
                    navigator.platform.toUpperCase().indexOf("MAC") >= 0 ||
                    navigator.userAgent.toUpperCase().indexOf("MAC") >= 0,
                r = n ? "Mac" : "Windows/Linux",
                o = n ? "cmd" : "ctrl",
                i = new Date().toLocaleString(),
                s = [
                    {
                        type: "text",
                        text: e.replace(/{{currentDateTime}}/g, i),
                    },
                ],
                a = await S(A.SYSTEM_PROMPT);
            if (
                (a && s.push({ type: "text", text: a }),
                s.push({
                    type: "text",
                    text: `Platform-specific information:\n- You are on a ${r} system\n- Use "${o}" as the modifier key for keyboard shortcuts (e.g., "${o}+a" for select all, "${o}+c" for copy, "${o}+v" for paste)`,
                }),
                t.url)
            )
                try {
                    const e = new URL(t.url).hostname;
                    s.push({
                        type: "text",
                        text: `The current page domain is "${e}"`,
                    });
                } catch (l) {}
            (s[s.length - 1].cache_control = { type: "ephemeral" }), k(s);
        }, [h, T, f]),
        U = r.useCallback(async () => {
            g([]), C(null), await e.clearOncePermissions();
            try {
                await B();
            } catch (t) {
                C(ee(t));
            }
        }, [B]);
    r.useEffect(() => {
        U();
    }, [U]);
    const Z = r.useCallback(() => {
            (P.current = !0),
                M.current && (M.current.abort(), (M.current = null)),
                x(!1);
        }, []),
        $ = r.useCallback((e, t = !1) => {
            const n = e.role;
            if ("string" == typeof e.content)
                return t
                    ? {
                          role: n,
                          content: [
                              {
                                  type: "text",
                                  text: e.content,
                                  cache_control: { type: "ephemeral" },
                              },
                          ],
                      }
                    : { role: n, content: e.content };
            if (Array.isArray(e.content)) {
                const r = JSON.parse(JSON.stringify(e.content));
                return (
                    t &&
                        r.length > 0 &&
                        (r[r.length - 1].cache_control = { type: "ephemeral" }),
                    { role: n, content: r }
                );
            }
            return { role: n, content: "" };
        }, []),
        q = r.useCallback(
            (e) => {
                let t = -1;
                for (let r = e.length - 1; r >= 0; r--)
                    if ("assistant" === e[r].role) {
                        t = r;
                        break;
                    }
                const n = e.map((e, n) => $(e, n === t));
                if (t >= 0) {
                    const e = t + 1;
                    n.length;
                }
                return n;
            },
            [$]
        ),
        K = r.useCallback(
            async (e, t, n) => {
                const r = {
                        toolUseId: n,
                        tabId: h,
                        sessionId: c,
                        anthropicClient: L.current || void 0,
                    },
                    o = j.current.find((t) => t.name === e);
                if (!o) throw new Error(`Unknown tool: ${e}`);
                const i = await o.execute(t, r),
                    s = { name: e },
                    a = t.action;
                return (
                    "computer" === e && a && (s.action = a),
                    p && (s.domain = p),
                    w?.track("claude_chrome.chat.tool_called", s),
                    i
                );
            },
            [w, h, c, p]
        ),
        J = r.useCallback(
            async (e) => {
                const t = [],
                    n = (e) => {
                        if (e.error) return e.error;
                        const t = [];
                        return (
                            e.output &&
                                t.push({ type: "text", text: e.output }),
                            e.base64Image &&
                                t.push({
                                    type: "image",
                                    source: {
                                        type: "base64",
                                        media_type: "image/png",
                                        data: e.base64Image,
                                    },
                                }),
                            t.length > 0 ? t : ""
                        );
                    },
                    r = (e, t) => {
                        const r = !!t.error;
                        return {
                            type: "tool_result",
                            tool_use_id: e,
                            content: n(t),
                            ...(r && { is_error: !0 }),
                        };
                    };
                for (const i of e)
                    try {
                        const e = await K(i.name, i.input, i.id);
                        if ("type" in e && "permission_required" === e.type) {
                            const n = { ...e };
                            if (!d) {
                                t.push(
                                    r(i.id, {
                                        error: "Permission required but no handler available",
                                    })
                                );
                                continue;
                            }
                            if (!(await d(n))) {
                                t.push(
                                    r(i.id, {
                                        error: "Permission denied by user",
                                    })
                                );
                                continue;
                            }
                            const o = await K(i.name, i.input, i.id);
                            if ("type" in o && "permission_required" === o.type)
                                throw new Error(
                                    "Permission still required after granting"
                                );
                            t.push(r(i.id, o));
                        } else t.push(r(i.id, e));
                    } catch (o) {
                        const e = ee(o);
                        t.push(r(i.id, { error: e }));
                    }
                return t;
            },
            [K, d]
        ),
        te = r.useCallback(
            async (e) => {
                if (!L.current) throw new Error("Client not initialized");
                if (!h) throw new Error("No active tab");
                if (!b)
                    throw new Error(
                        "Unable to initialize the chat session. Please check your connection and try again."
                    );
                x(!0),
                    C(null),
                    w?.track("claude_chrome.chat.user_message_sent", {
                        model: u,
                    });
                const t = {
                        role: "user",
                        content: [{ type: "text", text: e }],
                    },
                    n = [...m, t];
                if ((g(n), !h)) return C("No active tab"), void x(!1);
                let r = "regular";
                try {
                    const e = await chrome.tabs.get(h);
                    r = H(e.url);
                } catch (c) {}
                const o = F(r);
                let i = null;
                try {
                    i = await X(o, { tabId: h });
                } catch (c) {
                    const e = ee(c);
                    return C(e), void x(!1);
                }
                i.length > 0 &&
                    (i[i.length - 1].cache_control = { type: "ephemeral" }),
                    (P.current = !1);
                let s = !0,
                    a = 0;
                for (; s && !P.current; ) {
                    if (
                        (a++,
                        (s = !1),
                        (M.current = new AbortController()),
                        a > 1)
                    )
                        try {
                            const e = await chrome.tabs.get(h),
                                t = H(e.url);
                            if (t !== r) {
                                r = t;
                                const e = F(r);
                                (i = await X(e, { tabId: h })),
                                    i.length > 0 &&
                                        (i[i.length - 1].cache_control = {
                                            type: "ephemeral",
                                        });
                            }
                        } catch (c) {}
                    let e;
                    const t = new Promise((t) => {
                        e = t;
                    });
                    try {
                        const r = q(n),
                            o = { role: "assistant", content: [] };
                        n.push(o), g([...n]);
                        let a = "";
                        const d = {
                            messages: r,
                            model: u,
                            max_tokens: 1024,
                            tools: i,
                            system: b,
                            betas: [
                                "computer-use-2025-01-24",
                                "oauth-2025-04-20",
                            ],
                        };
                        N?.account.uuid &&
                            (d.metadata = { user_id: N.account.uuid });
                        const h = { signal: M.current.signal };
                        if (I) {
                            const { traceId: e, headers: t } = G(!0);
                            h.headers = t;
                        }
                        await l();
                        const p = L.current.beta.messages
                            .stream(d, h)
                            .on("text", (e) => {
                                a += e;
                                const t = n[n.length - 1];
                                t &&
                                    "assistant" === t.role &&
                                    (t.content = [{ type: "text", text: a }]),
                                    g([...n]);
                            })
                            .on("message", async (t) => {
                                try {
                                    if (
                                        (n.pop(),
                                        n.push(t),
                                        g([...n]),
                                        Array.isArray(t.content))
                                    ) {
                                        t.content.forEach((e, t) => {});
                                        const r = t.content.filter(
                                            (e) => "tool_use" === e.type
                                        );
                                        if (r.length > 0) {
                                            let t = [];
                                            P.current
                                                ? (t = r.map((e) => ({
                                                      type: "tool_result",
                                                      tool_use_id: e.id,
                                                      content:
                                                          "Tool execution cancelled by user",
                                                      is_error: !0,
                                                  })))
                                                : ((t = await J(r)), P.current);
                                            const o = {
                                                role: "user",
                                                content: t,
                                            };
                                            return (
                                                n.push(o),
                                                g([...n]),
                                                (s = !0),
                                                void e()
                                            );
                                        }
                                    }
                                    n.length, n[n.length - 1], e();
                                } catch (c) {
                                    throw (e(), c);
                                }
                            })
                            .on("error", (e) => {
                                const t = ee(e);
                                e instanceof Error && e.stack,
                                    e instanceof Error && e.constructor.name,
                                    P.current || C(t);
                            })
                            .on("finalMessage", (e) => {
                                if (e && "usage" in e) {
                                    const t = e.usage;
                                    w?.track("claude_chrome.chat.usage", {
                                        usage: t,
                                    });
                                }
                            });
                        await p.done(), await t;
                    } catch (c) {
                        const e = ee(c);
                        if ("Request was aborted." === e) return;
                        return (
                            Q(
                                0,
                                (c instanceof Error && c.stack,
                                c instanceof Error && c.constructor.name)
                            ),
                            void C(e)
                        );
                    } finally {
                        if (((M.current = null), !s)) {
                            x(!1);
                            try {
                                await z.detachDebugger(h);
                            } catch (c) {}
                            w?.track(
                                "claude_chrome.chat.assistant_response_stopped",
                                { model: u, cancelled: P.current }
                            ),
                                P.current;
                        }
                        const e = n[n.length - 1];
                        if (e && "assistant" === e.role) {
                            const t = e.content;
                            Array.isArray(t) &&
                                (0 === t.length ||
                                    (1 === t.length &&
                                        "text" === t[0].type &&
                                        "" === t[0].text)) &&
                                (n.pop(), g([...n]));
                        }
                    }
                }
            },
            [m, u, q, J, w, h, b, F, H, I, N?.account?.uuid, l]
        );
    return {
        messages: m,
        sendMessage: te,
        cancel: Z,
        clearMessages: U,
        isLoading: y,
        error: v,
    };
}
function ee(e) {
    if ("string" == typeof e) {
        const t = e.match(/^(\d{3})\s+(\{.+\})$/s);
        let n = e;
        t && (n = t[2]);
        try {
            const t = JSON.parse(n);
            return t?.error?.message
                ? t.error.message
                : t?.message
                ? t.message
                : e;
        } catch {
            return e;
        }
    }
    if (e instanceof Error) {
        const t = e.message,
            n = t.match(/^(\d{3})\s+(\{.+\})$/s);
        let r = t;
        n && (r = n[2]);
        try {
            const e = JSON.parse(r);
            if (e?.error?.message) return e.error.message;
            if (e?.message) return e.message;
        } catch {}
        return e.message;
    }
    if (e && "object" == typeof e) {
        if (
            "error" in e &&
            "object" == typeof e.error &&
            e.error &&
            "message" in e.error
        )
            return String(e.error.message);
        if ("message" in e) return String(e.message);
    }
    return String(e);
}
function te() {
    const [e, t] = r.useState(""),
        [o, i] = r.useState(!1),
        [s, a] = r.useState({
            isBlocked: !1,
            hasUpdate: !1,
            currentVersion: "",
            minSupportedVersion: null,
        }),
        { value: l } = n.useDynamicConfig("chrome_ext_version_info");
    return (
        r.useEffect(() => {
            const e = chrome.runtime.getManifest().version;
            t(e);
            (async () => {
                const e = await S(A.UPDATE_AVAILABLE);
                i(!!e);
            })();
            const n = (e) => {
                e[A.UPDATE_AVAILABLE] &&
                    i(!0 === e[A.UPDATE_AVAILABLE].newValue);
            };
            return (
                chrome.storage.onChanged.addListener(n),
                () => {
                    chrome.storage.onChanged.removeListener(n);
                }
            );
        }, []),
        r.useEffect(() => {
            if (!e) return;
            const t = l?.min_supported_version,
                n =
                    !!t &&
                    (function (e, t) {
                        const n = e.split(".").map(Number),
                            r = t.split(".").map(Number);
                        for (let o = 0; o < Math.max(n.length, r.length); o++) {
                            const e = n[o] || 0,
                                t = r[o] || 0;
                            if (e < t) return -1;
                            if (e > t) return 1;
                        }
                        return 0;
                    })(e, t) < 0;
            a({
                isBlocked: n,
                hasUpdate: o,
                currentVersion: e,
                minSupportedVersion: t || null,
            });
        }, [e, l, o]),
        s
    );
}
function ne_Login() {
    return a.jsx("div", {
        className:
            "flex flex-col h-screen bg-bg-100 items-center justify-center p-4",
        children: a.jsx(l_Login, {}),
    });
}
function re() {}
function oe() {}
const ie = /^[$_\p{ID_Start}][$_\u{200C}\u{200D}\p{ID_Continue}]*$/u,
    se = /^[$_\p{ID_Start}][-$_\u{200C}\u{200D}\p{ID_Continue}]*$/u,
    ae = {};
function le(e, t) {
    return (ae.jsx ? se : ie).test(e);
}
const ce = /[ \t\n\f\r]/g;
function ue(e) {
    return "" === e.replace(ce, "");
}
class de {
    constructor(e, t, n) {
        (this.normal = t), (this.property = e), n && (this.space = n);
    }
}
function he(e, t) {
    const n = {},
        r = {};
    for (const o of e) Object.assign(n, o.property), Object.assign(r, o.normal);
    return new de(n, r, t);
}
function pe(e) {
    return e.toLowerCase();
}
(de.prototype.normal = {}),
    (de.prototype.property = {}),
    (de.prototype.space = void 0);
class fe {
    constructor(e, t) {
        (this.attribute = t), (this.property = e);
    }
}
(fe.prototype.attribute = ""),
    (fe.prototype.booleanish = !1),
    (fe.prototype.boolean = !1),
    (fe.prototype.commaOrSpaceSeparated = !1),
    (fe.prototype.commaSeparated = !1),
    (fe.prototype.defined = !1),
    (fe.prototype.mustUseProperty = !1),
    (fe.prototype.number = !1),
    (fe.prototype.overloadedBoolean = !1),
    (fe.prototype.property = ""),
    (fe.prototype.spaceSeparated = !1),
    (fe.prototype.space = void 0);
let me = 0;
const ge = ke(),
    ye = ke(),
    xe = ke(),
    ve = ke(),
    Ce = ke(),
    we = ke(),
    be = ke();
function ke() {
    return 2 ** ++me;
}
const Ee = Object.freeze(
        Object.defineProperty(
            {
                __proto__: null,
                boolean: ge,
                booleanish: ye,
                commaOrSpaceSeparated: be,
                commaSeparated: we,
                number: ve,
                overloadedBoolean: xe,
                spaceSeparated: Ce,
            },
            Symbol.toStringTag,
            { value: "Module" }
        )
    ),
    Se = Object.keys(Ee);
class Ae extends fe {
    constructor(e, t, n, r) {
        let o = -1;
        if ((super(e, t), Te(this, "space", r), "number" == typeof n))
            for (; ++o < Se.length; ) {
                const e = Se[o];
                Te(this, Se[o], (n & Ee[e]) === Ee[e]);
            }
    }
}
function Te(e, t, n) {
    n && (e[t] = n);
}
function Le(e) {
    const t = {},
        n = {};
    for (const [r, o] of Object.entries(e.properties)) {
        const i = new Ae(r, e.transform(e.attributes || {}, r), o, e.space);
        e.mustUseProperty &&
            e.mustUseProperty.includes(r) &&
            (i.mustUseProperty = !0),
            (t[r] = i),
            (n[pe(r)] = r),
            (n[pe(i.attribute)] = r);
    }
    return new de(t, n, e.space);
}
Ae.prototype.defined = !0;
const Me = Le({
    properties: {
        ariaActiveDescendant: null,
        ariaAtomic: ye,
        ariaAutoComplete: null,
        ariaBusy: ye,
        ariaChecked: ye,
        ariaColCount: ve,
        ariaColIndex: ve,
        ariaColSpan: ve,
        ariaControls: Ce,
        ariaCurrent: null,
        ariaDescribedBy: Ce,
        ariaDetails: null,
        ariaDisabled: ye,
        ariaDropEffect: Ce,
        ariaErrorMessage: null,
        ariaExpanded: ye,
        ariaFlowTo: Ce,
        ariaGrabbed: ye,
        ariaHasPopup: null,
        ariaHidden: ye,
        ariaInvalid: null,
        ariaKeyShortcuts: null,
        ariaLabel: null,
        ariaLabelledBy: Ce,
        ariaLevel: ve,
        ariaLive: null,
        ariaModal: ye,
        ariaMultiLine: ye,
        ariaMultiSelectable: ye,
        ariaOrientation: null,
        ariaOwns: Ce,
        ariaPlaceholder: null,
        ariaPosInSet: ve,
        ariaPressed: ye,
        ariaReadOnly: ye,
        ariaRelevant: null,
        ariaRequired: ye,
        ariaRoleDescription: Ce,
        ariaRowCount: ve,
        ariaRowIndex: ve,
        ariaRowSpan: ve,
        ariaSelected: ye,
        ariaSetSize: ve,
        ariaSort: null,
        ariaValueMax: ve,
        ariaValueMin: ve,
        ariaValueNow: ve,
        ariaValueText: null,
        role: null,
    },
    transform: (e, t) =>
        "role" === t ? t : "aria-" + t.slice(4).toLowerCase(),
});
function Pe(e, t) {
    return t in e ? e[t] : t;
}
function je(e, t) {
    return Pe(e, t.toLowerCase());
}
const Ne = Le({
        attributes: {
            acceptcharset: "accept-charset",
            classname: "class",
            htmlfor: "for",
            httpequiv: "http-equiv",
        },
        mustUseProperty: ["checked", "multiple", "muted", "selected"],
        properties: {
            abbr: null,
            accept: we,
            acceptCharset: Ce,
            accessKey: Ce,
            action: null,
            allow: null,
            allowFullScreen: ge,
            allowPaymentRequest: ge,
            allowUserMedia: ge,
            alt: null,
            as: null,
            async: ge,
            autoCapitalize: null,
            autoComplete: Ce,
            autoFocus: ge,
            autoPlay: ge,
            blocking: Ce,
            capture: null,
            charSet: null,
            checked: ge,
            cite: null,
            className: Ce,
            cols: ve,
            colSpan: null,
            content: null,
            contentEditable: ye,
            controls: ge,
            controlsList: Ce,
            coords: ve | we,
            crossOrigin: null,
            data: null,
            dateTime: null,
            decoding: null,
            default: ge,
            defer: ge,
            dir: null,
            dirName: null,
            disabled: ge,
            download: xe,
            draggable: ye,
            encType: null,
            enterKeyHint: null,
            fetchPriority: null,
            form: null,
            formAction: null,
            formEncType: null,
            formMethod: null,
            formNoValidate: ge,
            formTarget: null,
            headers: Ce,
            height: ve,
            hidden: xe,
            high: ve,
            href: null,
            hrefLang: null,
            htmlFor: Ce,
            httpEquiv: Ce,
            id: null,
            imageSizes: null,
            imageSrcSet: null,
            inert: ge,
            inputMode: null,
            integrity: null,
            is: null,
            isMap: ge,
            itemId: null,
            itemProp: Ce,
            itemRef: Ce,
            itemScope: ge,
            itemType: Ce,
            kind: null,
            label: null,
            lang: null,
            language: null,
            list: null,
            loading: null,
            loop: ge,
            low: ve,
            manifest: null,
            max: null,
            maxLength: ve,
            media: null,
            method: null,
            min: null,
            minLength: ve,
            multiple: ge,
            muted: ge,
            name: null,
            nonce: null,
            noModule: ge,
            noValidate: ge,
            onAbort: null,
            onAfterPrint: null,
            onAuxClick: null,
            onBeforeMatch: null,
            onBeforePrint: null,
            onBeforeToggle: null,
            onBeforeUnload: null,
            onBlur: null,
            onCancel: null,
            onCanPlay: null,
            onCanPlayThrough: null,
            onChange: null,
            onClick: null,
            onClose: null,
            onContextLost: null,
            onContextMenu: null,
            onContextRestored: null,
            onCopy: null,
            onCueChange: null,
            onCut: null,
            onDblClick: null,
            onDrag: null,
            onDragEnd: null,
            onDragEnter: null,
            onDragExit: null,
            onDragLeave: null,
            onDragOver: null,
            onDragStart: null,
            onDrop: null,
            onDurationChange: null,
            onEmptied: null,
            onEnded: null,
            onError: null,
            onFocus: null,
            onFormData: null,
            onHashChange: null,
            onInput: null,
            onInvalid: null,
            onKeyDown: null,
            onKeyPress: null,
            onKeyUp: null,
            onLanguageChange: null,
            onLoad: null,
            onLoadedData: null,
            onLoadedMetadata: null,
            onLoadEnd: null,
            onLoadStart: null,
            onMessage: null,
            onMessageError: null,
            onMouseDown: null,
            onMouseEnter: null,
            onMouseLeave: null,
            onMouseMove: null,
            onMouseOut: null,
            onMouseOver: null,
            onMouseUp: null,
            onOffline: null,
            onOnline: null,
            onPageHide: null,
            onPageShow: null,
            onPaste: null,
            onPause: null,
            onPlay: null,
            onPlaying: null,
            onPopState: null,
            onProgress: null,
            onRateChange: null,
            onRejectionHandled: null,
            onReset: null,
            onResize: null,
            onScroll: null,
            onScrollEnd: null,
            onSecurityPolicyViolation: null,
            onSeeked: null,
            onSeeking: null,
            onSelect: null,
            onSlotChange: null,
            onStalled: null,
            onStorage: null,
            onSubmit: null,
            onSuspend: null,
            onTimeUpdate: null,
            onToggle: null,
            onUnhandledRejection: null,
            onUnload: null,
            onVolumeChange: null,
            onWaiting: null,
            onWheel: null,
            open: ge,
            optimum: ve,
            pattern: null,
            ping: Ce,
            placeholder: null,
            playsInline: ge,
            popover: null,
            popoverTarget: null,
            popoverTargetAction: null,
            poster: null,
            preload: null,
            readOnly: ge,
            referrerPolicy: null,
            rel: Ce,
            required: ge,
            reversed: ge,
            rows: ve,
            rowSpan: ve,
            sandbox: Ce,
            scope: null,
            scoped: ge,
            seamless: ge,
            selected: ge,
            shadowRootClonable: ge,
            shadowRootDelegatesFocus: ge,
            shadowRootMode: null,
            shape: null,
            size: ve,
            sizes: null,
            slot: null,
            span: ve,
            spellCheck: ye,
            src: null,
            srcDoc: null,
            srcLang: null,
            srcSet: null,
            start: ve,
            step: null,
            style: null,
            tabIndex: ve,
            target: null,
            title: null,
            translate: null,
            type: null,
            typeMustMatch: ge,
            useMap: null,
            value: ye,
            width: ve,
            wrap: null,
            writingSuggestions: null,
            align: null,
            aLink: null,
            archive: Ce,
            axis: null,
            background: null,
            bgColor: null,
            border: ve,
            borderColor: null,
            bottomMargin: ve,
            cellPadding: null,
            cellSpacing: null,
            char: null,
            charOff: null,
            classId: null,
            clear: null,
            code: null,
            codeBase: null,
            codeType: null,
            color: null,
            compact: ge,
            declare: ge,
            event: null,
            face: null,
            frame: null,
            frameBorder: null,
            hSpace: ve,
            leftMargin: ve,
            link: null,
            longDesc: null,
            lowSrc: null,
            marginHeight: ve,
            marginWidth: ve,
            noResize: ge,
            noHref: ge,
            noShade: ge,
            noWrap: ge,
            object: null,
            profile: null,
            prompt: null,
            rev: null,
            rightMargin: ve,
            rules: null,
            scheme: null,
            scrolling: ye,
            standby: null,
            summary: null,
            text: null,
            topMargin: ve,
            valueType: null,
            version: null,
            vAlign: null,
            vLink: null,
            vSpace: ve,
            allowTransparency: null,
            autoCorrect: null,
            autoSave: null,
            disablePictureInPicture: ge,
            disableRemotePlayback: ge,
            prefix: null,
            property: null,
            results: ve,
            security: null,
            unselectable: null,
        },
        space: "html",
        transform: je,
    }),
    Ie = Le({
        attributes: {
            accentHeight: "accent-height",
            alignmentBaseline: "alignment-baseline",
            arabicForm: "arabic-form",
            baselineShift: "baseline-shift",
            capHeight: "cap-height",
            className: "class",
            clipPath: "clip-path",
            clipRule: "clip-rule",
            colorInterpolation: "color-interpolation",
            colorInterpolationFilters: "color-interpolation-filters",
            colorProfile: "color-profile",
            colorRendering: "color-rendering",
            crossOrigin: "crossorigin",
            dataType: "datatype",
            dominantBaseline: "dominant-baseline",
            enableBackground: "enable-background",
            fillOpacity: "fill-opacity",
            fillRule: "fill-rule",
            floodColor: "flood-color",
            floodOpacity: "flood-opacity",
            fontFamily: "font-family",
            fontSize: "font-size",
            fontSizeAdjust: "font-size-adjust",
            fontStretch: "font-stretch",
            fontStyle: "font-style",
            fontVariant: "font-variant",
            fontWeight: "font-weight",
            glyphName: "glyph-name",
            glyphOrientationHorizontal: "glyph-orientation-horizontal",
            glyphOrientationVertical: "glyph-orientation-vertical",
            hrefLang: "hreflang",
            horizAdvX: "horiz-adv-x",
            horizOriginX: "horiz-origin-x",
            horizOriginY: "horiz-origin-y",
            imageRendering: "image-rendering",
            letterSpacing: "letter-spacing",
            lightingColor: "lighting-color",
            markerEnd: "marker-end",
            markerMid: "marker-mid",
            markerStart: "marker-start",
            navDown: "nav-down",
            navDownLeft: "nav-down-left",
            navDownRight: "nav-down-right",
            navLeft: "nav-left",
            navNext: "nav-next",
            navPrev: "nav-prev",
            navRight: "nav-right",
            navUp: "nav-up",
            navUpLeft: "nav-up-left",
            navUpRight: "nav-up-right",
            onAbort: "onabort",
            onActivate: "onactivate",
            onAfterPrint: "onafterprint",
            onBeforePrint: "onbeforeprint",
            onBegin: "onbegin",
            onCancel: "oncancel",
            onCanPlay: "oncanplay",
            onCanPlayThrough: "oncanplaythrough",
            onChange: "onchange",
            onClick: "onclick",
            onClose: "onclose",
            onCopy: "oncopy",
            onCueChange: "oncuechange",
            onCut: "oncut",
            onDblClick: "ondblclick",
            onDrag: "ondrag",
            onDragEnd: "ondragend",
            onDragEnter: "ondragenter",
            onDragExit: "ondragexit",
            onDragLeave: "ondragleave",
            onDragOver: "ondragover",
            onDragStart: "ondragstart",
            onDrop: "ondrop",
            onDurationChange: "ondurationchange",
            onEmptied: "onemptied",
            onEnd: "onend",
            onEnded: "onended",
            onError: "onerror",
            onFocus: "onfocus",
            onFocusIn: "onfocusin",
            onFocusOut: "onfocusout",
            onHashChange: "onhashchange",
            onInput: "oninput",
            onInvalid: "oninvalid",
            onKeyDown: "onkeydown",
            onKeyPress: "onkeypress",
            onKeyUp: "onkeyup",
            onLoad: "onload",
            onLoadedData: "onloadeddata",
            onLoadedMetadata: "onloadedmetadata",
            onLoadStart: "onloadstart",
            onMessage: "onmessage",
            onMouseDown: "onmousedown",
            onMouseEnter: "onmouseenter",
            onMouseLeave: "onmouseleave",
            onMouseMove: "onmousemove",
            onMouseOut: "onmouseout",
            onMouseOver: "onmouseover",
            onMouseUp: "onmouseup",
            onMouseWheel: "onmousewheel",
            onOffline: "onoffline",
            onOnline: "ononline",
            onPageHide: "onpagehide",
            onPageShow: "onpageshow",
            onPaste: "onpaste",
            onPause: "onpause",
            onPlay: "onplay",
            onPlaying: "onplaying",
            onPopState: "onpopstate",
            onProgress: "onprogress",
            onRateChange: "onratechange",
            onRepeat: "onrepeat",
            onReset: "onreset",
            onResize: "onresize",
            onScroll: "onscroll",
            onSeeked: "onseeked",
            onSeeking: "onseeking",
            onSelect: "onselect",
            onShow: "onshow",
            onStalled: "onstalled",
            onStorage: "onstorage",
            onSubmit: "onsubmit",
            onSuspend: "onsuspend",
            onTimeUpdate: "ontimeupdate",
            onToggle: "ontoggle",
            onUnload: "onunload",
            onVolumeChange: "onvolumechange",
            onWaiting: "onwaiting",
            onZoom: "onzoom",
            overlinePosition: "overline-position",
            overlineThickness: "overline-thickness",
            paintOrder: "paint-order",
            panose1: "panose-1",
            pointerEvents: "pointer-events",
            referrerPolicy: "referrerpolicy",
            renderingIntent: "rendering-intent",
            shapeRendering: "shape-rendering",
            stopColor: "stop-color",
            stopOpacity: "stop-opacity",
            strikethroughPosition: "strikethrough-position",
            strikethroughThickness: "strikethrough-thickness",
            strokeDashArray: "stroke-dasharray",
            strokeDashOffset: "stroke-dashoffset",
            strokeLineCap: "stroke-linecap",
            strokeLineJoin: "stroke-linejoin",
            strokeMiterLimit: "stroke-miterlimit",
            strokeOpacity: "stroke-opacity",
            strokeWidth: "stroke-width",
            tabIndex: "tabindex",
            textAnchor: "text-anchor",
            textDecoration: "text-decoration",
            textRendering: "text-rendering",
            transformOrigin: "transform-origin",
            typeOf: "typeof",
            underlinePosition: "underline-position",
            underlineThickness: "underline-thickness",
            unicodeBidi: "unicode-bidi",
            unicodeRange: "unicode-range",
            unitsPerEm: "units-per-em",
            vAlphabetic: "v-alphabetic",
            vHanging: "v-hanging",
            vIdeographic: "v-ideographic",
            vMathematical: "v-mathematical",
            vectorEffect: "vector-effect",
            vertAdvY: "vert-adv-y",
            vertOriginX: "vert-origin-x",
            vertOriginY: "vert-origin-y",
            wordSpacing: "word-spacing",
            writingMode: "writing-mode",
            xHeight: "x-height",
            playbackOrder: "playbackorder",
            timelineBegin: "timelinebegin",
        },
        properties: {
            about: be,
            accentHeight: ve,
            accumulate: null,
            additive: null,
            alignmentBaseline: null,
            alphabetic: ve,
            amplitude: ve,
            arabicForm: null,
            ascent: ve,
            attributeName: null,
            attributeType: null,
            azimuth: ve,
            bandwidth: null,
            baselineShift: null,
            baseFrequency: null,
            baseProfile: null,
            bbox: null,
            begin: null,
            bias: ve,
            by: null,
            calcMode: null,
            capHeight: ve,
            className: Ce,
            clip: null,
            clipPath: null,
            clipPathUnits: null,
            clipRule: null,
            color: null,
            colorInterpolation: null,
            colorInterpolationFilters: null,
            colorProfile: null,
            colorRendering: null,
            content: null,
            contentScriptType: null,
            contentStyleType: null,
            crossOrigin: null,
            cursor: null,
            cx: null,
            cy: null,
            d: null,
            dataType: null,
            defaultAction: null,
            descent: ve,
            diffuseConstant: ve,
            direction: null,
            display: null,
            dur: null,
            divisor: ve,
            dominantBaseline: null,
            download: ge,
            dx: null,
            dy: null,
            edgeMode: null,
            editable: null,
            elevation: ve,
            enableBackground: null,
            end: null,
            event: null,
            exponent: ve,
            externalResourcesRequired: null,
            fill: null,
            fillOpacity: ve,
            fillRule: null,
            filter: null,
            filterRes: null,
            filterUnits: null,
            floodColor: null,
            floodOpacity: null,
            focusable: null,
            focusHighlight: null,
            fontFamily: null,
            fontSize: null,
            fontSizeAdjust: null,
            fontStretch: null,
            fontStyle: null,
            fontVariant: null,
            fontWeight: null,
            format: null,
            fr: null,
            from: null,
            fx: null,
            fy: null,
            g1: we,
            g2: we,
            glyphName: we,
            glyphOrientationHorizontal: null,
            glyphOrientationVertical: null,
            glyphRef: null,
            gradientTransform: null,
            gradientUnits: null,
            handler: null,
            hanging: ve,
            hatchContentUnits: null,
            hatchUnits: null,
            height: null,
            href: null,
            hrefLang: null,
            horizAdvX: ve,
            horizOriginX: ve,
            horizOriginY: ve,
            id: null,
            ideographic: ve,
            imageRendering: null,
            initialVisibility: null,
            in: null,
            in2: null,
            intercept: ve,
            k: ve,
            k1: ve,
            k2: ve,
            k3: ve,
            k4: ve,
            kernelMatrix: be,
            kernelUnitLength: null,
            keyPoints: null,
            keySplines: null,
            keyTimes: null,
            kerning: null,
            lang: null,
            lengthAdjust: null,
            letterSpacing: null,
            lightingColor: null,
            limitingConeAngle: ve,
            local: null,
            markerEnd: null,
            markerMid: null,
            markerStart: null,
            markerHeight: null,
            markerUnits: null,
            markerWidth: null,
            mask: null,
            maskContentUnits: null,
            maskUnits: null,
            mathematical: null,
            max: null,
            media: null,
            mediaCharacterEncoding: null,
            mediaContentEncodings: null,
            mediaSize: ve,
            mediaTime: null,
            method: null,
            min: null,
            mode: null,
            name: null,
            navDown: null,
            navDownLeft: null,
            navDownRight: null,
            navLeft: null,
            navNext: null,
            navPrev: null,
            navRight: null,
            navUp: null,
            navUpLeft: null,
            navUpRight: null,
            numOctaves: null,
            observer: null,
            offset: null,
            onAbort: null,
            onActivate: null,
            onAfterPrint: null,
            onBeforePrint: null,
            onBegin: null,
            onCancel: null,
            onCanPlay: null,
            onCanPlayThrough: null,
            onChange: null,
            onClick: null,
            onClose: null,
            onCopy: null,
            onCueChange: null,
            onCut: null,
            onDblClick: null,
            onDrag: null,
            onDragEnd: null,
            onDragEnter: null,
            onDragExit: null,
            onDragLeave: null,
            onDragOver: null,
            onDragStart: null,
            onDrop: null,
            onDurationChange: null,
            onEmptied: null,
            onEnd: null,
            onEnded: null,
            onError: null,
            onFocus: null,
            onFocusIn: null,
            onFocusOut: null,
            onHashChange: null,
            onInput: null,
            onInvalid: null,
            onKeyDown: null,
            onKeyPress: null,
            onKeyUp: null,
            onLoad: null,
            onLoadedData: null,
            onLoadedMetadata: null,
            onLoadStart: null,
            onMessage: null,
            onMouseDown: null,
            onMouseEnter: null,
            onMouseLeave: null,
            onMouseMove: null,
            onMouseOut: null,
            onMouseOver: null,
            onMouseUp: null,
            onMouseWheel: null,
            onOffline: null,
            onOnline: null,
            onPageHide: null,
            onPageShow: null,
            onPaste: null,
            onPause: null,
            onPlay: null,
            onPlaying: null,
            onPopState: null,
            onProgress: null,
            onRateChange: null,
            onRepeat: null,
            onReset: null,
            onResize: null,
            onScroll: null,
            onSeeked: null,
            onSeeking: null,
            onSelect: null,
            onShow: null,
            onStalled: null,
            onStorage: null,
            onSubmit: null,
            onSuspend: null,
            onTimeUpdate: null,
            onToggle: null,
            onUnload: null,
            onVolumeChange: null,
            onWaiting: null,
            onZoom: null,
            opacity: null,
            operator: null,
            order: null,
            orient: null,
            orientation: null,
            origin: null,
            overflow: null,
            overlay: null,
            overlinePosition: ve,
            overlineThickness: ve,
            paintOrder: null,
            panose1: null,
            path: null,
            pathLength: ve,
            patternContentUnits: null,
            patternTransform: null,
            patternUnits: null,
            phase: null,
            ping: Ce,
            pitch: null,
            playbackOrder: null,
            pointerEvents: null,
            points: null,
            pointsAtX: ve,
            pointsAtY: ve,
            pointsAtZ: ve,
            preserveAlpha: null,
            preserveAspectRatio: null,
            primitiveUnits: null,
            propagate: null,
            property: be,
            r: null,
            radius: null,
            referrerPolicy: null,
            refX: null,
            refY: null,
            rel: be,
            rev: be,
            renderingIntent: null,
            repeatCount: null,
            repeatDur: null,
            requiredExtensions: be,
            requiredFeatures: be,
            requiredFonts: be,
            requiredFormats: be,
            resource: null,
            restart: null,
            result: null,
            rotate: null,
            rx: null,
            ry: null,
            scale: null,
            seed: null,
            shapeRendering: null,
            side: null,
            slope: null,
            snapshotTime: null,
            specularConstant: ve,
            specularExponent: ve,
            spreadMethod: null,
            spacing: null,
            startOffset: null,
            stdDeviation: null,
            stemh: null,
            stemv: null,
            stitchTiles: null,
            stopColor: null,
            stopOpacity: null,
            strikethroughPosition: ve,
            strikethroughThickness: ve,
            string: null,
            stroke: null,
            strokeDashArray: be,
            strokeDashOffset: null,
            strokeLineCap: null,
            strokeLineJoin: null,
            strokeMiterLimit: ve,
            strokeOpacity: ve,
            strokeWidth: null,
            style: null,
            surfaceScale: ve,
            syncBehavior: null,
            syncBehaviorDefault: null,
            syncMaster: null,
            syncTolerance: null,
            syncToleranceDefault: null,
            systemLanguage: be,
            tabIndex: ve,
            tableValues: null,
            target: null,
            targetX: ve,
            targetY: ve,
            textAnchor: null,
            textDecoration: null,
            textRendering: null,
            textLength: null,
            timelineBegin: null,
            title: null,
            transformBehavior: null,
            type: null,
            typeOf: be,
            to: null,
            transform: null,
            transformOrigin: null,
            u1: null,
            u2: null,
            underlinePosition: ve,
            underlineThickness: ve,
            unicode: null,
            unicodeBidi: null,
            unicodeRange: null,
            unitsPerEm: ve,
            values: null,
            vAlphabetic: ve,
            vMathematical: ve,
            vectorEffect: null,
            vHanging: ve,
            vIdeographic: ve,
            version: null,
            vertAdvY: ve,
            vertOriginX: ve,
            vertOriginY: ve,
            viewBox: null,
            viewTarget: null,
            visibility: null,
            width: null,
            widths: null,
            wordSpacing: null,
            writingMode: null,
            x: null,
            x1: null,
            x2: null,
            xChannelSelector: null,
            xHeight: ve,
            y: null,
            y1: null,
            y2: null,
            yChannelSelector: null,
            z: null,
            zoomAndPan: null,
        },
        space: "svg",
        transform: Pe,
    }),
    De = Le({
        properties: {
            xLinkActuate: null,
            xLinkArcRole: null,
            xLinkHref: null,
            xLinkRole: null,
            xLinkShow: null,
            xLinkTitle: null,
            xLinkType: null,
        },
        space: "xlink",
        transform: (e, t) => "xlink:" + t.slice(5).toLowerCase(),
    }),
    Ve = Le({
        attributes: { xmlnsxlink: "xmlns:xlink" },
        properties: { xmlnsXLink: null, xmlns: null },
        space: "xmlns",
        transform: je,
    }),
    Re = Le({
        properties: { xmlBase: null, xmlLang: null, xmlSpace: null },
        space: "xml",
        transform: (e, t) => "xml:" + t.slice(3).toLowerCase(),
    }),
    _e = {
        classId: "classID",
        dataType: "datatype",
        itemId: "itemID",
        strokeDashArray: "strokeDasharray",
        strokeDashOffset: "strokeDashoffset",
        strokeLineCap: "strokeLinecap",
        strokeLineJoin: "strokeLinejoin",
        strokeMiterLimit: "strokeMiterlimit",
        typeOf: "typeof",
        xLinkActuate: "xlinkActuate",
        xLinkArcRole: "xlinkArcrole",
        xLinkHref: "xlinkHref",
        xLinkRole: "xlinkRole",
        xLinkShow: "xlinkShow",
        xLinkTitle: "xlinkTitle",
        xLinkType: "xlinkType",
        xmlnsXLink: "xmlnsXlink",
    },
    Oe = /[A-Z]/g,
    He = /-[a-z]/g,
    Fe = /^data[-\w.:]+$/i;
function Be(e) {
    return "-" + e.toLowerCase();
}
function Ue(e) {
    return e.charAt(1).toUpperCase();
}
const Ze = he([Me, Ne, De, Ve, Re], "html"),
    ze = he([Me, Ie, De, Ve, Re], "svg");
var $e,
    We,
    qe,
    Ke = {};
function Ye() {
    if (qe) return Ke;
    qe = 1;
    var e =
        (Ke && Ke.__importDefault) ||
        function (e) {
            return e && e.__esModule ? e : { default: e };
        };
    Object.defineProperty(Ke, "__esModule", { value: !0 }),
        (Ke.default = function (e, n) {
            var r = null;
            if (!e || "string" != typeof e) return r;
            var o = (0, t.default)(e),
                i = "function" == typeof n;
            return (
                o.forEach(function (e) {
                    if ("declaration" === e.type) {
                        var t = e.property,
                            o = e.value;
                        i ? n(t, o, e) : o && ((r = r || {})[t] = o);
                    }
                }),
                r
            );
        });
    var t = e(
        (function () {
            if (We) return $e;
            We = 1;
            var e = /\/\*[^*]*\*+([^/*][^*]*\*+)*\//g,
                t = /\n/g,
                n = /^\s*/,
                r = /^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/,
                o = /^:\s*/,
                i = /^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};])+)/,
                s = /^[;\s]*/,
                a = /^\s+|\s+$/g,
                l = "";
            function c(e) {
                return e ? e.replace(a, l) : l;
            }
            return ($e = function (a, u) {
                if ("string" != typeof a)
                    throw new TypeError("First argument must be a string");
                if (!a) return [];
                u = u || {};
                var d = 1,
                    h = 1;
                function p(e) {
                    var n = e.match(t);
                    n && (d += n.length);
                    var r = e.lastIndexOf("\n");
                    h = ~r ? e.length - r : h + e.length;
                }
                function f() {
                    var e = { line: d, column: h };
                    return function (t) {
                        return (t.position = new m(e)), x(), t;
                    };
                }
                function m(e) {
                    (this.start = e),
                        (this.end = { line: d, column: h }),
                        (this.source = u.source);
                }
                function g(e) {
                    var t = new Error(u.source + ":" + d + ":" + h + ": " + e);
                    if (
                        ((t.reason = e),
                        (t.filename = u.source),
                        (t.line = d),
                        (t.column = h),
                        (t.source = a),
                        !u.silent)
                    )
                        throw t;
                }
                function y(e) {
                    var t = e.exec(a);
                    if (t) {
                        var n = t[0];
                        return p(n), (a = a.slice(n.length)), t;
                    }
                }
                function x() {
                    y(n);
                }
                function v(e) {
                    var t;
                    for (e = e || []; (t = C()); ) !1 !== t && e.push(t);
                    return e;
                }
                function C() {
                    var e = f();
                    if ("/" == a.charAt(0) && "*" == a.charAt(1)) {
                        for (
                            var t = 2;
                            l != a.charAt(t) &&
                            ("*" != a.charAt(t) || "/" != a.charAt(t + 1));

                        )
                            ++t;
                        if (((t += 2), l === a.charAt(t - 1)))
                            return g("End of comment missing");
                        var n = a.slice(2, t - 2);
                        return (
                            (h += 2),
                            p(n),
                            (a = a.slice(t)),
                            (h += 2),
                            e({ type: "comment", comment: n })
                        );
                    }
                }
                function w() {
                    var t = f(),
                        n = y(r);
                    if (n) {
                        if ((C(), !y(o))) return g("property missing ':'");
                        var a = y(i),
                            u = t({
                                type: "declaration",
                                property: c(n[0].replace(e, l)),
                                value: a ? c(a[0].replace(e, l)) : l,
                            });
                        return y(s), u;
                    }
                }
                return (
                    (m.prototype.content = a),
                    x(),
                    (function () {
                        var e,
                            t = [];
                        for (v(t); (e = w()); ) !1 !== e && (t.push(e), v(t));
                        return t;
                    })()
                );
            });
        })()
    );
    return Ke;
}
var Xe,
    Ge,
    Qe,
    Je = {};
function et() {
    if (Xe) return Je;
    (Xe = 1),
        Object.defineProperty(Je, "__esModule", { value: !0 }),
        (Je.camelCase = void 0);
    var e = /^--[a-zA-Z0-9_-]+$/,
        t = /-([a-z])/g,
        n = /^[^-]+$/,
        r = /^-(webkit|moz|ms|o|khtml)-/,
        o = /^-(ms)-/,
        i = function (e, t) {
            return t.toUpperCase();
        },
        s = function (e, t) {
            return "".concat(t, "-");
        };
    return (
        (Je.camelCase = function (a, l) {
            return (
                void 0 === l && (l = {}),
                (function (t) {
                    return !t || n.test(t) || e.test(t);
                })(a)
                    ? a
                    : ((a = a.toLowerCase()),
                      (a = l.reactCompat
                          ? a.replace(o, s)
                          : a.replace(r, s)).replace(t, i))
            );
        }),
        Je
    );
}
const tt = T(
        (function () {
            if (Qe) return Ge;
            Qe = 1;
            var e = (
                    (Ge && Ge.__importDefault) ||
                    function (e) {
                        return e && e.__esModule ? e : { default: e };
                    }
                )(Ye()),
                t = et();
            function n(n, r) {
                var o = {};
                return n && "string" == typeof n
                    ? ((0, e.default)(n, function (e, n) {
                          e && n && (o[(0, t.camelCase)(e, r)] = n);
                      }),
                      o)
                    : o;
            }
            return (n.default = n), (Ge = n);
        })()
    ),
    nt = ot("end"),
    rt = ot("start");
function ot(e) {
    return function (t) {
        const n = (t && t.position && t.position[e]) || {};
        if (
            "number" == typeof n.line &&
            n.line > 0 &&
            "number" == typeof n.column &&
            n.column > 0
        )
            return {
                line: n.line,
                column: n.column,
                offset:
                    "number" == typeof n.offset && n.offset > -1
                        ? n.offset
                        : void 0,
            };
    };
}
function it(e) {
    return e && "object" == typeof e
        ? "position" in e || "type" in e
            ? at(e.position)
            : "start" in e || "end" in e
            ? at(e)
            : "line" in e || "column" in e
            ? st(e)
            : ""
        : "";
}
function st(e) {
    return lt(e && e.line) + ":" + lt(e && e.column);
}
function at(e) {
    return st(e && e.start) + "-" + st(e && e.end);
}
function lt(e) {
    return e && "number" == typeof e ? e : 1;
}
class ct extends Error {
    constructor(e, t, n) {
        super(), "string" == typeof t && ((n = t), (t = void 0));
        let r = "",
            o = {},
            i = !1;
        if (
            (t &&
                (o =
                    ("line" in t && "column" in t) ||
                    ("start" in t && "end" in t)
                        ? { place: t }
                        : "type" in t
                        ? { ancestors: [t], place: t.position }
                        : { ...t }),
            "string" == typeof e
                ? (r = e)
                : !o.cause && e && ((i = !0), (r = e.message), (o.cause = e)),
            !o.ruleId && !o.source && "string" == typeof n)
        ) {
            const e = n.indexOf(":");
            -1 === e
                ? (o.ruleId = n)
                : ((o.source = n.slice(0, e)), (o.ruleId = n.slice(e + 1)));
        }
        if (!o.place && o.ancestors && o.ancestors) {
            const e = o.ancestors[o.ancestors.length - 1];
            e && (o.place = e.position);
        }
        const s = o.place && "start" in o.place ? o.place.start : o.place;
        (this.ancestors = o.ancestors || void 0),
            (this.cause = o.cause || void 0),
            (this.column = s ? s.column : void 0),
            (this.fatal = void 0),
            (this.file = ""),
            (this.message = r),
            (this.line = s ? s.line : void 0),
            (this.name = it(o.place) || "1:1"),
            (this.place = o.place || void 0),
            (this.reason = this.message),
            (this.ruleId = o.ruleId || void 0),
            (this.source = o.source || void 0),
            (this.stack =
                i && o.cause && "string" == typeof o.cause.stack
                    ? o.cause.stack
                    : ""),
            (this.actual = void 0),
            (this.expected = void 0),
            (this.note = void 0),
            (this.url = void 0);
    }
}
(ct.prototype.file = ""),
    (ct.prototype.name = ""),
    (ct.prototype.reason = ""),
    (ct.prototype.message = ""),
    (ct.prototype.stack = ""),
    (ct.prototype.column = void 0),
    (ct.prototype.line = void 0),
    (ct.prototype.ancestors = void 0),
    (ct.prototype.cause = void 0),
    (ct.prototype.fatal = void 0),
    (ct.prototype.place = void 0),
    (ct.prototype.ruleId = void 0),
    (ct.prototype.source = void 0);
const ut = {}.hasOwnProperty,
    dt = new Map(),
    ht = /[A-Z]/g,
    pt = new Set(["table", "tbody", "thead", "tfoot", "tr"]),
    ft = new Set(["td", "th"]),
    mt = "https://github.com/syntax-tree/hast-util-to-jsx-runtime";
function gt(e, t) {
    if (!t || void 0 === t.Fragment)
        throw new TypeError("Expected `Fragment` in options");
    const n = t.filePath || void 0;
    let r;
    if (t.development) {
        if ("function" != typeof t.jsxDEV)
            throw new TypeError(
                "Expected `jsxDEV` in options when `development: true`"
            );
        r = (function (e, t) {
            return n;
            function n(n, r, o, i) {
                const s = Array.isArray(o.children),
                    a = rt(n);
                return t(
                    r,
                    o,
                    i,
                    s,
                    {
                        columnNumber: a ? a.column - 1 : void 0,
                        fileName: e,
                        lineNumber: a ? a.line : void 0,
                    },
                    void 0
                );
            }
        })(n, t.jsxDEV);
    } else {
        if ("function" != typeof t.jsx)
            throw new TypeError("Expected `jsx` in production options");
        if ("function" != typeof t.jsxs)
            throw new TypeError("Expected `jsxs` in production options");
        r = (function (e, t, n) {
            return r;
            function r(e, r, o, i) {
                const s = Array.isArray(o.children) ? n : t;
                return i ? s(r, o, i) : s(r, o);
            }
        })(0, t.jsx, t.jsxs);
    }
    const o = {
            Fragment: t.Fragment,
            ancestors: [],
            components: t.components || {},
            create: r,
            elementAttributeNameCase: t.elementAttributeNameCase || "react",
            evaluater: t.createEvaluater ? t.createEvaluater() : void 0,
            filePath: n,
            ignoreInvalidStyle: t.ignoreInvalidStyle || !1,
            passKeys: !1 !== t.passKeys,
            passNode: t.passNode || !1,
            schema: "svg" === t.space ? ze : Ze,
            stylePropertyNameCase: t.stylePropertyNameCase || "dom",
            tableCellAlignToStyle: !1 !== t.tableCellAlignToStyle,
        },
        i = yt(o, e, void 0);
    return i && "string" != typeof i
        ? i
        : o.create(e, o.Fragment, { children: i || void 0 }, void 0);
}
function yt(e, t, n) {
    return "element" === t.type
        ? (function (e, t, n) {
              const r = e.schema;
              let o = r;
              "svg" === t.tagName.toLowerCase() &&
                  "html" === r.space &&
                  ((o = ze), (e.schema = o));
              e.ancestors.push(t);
              const i = bt(e, t.tagName, !1),
                  s = (function (e, t) {
                      const n = {};
                      let r, o;
                      for (o in t.properties)
                          if ("children" !== o && ut.call(t.properties, o)) {
                              const i = wt(e, o, t.properties[o]);
                              if (i) {
                                  const [o, s] = i;
                                  e.tableCellAlignToStyle &&
                                  "align" === o &&
                                  "string" == typeof s &&
                                  ft.has(t.tagName)
                                      ? (r = s)
                                      : (n[o] = s);
                              }
                          }
                      if (r) {
                          (n.style || (n.style = {}))[
                              "css" === e.stylePropertyNameCase
                                  ? "text-align"
                                  : "textAlign"
                          ] = r;
                      }
                      return n;
                  })(e, t);
              let a = Ct(e, t);
              pt.has(t.tagName) &&
                  (a = a.filter(function (e) {
                      return (
                          "string" != typeof e ||
                          !("object" == typeof (t = e)
                              ? "text" === t.type && ue(t.value)
                              : ue(t))
                      );
                      var t;
                  }));
              return (
                  xt(e, s, i, t),
                  vt(s, a),
                  e.ancestors.pop(),
                  (e.schema = r),
                  e.create(t, i, s, n)
              );
          })(e, t, n)
        : "mdxFlowExpression" === t.type || "mdxTextExpression" === t.type
        ? (function (e, t) {
              if (t.data && t.data.estree && e.evaluater) {
                  const n = t.data.estree.body[0];
                  return n.type, e.evaluater.evaluateExpression(n.expression);
              }
              kt(e, t.position);
          })(e, t)
        : "mdxJsxFlowElement" === t.type || "mdxJsxTextElement" === t.type
        ? (function (e, t, n) {
              const r = e.schema;
              let o = r;
              "svg" === t.name &&
                  "html" === r.space &&
                  ((o = ze), (e.schema = o));
              e.ancestors.push(t);
              const i = null === t.name ? e.Fragment : bt(e, t.name, !0),
                  s = (function (e, t) {
                      const n = {};
                      for (const r of t.attributes)
                          if ("mdxJsxExpressionAttribute" === r.type)
                              if (r.data && r.data.estree && e.evaluater) {
                                  const t = r.data.estree.body[0];
                                  re(t.type);
                                  const o = t.expression;
                                  re(o.type);
                                  const i = o.properties[0];
                                  re(i.type),
                                      Object.assign(
                                          n,
                                          e.evaluater.evaluateExpression(
                                              i.argument
                                          )
                                      );
                              } else kt(e, t.position);
                          else {
                              const o = r.name;
                              let i;
                              if (r.value && "object" == typeof r.value)
                                  if (
                                      r.value.data &&
                                      r.value.data.estree &&
                                      e.evaluater
                                  ) {
                                      const t = r.value.data.estree.body[0];
                                      re(t.type),
                                          (i = e.evaluater.evaluateExpression(
                                              t.expression
                                          ));
                                  } else kt(e, t.position);
                              else i = null === r.value || r.value;
                              n[o] = i;
                          }
                      return n;
                  })(e, t),
                  a = Ct(e, t);
              return (
                  xt(e, s, i, t),
                  vt(s, a),
                  e.ancestors.pop(),
                  (e.schema = r),
                  e.create(t, i, s, n)
              );
          })(e, t, n)
        : "mdxjsEsm" === t.type
        ? (function (e, t) {
              if (t.data && t.data.estree && e.evaluater)
                  return e.evaluater.evaluateProgram(t.data.estree);
              kt(e, t.position);
          })(e, t)
        : "root" === t.type
        ? (function (e, t, n) {
              const r = {};
              return vt(r, Ct(e, t)), e.create(t, e.Fragment, r, n);
          })(e, t, n)
        : "text" === t.type
        ? (function (e, t) {
              return t.value;
          })(0, t)
        : void 0;
}
function xt(e, t, n, r) {
    "string" != typeof n && n !== e.Fragment && e.passNode && (t.node = r);
}
function vt(e, t) {
    if (t.length > 0) {
        const n = t.length > 1 ? t : t[0];
        n && (e.children = n);
    }
}
function Ct(e, t) {
    const n = [];
    let r = -1;
    const o = e.passKeys ? new Map() : dt;
    for (; ++r < t.children.length; ) {
        const i = t.children[r];
        let s;
        if (e.passKeys) {
            const e =
                "element" === i.type
                    ? i.tagName
                    : "mdxJsxFlowElement" === i.type ||
                      "mdxJsxTextElement" === i.type
                    ? i.name
                    : void 0;
            if (e) {
                const t = o.get(e) || 0;
                (s = e + "-" + t), o.set(e, t + 1);
            }
        }
        const a = yt(e, i, s);
        void 0 !== a && n.push(a);
    }
    return n;
}
function wt(e, t, n) {
    const r = (function (e, t) {
        const n = pe(t);
        let r = t,
            o = fe;
        if (n in e.normal) return e.property[e.normal[n]];
        if (n.length > 4 && "data" === n.slice(0, 4) && Fe.test(t)) {
            if ("-" === t.charAt(4)) {
                const e = t.slice(5).replace(He, Ue);
                r = "data" + e.charAt(0).toUpperCase() + e.slice(1);
            } else {
                const e = t.slice(4);
                if (!He.test(e)) {
                    let n = e.replace(Oe, Be);
                    "-" !== n.charAt(0) && (n = "-" + n), (t = "data" + n);
                }
            }
            o = Ae;
        }
        return new o(r, t);
    })(e.schema, t);
    if (!(null == n || ("number" == typeof n && Number.isNaN(n)))) {
        if (
            (Array.isArray(n) &&
                (n = r.commaSeparated
                    ? (function (e) {
                          const t = {};
                          return ("" === e[e.length - 1] ? [...e, ""] : e)
                              .join(
                                  (t.padRight ? " " : "") +
                                      "," +
                                      (!1 === t.padLeft ? "" : " ")
                              )
                              .trim();
                      })(n)
                    : n.join(" ").trim()),
            "style" === r.property)
        ) {
            let t =
                "object" == typeof n
                    ? n
                    : (function (e, t) {
                          try {
                              return tt(t, { reactCompat: !0 });
                          } catch (n) {
                              if (e.ignoreInvalidStyle) return {};
                              const t = n,
                                  r = new ct("Cannot parse `style` attribute", {
                                      ancestors: e.ancestors,
                                      cause: t,
                                      ruleId: "style",
                                      source: "hast-util-to-jsx-runtime",
                                  });
                              throw (
                                  ((r.file = e.filePath || void 0),
                                  (r.url =
                                      mt + "#cannot-parse-style-attribute"),
                                  r)
                              );
                          }
                      })(e, String(n));
            return (
                "css" === e.stylePropertyNameCase &&
                    (t = (function (e) {
                        const t = {};
                        let n;
                        for (n in e) ut.call(e, n) && (t[Et(n)] = e[n]);
                        return t;
                    })(t)),
                ["style", t]
            );
        }
        return [
            "react" === e.elementAttributeNameCase && r.space
                ? _e[r.property] || r.property
                : r.attribute,
            n,
        ];
    }
}
function bt(e, t, n) {
    let r;
    if (n)
        if (t.includes(".")) {
            const e = t.split(".");
            let n,
                o = -1;
            for (; ++o < e.length; ) {
                const t = le(e[o])
                    ? { type: "Identifier", name: e[o] }
                    : { type: "Literal", value: e[o] };
                n = n
                    ? {
                          type: "MemberExpression",
                          object: n,
                          property: t,
                          computed: Boolean(o && "Literal" === t.type),
                          optional: !1,
                      }
                    : t;
            }
            r = n;
        } else
            r =
                le(t) && !/^[a-z]/.test(t)
                    ? { type: "Identifier", name: t }
                    : { type: "Literal", value: t };
    else r = { type: "Literal", value: t };
    if ("Literal" === r.type) {
        const t = r.value;
        return ut.call(e.components, t) ? e.components[t] : t;
    }
    if (e.evaluater) return e.evaluater.evaluateExpression(r);
    kt(e);
}
function kt(e, t) {
    const n = new ct("Cannot handle MDX estrees without `createEvaluater`", {
        ancestors: e.ancestors,
        place: t,
        ruleId: "mdx-estree",
        source: "hast-util-to-jsx-runtime",
    });
    throw (
        ((n.file = e.filePath || void 0),
        (n.url = mt + "#cannot-handle-mdx-estrees-without-createevaluater"),
        n)
    );
}
function Et(e) {
    let t = e.replace(ht, St);
    return "ms-" === t.slice(0, 3) && (t = "-" + t), t;
}
function St(e) {
    return "-" + e.toLowerCase();
}
const At = {
        action: ["form"],
        cite: ["blockquote", "del", "ins", "q"],
        data: ["object"],
        formAction: ["button", "input"],
        href: ["a", "area", "base", "link"],
        icon: ["menuitem"],
        itemId: null,
        manifest: ["html"],
        ping: ["a", "area"],
        poster: ["video"],
        src: [
            "audio",
            "embed",
            "iframe",
            "img",
            "input",
            "script",
            "source",
            "track",
            "video",
        ],
    },
    Tt = {};
function Lt(e, t, n) {
    if (
        (function (e) {
            return Boolean(e && "object" == typeof e);
        })(e)
    ) {
        if ("value" in e) return "html" !== e.type || n ? e.value : "";
        if (t && "alt" in e && e.alt) return e.alt;
        if ("children" in e) return Mt(e.children, t, n);
    }
    return Array.isArray(e) ? Mt(e, t, n) : "";
}
function Mt(e, t, n) {
    const r = [];
    let o = -1;
    for (; ++o < e.length; ) r[o] = Lt(e[o], t, n);
    return r.join("");
}
const Pt = document.createElement("i");
function jt(e) {
    const t = "&" + e + ";";
    Pt.innerHTML = t;
    const n = Pt.textContent;
    return (59 !== n.charCodeAt(n.length - 1) || "semi" === e) && n !== t && n;
}
function Nt(e, t, n, r) {
    const o = e.length;
    let i,
        s = 0;
    if (
        ((t = t < 0 ? (-t > o ? 0 : o + t) : t > o ? o : t),
        (n = n > 0 ? n : 0),
        r.length < 1e4)
    )
        (i = Array.from(r)), i.unshift(t, n), e.splice(...i);
    else
        for (n && e.splice(t, n); s < r.length; )
            (i = r.slice(s, s + 1e4)),
                i.unshift(t, 0),
                e.splice(...i),
                (s += 1e4),
                (t += 1e4);
}
function It(e, t) {
    return e.length > 0 ? (Nt(e, e.length, 0, t), e) : t;
}
const Dt = {}.hasOwnProperty;
function Vt(e, t) {
    let n;
    for (n in t) {
        const r = (Dt.call(e, n) ? e[n] : void 0) || (e[n] = {}),
            o = t[n];
        let i;
        if (o)
            for (i in o) {
                Dt.call(r, i) || (r[i] = []);
                const e = o[i];
                Rt(r[i], Array.isArray(e) ? e : e ? [e] : []);
            }
    }
}
function Rt(e, t) {
    let n = -1;
    const r = [];
    for (; ++n < t.length; ) ("after" === t[n].add ? e : r).push(t[n]);
    Nt(e, 0, 0, r);
}
function _t(e, t) {
    const n = Number.parseInt(e, t);
    return n < 9 ||
        11 === n ||
        (n > 13 && n < 32) ||
        (n > 126 && n < 160) ||
        (n > 55295 && n < 57344) ||
        (n > 64975 && n < 65008) ||
        !(65535 & ~n) ||
        65534 == (65535 & n) ||
        n > 1114111
        ? "�"
        : String.fromCodePoint(n);
}
function Ot(e) {
    return e
        .replace(/[\t\n\r ]+/g, " ")
        .replace(/^ | $/g, "")
        .toLowerCase()
        .toUpperCase();
}
const Ht = Gt(/[A-Za-z]/),
    Ft = Gt(/[\dA-Za-z]/),
    Bt = Gt(/[#-'*+\--9=?A-Z^-~]/);
function Ut(e) {
    return null !== e && (e < 32 || 127 === e);
}
const Zt = Gt(/\d/),
    zt = Gt(/[\dA-Fa-f]/),
    $t = Gt(/[!-/:-@[-`{-~]/);
function Wt(e) {
    return null !== e && e < -2;
}
function qt(e) {
    return null !== e && (e < 0 || 32 === e);
}
function Kt(e) {
    return -2 === e || -1 === e || 32 === e;
}
const Yt = Gt(new RegExp("\\p{P}|\\p{S}", "u")),
    Xt = Gt(/\s/);
function Gt(e) {
    return function (t) {
        return null !== t && t > -1 && e.test(String.fromCharCode(t));
    };
}
function Qt(e) {
    const t = [];
    let n = -1,
        r = 0,
        o = 0;
    for (; ++n < e.length; ) {
        const i = e.charCodeAt(n);
        let s = "";
        if (37 === i && Ft(e.charCodeAt(n + 1)) && Ft(e.charCodeAt(n + 2)))
            o = 2;
        else if (i < 128)
            /[!#$&-;=?-Z_a-z~]/.test(String.fromCharCode(i)) ||
                (s = String.fromCharCode(i));
        else if (i > 55295 && i < 57344) {
            const t = e.charCodeAt(n + 1);
            i < 56320 && t > 56319 && t < 57344
                ? ((s = String.fromCharCode(i, t)), (o = 1))
                : (s = "�");
        } else s = String.fromCharCode(i);
        s &&
            (t.push(e.slice(r, n), encodeURIComponent(s)),
            (r = n + o + 1),
            (s = "")),
            o && ((n += o), (o = 0));
    }
    return t.join("") + e.slice(r);
}
function Jt(e, t, n, r) {
    const o = r ? r - 1 : Number.POSITIVE_INFINITY;
    let i = 0;
    return function (r) {
        if (Kt(r)) return e.enter(n), s(r);
        return t(r);
    };
    function s(r) {
        return Kt(r) && i++ < o ? (e.consume(r), s) : (e.exit(n), t(r));
    }
}
const en = {
    tokenize: function (e) {
        const t = e.attempt(
            this.parser.constructs.contentInitial,
            function (n) {
                if (null === n) return void e.consume(n);
                return (
                    e.enter("lineEnding"),
                    e.consume(n),
                    e.exit("lineEnding"),
                    Jt(e, t, "linePrefix")
                );
            },
            function (t) {
                return e.enter("paragraph"), r(t);
            }
        );
        let n;
        return t;
        function r(t) {
            const r = e.enter("chunkText", {
                contentType: "text",
                previous: n,
            });
            return n && (n.next = r), (n = r), o(t);
        }
        function o(t) {
            return null === t
                ? (e.exit("chunkText"), e.exit("paragraph"), void e.consume(t))
                : Wt(t)
                ? (e.consume(t), e.exit("chunkText"), r)
                : (e.consume(t), o);
        }
    },
};
const tn = {
        tokenize: function (e) {
            const t = this,
                n = [];
            let r,
                o,
                i,
                s = 0;
            return a;
            function a(r) {
                if (s < n.length) {
                    const o = n[s];
                    return (
                        (t.containerState = o[1]),
                        e.attempt(o[0].continuation, l, c)(r)
                    );
                }
                return c(r);
            }
            function l(e) {
                if ((s++, t.containerState._closeFlow)) {
                    (t.containerState._closeFlow = void 0), r && x();
                    const n = t.events.length;
                    let o,
                        i = n;
                    for (; i--; )
                        if (
                            "exit" === t.events[i][0] &&
                            "chunkFlow" === t.events[i][1].type
                        ) {
                            o = t.events[i][1].end;
                            break;
                        }
                    y(s);
                    let a = n;
                    for (; a < t.events.length; )
                        (t.events[a][1].end = { ...o }), a++;
                    return (
                        Nt(t.events, i + 1, 0, t.events.slice(n)),
                        (t.events.length = a),
                        c(e)
                    );
                }
                return a(e);
            }
            function c(o) {
                if (s === n.length) {
                    if (!r) return h(o);
                    if (r.currentConstruct && r.currentConstruct.concrete)
                        return f(o);
                    t.interrupt = Boolean(
                        r.currentConstruct && !r._gfmTableDynamicInterruptHack
                    );
                }
                return (t.containerState = {}), e.check(nn, u, d)(o);
            }
            function u(e) {
                return r && x(), y(s), h(e);
            }
            function d(e) {
                return (
                    (t.parser.lazy[t.now().line] = s !== n.length),
                    (i = t.now().offset),
                    f(e)
                );
            }
            function h(n) {
                return (t.containerState = {}), e.attempt(nn, p, f)(n);
            }
            function p(e) {
                return (
                    s++, n.push([t.currentConstruct, t.containerState]), h(e)
                );
            }
            function f(n) {
                return null === n
                    ? (r && x(), y(0), void e.consume(n))
                    : ((r = r || t.parser.flow(t.now())),
                      e.enter("chunkFlow", {
                          _tokenizer: r,
                          contentType: "flow",
                          previous: o,
                      }),
                      m(n));
            }
            function m(n) {
                return null === n
                    ? (g(e.exit("chunkFlow"), !0), y(0), void e.consume(n))
                    : Wt(n)
                    ? (e.consume(n),
                      g(e.exit("chunkFlow")),
                      (s = 0),
                      (t.interrupt = void 0),
                      a)
                    : (e.consume(n), m);
            }
            function g(e, n) {
                const a = t.sliceStream(e);
                if (
                    (n && a.push(null),
                    (e.previous = o),
                    o && (o.next = e),
                    (o = e),
                    r.defineSkip(e.start),
                    r.write(a),
                    t.parser.lazy[e.start.line])
                ) {
                    let e = r.events.length;
                    for (; e--; )
                        if (
                            r.events[e][1].start.offset < i &&
                            (!r.events[e][1].end ||
                                r.events[e][1].end.offset > i)
                        )
                            return;
                    const n = t.events.length;
                    let o,
                        a,
                        l = n;
                    for (; l--; )
                        if (
                            "exit" === t.events[l][0] &&
                            "chunkFlow" === t.events[l][1].type
                        ) {
                            if (o) {
                                a = t.events[l][1].end;
                                break;
                            }
                            o = !0;
                        }
                    for (y(s), e = n; e < t.events.length; )
                        (t.events[e][1].end = { ...a }), e++;
                    Nt(t.events, l + 1, 0, t.events.slice(n)),
                        (t.events.length = e);
                }
            }
            function y(r) {
                let o = n.length;
                for (; o-- > r; ) {
                    const r = n[o];
                    (t.containerState = r[1]), r[0].exit.call(t, e);
                }
                n.length = r;
            }
            function x() {
                r.write([null]),
                    (o = void 0),
                    (r = void 0),
                    (t.containerState._closeFlow = void 0);
            }
        },
    },
    nn = {
        tokenize: function (e, t, n) {
            return Jt(
                e,
                e.attempt(this.parser.constructs.document, t, n),
                "linePrefix",
                this.parser.constructs.disable.null.includes("codeIndented")
                    ? void 0
                    : 4
            );
        },
    };
function rn(e) {
    return null === e || qt(e) || Xt(e) ? 1 : Yt(e) ? 2 : void 0;
}
function on(e, t, n) {
    const r = [];
    let o = -1;
    for (; ++o < e.length; ) {
        const i = e[o].resolveAll;
        i && !r.includes(i) && ((t = i(t, n)), r.push(i));
    }
    return t;
}
const sn = {
    name: "attention",
    resolveAll: function (e, t) {
        let n,
            r,
            o,
            i,
            s,
            a,
            l,
            c,
            u = -1;
        for (; ++u < e.length; )
            if (
                "enter" === e[u][0] &&
                "attentionSequence" === e[u][1].type &&
                e[u][1]._close
            )
                for (n = u; n--; )
                    if (
                        "exit" === e[n][0] &&
                        "attentionSequence" === e[n][1].type &&
                        e[n][1]._open &&
                        t.sliceSerialize(e[n][1]).charCodeAt(0) ===
                            t.sliceSerialize(e[u][1]).charCodeAt(0)
                    ) {
                        if (
                            (e[n][1]._close || e[u][1]._open) &&
                            (e[u][1].end.offset - e[u][1].start.offset) % 3 &&
                            !(
                                (e[n][1].end.offset -
                                    e[n][1].start.offset +
                                    e[u][1].end.offset -
                                    e[u][1].start.offset) %
                                3
                            )
                        )
                            continue;
                        a =
                            e[n][1].end.offset - e[n][1].start.offset > 1 &&
                            e[u][1].end.offset - e[u][1].start.offset > 1
                                ? 2
                                : 1;
                        const d = { ...e[n][1].end },
                            h = { ...e[u][1].start };
                        an(d, -a),
                            an(h, a),
                            (i = {
                                type:
                                    a > 1
                                        ? "strongSequence"
                                        : "emphasisSequence",
                                start: d,
                                end: { ...e[n][1].end },
                            }),
                            (s = {
                                type:
                                    a > 1
                                        ? "strongSequence"
                                        : "emphasisSequence",
                                start: { ...e[u][1].start },
                                end: h,
                            }),
                            (o = {
                                type: a > 1 ? "strongText" : "emphasisText",
                                start: { ...e[n][1].end },
                                end: { ...e[u][1].start },
                            }),
                            (r = {
                                type: a > 1 ? "strong" : "emphasis",
                                start: { ...i.start },
                                end: { ...s.end },
                            }),
                            (e[n][1].end = { ...i.start }),
                            (e[u][1].start = { ...s.end }),
                            (l = []),
                            e[n][1].end.offset - e[n][1].start.offset &&
                                (l = It(l, [
                                    ["enter", e[n][1], t],
                                    ["exit", e[n][1], t],
                                ])),
                            (l = It(l, [
                                ["enter", r, t],
                                ["enter", i, t],
                                ["exit", i, t],
                                ["enter", o, t],
                            ])),
                            (l = It(
                                l,
                                on(
                                    t.parser.constructs.insideSpan.null,
                                    e.slice(n + 1, u),
                                    t
                                )
                            )),
                            (l = It(l, [
                                ["exit", o, t],
                                ["enter", s, t],
                                ["exit", s, t],
                                ["exit", r, t],
                            ])),
                            e[u][1].end.offset - e[u][1].start.offset
                                ? ((c = 2),
                                  (l = It(l, [
                                      ["enter", e[u][1], t],
                                      ["exit", e[u][1], t],
                                  ])))
                                : (c = 0),
                            Nt(e, n - 1, u - n + 3, l),
                            (u = n + l.length - c - 2);
                        break;
                    }
        u = -1;
        for (; ++u < e.length; )
            "attentionSequence" === e[u][1].type && (e[u][1].type = "data");
        return e;
    },
    tokenize: function (e, t) {
        const n = this.parser.constructs.attentionMarkers.null,
            r = this.previous,
            o = rn(r);
        let i;
        return function (t) {
            return (i = t), e.enter("attentionSequence"), s(t);
        };
        function s(a) {
            if (a === i) return e.consume(a), s;
            const l = e.exit("attentionSequence"),
                c = rn(a),
                u = !c || (2 === c && o) || n.includes(a),
                d = !o || (2 === o && c) || n.includes(r);
            return (
                (l._open = Boolean(42 === i ? u : u && (o || !d))),
                (l._close = Boolean(42 === i ? d : d && (c || !u))),
                t(a)
            );
        }
    },
};
function an(e, t) {
    (e.column += t), (e.offset += t), (e._bufferIndex += t);
}
const ln = {
    name: "autolink",
    tokenize: function (e, t, n) {
        let r = 0;
        return function (t) {
            return (
                e.enter("autolink"),
                e.enter("autolinkMarker"),
                e.consume(t),
                e.exit("autolinkMarker"),
                e.enter("autolinkProtocol"),
                o
            );
        };
        function o(t) {
            return Ht(t) ? (e.consume(t), i) : 64 === t ? n(t) : l(t);
        }
        function i(e) {
            return 43 === e || 45 === e || 46 === e || Ft(e)
                ? ((r = 1), s(e))
                : l(e);
        }
        function s(t) {
            return 58 === t
                ? (e.consume(t), (r = 0), a)
                : (43 === t || 45 === t || 46 === t || Ft(t)) && r++ < 32
                ? (e.consume(t), s)
                : ((r = 0), l(t));
        }
        function a(r) {
            return 62 === r
                ? (e.exit("autolinkProtocol"),
                  e.enter("autolinkMarker"),
                  e.consume(r),
                  e.exit("autolinkMarker"),
                  e.exit("autolink"),
                  t)
                : null === r || 32 === r || 60 === r || Ut(r)
                ? n(r)
                : (e.consume(r), a);
        }
        function l(t) {
            return 64 === t
                ? (e.consume(t), c)
                : Bt(t)
                ? (e.consume(t), l)
                : n(t);
        }
        function c(e) {
            return Ft(e) ? u(e) : n(e);
        }
        function u(n) {
            return 46 === n
                ? (e.consume(n), (r = 0), c)
                : 62 === n
                ? ((e.exit("autolinkProtocol").type = "autolinkEmail"),
                  e.enter("autolinkMarker"),
                  e.consume(n),
                  e.exit("autolinkMarker"),
                  e.exit("autolink"),
                  t)
                : d(n);
        }
        function d(t) {
            if ((45 === t || Ft(t)) && r++ < 63) {
                const n = 45 === t ? d : u;
                return e.consume(t), n;
            }
            return n(t);
        }
    },
};
const cn = {
    partial: !0,
    tokenize: function (e, t, n) {
        return function (t) {
            return Kt(t) ? Jt(e, r, "linePrefix")(t) : r(t);
        };
        function r(e) {
            return null === e || Wt(e) ? t(e) : n(e);
        }
    },
};
const un = {
    continuation: {
        tokenize: function (e, t, n) {
            const r = this;
            return function (t) {
                if (Kt(t))
                    return Jt(
                        e,
                        o,
                        "linePrefix",
                        r.parser.constructs.disable.null.includes(
                            "codeIndented"
                        )
                            ? void 0
                            : 4
                    )(t);
                return o(t);
            };
            function o(r) {
                return e.attempt(un, t, n)(r);
            }
        },
    },
    exit: function (e) {
        e.exit("blockQuote");
    },
    name: "blockQuote",
    tokenize: function (e, t, n) {
        const r = this;
        return function (t) {
            if (62 === t) {
                const n = r.containerState;
                return (
                    n.open ||
                        (e.enter("blockQuote", { _container: !0 }),
                        (n.open = !0)),
                    e.enter("blockQuotePrefix"),
                    e.enter("blockQuoteMarker"),
                    e.consume(t),
                    e.exit("blockQuoteMarker"),
                    o
                );
            }
            return n(t);
        };
        function o(n) {
            return Kt(n)
                ? (e.enter("blockQuotePrefixWhitespace"),
                  e.consume(n),
                  e.exit("blockQuotePrefixWhitespace"),
                  e.exit("blockQuotePrefix"),
                  t)
                : (e.exit("blockQuotePrefix"), t(n));
        }
    },
};
const dn = {
    name: "characterEscape",
    tokenize: function (e, t, n) {
        return function (t) {
            return (
                e.enter("characterEscape"),
                e.enter("escapeMarker"),
                e.consume(t),
                e.exit("escapeMarker"),
                r
            );
        };
        function r(r) {
            return $t(r)
                ? (e.enter("characterEscapeValue"),
                  e.consume(r),
                  e.exit("characterEscapeValue"),
                  e.exit("characterEscape"),
                  t)
                : n(r);
        }
    },
};
const hn = {
    name: "characterReference",
    tokenize: function (e, t, n) {
        const r = this;
        let o,
            i,
            s = 0;
        return function (t) {
            return (
                e.enter("characterReference"),
                e.enter("characterReferenceMarker"),
                e.consume(t),
                e.exit("characterReferenceMarker"),
                a
            );
        };
        function a(t) {
            return 35 === t
                ? (e.enter("characterReferenceMarkerNumeric"),
                  e.consume(t),
                  e.exit("characterReferenceMarkerNumeric"),
                  l)
                : (e.enter("characterReferenceValue"),
                  (o = 31),
                  (i = Ft),
                  c(t));
        }
        function l(t) {
            return 88 === t || 120 === t
                ? (e.enter("characterReferenceMarkerHexadecimal"),
                  e.consume(t),
                  e.exit("characterReferenceMarkerHexadecimal"),
                  e.enter("characterReferenceValue"),
                  (o = 6),
                  (i = zt),
                  c)
                : (e.enter("characterReferenceValue"), (o = 7), (i = Zt), c(t));
        }
        function c(a) {
            if (59 === a && s) {
                const o = e.exit("characterReferenceValue");
                return i !== Ft || jt(r.sliceSerialize(o))
                    ? (e.enter("characterReferenceMarker"),
                      e.consume(a),
                      e.exit("characterReferenceMarker"),
                      e.exit("characterReference"),
                      t)
                    : n(a);
            }
            return i(a) && s++ < o ? (e.consume(a), c) : n(a);
        }
    },
};
const pn = {
        partial: !0,
        tokenize: function (e, t, n) {
            const r = this;
            return function (t) {
                if (null === t) return n(t);
                return (
                    e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), o
                );
            };
            function o(e) {
                return r.parser.lazy[r.now().line] ? n(e) : t(e);
            }
        },
    },
    fn = {
        concrete: !0,
        name: "codeFenced",
        tokenize: function (e, t, n) {
            const r = this,
                o = {
                    partial: !0,
                    tokenize: function (e, t, n) {
                        let o = 0;
                        return s;
                        function s(t) {
                            return (
                                e.enter("lineEnding"),
                                e.consume(t),
                                e.exit("lineEnding"),
                                l
                            );
                        }
                        function l(t) {
                            return (
                                e.enter("codeFencedFence"),
                                Kt(t)
                                    ? Jt(
                                          e,
                                          c,
                                          "linePrefix",
                                          r.parser.constructs.disable.null.includes(
                                              "codeIndented"
                                          )
                                              ? void 0
                                              : 4
                                      )(t)
                                    : c(t)
                            );
                        }
                        function c(t) {
                            return t === i
                                ? (e.enter("codeFencedFenceSequence"), u(t))
                                : n(t);
                        }
                        function u(t) {
                            return t === i
                                ? (o++, e.consume(t), u)
                                : o >= a
                                ? (e.exit("codeFencedFenceSequence"),
                                  Kt(t) ? Jt(e, d, "whitespace")(t) : d(t))
                                : n(t);
                        }
                        function d(r) {
                            return null === r || Wt(r)
                                ? (e.exit("codeFencedFence"), t(r))
                                : n(r);
                        }
                    },
                };
            let i,
                s = 0,
                a = 0;
            return function (t) {
                return (function (t) {
                    const n = r.events[r.events.length - 1];
                    return (
                        (s =
                            n && "linePrefix" === n[1].type
                                ? n[2].sliceSerialize(n[1], !0).length
                                : 0),
                        (i = t),
                        e.enter("codeFenced"),
                        e.enter("codeFencedFence"),
                        e.enter("codeFencedFenceSequence"),
                        l(t)
                    );
                })(t);
            };
            function l(t) {
                return t === i
                    ? (a++, e.consume(t), l)
                    : a < 3
                    ? n(t)
                    : (e.exit("codeFencedFenceSequence"),
                      Kt(t) ? Jt(e, c, "whitespace")(t) : c(t));
            }
            function c(n) {
                return null === n || Wt(n)
                    ? (e.exit("codeFencedFence"),
                      r.interrupt ? t(n) : e.check(pn, p, x)(n))
                    : (e.enter("codeFencedFenceInfo"),
                      e.enter("chunkString", { contentType: "string" }),
                      u(n));
            }
            function u(t) {
                return null === t || Wt(t)
                    ? (e.exit("chunkString"),
                      e.exit("codeFencedFenceInfo"),
                      c(t))
                    : Kt(t)
                    ? (e.exit("chunkString"),
                      e.exit("codeFencedFenceInfo"),
                      Jt(e, d, "whitespace")(t))
                    : 96 === t && t === i
                    ? n(t)
                    : (e.consume(t), u);
            }
            function d(t) {
                return null === t || Wt(t)
                    ? c(t)
                    : (e.enter("codeFencedFenceMeta"),
                      e.enter("chunkString", { contentType: "string" }),
                      h(t));
            }
            function h(t) {
                return null === t || Wt(t)
                    ? (e.exit("chunkString"),
                      e.exit("codeFencedFenceMeta"),
                      c(t))
                    : 96 === t && t === i
                    ? n(t)
                    : (e.consume(t), h);
            }
            function p(t) {
                return e.attempt(o, x, f)(t);
            }
            function f(t) {
                return (
                    e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), m
                );
            }
            function m(t) {
                return s > 0 && Kt(t) ? Jt(e, g, "linePrefix", s + 1)(t) : g(t);
            }
            function g(t) {
                return null === t || Wt(t)
                    ? e.check(pn, p, x)(t)
                    : (e.enter("codeFlowValue"), y(t));
            }
            function y(t) {
                return null === t || Wt(t)
                    ? (e.exit("codeFlowValue"), g(t))
                    : (e.consume(t), y);
            }
            function x(n) {
                return e.exit("codeFenced"), t(n);
            }
        },
    };
const mn = {
        name: "codeIndented",
        tokenize: function (e, t, n) {
            const r = this;
            return function (t) {
                return e.enter("codeIndented"), Jt(e, o, "linePrefix", 5)(t);
            };
            function o(e) {
                const t = r.events[r.events.length - 1];
                return t &&
                    "linePrefix" === t[1].type &&
                    t[2].sliceSerialize(t[1], !0).length >= 4
                    ? i(e)
                    : n(e);
            }
            function i(t) {
                return null === t
                    ? a(t)
                    : Wt(t)
                    ? e.attempt(gn, i, a)(t)
                    : (e.enter("codeFlowValue"), s(t));
            }
            function s(t) {
                return null === t || Wt(t)
                    ? (e.exit("codeFlowValue"), i(t))
                    : (e.consume(t), s);
            }
            function a(n) {
                return e.exit("codeIndented"), t(n);
            }
        },
    },
    gn = {
        partial: !0,
        tokenize: function (e, t, n) {
            const r = this;
            return o;
            function o(t) {
                return r.parser.lazy[r.now().line]
                    ? n(t)
                    : Wt(t)
                    ? (e.enter("lineEnding"),
                      e.consume(t),
                      e.exit("lineEnding"),
                      o)
                    : Jt(e, i, "linePrefix", 5)(t);
            }
            function i(e) {
                const i = r.events[r.events.length - 1];
                return i &&
                    "linePrefix" === i[1].type &&
                    i[2].sliceSerialize(i[1], !0).length >= 4
                    ? t(e)
                    : Wt(e)
                    ? o(e)
                    : n(e);
            }
        },
    };
const yn = {
    name: "codeText",
    previous: function (e) {
        return (
            96 !== e ||
            "characterEscape" === this.events[this.events.length - 1][1].type
        );
    },
    resolve: function (e) {
        let t,
            n,
            r = e.length - 4,
            o = 3;
        if (
            !(
                ("lineEnding" !== e[o][1].type && "space" !== e[o][1].type) ||
                ("lineEnding" !== e[r][1].type && "space" !== e[r][1].type)
            )
        )
            for (t = o; ++t < r; )
                if ("codeTextData" === e[t][1].type) {
                    (e[o][1].type = "codeTextPadding"),
                        (e[r][1].type = "codeTextPadding"),
                        (o += 2),
                        (r -= 2);
                    break;
                }
        (t = o - 1), r++;
        for (; ++t <= r; )
            void 0 === n
                ? t !== r && "lineEnding" !== e[t][1].type && (n = t)
                : (t !== r && "lineEnding" !== e[t][1].type) ||
                  ((e[n][1].type = "codeTextData"),
                  t !== n + 2 &&
                      ((e[n][1].end = e[t - 1][1].end),
                      e.splice(n + 2, t - n - 2),
                      (r -= t - n - 2),
                      (t = n + 2)),
                  (n = void 0));
        return e;
    },
    tokenize: function (e, t, n) {
        let r,
            o,
            i = 0;
        return function (t) {
            return e.enter("codeText"), e.enter("codeTextSequence"), s(t);
        };
        function s(t) {
            return 96 === t
                ? (e.consume(t), i++, s)
                : (e.exit("codeTextSequence"), a(t));
        }
        function a(t) {
            return null === t
                ? n(t)
                : 32 === t
                ? (e.enter("space"), e.consume(t), e.exit("space"), a)
                : 96 === t
                ? ((o = e.enter("codeTextSequence")), (r = 0), c(t))
                : Wt(t)
                ? (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), a)
                : (e.enter("codeTextData"), l(t));
        }
        function l(t) {
            return null === t || 32 === t || 96 === t || Wt(t)
                ? (e.exit("codeTextData"), a(t))
                : (e.consume(t), l);
        }
        function c(n) {
            return 96 === n
                ? (e.consume(n), r++, c)
                : r === i
                ? (e.exit("codeTextSequence"), e.exit("codeText"), t(n))
                : ((o.type = "codeTextData"), l(n));
        }
    },
};
class xn {
    constructor(e) {
        (this.left = e ? [...e] : []), (this.right = []);
    }
    get(e) {
        if (e < 0 || e >= this.left.length + this.right.length)
            throw new RangeError(
                "Cannot access index `" +
                    e +
                    "` in a splice buffer of size `" +
                    (this.left.length + this.right.length) +
                    "`"
            );
        return e < this.left.length
            ? this.left[e]
            : this.right[this.right.length - e + this.left.length - 1];
    }
    get length() {
        return this.left.length + this.right.length;
    }
    shift() {
        return this.setCursor(0), this.right.pop();
    }
    slice(e, t) {
        const n = null == t ? Number.POSITIVE_INFINITY : t;
        return n < this.left.length
            ? this.left.slice(e, n)
            : e > this.left.length
            ? this.right
                  .slice(
                      this.right.length - n + this.left.length,
                      this.right.length - e + this.left.length
                  )
                  .reverse()
            : this.left
                  .slice(e)
                  .concat(
                      this.right
                          .slice(this.right.length - n + this.left.length)
                          .reverse()
                  );
    }
    splice(e, t, n) {
        const r = t || 0;
        this.setCursor(Math.trunc(e));
        const o = this.right.splice(
            this.right.length - r,
            Number.POSITIVE_INFINITY
        );
        return n && vn(this.left, n), o.reverse();
    }
    pop() {
        return this.setCursor(Number.POSITIVE_INFINITY), this.left.pop();
    }
    push(e) {
        this.setCursor(Number.POSITIVE_INFINITY), this.left.push(e);
    }
    pushMany(e) {
        this.setCursor(Number.POSITIVE_INFINITY), vn(this.left, e);
    }
    unshift(e) {
        this.setCursor(0), this.right.push(e);
    }
    unshiftMany(e) {
        this.setCursor(0), vn(this.right, e.reverse());
    }
    setCursor(e) {
        if (
            !(
                e === this.left.length ||
                (e > this.left.length && 0 === this.right.length) ||
                (e < 0 && 0 === this.left.length)
            )
        )
            if (e < this.left.length) {
                const t = this.left.splice(e, Number.POSITIVE_INFINITY);
                vn(this.right, t.reverse());
            } else {
                const t = this.right.splice(
                    this.left.length + this.right.length - e,
                    Number.POSITIVE_INFINITY
                );
                vn(this.left, t.reverse());
            }
    }
}
function vn(e, t) {
    let n = 0;
    if (t.length < 1e4) e.push(...t);
    else for (; n < t.length; ) e.push(...t.slice(n, n + 1e4)), (n += 1e4);
}
function Cn(e) {
    const t = {};
    let n,
        r,
        o,
        i,
        s,
        a,
        l,
        c = -1;
    const u = new xn(e);
    for (; ++c < u.length; ) {
        for (; c in t; ) c = t[c];
        if (
            ((n = u.get(c)),
            c &&
                "chunkFlow" === n[1].type &&
                "listItemPrefix" === u.get(c - 1)[1].type &&
                ((a = n[1]._tokenizer.events),
                (o = 0),
                o < a.length && "lineEndingBlank" === a[o][1].type && (o += 2),
                o < a.length && "content" === a[o][1].type))
        )
            for (; ++o < a.length && "content" !== a[o][1].type; )
                "chunkText" === a[o][1].type &&
                    ((a[o][1]._isInFirstContentOfListItem = !0), o++);
        if ("enter" === n[0])
            n[1].contentType &&
                (Object.assign(t, wn(u, c)), (c = t[c]), (l = !0));
        else if (n[1]._container) {
            for (o = c, r = void 0; o--; )
                if (
                    ((i = u.get(o)),
                    "lineEnding" === i[1].type ||
                        "lineEndingBlank" === i[1].type)
                )
                    "enter" === i[0] &&
                        (r && (u.get(r)[1].type = "lineEndingBlank"),
                        (i[1].type = "lineEnding"),
                        (r = o));
                else if (
                    "linePrefix" !== i[1].type &&
                    "listItemIndent" !== i[1].type
                )
                    break;
            r &&
                ((n[1].end = { ...u.get(r)[1].start }),
                (s = u.slice(r, c)),
                s.unshift(n),
                u.splice(r, c - r + 1, s));
        }
    }
    return Nt(e, 0, Number.POSITIVE_INFINITY, u.slice(0)), !l;
}
function wn(e, t) {
    const n = e.get(t)[1],
        r = e.get(t)[2];
    let o = t - 1;
    const i = [];
    let s = n._tokenizer;
    s ||
        ((s = r.parser[n.contentType](n.start)),
        n._contentTypeTextTrailing && (s._contentTypeTextTrailing = !0));
    const a = s.events,
        l = [],
        c = {};
    let u,
        d,
        h = -1,
        p = n,
        f = 0,
        m = 0;
    const g = [m];
    for (; p; ) {
        for (; e.get(++o)[1] !== p; );
        i.push(o),
            p._tokenizer ||
                ((u = r.sliceStream(p)),
                p.next || u.push(null),
                d && s.defineSkip(p.start),
                p._isInFirstContentOfListItem &&
                    (s._gfmTasklistFirstContentOfListItem = !0),
                s.write(u),
                p._isInFirstContentOfListItem &&
                    (s._gfmTasklistFirstContentOfListItem = void 0)),
            (d = p),
            (p = p.next);
    }
    for (p = n; ++h < a.length; )
        "exit" === a[h][0] &&
            "enter" === a[h - 1][0] &&
            a[h][1].type === a[h - 1][1].type &&
            a[h][1].start.line !== a[h][1].end.line &&
            ((m = h + 1),
            g.push(m),
            (p._tokenizer = void 0),
            (p.previous = void 0),
            (p = p.next));
    for (
        s.events = [],
            p ? ((p._tokenizer = void 0), (p.previous = void 0)) : g.pop(),
            h = g.length;
        h--;

    ) {
        const t = a.slice(g[h], g[h + 1]),
            n = i.pop();
        l.push([n, n + t.length - 1]), e.splice(n, 2, t);
    }
    for (l.reverse(), h = -1; ++h < l.length; )
        (c[f + l[h][0]] = f + l[h][1]), (f += l[h][1] - l[h][0] - 1);
    return c;
}
const bn = {
        resolve: function (e) {
            return Cn(e), e;
        },
        tokenize: function (e, t) {
            let n;
            return function (t) {
                return (
                    e.enter("content"),
                    (n = e.enter("chunkContent", { contentType: "content" })),
                    r(t)
                );
            };
            function r(t) {
                return null === t
                    ? o(t)
                    : Wt(t)
                    ? e.check(kn, i, o)(t)
                    : (e.consume(t), r);
            }
            function o(n) {
                return e.exit("chunkContent"), e.exit("content"), t(n);
            }
            function i(t) {
                return (
                    e.consume(t),
                    e.exit("chunkContent"),
                    (n.next = e.enter("chunkContent", {
                        contentType: "content",
                        previous: n,
                    })),
                    (n = n.next),
                    r
                );
            }
        },
    },
    kn = {
        partial: !0,
        tokenize: function (e, t, n) {
            const r = this;
            return function (t) {
                return (
                    e.exit("chunkContent"),
                    e.enter("lineEnding"),
                    e.consume(t),
                    e.exit("lineEnding"),
                    Jt(e, o, "linePrefix")
                );
            };
            function o(o) {
                if (null === o || Wt(o)) return n(o);
                const i = r.events[r.events.length - 1];
                return !r.parser.constructs.disable.null.includes(
                    "codeIndented"
                ) &&
                    i &&
                    "linePrefix" === i[1].type &&
                    i[2].sliceSerialize(i[1], !0).length >= 4
                    ? t(o)
                    : e.interrupt(r.parser.constructs.flow, n, t)(o);
            }
        },
    };
function En(e, t, n, r, o, i, s, a, l) {
    const c = l || Number.POSITIVE_INFINITY;
    let u = 0;
    return function (t) {
        if (60 === t)
            return (
                e.enter(r), e.enter(o), e.enter(i), e.consume(t), e.exit(i), d
            );
        if (null === t || 32 === t || 41 === t || Ut(t)) return n(t);
        return (
            e.enter(r),
            e.enter(s),
            e.enter(a),
            e.enter("chunkString", { contentType: "string" }),
            f(t)
        );
    };
    function d(n) {
        return 62 === n
            ? (e.enter(i), e.consume(n), e.exit(i), e.exit(o), e.exit(r), t)
            : (e.enter(a),
              e.enter("chunkString", { contentType: "string" }),
              h(n));
    }
    function h(t) {
        return 62 === t
            ? (e.exit("chunkString"), e.exit(a), d(t))
            : null === t || 60 === t || Wt(t)
            ? n(t)
            : (e.consume(t), 92 === t ? p : h);
    }
    function p(t) {
        return 60 === t || 62 === t || 92 === t ? (e.consume(t), h) : h(t);
    }
    function f(o) {
        return u || (null !== o && 41 !== o && !qt(o))
            ? u < c && 40 === o
                ? (e.consume(o), u++, f)
                : 41 === o
                ? (e.consume(o), u--, f)
                : null === o || 32 === o || 40 === o || Ut(o)
                ? n(o)
                : (e.consume(o), 92 === o ? m : f)
            : (e.exit("chunkString"), e.exit(a), e.exit(s), e.exit(r), t(o));
    }
    function m(t) {
        return 40 === t || 41 === t || 92 === t ? (e.consume(t), f) : f(t);
    }
}
function Sn(e, t, n, r, o, i) {
    const s = this;
    let a,
        l = 0;
    return function (t) {
        return e.enter(r), e.enter(o), e.consume(t), e.exit(o), e.enter(i), c;
    };
    function c(d) {
        return l > 999 ||
            null === d ||
            91 === d ||
            (93 === d && !a) ||
            (94 === d && !l && "_hiddenFootnoteSupport" in s.parser.constructs)
            ? n(d)
            : 93 === d
            ? (e.exit(i), e.enter(o), e.consume(d), e.exit(o), e.exit(r), t)
            : Wt(d)
            ? (e.enter("lineEnding"), e.consume(d), e.exit("lineEnding"), c)
            : (e.enter("chunkString", { contentType: "string" }), u(d));
    }
    function u(t) {
        return null === t || 91 === t || 93 === t || Wt(t) || l++ > 999
            ? (e.exit("chunkString"), c(t))
            : (e.consume(t), a || (a = !Kt(t)), 92 === t ? d : u);
    }
    function d(t) {
        return 91 === t || 92 === t || 93 === t ? (e.consume(t), l++, u) : u(t);
    }
}
function An(e, t, n, r, o, i) {
    let s;
    return function (t) {
        if (34 === t || 39 === t || 40 === t)
            return (
                e.enter(r),
                e.enter(o),
                e.consume(t),
                e.exit(o),
                (s = 40 === t ? 41 : t),
                a
            );
        return n(t);
    };
    function a(n) {
        return n === s
            ? (e.enter(o), e.consume(n), e.exit(o), e.exit(r), t)
            : (e.enter(i), l(n));
    }
    function l(t) {
        return t === s
            ? (e.exit(i), a(s))
            : null === t
            ? n(t)
            : Wt(t)
            ? (e.enter("lineEnding"),
              e.consume(t),
              e.exit("lineEnding"),
              Jt(e, l, "linePrefix"))
            : (e.enter("chunkString", { contentType: "string" }), c(t));
    }
    function c(t) {
        return t === s || null === t || Wt(t)
            ? (e.exit("chunkString"), l(t))
            : (e.consume(t), 92 === t ? u : c);
    }
    function u(t) {
        return t === s || 92 === t ? (e.consume(t), c) : c(t);
    }
}
function Tn(e, t) {
    let n;
    return function r(o) {
        if (Wt(o))
            return (
                e.enter("lineEnding"),
                e.consume(o),
                e.exit("lineEnding"),
                (n = !0),
                r
            );
        if (Kt(o)) return Jt(e, r, n ? "linePrefix" : "lineSuffix")(o);
        return t(o);
    };
}
const Ln = {
        name: "definition",
        tokenize: function (e, t, n) {
            const r = this;
            let o;
            return function (t) {
                return (
                    e.enter("definition"),
                    (function (t) {
                        return Sn.call(
                            r,
                            e,
                            i,
                            n,
                            "definitionLabel",
                            "definitionLabelMarker",
                            "definitionLabelString"
                        )(t);
                    })(t)
                );
            };
            function i(t) {
                return (
                    (o = Ot(
                        r
                            .sliceSerialize(r.events[r.events.length - 1][1])
                            .slice(1, -1)
                    )),
                    58 === t
                        ? (e.enter("definitionMarker"),
                          e.consume(t),
                          e.exit("definitionMarker"),
                          s)
                        : n(t)
                );
            }
            function s(t) {
                return qt(t) ? Tn(e, a)(t) : a(t);
            }
            function a(t) {
                return En(
                    e,
                    l,
                    n,
                    "definitionDestination",
                    "definitionDestinationLiteral",
                    "definitionDestinationLiteralMarker",
                    "definitionDestinationRaw",
                    "definitionDestinationString"
                )(t);
            }
            function l(t) {
                return e.attempt(Mn, c, c)(t);
            }
            function c(t) {
                return Kt(t) ? Jt(e, u, "whitespace")(t) : u(t);
            }
            function u(i) {
                return null === i || Wt(i)
                    ? (e.exit("definition"), r.parser.defined.push(o), t(i))
                    : n(i);
            }
        },
    },
    Mn = {
        partial: !0,
        tokenize: function (e, t, n) {
            return function (t) {
                return qt(t) ? Tn(e, r)(t) : n(t);
            };
            function r(t) {
                return An(
                    e,
                    o,
                    n,
                    "definitionTitle",
                    "definitionTitleMarker",
                    "definitionTitleString"
                )(t);
            }
            function o(t) {
                return Kt(t) ? Jt(e, i, "whitespace")(t) : i(t);
            }
            function i(e) {
                return null === e || Wt(e) ? t(e) : n(e);
            }
        },
    };
const Pn = {
    name: "hardBreakEscape",
    tokenize: function (e, t, n) {
        return function (t) {
            return e.enter("hardBreakEscape"), e.consume(t), r;
        };
        function r(r) {
            return Wt(r) ? (e.exit("hardBreakEscape"), t(r)) : n(r);
        }
    },
};
const jn = {
    name: "headingAtx",
    resolve: function (e, t) {
        let n,
            r,
            o = e.length - 2,
            i = 3;
        "whitespace" === e[i][1].type && (i += 2);
        o - 2 > i && "whitespace" === e[o][1].type && (o -= 2);
        "atxHeadingSequence" === e[o][1].type &&
            (i === o - 1 || (o - 4 > i && "whitespace" === e[o - 2][1].type)) &&
            (o -= i + 1 === o ? 2 : 4);
        o > i &&
            ((n = {
                type: "atxHeadingText",
                start: e[i][1].start,
                end: e[o][1].end,
            }),
            (r = {
                type: "chunkText",
                start: e[i][1].start,
                end: e[o][1].end,
                contentType: "text",
            }),
            Nt(e, i, o - i + 1, [
                ["enter", n, t],
                ["enter", r, t],
                ["exit", r, t],
                ["exit", n, t],
            ]));
        return e;
    },
    tokenize: function (e, t, n) {
        let r = 0;
        return function (t) {
            return (
                e.enter("atxHeading"),
                (function (t) {
                    return e.enter("atxHeadingSequence"), o(t);
                })(t)
            );
        };
        function o(t) {
            return 35 === t && r++ < 6
                ? (e.consume(t), o)
                : null === t || qt(t)
                ? (e.exit("atxHeadingSequence"), i(t))
                : n(t);
        }
        function i(n) {
            return 35 === n
                ? (e.enter("atxHeadingSequence"), s(n))
                : null === n || Wt(n)
                ? (e.exit("atxHeading"), t(n))
                : Kt(n)
                ? Jt(e, i, "whitespace")(n)
                : (e.enter("atxHeadingText"), a(n));
        }
        function s(t) {
            return 35 === t
                ? (e.consume(t), s)
                : (e.exit("atxHeadingSequence"), i(t));
        }
        function a(t) {
            return null === t || 35 === t || qt(t)
                ? (e.exit("atxHeadingText"), i(t))
                : (e.consume(t), a);
        }
    },
};
const Nn = [
        "address",
        "article",
        "aside",
        "base",
        "basefont",
        "blockquote",
        "body",
        "caption",
        "center",
        "col",
        "colgroup",
        "dd",
        "details",
        "dialog",
        "dir",
        "div",
        "dl",
        "dt",
        "fieldset",
        "figcaption",
        "figure",
        "footer",
        "form",
        "frame",
        "frameset",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "head",
        "header",
        "hr",
        "html",
        "iframe",
        "legend",
        "li",
        "link",
        "main",
        "menu",
        "menuitem",
        "nav",
        "noframes",
        "ol",
        "optgroup",
        "option",
        "p",
        "param",
        "search",
        "section",
        "summary",
        "table",
        "tbody",
        "td",
        "tfoot",
        "th",
        "thead",
        "title",
        "tr",
        "track",
        "ul",
    ],
    In = ["pre", "script", "style", "textarea"],
    Dn = {
        concrete: !0,
        name: "htmlFlow",
        resolveTo: function (e) {
            let t = e.length;
            for (
                ;
                t-- && ("enter" !== e[t][0] || "htmlFlow" !== e[t][1].type);

            );
            t > 1 &&
                "linePrefix" === e[t - 2][1].type &&
                ((e[t][1].start = e[t - 2][1].start),
                (e[t + 1][1].start = e[t - 2][1].start),
                e.splice(t - 2, 2));
            return e;
        },
        tokenize: function (e, t, n) {
            const r = this;
            let o, i, s, a, l;
            return function (t) {
                return (function (t) {
                    return (
                        e.enter("htmlFlow"),
                        e.enter("htmlFlowData"),
                        e.consume(t),
                        c
                    );
                })(t);
            };
            function c(a) {
                return 33 === a
                    ? (e.consume(a), u)
                    : 47 === a
                    ? (e.consume(a), (i = !0), p)
                    : 63 === a
                    ? (e.consume(a), (o = 3), r.interrupt ? t : D)
                    : Ht(a)
                    ? (e.consume(a), (s = String.fromCharCode(a)), f)
                    : n(a);
            }
            function u(i) {
                return 45 === i
                    ? (e.consume(i), (o = 2), d)
                    : 91 === i
                    ? (e.consume(i), (o = 5), (a = 0), h)
                    : Ht(i)
                    ? (e.consume(i), (o = 4), r.interrupt ? t : D)
                    : n(i);
            }
            function d(o) {
                return 45 === o ? (e.consume(o), r.interrupt ? t : D) : n(o);
            }
            function h(o) {
                const i = "CDATA[";
                return o === i.charCodeAt(a++)
                    ? (e.consume(o), 6 === a ? (r.interrupt ? t : A) : h)
                    : n(o);
            }
            function p(t) {
                return Ht(t)
                    ? (e.consume(t), (s = String.fromCharCode(t)), f)
                    : n(t);
            }
            function f(a) {
                if (null === a || 47 === a || 62 === a || qt(a)) {
                    const l = 47 === a,
                        c = s.toLowerCase();
                    return l || i || !In.includes(c)
                        ? Nn.includes(s.toLowerCase())
                            ? ((o = 6),
                              l ? (e.consume(a), m) : r.interrupt ? t(a) : A(a))
                            : ((o = 7),
                              r.interrupt && !r.parser.lazy[r.now().line]
                                  ? n(a)
                                  : i
                                  ? g(a)
                                  : y(a))
                        : ((o = 1), r.interrupt ? t(a) : A(a));
                }
                return 45 === a || Ft(a)
                    ? (e.consume(a), (s += String.fromCharCode(a)), f)
                    : n(a);
            }
            function m(o) {
                return 62 === o ? (e.consume(o), r.interrupt ? t : A) : n(o);
            }
            function g(t) {
                return Kt(t) ? (e.consume(t), g) : E(t);
            }
            function y(t) {
                return 47 === t
                    ? (e.consume(t), E)
                    : 58 === t || 95 === t || Ht(t)
                    ? (e.consume(t), x)
                    : Kt(t)
                    ? (e.consume(t), y)
                    : E(t);
            }
            function x(t) {
                return 45 === t || 46 === t || 58 === t || 95 === t || Ft(t)
                    ? (e.consume(t), x)
                    : v(t);
            }
            function v(t) {
                return 61 === t
                    ? (e.consume(t), C)
                    : Kt(t)
                    ? (e.consume(t), v)
                    : y(t);
            }
            function C(t) {
                return null === t ||
                    60 === t ||
                    61 === t ||
                    62 === t ||
                    96 === t
                    ? n(t)
                    : 34 === t || 39 === t
                    ? (e.consume(t), (l = t), w)
                    : Kt(t)
                    ? (e.consume(t), C)
                    : b(t);
            }
            function w(t) {
                return t === l
                    ? (e.consume(t), (l = null), k)
                    : null === t || Wt(t)
                    ? n(t)
                    : (e.consume(t), w);
            }
            function b(t) {
                return null === t ||
                    34 === t ||
                    39 === t ||
                    47 === t ||
                    60 === t ||
                    61 === t ||
                    62 === t ||
                    96 === t ||
                    qt(t)
                    ? v(t)
                    : (e.consume(t), b);
            }
            function k(e) {
                return 47 === e || 62 === e || Kt(e) ? y(e) : n(e);
            }
            function E(t) {
                return 62 === t ? (e.consume(t), S) : n(t);
            }
            function S(t) {
                return null === t || Wt(t)
                    ? A(t)
                    : Kt(t)
                    ? (e.consume(t), S)
                    : n(t);
            }
            function A(t) {
                return 45 === t && 2 === o
                    ? (e.consume(t), P)
                    : 60 === t && 1 === o
                    ? (e.consume(t), j)
                    : 62 === t && 4 === o
                    ? (e.consume(t), V)
                    : 63 === t && 3 === o
                    ? (e.consume(t), D)
                    : 93 === t && 5 === o
                    ? (e.consume(t), I)
                    : !Wt(t) || (6 !== o && 7 !== o)
                    ? null === t || Wt(t)
                        ? (e.exit("htmlFlowData"), T(t))
                        : (e.consume(t), A)
                    : (e.exit("htmlFlowData"), e.check(Vn, R, T)(t));
            }
            function T(t) {
                return e.check(Rn, L, R)(t);
            }
            function L(t) {
                return (
                    e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), M
                );
            }
            function M(t) {
                return null === t || Wt(t)
                    ? T(t)
                    : (e.enter("htmlFlowData"), A(t));
            }
            function P(t) {
                return 45 === t ? (e.consume(t), D) : A(t);
            }
            function j(t) {
                return 47 === t ? (e.consume(t), (s = ""), N) : A(t);
            }
            function N(t) {
                if (62 === t) {
                    const n = s.toLowerCase();
                    return In.includes(n) ? (e.consume(t), V) : A(t);
                }
                return Ht(t) && s.length < 8
                    ? (e.consume(t), (s += String.fromCharCode(t)), N)
                    : A(t);
            }
            function I(t) {
                return 93 === t ? (e.consume(t), D) : A(t);
            }
            function D(t) {
                return 62 === t
                    ? (e.consume(t), V)
                    : 45 === t && 2 === o
                    ? (e.consume(t), D)
                    : A(t);
            }
            function V(t) {
                return null === t || Wt(t)
                    ? (e.exit("htmlFlowData"), R(t))
                    : (e.consume(t), V);
            }
            function R(n) {
                return e.exit("htmlFlow"), t(n);
            }
        },
    },
    Vn = {
        partial: !0,
        tokenize: function (e, t, n) {
            return function (r) {
                return (
                    e.enter("lineEnding"),
                    e.consume(r),
                    e.exit("lineEnding"),
                    e.attempt(cn, t, n)
                );
            };
        },
    },
    Rn = {
        partial: !0,
        tokenize: function (e, t, n) {
            const r = this;
            return function (t) {
                if (Wt(t))
                    return (
                        e.enter("lineEnding"),
                        e.consume(t),
                        e.exit("lineEnding"),
                        o
                    );
                return n(t);
            };
            function o(e) {
                return r.parser.lazy[r.now().line] ? n(e) : t(e);
            }
        },
    };
const _n = {
    name: "htmlText",
    tokenize: function (e, t, n) {
        const r = this;
        let o, i, s;
        return function (t) {
            return (
                e.enter("htmlText"), e.enter("htmlTextData"), e.consume(t), a
            );
        };
        function a(t) {
            return 33 === t
                ? (e.consume(t), l)
                : 47 === t
                ? (e.consume(t), C)
                : 63 === t
                ? (e.consume(t), x)
                : Ht(t)
                ? (e.consume(t), k)
                : n(t);
        }
        function l(t) {
            return 45 === t
                ? (e.consume(t), c)
                : 91 === t
                ? (e.consume(t), (i = 0), p)
                : Ht(t)
                ? (e.consume(t), y)
                : n(t);
        }
        function c(t) {
            return 45 === t ? (e.consume(t), h) : n(t);
        }
        function u(t) {
            return null === t
                ? n(t)
                : 45 === t
                ? (e.consume(t), d)
                : Wt(t)
                ? ((s = u), N(t))
                : (e.consume(t), u);
        }
        function d(t) {
            return 45 === t ? (e.consume(t), h) : u(t);
        }
        function h(e) {
            return 62 === e ? j(e) : 45 === e ? d(e) : u(e);
        }
        function p(t) {
            const r = "CDATA[";
            return t === r.charCodeAt(i++)
                ? (e.consume(t), 6 === i ? f : p)
                : n(t);
        }
        function f(t) {
            return null === t
                ? n(t)
                : 93 === t
                ? (e.consume(t), m)
                : Wt(t)
                ? ((s = f), N(t))
                : (e.consume(t), f);
        }
        function m(t) {
            return 93 === t ? (e.consume(t), g) : f(t);
        }
        function g(t) {
            return 62 === t ? j(t) : 93 === t ? (e.consume(t), g) : f(t);
        }
        function y(t) {
            return null === t || 62 === t
                ? j(t)
                : Wt(t)
                ? ((s = y), N(t))
                : (e.consume(t), y);
        }
        function x(t) {
            return null === t
                ? n(t)
                : 63 === t
                ? (e.consume(t), v)
                : Wt(t)
                ? ((s = x), N(t))
                : (e.consume(t), x);
        }
        function v(e) {
            return 62 === e ? j(e) : x(e);
        }
        function C(t) {
            return Ht(t) ? (e.consume(t), w) : n(t);
        }
        function w(t) {
            return 45 === t || Ft(t) ? (e.consume(t), w) : b(t);
        }
        function b(t) {
            return Wt(t) ? ((s = b), N(t)) : Kt(t) ? (e.consume(t), b) : j(t);
        }
        function k(t) {
            return 45 === t || Ft(t)
                ? (e.consume(t), k)
                : 47 === t || 62 === t || qt(t)
                ? E(t)
                : n(t);
        }
        function E(t) {
            return 47 === t
                ? (e.consume(t), j)
                : 58 === t || 95 === t || Ht(t)
                ? (e.consume(t), S)
                : Wt(t)
                ? ((s = E), N(t))
                : Kt(t)
                ? (e.consume(t), E)
                : j(t);
        }
        function S(t) {
            return 45 === t || 46 === t || 58 === t || 95 === t || Ft(t)
                ? (e.consume(t), S)
                : A(t);
        }
        function A(t) {
            return 61 === t
                ? (e.consume(t), T)
                : Wt(t)
                ? ((s = A), N(t))
                : Kt(t)
                ? (e.consume(t), A)
                : E(t);
        }
        function T(t) {
            return null === t || 60 === t || 61 === t || 62 === t || 96 === t
                ? n(t)
                : 34 === t || 39 === t
                ? (e.consume(t), (o = t), L)
                : Wt(t)
                ? ((s = T), N(t))
                : Kt(t)
                ? (e.consume(t), T)
                : (e.consume(t), M);
        }
        function L(t) {
            return t === o
                ? (e.consume(t), (o = void 0), P)
                : null === t
                ? n(t)
                : Wt(t)
                ? ((s = L), N(t))
                : (e.consume(t), L);
        }
        function M(t) {
            return null === t ||
                34 === t ||
                39 === t ||
                60 === t ||
                61 === t ||
                96 === t
                ? n(t)
                : 47 === t || 62 === t || qt(t)
                ? E(t)
                : (e.consume(t), M);
        }
        function P(e) {
            return 47 === e || 62 === e || qt(e) ? E(e) : n(e);
        }
        function j(r) {
            return 62 === r
                ? (e.consume(r), e.exit("htmlTextData"), e.exit("htmlText"), t)
                : n(r);
        }
        function N(t) {
            return (
                e.exit("htmlTextData"),
                e.enter("lineEnding"),
                e.consume(t),
                e.exit("lineEnding"),
                I
            );
        }
        function I(t) {
            return Kt(t)
                ? Jt(
                      e,
                      D,
                      "linePrefix",
                      r.parser.constructs.disable.null.includes("codeIndented")
                          ? void 0
                          : 4
                  )(t)
                : D(t);
        }
        function D(t) {
            return e.enter("htmlTextData"), s(t);
        }
    },
};
const On = {
        name: "labelEnd",
        resolveAll: function (e) {
            let t = -1;
            const n = [];
            for (; ++t < e.length; ) {
                const r = e[t][1];
                if (
                    (n.push(e[t]),
                    "labelImage" === r.type ||
                        "labelLink" === r.type ||
                        "labelEnd" === r.type)
                ) {
                    const e = "labelImage" === r.type ? 4 : 2;
                    (r.type = "data"), (t += e);
                }
            }
            e.length !== n.length && Nt(e, 0, e.length, n);
            return e;
        },
        resolveTo: function (e, t) {
            let n,
                r,
                o,
                i,
                s = e.length,
                a = 0;
            for (; s--; )
                if (((n = e[s][1]), r)) {
                    if (
                        "link" === n.type ||
                        ("labelLink" === n.type && n._inactive)
                    )
                        break;
                    "enter" === e[s][0] &&
                        "labelLink" === n.type &&
                        (n._inactive = !0);
                } else if (o) {
                    if (
                        "enter" === e[s][0] &&
                        ("labelImage" === n.type || "labelLink" === n.type) &&
                        !n._balanced &&
                        ((r = s), "labelLink" !== n.type)
                    ) {
                        a = 2;
                        break;
                    }
                } else "labelEnd" === n.type && (o = s);
            const l = {
                    type: "labelLink" === e[r][1].type ? "link" : "image",
                    start: { ...e[r][1].start },
                    end: { ...e[e.length - 1][1].end },
                },
                c = {
                    type: "label",
                    start: { ...e[r][1].start },
                    end: { ...e[o][1].end },
                },
                u = {
                    type: "labelText",
                    start: { ...e[r + a + 2][1].end },
                    end: { ...e[o - 2][1].start },
                };
            return (
                (i = [
                    ["enter", l, t],
                    ["enter", c, t],
                ]),
                (i = It(i, e.slice(r + 1, r + a + 3))),
                (i = It(i, [["enter", u, t]])),
                (i = It(
                    i,
                    on(
                        t.parser.constructs.insideSpan.null,
                        e.slice(r + a + 4, o - 3),
                        t
                    )
                )),
                (i = It(i, [
                    ["exit", u, t],
                    e[o - 2],
                    e[o - 1],
                    ["exit", c, t],
                ])),
                (i = It(i, e.slice(o + 1))),
                (i = It(i, [["exit", l, t]])),
                Nt(e, r, e.length, i),
                e
            );
        },
        tokenize: function (e, t, n) {
            const r = this;
            let o,
                i,
                s = r.events.length;
            for (; s--; )
                if (
                    ("labelImage" === r.events[s][1].type ||
                        "labelLink" === r.events[s][1].type) &&
                    !r.events[s][1]._balanced
                ) {
                    o = r.events[s][1];
                    break;
                }
            return function (t) {
                if (!o) return n(t);
                if (o._inactive) return u(t);
                return (
                    (i = r.parser.defined.includes(
                        Ot(r.sliceSerialize({ start: o.end, end: r.now() }))
                    )),
                    e.enter("labelEnd"),
                    e.enter("labelMarker"),
                    e.consume(t),
                    e.exit("labelMarker"),
                    e.exit("labelEnd"),
                    a
                );
            };
            function a(t) {
                return 40 === t
                    ? e.attempt(Hn, c, i ? c : u)(t)
                    : 91 === t
                    ? e.attempt(Fn, c, i ? l : u)(t)
                    : i
                    ? c(t)
                    : u(t);
            }
            function l(t) {
                return e.attempt(Bn, c, u)(t);
            }
            function c(e) {
                return t(e);
            }
            function u(e) {
                return (o._balanced = !0), n(e);
            }
        },
    },
    Hn = {
        tokenize: function (e, t, n) {
            return function (t) {
                return (
                    e.enter("resource"),
                    e.enter("resourceMarker"),
                    e.consume(t),
                    e.exit("resourceMarker"),
                    r
                );
            };
            function r(t) {
                return qt(t) ? Tn(e, o)(t) : o(t);
            }
            function o(t) {
                return 41 === t
                    ? c(t)
                    : En(
                          e,
                          i,
                          s,
                          "resourceDestination",
                          "resourceDestinationLiteral",
                          "resourceDestinationLiteralMarker",
                          "resourceDestinationRaw",
                          "resourceDestinationString",
                          32
                      )(t);
            }
            function i(t) {
                return qt(t) ? Tn(e, a)(t) : c(t);
            }
            function s(e) {
                return n(e);
            }
            function a(t) {
                return 34 === t || 39 === t || 40 === t
                    ? An(
                          e,
                          l,
                          n,
                          "resourceTitle",
                          "resourceTitleMarker",
                          "resourceTitleString"
                      )(t)
                    : c(t);
            }
            function l(t) {
                return qt(t) ? Tn(e, c)(t) : c(t);
            }
            function c(r) {
                return 41 === r
                    ? (e.enter("resourceMarker"),
                      e.consume(r),
                      e.exit("resourceMarker"),
                      e.exit("resource"),
                      t)
                    : n(r);
            }
        },
    },
    Fn = {
        tokenize: function (e, t, n) {
            const r = this;
            return function (t) {
                return Sn.call(
                    r,
                    e,
                    o,
                    i,
                    "reference",
                    "referenceMarker",
                    "referenceString"
                )(t);
            };
            function o(e) {
                return r.parser.defined.includes(
                    Ot(
                        r
                            .sliceSerialize(r.events[r.events.length - 1][1])
                            .slice(1, -1)
                    )
                )
                    ? t(e)
                    : n(e);
            }
            function i(e) {
                return n(e);
            }
        },
    },
    Bn = {
        tokenize: function (e, t, n) {
            return function (t) {
                return (
                    e.enter("reference"),
                    e.enter("referenceMarker"),
                    e.consume(t),
                    e.exit("referenceMarker"),
                    r
                );
            };
            function r(r) {
                return 93 === r
                    ? (e.enter("referenceMarker"),
                      e.consume(r),
                      e.exit("referenceMarker"),
                      e.exit("reference"),
                      t)
                    : n(r);
            }
        },
    };
const Un = {
    name: "labelStartImage",
    resolveAll: On.resolveAll,
    tokenize: function (e, t, n) {
        const r = this;
        return function (t) {
            return (
                e.enter("labelImage"),
                e.enter("labelImageMarker"),
                e.consume(t),
                e.exit("labelImageMarker"),
                o
            );
        };
        function o(t) {
            return 91 === t
                ? (e.enter("labelMarker"),
                  e.consume(t),
                  e.exit("labelMarker"),
                  e.exit("labelImage"),
                  i)
                : n(t);
        }
        function i(e) {
            return 94 === e && "_hiddenFootnoteSupport" in r.parser.constructs
                ? n(e)
                : t(e);
        }
    },
};
const Zn = {
    name: "labelStartLink",
    resolveAll: On.resolveAll,
    tokenize: function (e, t, n) {
        const r = this;
        return function (t) {
            return (
                e.enter("labelLink"),
                e.enter("labelMarker"),
                e.consume(t),
                e.exit("labelMarker"),
                e.exit("labelLink"),
                o
            );
        };
        function o(e) {
            return 94 === e && "_hiddenFootnoteSupport" in r.parser.constructs
                ? n(e)
                : t(e);
        }
    },
};
const zn = {
    name: "lineEnding",
    tokenize: function (e, t) {
        return function (n) {
            return (
                e.enter("lineEnding"),
                e.consume(n),
                e.exit("lineEnding"),
                Jt(e, t, "linePrefix")
            );
        };
    },
};
const $n = {
    name: "thematicBreak",
    tokenize: function (e, t, n) {
        let r,
            o = 0;
        return function (t) {
            return (
                e.enter("thematicBreak"),
                (function (e) {
                    return (r = e), i(e);
                })(t)
            );
        };
        function i(i) {
            return i === r
                ? (e.enter("thematicBreakSequence"), s(i))
                : o >= 3 && (null === i || Wt(i))
                ? (e.exit("thematicBreak"), t(i))
                : n(i);
        }
        function s(t) {
            return t === r
                ? (e.consume(t), o++, s)
                : (e.exit("thematicBreakSequence"),
                  Kt(t) ? Jt(e, i, "whitespace")(t) : i(t));
        }
    },
};
const Wn = {
        continuation: {
            tokenize: function (e, t, n) {
                const r = this;
                return (
                    (r.containerState._closeFlow = void 0),
                    e.check(
                        cn,
                        function (n) {
                            return (
                                (r.containerState.furtherBlankLines =
                                    r.containerState.furtherBlankLines ||
                                    r.containerState.initialBlankLine),
                                Jt(
                                    e,
                                    t,
                                    "listItemIndent",
                                    r.containerState.size + 1
                                )(n)
                            );
                        },
                        function (n) {
                            if (r.containerState.furtherBlankLines || !Kt(n))
                                return (
                                    (r.containerState.furtherBlankLines =
                                        void 0),
                                    (r.containerState.initialBlankLine =
                                        void 0),
                                    o(n)
                                );
                            return (
                                (r.containerState.furtherBlankLines = void 0),
                                (r.containerState.initialBlankLine = void 0),
                                e.attempt(Kn, t, o)(n)
                            );
                        }
                    )
                );
                function o(o) {
                    return (
                        (r.containerState._closeFlow = !0),
                        (r.interrupt = void 0),
                        Jt(
                            e,
                            e.attempt(Wn, t, n),
                            "linePrefix",
                            r.parser.constructs.disable.null.includes(
                                "codeIndented"
                            )
                                ? void 0
                                : 4
                        )(o)
                    );
                }
            },
        },
        exit: function (e) {
            e.exit(this.containerState.type);
        },
        name: "list",
        tokenize: function (e, t, n) {
            const r = this,
                o = r.events[r.events.length - 1];
            let i =
                    o && "linePrefix" === o[1].type
                        ? o[2].sliceSerialize(o[1], !0).length
                        : 0,
                s = 0;
            return function (t) {
                const o =
                    r.containerState.type ||
                    (42 === t || 43 === t || 45 === t
                        ? "listUnordered"
                        : "listOrdered");
                if (
                    "listUnordered" === o
                        ? !r.containerState.marker ||
                          t === r.containerState.marker
                        : Zt(t)
                ) {
                    if (
                        (r.containerState.type ||
                            ((r.containerState.type = o),
                            e.enter(o, { _container: !0 })),
                        "listUnordered" === o)
                    )
                        return (
                            e.enter("listItemPrefix"),
                            42 === t || 45 === t ? e.check($n, n, l)(t) : l(t)
                        );
                    if (!r.interrupt || 49 === t)
                        return (
                            e.enter("listItemPrefix"),
                            e.enter("listItemValue"),
                            a(t)
                        );
                }
                return n(t);
            };
            function a(t) {
                return Zt(t) && ++s < 10
                    ? (e.consume(t), a)
                    : (!r.interrupt || s < 2) &&
                      (r.containerState.marker
                          ? t === r.containerState.marker
                          : 41 === t || 46 === t)
                    ? (e.exit("listItemValue"), l(t))
                    : n(t);
            }
            function l(t) {
                return (
                    e.enter("listItemMarker"),
                    e.consume(t),
                    e.exit("listItemMarker"),
                    (r.containerState.marker = r.containerState.marker || t),
                    e.check(cn, r.interrupt ? n : c, e.attempt(qn, d, u))
                );
            }
            function c(e) {
                return (r.containerState.initialBlankLine = !0), i++, d(e);
            }
            function u(t) {
                return Kt(t)
                    ? (e.enter("listItemPrefixWhitespace"),
                      e.consume(t),
                      e.exit("listItemPrefixWhitespace"),
                      d)
                    : n(t);
            }
            function d(n) {
                return (
                    (r.containerState.size =
                        i +
                        r.sliceSerialize(e.exit("listItemPrefix"), !0).length),
                    t(n)
                );
            }
        },
    },
    qn = {
        partial: !0,
        tokenize: function (e, t, n) {
            const r = this;
            return Jt(
                e,
                function (e) {
                    const o = r.events[r.events.length - 1];
                    return !Kt(e) &&
                        o &&
                        "listItemPrefixWhitespace" === o[1].type
                        ? t(e)
                        : n(e);
                },
                "listItemPrefixWhitespace",
                r.parser.constructs.disable.null.includes("codeIndented")
                    ? void 0
                    : 5
            );
        },
    },
    Kn = {
        partial: !0,
        tokenize: function (e, t, n) {
            const r = this;
            return Jt(
                e,
                function (e) {
                    const o = r.events[r.events.length - 1];
                    return o &&
                        "listItemIndent" === o[1].type &&
                        o[2].sliceSerialize(o[1], !0).length ===
                            r.containerState.size
                        ? t(e)
                        : n(e);
                },
                "listItemIndent",
                r.containerState.size + 1
            );
        },
    };
const Yn = {
    name: "setextUnderline",
    resolveTo: function (e, t) {
        let n,
            r,
            o,
            i = e.length;
        for (; i--; )
            if ("enter" === e[i][0]) {
                if ("content" === e[i][1].type) {
                    n = i;
                    break;
                }
                "paragraph" === e[i][1].type && (r = i);
            } else
                "content" === e[i][1].type && e.splice(i, 1),
                    o || "definition" !== e[i][1].type || (o = i);
        const s = {
            type: "setextHeading",
            start: { ...e[n][1].start },
            end: { ...e[e.length - 1][1].end },
        };
        (e[r][1].type = "setextHeadingText"),
            o
                ? (e.splice(r, 0, ["enter", s, t]),
                  e.splice(o + 1, 0, ["exit", e[n][1], t]),
                  (e[n][1].end = { ...e[o][1].end }))
                : (e[n][1] = s);
        return e.push(["exit", s, t]), e;
    },
    tokenize: function (e, t, n) {
        const r = this;
        let o;
        return function (t) {
            let s,
                a = r.events.length;
            for (; a--; )
                if (
                    "lineEnding" !== r.events[a][1].type &&
                    "linePrefix" !== r.events[a][1].type &&
                    "content" !== r.events[a][1].type
                ) {
                    s = "paragraph" === r.events[a][1].type;
                    break;
                }
            if (!r.parser.lazy[r.now().line] && (r.interrupt || s))
                return (
                    e.enter("setextHeadingLine"),
                    (o = t),
                    (function (t) {
                        return e.enter("setextHeadingLineSequence"), i(t);
                    })(t)
                );
            return n(t);
        };
        function i(t) {
            return t === o
                ? (e.consume(t), i)
                : (e.exit("setextHeadingLineSequence"),
                  Kt(t) ? Jt(e, s, "lineSuffix")(t) : s(t));
        }
        function s(r) {
            return null === r || Wt(r)
                ? (e.exit("setextHeadingLine"), t(r))
                : n(r);
        }
    },
};
const Xn = {
    tokenize: function (e) {
        const t = this,
            n = e.attempt(
                cn,
                function (r) {
                    if (null === r) return void e.consume(r);
                    return (
                        e.enter("lineEndingBlank"),
                        e.consume(r),
                        e.exit("lineEndingBlank"),
                        (t.currentConstruct = void 0),
                        n
                    );
                },
                e.attempt(
                    this.parser.constructs.flowInitial,
                    r,
                    Jt(
                        e,
                        e.attempt(
                            this.parser.constructs.flow,
                            r,
                            e.attempt(bn, r)
                        ),
                        "linePrefix"
                    )
                )
            );
        return n;
        function r(r) {
            if (null !== r)
                return (
                    e.enter("lineEnding"),
                    e.consume(r),
                    e.exit("lineEnding"),
                    (t.currentConstruct = void 0),
                    n
                );
            e.consume(r);
        }
    },
};
const Gn = { resolveAll: tr() },
    Qn = er("string"),
    Jn = er("text");
function er(e) {
    return {
        resolveAll: tr("text" === e ? nr : void 0),
        tokenize: function (t) {
            const n = this,
                r = this.parser.constructs[e],
                o = t.attempt(r, i, s);
            return i;
            function i(e) {
                return l(e) ? o(e) : s(e);
            }
            function s(e) {
                if (null !== e) return t.enter("data"), t.consume(e), a;
                t.consume(e);
            }
            function a(e) {
                return l(e) ? (t.exit("data"), o(e)) : (t.consume(e), a);
            }
            function l(e) {
                if (null === e) return !0;
                const t = r[e];
                let o = -1;
                if (t)
                    for (; ++o < t.length; ) {
                        const e = t[o];
                        if (!e.previous || e.previous.call(n, n.previous))
                            return !0;
                    }
                return !1;
            }
        },
    };
}
function tr(e) {
    return function (t, n) {
        let r,
            o = -1;
        for (; ++o <= t.length; )
            void 0 === r
                ? t[o] && "data" === t[o][1].type && ((r = o), o++)
                : (t[o] && "data" === t[o][1].type) ||
                  (o !== r + 2 &&
                      ((t[r][1].end = t[o - 1][1].end),
                      t.splice(r + 2, o - r - 2),
                      (o = r + 2)),
                  (r = void 0));
        return e ? e(t, n) : t;
    };
}
function nr(e, t) {
    let n = 0;
    for (; ++n <= e.length; )
        if (
            (n === e.length || "lineEnding" === e[n][1].type) &&
            "data" === e[n - 1][1].type
        ) {
            const r = e[n - 1][1],
                o = t.sliceStream(r);
            let i,
                s = o.length,
                a = -1,
                l = 0;
            for (; s--; ) {
                const e = o[s];
                if ("string" == typeof e) {
                    for (a = e.length; 32 === e.charCodeAt(a - 1); ) l++, a--;
                    if (a) break;
                    a = -1;
                } else if (-2 === e) (i = !0), l++;
                else if (-1 !== e) {
                    s++;
                    break;
                }
            }
            if ((t._contentTypeTextTrailing && n === e.length && (l = 0), l)) {
                const o = {
                    type:
                        n === e.length || i || l < 2
                            ? "lineSuffix"
                            : "hardBreakTrailing",
                    start: {
                        _bufferIndex: s ? a : r.start._bufferIndex + a,
                        _index: r.start._index + s,
                        line: r.end.line,
                        column: r.end.column - l,
                        offset: r.end.offset - l,
                    },
                    end: { ...r.end },
                };
                (r.end = { ...o.start }),
                    r.start.offset === r.end.offset
                        ? Object.assign(r, o)
                        : (e.splice(n, 0, ["enter", o, t], ["exit", o, t]),
                          (n += 2));
            }
            n++;
        }
    return e;
}
const rr = {
        42: Wn,
        43: Wn,
        45: Wn,
        48: Wn,
        49: Wn,
        50: Wn,
        51: Wn,
        52: Wn,
        53: Wn,
        54: Wn,
        55: Wn,
        56: Wn,
        57: Wn,
        62: un,
    },
    or = { 91: Ln },
    ir = { [-2]: mn, [-1]: mn, 32: mn },
    sr = {
        35: jn,
        42: $n,
        45: [Yn, $n],
        60: Dn,
        61: Yn,
        95: $n,
        96: fn,
        126: fn,
    },
    ar = { 38: hn, 92: dn },
    lr = {
        [-5]: zn,
        [-4]: zn,
        [-3]: zn,
        33: Un,
        38: hn,
        42: sn,
        60: [ln, _n],
        91: Zn,
        92: [Pn, dn],
        93: On,
        95: sn,
        96: yn,
    },
    cr = { null: [sn, Gn] },
    ur = Object.freeze(
        Object.defineProperty(
            {
                __proto__: null,
                attentionMarkers: { null: [42, 95] },
                contentInitial: or,
                disable: { null: [] },
                document: rr,
                flow: sr,
                flowInitial: ir,
                insideSpan: cr,
                string: ar,
                text: lr,
            },
            Symbol.toStringTag,
            { value: "Module" }
        )
    );
function dr(e, t, n) {
    let r = {
        _bufferIndex: -1,
        _index: 0,
        line: (n && n.line) || 1,
        column: (n && n.column) || 1,
        offset: (n && n.offset) || 0,
    };
    const o = {},
        i = [];
    let s = [],
        a = [];
    const l = {
            attempt: g(function (e, t) {
                y(e, t.from);
            }),
            check: g(m),
            consume: function (e) {
                Wt(e)
                    ? (r.line++,
                      (r.column = 1),
                      (r.offset += -3 === e ? 2 : 1),
                      x())
                    : -1 !== e && (r.column++, r.offset++);
                r._bufferIndex < 0
                    ? r._index++
                    : (r._bufferIndex++,
                      r._bufferIndex === s[r._index].length &&
                          ((r._bufferIndex = -1), r._index++));
                c.previous = e;
            },
            enter: function (e, t) {
                const n = t || {};
                return (
                    (n.type = e),
                    (n.start = h()),
                    c.events.push(["enter", n, c]),
                    a.push(n),
                    n
                );
            },
            exit: function (e) {
                const t = a.pop();
                return (t.end = h()), c.events.push(["exit", t, c]), t;
            },
            interrupt: g(m, { interrupt: !0 }),
        },
        c = {
            code: null,
            containerState: {},
            defineSkip: function (e) {
                (o[e.line] = e.column), x();
            },
            events: [],
            now: h,
            parser: e,
            previous: null,
            sliceSerialize: function (e, t) {
                return (function (e, t) {
                    let n = -1;
                    const r = [];
                    let o;
                    for (; ++n < e.length; ) {
                        const i = e[n];
                        let s;
                        if ("string" == typeof i) s = i;
                        else
                            switch (i) {
                                case -5:
                                    s = "\r";
                                    break;
                                case -4:
                                    s = "\n";
                                    break;
                                case -3:
                                    s = "\r\n";
                                    break;
                                case -2:
                                    s = t ? " " : "\t";
                                    break;
                                case -1:
                                    if (!t && o) continue;
                                    s = " ";
                                    break;
                                default:
                                    s = String.fromCharCode(i);
                            }
                        (o = -2 === i), r.push(s);
                    }
                    return r.join("");
                })(d(e), t);
            },
            sliceStream: d,
            write: function (e) {
                if (((s = It(s, e)), p(), null !== s[s.length - 1])) return [];
                return y(t, 0), (c.events = on(i, c.events, c)), c.events;
            },
        };
    let u = t.tokenize.call(c, l);
    return t.resolveAll && i.push(t), c;
    function d(e) {
        return (function (e, t) {
            const n = t.start._index,
                r = t.start._bufferIndex,
                o = t.end._index,
                i = t.end._bufferIndex;
            let s;
            if (n === o) s = [e[n].slice(r, i)];
            else {
                if (((s = e.slice(n, o)), r > -1)) {
                    const e = s[0];
                    "string" == typeof e ? (s[0] = e.slice(r)) : s.shift();
                }
                i > 0 && s.push(e[o].slice(0, i));
            }
            return s;
        })(s, e);
    }
    function h() {
        const { _bufferIndex: e, _index: t, line: n, column: o, offset: i } = r;
        return { _bufferIndex: e, _index: t, line: n, column: o, offset: i };
    }
    function p() {
        let e;
        for (; r._index < s.length; ) {
            const t = s[r._index];
            if ("string" == typeof t)
                for (
                    e = r._index, r._bufferIndex < 0 && (r._bufferIndex = 0);
                    r._index === e && r._bufferIndex < t.length;

                )
                    f(t.charCodeAt(r._bufferIndex));
            else f(t);
        }
    }
    function f(e) {
        u = u(e);
    }
    function m(e, t) {
        t.restore();
    }
    function g(e, t) {
        return function (n, o, i) {
            let s, u, d, p;
            return Array.isArray(n)
                ? f(n)
                : "tokenize" in n
                ? f([n])
                : (function (e) {
                      return t;
                      function t(t) {
                          const n = null !== t && e[t],
                              r = null !== t && e.null;
                          return f([
                              ...(Array.isArray(n) ? n : n ? [n] : []),
                              ...(Array.isArray(r) ? r : r ? [r] : []),
                          ])(t);
                      }
                  })(n);
            function f(e) {
                return (s = e), (u = 0), 0 === e.length ? i : m(e[u]);
            }
            function m(e) {
                return function (n) {
                    (p = (function () {
                        const e = h(),
                            t = c.previous,
                            n = c.currentConstruct,
                            o = c.events.length,
                            i = Array.from(a);
                        return { from: o, restore: s };
                        function s() {
                            (r = e),
                                (c.previous = t),
                                (c.currentConstruct = n),
                                (c.events.length = o),
                                (a = i),
                                x();
                        }
                    })()),
                        (d = e),
                        e.partial || (c.currentConstruct = e);
                    if (
                        e.name &&
                        c.parser.constructs.disable.null.includes(e.name)
                    )
                        return y();
                    return e.tokenize.call(
                        t ? Object.assign(Object.create(c), t) : c,
                        l,
                        g,
                        y
                    )(n);
                };
            }
            function g(t) {
                return e(d, p), o;
            }
            function y(e) {
                return p.restore(), ++u < s.length ? m(s[u]) : i;
            }
        };
    }
    function y(e, t) {
        e.resolveAll && !i.includes(e) && i.push(e),
            e.resolve &&
                Nt(
                    c.events,
                    t,
                    c.events.length - t,
                    e.resolve(c.events.slice(t), c)
                ),
            e.resolveTo && (c.events = e.resolveTo(c.events, c));
    }
    function x() {
        r.line in o &&
            r.column < 2 &&
            ((r.column = o[r.line]), (r.offset += o[r.line] - 1));
    }
}
function hr(e) {
    const t = {
        constructs: (function (e) {
            const t = {};
            let n = -1;
            for (; ++n < e.length; ) Vt(t, e[n]);
            return t;
        })([ur, ...((e || {}).extensions || [])]),
        content: n(en),
        defined: [],
        document: n(tn),
        flow: n(Xn),
        lazy: {},
        string: n(Qn),
        text: n(Jn),
    };
    return t;
    function n(e) {
        return function (n) {
            return dr(t, e, n);
        };
    }
}
const pr = /[\0\t\n\r]/g;
const fr = /\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;
function mr(e, t, n) {
    if (t) return t;
    if (35 === n.charCodeAt(0)) {
        const e = n.charCodeAt(1),
            t = 120 === e || 88 === e;
        return _t(n.slice(t ? 2 : 1), t ? 16 : 10);
    }
    return jt(n) || e;
}
const gr = {}.hasOwnProperty;
function yr(e, t, n) {
    return (
        "string" != typeof t && ((n = t), (t = void 0)),
        (function (e) {
            const t = {
                transforms: [],
                canContainEols: [
                    "emphasis",
                    "fragment",
                    "heading",
                    "paragraph",
                    "strong",
                ],
                enter: {
                    autolink: i(te),
                    autolinkProtocol: S,
                    autolinkEmail: S,
                    atxHeading: i(G),
                    blockQuote: i(W),
                    characterEscape: S,
                    characterReference: S,
                    codeFenced: i(q),
                    codeFencedFenceInfo: s,
                    codeFencedFenceMeta: s,
                    codeIndented: i(q, s),
                    codeText: i(K, s),
                    codeTextData: S,
                    data: S,
                    codeFlowValue: S,
                    definition: i(Y),
                    definitionDestinationString: s,
                    definitionLabelString: s,
                    definitionTitleString: s,
                    emphasis: i(X),
                    hardBreakEscape: i(Q),
                    hardBreakTrailing: i(Q),
                    htmlFlow: i(J, s),
                    htmlFlowData: S,
                    htmlText: i(J, s),
                    htmlTextData: S,
                    image: i(ee),
                    label: s,
                    link: i(te),
                    listItem: i(re),
                    listItemValue: h,
                    listOrdered: i(ne, d),
                    listUnordered: i(ne),
                    paragraph: i(oe),
                    reference: H,
                    referenceString: s,
                    resourceDestinationString: s,
                    resourceTitleString: s,
                    setextHeading: i(G),
                    strong: i(ie),
                    thematicBreak: i(ae),
                },
                exit: {
                    atxHeading: l(),
                    atxHeadingSequence: w,
                    autolink: l(),
                    autolinkEmail: $,
                    autolinkProtocol: z,
                    blockQuote: l(),
                    characterEscapeValue: A,
                    characterReferenceMarkerHexadecimal: B,
                    characterReferenceMarkerNumeric: B,
                    characterReferenceValue: U,
                    characterReference: Z,
                    codeFenced: l(g),
                    codeFencedFence: m,
                    codeFencedFenceInfo: p,
                    codeFencedFenceMeta: f,
                    codeFlowValue: A,
                    codeIndented: l(y),
                    codeText: l(j),
                    codeTextData: A,
                    data: A,
                    definition: l(),
                    definitionDestinationString: C,
                    definitionLabelString: x,
                    definitionTitleString: v,
                    emphasis: l(),
                    hardBreakEscape: l(L),
                    hardBreakTrailing: l(L),
                    htmlFlow: l(M),
                    htmlFlowData: A,
                    htmlText: l(P),
                    htmlTextData: A,
                    image: l(I),
                    label: V,
                    labelText: D,
                    lineEnding: T,
                    link: l(N),
                    listItem: l(),
                    listOrdered: l(),
                    listUnordered: l(),
                    paragraph: l(),
                    referenceString: F,
                    resourceDestinationString: R,
                    resourceTitleString: _,
                    resource: O,
                    setextHeading: l(E),
                    setextHeadingLineSequence: k,
                    setextHeadingText: b,
                    strong: l(),
                    thematicBreak: l(),
                },
            };
            vr(t, (e || {}).mdastExtensions || []);
            const n = {};
            return r;
            function r(e) {
                let r = { type: "root", children: [] };
                const i = {
                        stack: [r],
                        tokenStack: [],
                        config: t,
                        enter: a,
                        exit: c,
                        buffer: s,
                        resume: u,
                        data: n,
                    },
                    l = [];
                let d = -1;
                for (; ++d < e.length; )
                    if (
                        "listOrdered" === e[d][1].type ||
                        "listUnordered" === e[d][1].type
                    )
                        if ("enter" === e[d][0]) l.push(d);
                        else {
                            d = o(e, l.pop(), d);
                        }
                for (d = -1; ++d < e.length; ) {
                    const n = t[e[d][0]];
                    gr.call(n, e[d][1].type) &&
                        n[e[d][1].type].call(
                            Object.assign(
                                { sliceSerialize: e[d][2].sliceSerialize },
                                i
                            ),
                            e[d][1]
                        );
                }
                if (i.tokenStack.length > 0) {
                    const e = i.tokenStack[i.tokenStack.length - 1];
                    (e[1] || wr).call(i, void 0, e[0]);
                }
                for (
                    r.position = {
                        start: xr(
                            e.length > 0
                                ? e[0][1].start
                                : { line: 1, column: 1, offset: 0 }
                        ),
                        end: xr(
                            e.length > 0
                                ? e[e.length - 2][1].end
                                : { line: 1, column: 1, offset: 0 }
                        ),
                    },
                        d = -1;
                    ++d < t.transforms.length;

                )
                    r = t.transforms[d](r) || r;
                return r;
            }
            function o(e, t, n) {
                let r,
                    o,
                    i,
                    s,
                    a = t - 1,
                    l = -1,
                    c = !1;
                for (; ++a <= n; ) {
                    const t = e[a];
                    switch (t[1].type) {
                        case "listUnordered":
                        case "listOrdered":
                        case "blockQuote":
                            "enter" === t[0] ? l++ : l--, (s = void 0);
                            break;
                        case "lineEndingBlank":
                            "enter" === t[0] &&
                                (!r || s || l || i || (i = a), (s = void 0));
                            break;
                        case "linePrefix":
                        case "listItemValue":
                        case "listItemMarker":
                        case "listItemPrefix":
                        case "listItemPrefixWhitespace":
                            break;
                        default:
                            s = void 0;
                    }
                    if (
                        (!l &&
                            "enter" === t[0] &&
                            "listItemPrefix" === t[1].type) ||
                        (-1 === l &&
                            "exit" === t[0] &&
                            ("listUnordered" === t[1].type ||
                                "listOrdered" === t[1].type))
                    ) {
                        if (r) {
                            let s = a;
                            for (o = void 0; s--; ) {
                                const t = e[s];
                                if (
                                    "lineEnding" === t[1].type ||
                                    "lineEndingBlank" === t[1].type
                                ) {
                                    if ("exit" === t[0]) continue;
                                    o &&
                                        ((e[o][1].type = "lineEndingBlank"),
                                        (c = !0)),
                                        (t[1].type = "lineEnding"),
                                        (o = s);
                                } else if (
                                    "linePrefix" !== t[1].type &&
                                    "blockQuotePrefix" !== t[1].type &&
                                    "blockQuotePrefixWhitespace" !==
                                        t[1].type &&
                                    "blockQuoteMarker" !== t[1].type &&
                                    "listItemIndent" !== t[1].type
                                )
                                    break;
                            }
                            i && (!o || i < o) && (r._spread = !0),
                                (r.end = Object.assign(
                                    {},
                                    o ? e[o][1].start : t[1].end
                                )),
                                e.splice(o || a, 0, ["exit", r, t[2]]),
                                a++,
                                n++;
                        }
                        if ("listItemPrefix" === t[1].type) {
                            const o = {
                                type: "listItem",
                                _spread: !1,
                                start: Object.assign({}, t[1].start),
                                end: void 0,
                            };
                            (r = o),
                                e.splice(a, 0, ["enter", o, t[2]]),
                                a++,
                                n++,
                                (i = void 0),
                                (s = !0);
                        }
                    }
                }
                return (e[t][1]._spread = c), n;
            }
            function i(e, t) {
                return n;
                function n(n) {
                    a.call(this, e(n), n), t && t.call(this, n);
                }
            }
            function s() {
                this.stack.push({ type: "fragment", children: [] });
            }
            function a(e, t, n) {
                this.stack[this.stack.length - 1].children.push(e),
                    this.stack.push(e),
                    this.tokenStack.push([t, n || void 0]),
                    (e.position = { start: xr(t.start), end: void 0 });
            }
            function l(e) {
                return t;
                function t(t) {
                    e && e.call(this, t), c.call(this, t);
                }
            }
            function c(e, t) {
                const n = this.stack.pop(),
                    r = this.tokenStack.pop();
                if (!r)
                    throw new Error(
                        "Cannot close `" +
                            e.type +
                            "` (" +
                            it({ start: e.start, end: e.end }) +
                            "): it’s not open"
                    );
                if (r[0].type !== e.type)
                    if (t) t.call(this, e, r[0]);
                    else {
                        (r[1] || wr).call(this, e, r[0]);
                    }
                n.position.end = xr(e.end);
            }
            function u() {
                return (function (e) {
                    return Lt(
                        e,
                        "boolean" != typeof Tt.includeImageAlt ||
                            Tt.includeImageAlt,
                        "boolean" != typeof Tt.includeHtml || Tt.includeHtml
                    );
                })(this.stack.pop());
            }
            function d() {
                this.data.expectingFirstListItemValue = !0;
            }
            function h(e) {
                if (this.data.expectingFirstListItemValue) {
                    (this.stack[this.stack.length - 2].start = Number.parseInt(
                        this.sliceSerialize(e),
                        10
                    )),
                        (this.data.expectingFirstListItemValue = void 0);
                }
            }
            function p() {
                const e = this.resume();
                this.stack[this.stack.length - 1].lang = e;
            }
            function f() {
                const e = this.resume();
                this.stack[this.stack.length - 1].meta = e;
            }
            function m() {
                this.data.flowCodeInside ||
                    (this.buffer(), (this.data.flowCodeInside = !0));
            }
            function g() {
                const e = this.resume();
                (this.stack[this.stack.length - 1].value = e.replace(
                    /^(\r?\n|\r)|(\r?\n|\r)$/g,
                    ""
                )),
                    (this.data.flowCodeInside = void 0);
            }
            function y() {
                const e = this.resume();
                this.stack[this.stack.length - 1].value = e.replace(
                    /(\r?\n|\r)$/g,
                    ""
                );
            }
            function x(e) {
                const t = this.resume(),
                    n = this.stack[this.stack.length - 1];
                (n.label = t),
                    (n.identifier = Ot(this.sliceSerialize(e)).toLowerCase());
            }
            function v() {
                const e = this.resume();
                this.stack[this.stack.length - 1].title = e;
            }
            function C() {
                const e = this.resume();
                this.stack[this.stack.length - 1].url = e;
            }
            function w(e) {
                const t = this.stack[this.stack.length - 1];
                if (!t.depth) {
                    const n = this.sliceSerialize(e).length;
                    t.depth = n;
                }
            }
            function b() {
                this.data.setextHeadingSlurpLineEnding = !0;
            }
            function k(e) {
                this.stack[this.stack.length - 1].depth =
                    61 === this.sliceSerialize(e).codePointAt(0) ? 1 : 2;
            }
            function E() {
                this.data.setextHeadingSlurpLineEnding = void 0;
            }
            function S(e) {
                const t = this.stack[this.stack.length - 1].children;
                let n = t[t.length - 1];
                (n && "text" === n.type) ||
                    ((n = se()),
                    (n.position = { start: xr(e.start), end: void 0 }),
                    t.push(n)),
                    this.stack.push(n);
            }
            function A(e) {
                const t = this.stack.pop();
                (t.value += this.sliceSerialize(e)),
                    (t.position.end = xr(e.end));
            }
            function T(e) {
                const n = this.stack[this.stack.length - 1];
                if (this.data.atHardBreak) {
                    return (
                        (n.children[n.children.length - 1].position.end = xr(
                            e.end
                        )),
                        void (this.data.atHardBreak = void 0)
                    );
                }
                !this.data.setextHeadingSlurpLineEnding &&
                    t.canContainEols.includes(n.type) &&
                    (S.call(this, e), A.call(this, e));
            }
            function L() {
                this.data.atHardBreak = !0;
            }
            function M() {
                const e = this.resume();
                this.stack[this.stack.length - 1].value = e;
            }
            function P() {
                const e = this.resume();
                this.stack[this.stack.length - 1].value = e;
            }
            function j() {
                const e = this.resume();
                this.stack[this.stack.length - 1].value = e;
            }
            function N() {
                const e = this.stack[this.stack.length - 1];
                if (this.data.inReference) {
                    const t = this.data.referenceType || "shortcut";
                    (e.type += "Reference"),
                        (e.referenceType = t),
                        delete e.url,
                        delete e.title;
                } else delete e.identifier, delete e.label;
                this.data.referenceType = void 0;
            }
            function I() {
                const e = this.stack[this.stack.length - 1];
                if (this.data.inReference) {
                    const t = this.data.referenceType || "shortcut";
                    (e.type += "Reference"),
                        (e.referenceType = t),
                        delete e.url,
                        delete e.title;
                } else delete e.identifier, delete e.label;
                this.data.referenceType = void 0;
            }
            function D(e) {
                const t = this.sliceSerialize(e),
                    n = this.stack[this.stack.length - 2];
                (n.label = (function (e) {
                    return e.replace(fr, mr);
                })(t)),
                    (n.identifier = Ot(t).toLowerCase());
            }
            function V() {
                const e = this.stack[this.stack.length - 1],
                    t = this.resume(),
                    n = this.stack[this.stack.length - 1];
                if (((this.data.inReference = !0), "link" === n.type)) {
                    const t = e.children;
                    n.children = t;
                } else n.alt = t;
            }
            function R() {
                const e = this.resume();
                this.stack[this.stack.length - 1].url = e;
            }
            function _() {
                const e = this.resume();
                this.stack[this.stack.length - 1].title = e;
            }
            function O() {
                this.data.inReference = void 0;
            }
            function H() {
                this.data.referenceType = "collapsed";
            }
            function F(e) {
                const t = this.resume(),
                    n = this.stack[this.stack.length - 1];
                (n.label = t),
                    (n.identifier = Ot(this.sliceSerialize(e)).toLowerCase()),
                    (this.data.referenceType = "full");
            }
            function B(e) {
                this.data.characterReferenceType = e.type;
            }
            function U(e) {
                const t = this.sliceSerialize(e),
                    n = this.data.characterReferenceType;
                let r;
                if (n)
                    (r = _t(
                        t,
                        "characterReferenceMarkerNumeric" === n ? 10 : 16
                    )),
                        (this.data.characterReferenceType = void 0);
                else {
                    r = jt(t);
                }
                this.stack[this.stack.length - 1].value += r;
            }
            function Z(e) {
                this.stack.pop().position.end = xr(e.end);
            }
            function z(e) {
                A.call(this, e);
                this.stack[this.stack.length - 1].url = this.sliceSerialize(e);
            }
            function $(e) {
                A.call(this, e);
                this.stack[this.stack.length - 1].url =
                    "mailto:" + this.sliceSerialize(e);
            }
            function W() {
                return { type: "blockquote", children: [] };
            }
            function q() {
                return { type: "code", lang: null, meta: null, value: "" };
            }
            function K() {
                return { type: "inlineCode", value: "" };
            }
            function Y() {
                return {
                    type: "definition",
                    identifier: "",
                    label: null,
                    title: null,
                    url: "",
                };
            }
            function X() {
                return { type: "emphasis", children: [] };
            }
            function G() {
                return { type: "heading", depth: 0, children: [] };
            }
            function Q() {
                return { type: "break" };
            }
            function J() {
                return { type: "html", value: "" };
            }
            function ee() {
                return { type: "image", title: null, url: "", alt: null };
            }
            function te() {
                return { type: "link", title: null, url: "", children: [] };
            }
            function ne(e) {
                return {
                    type: "list",
                    ordered: "listOrdered" === e.type,
                    start: null,
                    spread: e._spread,
                    children: [],
                };
            }
            function re(e) {
                return {
                    type: "listItem",
                    spread: e._spread,
                    checked: null,
                    children: [],
                };
            }
            function oe() {
                return { type: "paragraph", children: [] };
            }
            function ie() {
                return { type: "strong", children: [] };
            }
            function se() {
                return { type: "text", value: "" };
            }
            function ae() {
                return { type: "thematicBreak" };
            }
        })(n)(
            (function (e) {
                for (; !Cn(e); );
                return e;
            })(
                hr(n)
                    .document()
                    .write(
                        (function () {
                            let e,
                                t = 1,
                                n = "",
                                r = !0;
                            return function (o, i, s) {
                                const a = [];
                                let l, c, u, d, h;
                                for (
                                    o =
                                        n +
                                        ("string" == typeof o
                                            ? o.toString()
                                            : new TextDecoder(
                                                  i || void 0
                                              ).decode(o)),
                                        u = 0,
                                        n = "",
                                        r &&
                                            (65279 === o.charCodeAt(0) && u++,
                                            (r = void 0));
                                    u < o.length;

                                ) {
                                    if (
                                        ((pr.lastIndex = u),
                                        (l = pr.exec(o)),
                                        (d =
                                            l && void 0 !== l.index
                                                ? l.index
                                                : o.length),
                                        (h = o.charCodeAt(d)),
                                        !l)
                                    ) {
                                        n = o.slice(u);
                                        break;
                                    }
                                    if (10 === h && u === d && e)
                                        a.push(-3), (e = void 0);
                                    else
                                        switch (
                                            (e && (a.push(-5), (e = void 0)),
                                            u < d &&
                                                (a.push(o.slice(u, d)),
                                                (t += d - u)),
                                            h)
                                        ) {
                                            case 0:
                                                a.push(65533), t++;
                                                break;
                                            case 9:
                                                for (
                                                    c = 4 * Math.ceil(t / 4),
                                                        a.push(-2);
                                                    t++ < c;

                                                )
                                                    a.push(-1);
                                                break;
                                            case 10:
                                                a.push(-4), (t = 1);
                                                break;
                                            default:
                                                (e = !0), (t = 1);
                                        }
                                    u = d + 1;
                                }
                                return (
                                    s &&
                                        (e && a.push(-5),
                                        n && a.push(n),
                                        a.push(null)),
                                    a
                                );
                            };
                        })()(e, t, !0)
                    )
            )
        )
    );
}
function xr(e) {
    return { line: e.line, column: e.column, offset: e.offset };
}
function vr(e, t) {
    let n = -1;
    for (; ++n < t.length; ) {
        const r = t[n];
        Array.isArray(r) ? vr(e, r) : Cr(e, r);
    }
}
function Cr(e, t) {
    let n;
    for (n in t)
        if (gr.call(t, n))
            switch (n) {
                case "canContainEols": {
                    const r = t[n];
                    r && e[n].push(...r);
                    break;
                }
                case "transforms": {
                    const r = t[n];
                    r && e[n].push(...r);
                    break;
                }
                case "enter":
                case "exit": {
                    const r = t[n];
                    r && Object.assign(e[n], r);
                    break;
                }
            }
}
function wr(e, t) {
    throw e
        ? new Error(
              "Cannot close `" +
                  e.type +
                  "` (" +
                  it({ start: e.start, end: e.end }) +
                  "): a different token (`" +
                  t.type +
                  "`, " +
                  it({ start: t.start, end: t.end }) +
                  ") is open"
          )
        : new Error(
              "Cannot close document, a token (`" +
                  t.type +
                  "`, " +
                  it({ start: t.start, end: t.end }) +
                  ") is still open"
          );
}
function br(e) {
    const t = this;
    t.parser = function (n) {
        return yr(n, {
            ...t.data("settings"),
            ...e,
            extensions: t.data("micromarkExtensions") || [],
            mdastExtensions: t.data("fromMarkdownExtensions") || [],
        });
    };
}
function kr(e, t) {
    const n = t.referenceType;
    let r = "]";
    if (
        ("collapsed" === n
            ? (r += "[]")
            : "full" === n && (r += "[" + (t.label || t.identifier) + "]"),
        "imageReference" === t.type)
    )
        return [{ type: "text", value: "![" + t.alt + r }];
    const o = e.all(t),
        i = o[0];
    i && "text" === i.type
        ? (i.value = "[" + i.value)
        : o.unshift({ type: "text", value: "[" });
    const s = o[o.length - 1];
    return (
        s && "text" === s.type
            ? (s.value += r)
            : o.push({ type: "text", value: r }),
        o
    );
}
function Er(e) {
    const t = e.spread;
    return null == t ? e.children.length > 1 : t;
}
function Sr(e) {
    const t = String(e),
        n = /\r?\n|\r/g;
    let r = n.exec(t),
        o = 0;
    const i = [];
    for (; r; )
        i.push(Ar(t.slice(o, r.index), o > 0, !0), r[0]),
            (o = r.index + r[0].length),
            (r = n.exec(t));
    return i.push(Ar(t.slice(o), o > 0, !1)), i.join("");
}
function Ar(e, t, n) {
    let r = 0,
        o = e.length;
    if (t) {
        let t = e.codePointAt(r);
        for (; 9 === t || 32 === t; ) r++, (t = e.codePointAt(r));
    }
    if (n) {
        let t = e.codePointAt(o - 1);
        for (; 9 === t || 32 === t; ) o--, (t = e.codePointAt(o - 1));
    }
    return o > r ? e.slice(r, o) : "";
}
const Tr = {
    blockquote: function (e, t) {
        const n = {
            type: "element",
            tagName: "blockquote",
            properties: {},
            children: e.wrap(e.all(t), !0),
        };
        return e.patch(t, n), e.applyData(t, n);
    },
    break: function (e, t) {
        const n = {
            type: "element",
            tagName: "br",
            properties: {},
            children: [],
        };
        return (
            e.patch(t, n), [e.applyData(t, n), { type: "text", value: "\n" }]
        );
    },
    code: function (e, t) {
        const n = t.value ? t.value + "\n" : "",
            r = {};
        t.lang && (r.className = ["language-" + t.lang]);
        let o = {
            type: "element",
            tagName: "code",
            properties: r,
            children: [{ type: "text", value: n }],
        };
        return (
            t.meta && (o.data = { meta: t.meta }),
            e.patch(t, o),
            (o = e.applyData(t, o)),
            (o = {
                type: "element",
                tagName: "pre",
                properties: {},
                children: [o],
            }),
            e.patch(t, o),
            o
        );
    },
    delete: function (e, t) {
        const n = {
            type: "element",
            tagName: "del",
            properties: {},
            children: e.all(t),
        };
        return e.patch(t, n), e.applyData(t, n);
    },
    emphasis: function (e, t) {
        const n = {
            type: "element",
            tagName: "em",
            properties: {},
            children: e.all(t),
        };
        return e.patch(t, n), e.applyData(t, n);
    },
    footnoteReference: function (e, t) {
        const n =
                "string" == typeof e.options.clobberPrefix
                    ? e.options.clobberPrefix
                    : "user-content-",
            r = String(t.identifier).toUpperCase(),
            o = Qt(r.toLowerCase()),
            i = e.footnoteOrder.indexOf(r);
        let s,
            a = e.footnoteCounts.get(r);
        void 0 === a
            ? ((a = 0), e.footnoteOrder.push(r), (s = e.footnoteOrder.length))
            : (s = i + 1),
            (a += 1),
            e.footnoteCounts.set(r, a);
        const l = {
            type: "element",
            tagName: "a",
            properties: {
                href: "#" + n + "fn-" + o,
                id: n + "fnref-" + o + (a > 1 ? "-" + a : ""),
                dataFootnoteRef: !0,
                ariaDescribedBy: ["footnote-label"],
            },
            children: [{ type: "text", value: String(s) }],
        };
        e.patch(t, l);
        const c = {
            type: "element",
            tagName: "sup",
            properties: {},
            children: [l],
        };
        return e.patch(t, c), e.applyData(t, c);
    },
    heading: function (e, t) {
        const n = {
            type: "element",
            tagName: "h" + t.depth,
            properties: {},
            children: e.all(t),
        };
        return e.patch(t, n), e.applyData(t, n);
    },
    html: function (e, t) {
        if (e.options.allowDangerousHtml) {
            const n = { type: "raw", value: t.value };
            return e.patch(t, n), e.applyData(t, n);
        }
    },
    imageReference: function (e, t) {
        const n = String(t.identifier).toUpperCase(),
            r = e.definitionById.get(n);
        if (!r) return kr(e, t);
        const o = { src: Qt(r.url || ""), alt: t.alt };
        null !== r.title && void 0 !== r.title && (o.title = r.title);
        const i = {
            type: "element",
            tagName: "img",
            properties: o,
            children: [],
        };
        return e.patch(t, i), e.applyData(t, i);
    },
    image: function (e, t) {
        const n = { src: Qt(t.url) };
        null !== t.alt && void 0 !== t.alt && (n.alt = t.alt),
            null !== t.title && void 0 !== t.title && (n.title = t.title);
        const r = {
            type: "element",
            tagName: "img",
            properties: n,
            children: [],
        };
        return e.patch(t, r), e.applyData(t, r);
    },
    inlineCode: function (e, t) {
        const n = { type: "text", value: t.value.replace(/\r?\n|\r/g, " ") };
        e.patch(t, n);
        const r = {
            type: "element",
            tagName: "code",
            properties: {},
            children: [n],
        };
        return e.patch(t, r), e.applyData(t, r);
    },
    linkReference: function (e, t) {
        const n = String(t.identifier).toUpperCase(),
            r = e.definitionById.get(n);
        if (!r) return kr(e, t);
        const o = { href: Qt(r.url || "") };
        null !== r.title && void 0 !== r.title && (o.title = r.title);
        const i = {
            type: "element",
            tagName: "a",
            properties: o,
            children: e.all(t),
        };
        return e.patch(t, i), e.applyData(t, i);
    },
    link: function (e, t) {
        const n = { href: Qt(t.url) };
        null !== t.title && void 0 !== t.title && (n.title = t.title);
        const r = {
            type: "element",
            tagName: "a",
            properties: n,
            children: e.all(t),
        };
        return e.patch(t, r), e.applyData(t, r);
    },
    listItem: function (e, t, n) {
        const r = e.all(t),
            o = n
                ? (function (e) {
                      let t = !1;
                      if ("list" === e.type) {
                          t = e.spread || !1;
                          const n = e.children;
                          let r = -1;
                          for (; !t && ++r < n.length; ) t = Er(n[r]);
                      }
                      return t;
                  })(n)
                : Er(t),
            i = {},
            s = [];
        if ("boolean" == typeof t.checked) {
            const e = r[0];
            let n;
            e && "element" === e.type && "p" === e.tagName
                ? (n = e)
                : ((n = {
                      type: "element",
                      tagName: "p",
                      properties: {},
                      children: [],
                  }),
                  r.unshift(n)),
                n.children.length > 0 &&
                    n.children.unshift({ type: "text", value: " " }),
                n.children.unshift({
                    type: "element",
                    tagName: "input",
                    properties: {
                        type: "checkbox",
                        checked: t.checked,
                        disabled: !0,
                    },
                    children: [],
                }),
                (i.className = ["task-list-item"]);
        }
        let a = -1;
        for (; ++a < r.length; ) {
            const e = r[a];
            (o || 0 !== a || "element" !== e.type || "p" !== e.tagName) &&
                s.push({ type: "text", value: "\n" }),
                "element" !== e.type || "p" !== e.tagName || o
                    ? s.push(e)
                    : s.push(...e.children);
        }
        const l = r[r.length - 1];
        l &&
            (o || "element" !== l.type || "p" !== l.tagName) &&
            s.push({ type: "text", value: "\n" });
        const c = {
            type: "element",
            tagName: "li",
            properties: i,
            children: s,
        };
        return e.patch(t, c), e.applyData(t, c);
    },
    list: function (e, t) {
        const n = {},
            r = e.all(t);
        let o = -1;
        for (
            "number" == typeof t.start && 1 !== t.start && (n.start = t.start);
            ++o < r.length;

        ) {
            const e = r[o];
            if (
                "element" === e.type &&
                "li" === e.tagName &&
                e.properties &&
                Array.isArray(e.properties.className) &&
                e.properties.className.includes("task-list-item")
            ) {
                n.className = ["contains-task-list"];
                break;
            }
        }
        const i = {
            type: "element",
            tagName: t.ordered ? "ol" : "ul",
            properties: n,
            children: e.wrap(r, !0),
        };
        return e.patch(t, i), e.applyData(t, i);
    },
    paragraph: function (e, t) {
        const n = {
            type: "element",
            tagName: "p",
            properties: {},
            children: e.all(t),
        };
        return e.patch(t, n), e.applyData(t, n);
    },
    root: function (e, t) {
        const n = { type: "root", children: e.wrap(e.all(t)) };
        return e.patch(t, n), e.applyData(t, n);
    },
    strong: function (e, t) {
        const n = {
            type: "element",
            tagName: "strong",
            properties: {},
            children: e.all(t),
        };
        return e.patch(t, n), e.applyData(t, n);
    },
    table: function (e, t) {
        const n = e.all(t),
            r = n.shift(),
            o = [];
        if (r) {
            const n = {
                type: "element",
                tagName: "thead",
                properties: {},
                children: e.wrap([r], !0),
            };
            e.patch(t.children[0], n), o.push(n);
        }
        if (n.length > 0) {
            const r = {
                    type: "element",
                    tagName: "tbody",
                    properties: {},
                    children: e.wrap(n, !0),
                },
                i = rt(t.children[1]),
                s = nt(t.children[t.children.length - 1]);
            i && s && (r.position = { start: i, end: s }), o.push(r);
        }
        const i = {
            type: "element",
            tagName: "table",
            properties: {},
            children: e.wrap(o, !0),
        };
        return e.patch(t, i), e.applyData(t, i);
    },
    tableCell: function (e, t) {
        const n = {
            type: "element",
            tagName: "td",
            properties: {},
            children: e.all(t),
        };
        return e.patch(t, n), e.applyData(t, n);
    },
    tableRow: function (e, t, n) {
        const r = n ? n.children : void 0,
            o = 0 === (r ? r.indexOf(t) : 1) ? "th" : "td",
            i = n && "table" === n.type ? n.align : void 0,
            s = i ? i.length : t.children.length;
        let a = -1;
        const l = [];
        for (; ++a < s; ) {
            const n = t.children[a],
                r = {},
                s = i ? i[a] : void 0;
            s && (r.align = s);
            let c = {
                type: "element",
                tagName: o,
                properties: r,
                children: [],
            };
            n &&
                ((c.children = e.all(n)),
                e.patch(n, c),
                (c = e.applyData(n, c))),
                l.push(c);
        }
        const c = {
            type: "element",
            tagName: "tr",
            properties: {},
            children: e.wrap(l, !0),
        };
        return e.patch(t, c), e.applyData(t, c);
    },
    text: function (e, t) {
        const n = { type: "text", value: Sr(String(t.value)) };
        return e.patch(t, n), e.applyData(t, n);
    },
    thematicBreak: function (e, t) {
        const n = {
            type: "element",
            tagName: "hr",
            properties: {},
            children: [],
        };
        return e.patch(t, n), e.applyData(t, n);
    },
    toml: Lr,
    yaml: Lr,
    definition: Lr,
    footnoteDefinition: Lr,
};
function Lr() {}
const Mr = "object" == typeof self ? self : globalThis,
    Pr = (e) =>
        ((e, t) => {
            const n = (t, n) => (e.set(n, t), t),
                r = (o) => {
                    if (e.has(o)) return e.get(o);
                    const [i, s] = t[o];
                    switch (i) {
                        case 0:
                        case -1:
                            return n(s, o);
                        case 1: {
                            const e = n([], o);
                            for (const t of s) e.push(r(t));
                            return e;
                        }
                        case 2: {
                            const e = n({}, o);
                            for (const [t, n] of s) e[r(t)] = r(n);
                            return e;
                        }
                        case 3:
                            return n(new Date(s), o);
                        case 4: {
                            const { source: e, flags: t } = s;
                            return n(new RegExp(e, t), o);
                        }
                        case 5: {
                            const e = n(new Map(), o);
                            for (const [t, n] of s) e.set(r(t), r(n));
                            return e;
                        }
                        case 6: {
                            const e = n(new Set(), o);
                            for (const t of s) e.add(r(t));
                            return e;
                        }
                        case 7: {
                            const { name: e, message: t } = s;
                            return n(new Mr[e](t), o);
                        }
                        case 8:
                            return n(BigInt(s), o);
                        case "BigInt":
                            return n(Object(BigInt(s)), o);
                        case "ArrayBuffer":
                            return n(new Uint8Array(s).buffer, s);
                        case "DataView": {
                            const { buffer: e } = new Uint8Array(s);
                            return n(new DataView(e), s);
                        }
                    }
                    return n(new Mr[i](s), o);
                };
            return r;
        })(
            new Map(),
            e
        )(0),
    jr = "",
    { toString: Nr } = {},
    { keys: Ir } = Object,
    Dr = (e) => {
        const t = typeof e;
        if ("object" !== t || !e) return [0, t];
        const n = Nr.call(e).slice(8, -1);
        switch (n) {
            case "Array":
                return [1, jr];
            case "Object":
                return [2, jr];
            case "Date":
                return [3, jr];
            case "RegExp":
                return [4, jr];
            case "Map":
                return [5, jr];
            case "Set":
                return [6, jr];
            case "DataView":
                return [1, n];
        }
        return n.includes("Array")
            ? [1, n]
            : n.includes("Error")
            ? [7, n]
            : [2, n];
    },
    Vr = ([e, t]) => 0 === e && ("function" === t || "symbol" === t),
    Rr = (e, { json: t, lossy: n } = {}) => {
        const r = [];
        return (
            ((e, t, n, r) => {
                const o = (e, t) => {
                        const o = r.push(e) - 1;
                        return n.set(t, o), o;
                    },
                    i = (r) => {
                        if (n.has(r)) return n.get(r);
                        let [s, a] = Dr(r);
                        switch (s) {
                            case 0: {
                                let t = r;
                                switch (a) {
                                    case "bigint":
                                        (s = 8), (t = r.toString());
                                        break;
                                    case "function":
                                    case "symbol":
                                        if (e)
                                            throw new TypeError(
                                                "unable to serialize " + a
                                            );
                                        t = null;
                                        break;
                                    case "undefined":
                                        return o([-1], r);
                                }
                                return o([s, t], r);
                            }
                            case 1: {
                                if (a) {
                                    let e = r;
                                    return (
                                        "DataView" === a
                                            ? (e = new Uint8Array(r.buffer))
                                            : "ArrayBuffer" === a &&
                                              (e = new Uint8Array(r)),
                                        o([a, [...e]], r)
                                    );
                                }
                                const e = [],
                                    t = o([s, e], r);
                                for (const n of r) e.push(i(n));
                                return t;
                            }
                            case 2: {
                                if (a)
                                    switch (a) {
                                        case "BigInt":
                                            return o([a, r.toString()], r);
                                        case "Boolean":
                                        case "Number":
                                        case "String":
                                            return o([a, r.valueOf()], r);
                                    }
                                if (t && "toJSON" in r) return i(r.toJSON());
                                const n = [],
                                    l = o([s, n], r);
                                for (const t of Ir(r))
                                    (!e && Vr(Dr(r[t]))) ||
                                        n.push([i(t), i(r[t])]);
                                return l;
                            }
                            case 3:
                                return o([s, r.toISOString()], r);
                            case 4: {
                                const { source: e, flags: t } = r;
                                return o([s, { source: e, flags: t }], r);
                            }
                            case 5: {
                                const t = [],
                                    n = o([s, t], r);
                                for (const [o, s] of r)
                                    (e || (!Vr(Dr(o)) && !Vr(Dr(s)))) &&
                                        t.push([i(o), i(s)]);
                                return n;
                            }
                            case 6: {
                                const t = [],
                                    n = o([s, t], r);
                                for (const o of r)
                                    (!e && Vr(Dr(o))) || t.push(i(o));
                                return n;
                            }
                        }
                        const { message: l } = r;
                        return o([s, { name: a, message: l }], r);
                    };
                return i;
            })(
                !(t || n),
                !!t,
                new Map(),
                r
            )(e),
            r
        );
    },
    _r =
        "function" == typeof structuredClone
            ? (e, t) =>
                  t && ("json" in t || "lossy" in t)
                      ? Pr(Rr(e, t))
                      : structuredClone(e)
            : (e, t) => Pr(Rr(e, t));
function Or(e, t) {
    const n = [{ type: "text", value: "↩" }];
    return (
        t > 1 &&
            n.push({
                type: "element",
                tagName: "sup",
                properties: {},
                children: [{ type: "text", value: String(t) }],
            }),
        n
    );
}
function Hr(e, t) {
    return "Back to reference " + (e + 1) + (t > 1 ? "-" + t : "");
}
const Fr = function (e) {
    if (null == e) return Ur;
    if ("function" == typeof e) return Br(e);
    if ("object" == typeof e)
        return Array.isArray(e)
            ? (function (e) {
                  const t = [];
                  let n = -1;
                  for (; ++n < e.length; ) t[n] = Fr(e[n]);
                  return Br(r);
                  function r(...e) {
                      let n = -1;
                      for (; ++n < t.length; )
                          if (t[n].apply(this, e)) return !0;
                      return !1;
                  }
              })(e)
            : (function (e) {
                  const t = e;
                  return Br(n);
                  function n(n) {
                      const r = n;
                      let o;
                      for (o in e) if (r[o] !== t[o]) return !1;
                      return !0;
                  }
              })(e);
    if ("string" == typeof e)
        return (function (e) {
            return Br(t);
            function t(t) {
                return t && t.type === e;
            }
        })(e);
    throw new Error("Expected function, string, or object as test");
};
function Br(e) {
    return function (t, n, r) {
        return Boolean(
            (function (e) {
                return null !== e && "object" == typeof e && "type" in e;
            })(t) &&
                e.call(this, t, "number" == typeof n ? n : void 0, r || void 0)
        );
    };
}
function Ur() {
    return !0;
}
const Zr = [],
    zr = !0,
    $r = !1;
function Wr(e, t, n, r) {
    let o;
    "function" == typeof t && "function" != typeof n
        ? ((r = n), (n = t))
        : (o = t);
    const i = Fr(o),
        s = r ? -1 : 1;
    !(function e(o, a, l) {
        const c = o && "object" == typeof o ? o : {};
        if ("string" == typeof c.type) {
            const e =
                "string" == typeof c.tagName
                    ? c.tagName
                    : "string" == typeof c.name
                    ? c.name
                    : void 0;
            Object.defineProperty(u, "name", {
                value: "node (" + o.type + (e ? "<" + e + ">" : "") + ")",
            });
        }
        return u;
        function u() {
            let c,
                u,
                d,
                h = Zr;
            if (
                (!t || i(o, a, l[l.length - 1] || void 0)) &&
                ((h = (function (e) {
                    if (Array.isArray(e)) return e;
                    if ("number" == typeof e) return [zr, e];
                    return null == e ? Zr : [e];
                })(n(o, l))),
                h[0] === $r)
            )
                return h;
            if ("children" in o && o.children) {
                const t = o;
                if (t.children && "skip" !== h[0])
                    for (
                        u = (r ? t.children.length : -1) + s, d = l.concat(t);
                        u > -1 && u < t.children.length;

                    ) {
                        const n = t.children[u];
                        if (((c = e(n, u, d)()), c[0] === $r)) return c;
                        u = "number" == typeof c[1] ? c[1] : u + s;
                    }
            }
            return h;
        }
    })(e, void 0, [])();
}
function qr(e, t, n, r) {
    let o, i, s;
    "function" == typeof t && "function" != typeof n
        ? ((i = void 0), (s = t), (o = n))
        : ((i = t), (s = n), (o = r)),
        Wr(
            e,
            i,
            function (e, t) {
                const n = t[t.length - 1],
                    r = n ? n.children.indexOf(e) : void 0;
                return s(e, r, n);
            },
            o
        );
}
const Kr = {}.hasOwnProperty,
    Yr = {};
function Xr(e, t) {
    e.position &&
        (t.position = (function (e) {
            const t = rt(e),
                n = nt(e);
            if (t && n) return { start: t, end: n };
        })(e));
}
function Gr(e, t) {
    let n = t;
    if (e && e.data) {
        const t = e.data.hName,
            r = e.data.hChildren,
            o = e.data.hProperties;
        if ("string" == typeof t)
            if ("element" === n.type) n.tagName = t;
            else {
                n = {
                    type: "element",
                    tagName: t,
                    properties: {},
                    children: "children" in n ? n.children : [n],
                };
            }
        "element" === n.type && o && Object.assign(n.properties, _r(o)),
            "children" in n && n.children && null != r && (n.children = r);
    }
    return n;
}
function Qr(e, t) {
    const n = t.data || {},
        r =
            !("value" in t) ||
            Kr.call(n, "hProperties") ||
            Kr.call(n, "hChildren")
                ? {
                      type: "element",
                      tagName: "div",
                      properties: {},
                      children: e.all(t),
                  }
                : { type: "text", value: t.value };
    return e.patch(t, r), e.applyData(t, r);
}
function Jr(e, t) {
    const n = [];
    let r = -1;
    for (t && n.push({ type: "text", value: "\n" }); ++r < e.length; )
        r && n.push({ type: "text", value: "\n" }), n.push(e[r]);
    return t && e.length > 0 && n.push({ type: "text", value: "\n" }), n;
}
function eo(e) {
    let t = 0,
        n = e.charCodeAt(t);
    for (; 9 === n || 32 === n; ) t++, (n = e.charCodeAt(t));
    return e.slice(t);
}
function to(e, t) {
    const n = (function (e, t) {
            const n = t || Yr,
                r = new Map(),
                o = new Map(),
                i = new Map(),
                s = { ...Tr, ...n.handlers },
                a = {
                    all: function (e) {
                        const t = [];
                        if ("children" in e) {
                            const n = e.children;
                            let r = -1;
                            for (; ++r < n.length; ) {
                                const o = a.one(n[r], e);
                                if (o) {
                                    if (
                                        r &&
                                        "break" === n[r - 1].type &&
                                        (Array.isArray(o) ||
                                            "text" !== o.type ||
                                            (o.value = eo(o.value)),
                                        !Array.isArray(o) &&
                                            "element" === o.type)
                                    ) {
                                        const e = o.children[0];
                                        e &&
                                            "text" === e.type &&
                                            (e.value = eo(e.value));
                                    }
                                    Array.isArray(o) ? t.push(...o) : t.push(o);
                                }
                            }
                        }
                        return t;
                    },
                    applyData: Gr,
                    definitionById: r,
                    footnoteById: o,
                    footnoteCounts: i,
                    footnoteOrder: [],
                    handlers: s,
                    one: function (e, t) {
                        const n = e.type,
                            r = a.handlers[n];
                        if (Kr.call(a.handlers, n) && r) return r(a, e, t);
                        if (
                            a.options.passThrough &&
                            a.options.passThrough.includes(n)
                        ) {
                            if ("children" in e) {
                                const { children: t, ...n } = e,
                                    r = _r(n);
                                return (r.children = a.all(e)), r;
                            }
                            return _r(e);
                        }
                        return (a.options.unknownHandler || Qr)(a, e, t);
                    },
                    options: n,
                    patch: Xr,
                    wrap: Jr,
                };
            return (
                qr(e, function (e) {
                    if (
                        "definition" === e.type ||
                        "footnoteDefinition" === e.type
                    ) {
                        const t = "definition" === e.type ? r : o,
                            n = String(e.identifier).toUpperCase();
                        t.has(n) || t.set(n, e);
                    }
                }),
                a
            );
        })(e, t),
        r = n.one(e, void 0),
        o = (function (e) {
            const t =
                    "string" == typeof e.options.clobberPrefix
                        ? e.options.clobberPrefix
                        : "user-content-",
                n = e.options.footnoteBackContent || Or,
                r = e.options.footnoteBackLabel || Hr,
                o = e.options.footnoteLabel || "Footnotes",
                i = e.options.footnoteLabelTagName || "h2",
                s = e.options.footnoteLabelProperties || {
                    className: ["sr-only"],
                },
                a = [];
            let l = -1;
            for (; ++l < e.footnoteOrder.length; ) {
                const o = e.footnoteById.get(e.footnoteOrder[l]);
                if (!o) continue;
                const i = e.all(o),
                    s = String(o.identifier).toUpperCase(),
                    c = Qt(s.toLowerCase());
                let u = 0;
                const d = [],
                    h = e.footnoteCounts.get(s);
                for (; void 0 !== h && ++u <= h; ) {
                    d.length > 0 && d.push({ type: "text", value: " " });
                    let e = "string" == typeof n ? n : n(l, u);
                    "string" == typeof e && (e = { type: "text", value: e }),
                        d.push({
                            type: "element",
                            tagName: "a",
                            properties: {
                                href:
                                    "#" +
                                    t +
                                    "fnref-" +
                                    c +
                                    (u > 1 ? "-" + u : ""),
                                dataFootnoteBackref: "",
                                ariaLabel: "string" == typeof r ? r : r(l, u),
                                className: ["data-footnote-backref"],
                            },
                            children: Array.isArray(e) ? e : [e],
                        });
                }
                const p = i[i.length - 1];
                if (p && "element" === p.type && "p" === p.tagName) {
                    const e = p.children[p.children.length - 1];
                    e && "text" === e.type
                        ? (e.value += " ")
                        : p.children.push({ type: "text", value: " " }),
                        p.children.push(...d);
                } else i.push(...d);
                const f = {
                    type: "element",
                    tagName: "li",
                    properties: { id: t + "fn-" + c },
                    children: e.wrap(i, !0),
                };
                e.patch(o, f), a.push(f);
            }
            if (0 !== a.length)
                return {
                    type: "element",
                    tagName: "section",
                    properties: { dataFootnotes: !0, className: ["footnotes"] },
                    children: [
                        {
                            type: "element",
                            tagName: i,
                            properties: { ..._r(s), id: "footnote-label" },
                            children: [{ type: "text", value: o }],
                        },
                        { type: "text", value: "\n" },
                        {
                            type: "element",
                            tagName: "ol",
                            properties: {},
                            children: e.wrap(a, !0),
                        },
                        { type: "text", value: "\n" },
                    ],
                };
        })(n),
        i = Array.isArray(r)
            ? { type: "root", children: r }
            : r || { type: "root", children: [] };
    return o && i.children.push({ type: "text", value: "\n" }, o), i;
}
function no(e, t) {
    return e && "run" in e
        ? async function (n, r) {
              const o = to(n, { file: r, ...t });
              await e.run(o, r);
          }
        : function (n, r) {
              return to(n, { file: r, ...(e || t) });
          };
}
function ro(e) {
    if (e) throw e;
}
var oo, io;
const so = T(
    (function () {
        if (io) return oo;
        io = 1;
        var e = Object.prototype.hasOwnProperty,
            t = Object.prototype.toString,
            n = Object.defineProperty,
            r = Object.getOwnPropertyDescriptor,
            o = function (e) {
                return "function" == typeof Array.isArray
                    ? Array.isArray(e)
                    : "[object Array]" === t.call(e);
            },
            i = function (n) {
                if (!n || "[object Object]" !== t.call(n)) return !1;
                var r,
                    o = e.call(n, "constructor"),
                    i =
                        n.constructor &&
                        n.constructor.prototype &&
                        e.call(n.constructor.prototype, "isPrototypeOf");
                if (n.constructor && !o && !i) return !1;
                for (r in n);
                return void 0 === r || e.call(n, r);
            },
            s = function (e, t) {
                n && "__proto__" === t.name
                    ? n(e, t.name, {
                          enumerable: !0,
                          configurable: !0,
                          value: t.newValue,
                          writable: !0,
                      })
                    : (e[t.name] = t.newValue);
            },
            a = function (t, n) {
                if ("__proto__" === n) {
                    if (!e.call(t, n)) return;
                    if (r) return r(t, n).value;
                }
                return t[n];
            };
        return (oo = function e() {
            var t,
                n,
                r,
                l,
                c,
                u,
                d = arguments[0],
                h = 1,
                p = arguments.length,
                f = !1;
            for (
                "boolean" == typeof d &&
                    ((f = d), (d = arguments[1] || {}), (h = 2)),
                    (null == d ||
                        ("object" != typeof d && "function" != typeof d)) &&
                        (d = {});
                h < p;
                ++h
            )
                if (null != (t = arguments[h]))
                    for (n in t)
                        (r = a(d, n)),
                            d !== (l = a(t, n)) &&
                                (f && l && (i(l) || (c = o(l)))
                                    ? (c
                                          ? ((c = !1), (u = r && o(r) ? r : []))
                                          : (u = r && i(r) ? r : {}),
                                      s(d, { name: n, newValue: e(f, u, l) }))
                                    : void 0 !== l &&
                                      s(d, { name: n, newValue: l }));
            return d;
        });
    })()
);
function ao(e) {
    if ("object" != typeof e || null === e) return !1;
    const t = Object.getPrototypeOf(e);
    return !(
        (null !== t &&
            t !== Object.prototype &&
            null !== Object.getPrototypeOf(t)) ||
        Symbol.toStringTag in e ||
        Symbol.iterator in e
    );
}
function lo() {
    const e = [],
        t = {
            run: function (...t) {
                let n = -1;
                const r = t.pop();
                if ("function" != typeof r)
                    throw new TypeError(
                        "Expected function as last argument, not " + r
                    );
                !(function o(i, ...s) {
                    const a = e[++n];
                    let l = -1;
                    if (i) r(i);
                    else {
                        for (; ++l < t.length; )
                            (null !== s[l] && void 0 !== s[l]) || (s[l] = t[l]);
                        (t = s),
                            a
                                ? (function (e, t) {
                                      let n;
                                      return r;
                                      function r(...t) {
                                          const r = e.length > t.length;
                                          let a;
                                          r && t.push(o);
                                          try {
                                              a = e.apply(this, t);
                                          } catch (i) {
                                              if (r && n) throw i;
                                              return o(i);
                                          }
                                          r ||
                                              (a &&
                                              a.then &&
                                              "function" == typeof a.then
                                                  ? a.then(s, o)
                                                  : a instanceof Error
                                                  ? o(a)
                                                  : s(a));
                                      }
                                      function o(e, ...r) {
                                          n || ((n = !0), t(e, ...r));
                                      }
                                      function s(e) {
                                          o(null, e);
                                      }
                                  })(
                                      a,
                                      o
                                  )(...s)
                                : r(null, ...s);
                    }
                })(null, ...t);
            },
            use: function (n) {
                if ("function" != typeof n)
                    throw new TypeError(
                        "Expected `middelware` to be a function, not " + n
                    );
                return e.push(n), t;
            },
        };
    return t;
}
const co = {
    basename: function (e, t) {
        if (void 0 !== t && "string" != typeof t)
            throw new TypeError('"ext" argument must be a string');
        uo(e);
        let n,
            r = 0,
            o = -1,
            i = e.length;
        if (void 0 === t || 0 === t.length || t.length > e.length) {
            for (; i--; )
                if (47 === e.codePointAt(i)) {
                    if (n) {
                        r = i + 1;
                        break;
                    }
                } else o < 0 && ((n = !0), (o = i + 1));
            return o < 0 ? "" : e.slice(r, o);
        }
        if (t === e) return "";
        let s = -1,
            a = t.length - 1;
        for (; i--; )
            if (47 === e.codePointAt(i)) {
                if (n) {
                    r = i + 1;
                    break;
                }
            } else
                s < 0 && ((n = !0), (s = i + 1)),
                    a > -1 &&
                        (e.codePointAt(i) === t.codePointAt(a--)
                            ? a < 0 && (o = i)
                            : ((a = -1), (o = s)));
        r === o ? (o = s) : o < 0 && (o = e.length);
        return e.slice(r, o);
    },
    dirname: function (e) {
        if ((uo(e), 0 === e.length)) return ".";
        let t,
            n = -1,
            r = e.length;
        for (; --r; )
            if (47 === e.codePointAt(r)) {
                if (t) {
                    n = r;
                    break;
                }
            } else t || (t = !0);
        return n < 0
            ? 47 === e.codePointAt(0)
                ? "/"
                : "."
            : 1 === n && 47 === e.codePointAt(0)
            ? "//"
            : e.slice(0, n);
    },
    extname: function (e) {
        uo(e);
        let t,
            n = e.length,
            r = -1,
            o = 0,
            i = -1,
            s = 0;
        for (; n--; ) {
            const a = e.codePointAt(n);
            if (47 !== a)
                r < 0 && ((t = !0), (r = n + 1)),
                    46 === a
                        ? i < 0
                            ? (i = n)
                            : 1 !== s && (s = 1)
                        : i > -1 && (s = -1);
            else if (t) {
                o = n + 1;
                break;
            }
        }
        if (
            i < 0 ||
            r < 0 ||
            0 === s ||
            (1 === s && i === r - 1 && i === o + 1)
        )
            return "";
        return e.slice(i, r);
    },
    join: function (...e) {
        let t,
            n = -1;
        for (; ++n < e.length; )
            uo(e[n]), e[n] && (t = void 0 === t ? e[n] : t + "/" + e[n]);
        return void 0 === t
            ? "."
            : (function (e) {
                  uo(e);
                  const t = 47 === e.codePointAt(0);
                  let n = (function (e, t) {
                      let n,
                          r,
                          o = "",
                          i = 0,
                          s = -1,
                          a = 0,
                          l = -1;
                      for (; ++l <= e.length; ) {
                          if (l < e.length) n = e.codePointAt(l);
                          else {
                              if (47 === n) break;
                              n = 47;
                          }
                          if (47 === n) {
                              if (s === l - 1 || 1 === a);
                              else if (s !== l - 1 && 2 === a) {
                                  if (
                                      o.length < 2 ||
                                      2 !== i ||
                                      46 !== o.codePointAt(o.length - 1) ||
                                      46 !== o.codePointAt(o.length - 2)
                                  )
                                      if (o.length > 2) {
                                          if (
                                              ((r = o.lastIndexOf("/")),
                                              r !== o.length - 1)
                                          ) {
                                              r < 0
                                                  ? ((o = ""), (i = 0))
                                                  : ((o = o.slice(0, r)),
                                                    (i =
                                                        o.length -
                                                        1 -
                                                        o.lastIndexOf("/"))),
                                                  (s = l),
                                                  (a = 0);
                                              continue;
                                          }
                                      } else if (o.length > 0) {
                                          (o = ""), (i = 0), (s = l), (a = 0);
                                          continue;
                                      }
                                  t &&
                                      ((o = o.length > 0 ? o + "/.." : ".."),
                                      (i = 2));
                              } else
                                  o.length > 0
                                      ? (o += "/" + e.slice(s + 1, l))
                                      : (o = e.slice(s + 1, l)),
                                      (i = l - s - 1);
                              (s = l), (a = 0);
                          } else 46 === n && a > -1 ? a++ : (a = -1);
                      }
                      return o;
                  })(e, !t);
                  0 !== n.length || t || (n = ".");
                  n.length > 0 &&
                      47 === e.codePointAt(e.length - 1) &&
                      (n += "/");
                  return t ? "/" + n : n;
              })(t);
    },
    sep: "/",
};
function uo(e) {
    if ("string" != typeof e)
        throw new TypeError(
            "Path must be a string. Received " + JSON.stringify(e)
        );
}
const ho = {
    cwd: function () {
        return "/";
    },
};
function po(e) {
    return Boolean(
        null !== e &&
            "object" == typeof e &&
            "href" in e &&
            e.href &&
            "protocol" in e &&
            e.protocol &&
            void 0 === e.auth
    );
}
function fo(e) {
    if ("string" == typeof e) e = new URL(e);
    else if (!po(e)) {
        const t = new TypeError(
            'The "path" argument must be of type string or an instance of URL. Received `' +
                e +
                "`"
        );
        throw ((t.code = "ERR_INVALID_ARG_TYPE"), t);
    }
    if ("file:" !== e.protocol) {
        const e = new TypeError("The URL must be of scheme file");
        throw ((e.code = "ERR_INVALID_URL_SCHEME"), e);
    }
    return (function (e) {
        if ("" !== e.hostname) {
            const e = new TypeError(
                'File URL host must be "localhost" or empty on darwin'
            );
            throw ((e.code = "ERR_INVALID_FILE_URL_HOST"), e);
        }
        const t = e.pathname;
        let n = -1;
        for (; ++n < t.length; )
            if (37 === t.codePointAt(n) && 50 === t.codePointAt(n + 1)) {
                const e = t.codePointAt(n + 2);
                if (70 === e || 102 === e) {
                    const e = new TypeError(
                        "File URL path must not include encoded / characters"
                    );
                    throw ((e.code = "ERR_INVALID_FILE_URL_PATH"), e);
                }
            }
        return decodeURIComponent(t);
    })(e);
}
const mo = ["history", "path", "basename", "stem", "extname", "dirname"];
class go {
    constructor(e) {
        let t;
        (t = e
            ? po(e)
                ? { path: e }
                : "string" == typeof e ||
                  (function (e) {
                      return Boolean(
                          e &&
                              "object" == typeof e &&
                              "byteLength" in e &&
                              "byteOffset" in e
                      );
                  })(e)
                ? { value: e }
                : e
            : {}),
            (this.cwd = "cwd" in t ? "" : ho.cwd()),
            (this.data = {}),
            (this.history = []),
            (this.messages = []),
            this.value,
            this.map,
            this.result,
            this.stored;
        let n,
            r = -1;
        for (; ++r < mo.length; ) {
            const e = mo[r];
            e in t &&
                void 0 !== t[e] &&
                null !== t[e] &&
                (this[e] = "history" === e ? [...t[e]] : t[e]);
        }
        for (n in t) mo.includes(n) || (this[n] = t[n]);
    }
    get basename() {
        return "string" == typeof this.path ? co.basename(this.path) : void 0;
    }
    set basename(e) {
        xo(e, "basename"),
            yo(e, "basename"),
            (this.path = co.join(this.dirname || "", e));
    }
    get dirname() {
        return "string" == typeof this.path ? co.dirname(this.path) : void 0;
    }
    set dirname(e) {
        vo(this.basename, "dirname"),
            (this.path = co.join(e || "", this.basename));
    }
    get extname() {
        return "string" == typeof this.path ? co.extname(this.path) : void 0;
    }
    set extname(e) {
        if ((yo(e, "extname"), vo(this.dirname, "extname"), e)) {
            if (46 !== e.codePointAt(0))
                throw new Error("`extname` must start with `.`");
            if (e.includes(".", 1))
                throw new Error("`extname` cannot contain multiple dots");
        }
        this.path = co.join(this.dirname, this.stem + (e || ""));
    }
    get path() {
        return this.history[this.history.length - 1];
    }
    set path(e) {
        po(e) && (e = fo(e)),
            xo(e, "path"),
            this.path !== e && this.history.push(e);
    }
    get stem() {
        return "string" == typeof this.path
            ? co.basename(this.path, this.extname)
            : void 0;
    }
    set stem(e) {
        xo(e, "stem"),
            yo(e, "stem"),
            (this.path = co.join(this.dirname || "", e + (this.extname || "")));
    }
    fail(e, t, n) {
        const r = this.message(e, t, n);
        throw ((r.fatal = !0), r);
    }
    info(e, t, n) {
        const r = this.message(e, t, n);
        return (r.fatal = void 0), r;
    }
    message(e, t, n) {
        const r = new ct(e, t, n);
        return (
            this.path &&
                ((r.name = this.path + ":" + r.name), (r.file = this.path)),
            (r.fatal = !1),
            this.messages.push(r),
            r
        );
    }
    toString(e) {
        if (void 0 === this.value) return "";
        if ("string" == typeof this.value) return this.value;
        return new TextDecoder(e || void 0).decode(this.value);
    }
}
function yo(e, t) {
    if (e && e.includes(co.sep))
        throw new Error(
            "`" + t + "` cannot be a path: did not expect `" + co.sep + "`"
        );
}
function xo(e, t) {
    if (!e) throw new Error("`" + t + "` cannot be empty");
}
function vo(e, t) {
    if (!e)
        throw new Error("Setting `" + t + "` requires `path` to be set too");
}
const Co = function (e) {
        const t = this.constructor.prototype,
            n = t[e],
            r = function () {
                return n.apply(r, arguments);
            };
        return Object.setPrototypeOf(r, t), r;
    },
    wo = {}.hasOwnProperty;
class bo extends Co {
    constructor() {
        super("copy"),
            (this.Compiler = void 0),
            (this.Parser = void 0),
            (this.attachers = []),
            (this.compiler = void 0),
            (this.freezeIndex = -1),
            (this.frozen = void 0),
            (this.namespace = {}),
            (this.parser = void 0),
            (this.transformers = lo());
    }
    copy() {
        const e = new bo();
        let t = -1;
        for (; ++t < this.attachers.length; ) {
            const n = this.attachers[t];
            e.use(...n);
        }
        return e.data(so(!0, {}, this.namespace)), e;
    }
    data(e, t) {
        return "string" == typeof e
            ? 2 === arguments.length
                ? (Ao("data", this.frozen), (this.namespace[e] = t), this)
                : (wo.call(this.namespace, e) && this.namespace[e]) || void 0
            : e
            ? (Ao("data", this.frozen), (this.namespace = e), this)
            : this.namespace;
    }
    freeze() {
        if (this.frozen) return this;
        const e = this;
        for (; ++this.freezeIndex < this.attachers.length; ) {
            const [t, ...n] = this.attachers[this.freezeIndex];
            if (!1 === n[0]) continue;
            !0 === n[0] && (n[0] = void 0);
            const r = t.call(e, ...n);
            "function" == typeof r && this.transformers.use(r);
        }
        return (
            (this.frozen = !0),
            (this.freezeIndex = Number.POSITIVE_INFINITY),
            this
        );
    }
    parse(e) {
        this.freeze();
        const t = Mo(e),
            n = this.parser || this.Parser;
        return Eo("parse", n), n(String(t), t);
    }
    process(e, t) {
        const n = this;
        return (
            this.freeze(),
            Eo("process", this.parser || this.Parser),
            So("process", this.compiler || this.Compiler),
            t ? r(void 0, t) : new Promise(r)
        );
        function r(r, o) {
            const i = Mo(e),
                s = n.parse(i);
            function a(e, n) {
                e || !n ? o(e) : r ? r(n) : t(void 0, n);
            }
            n.run(s, i, function (e, t, r) {
                if (e || !t || !r) return a(e);
                const o = t,
                    i = n.stringify(o, r);
                var s;
                "string" == typeof (s = i) ||
                (function (e) {
                    return Boolean(
                        e &&
                            "object" == typeof e &&
                            "byteLength" in e &&
                            "byteOffset" in e
                    );
                })(s)
                    ? (r.value = i)
                    : (r.result = i),
                    a(e, r);
            });
        }
    }
    processSync(e) {
        let t,
            n = !1;
        return (
            this.freeze(),
            Eo("processSync", this.parser || this.Parser),
            So("processSync", this.compiler || this.Compiler),
            this.process(e, function (e, r) {
                (n = !0), ro(e), (t = r);
            }),
            Lo("processSync", "process", n),
            t
        );
    }
    run(e, t, n) {
        To(e), this.freeze();
        const r = this.transformers;
        return (
            n || "function" != typeof t || ((n = t), (t = void 0)),
            n ? o(void 0, n) : new Promise(o)
        );
        function o(o, i) {
            const s = Mo(t);
            r.run(e, s, function (t, r, s) {
                const a = r || e;
                t ? i(t) : o ? o(a) : n(void 0, a, s);
            });
        }
    }
    runSync(e, t) {
        let n,
            r = !1;
        return (
            this.run(e, t, function (e, t) {
                ro(e), (n = t), (r = !0);
            }),
            Lo("runSync", "run", r),
            n
        );
    }
    stringify(e, t) {
        this.freeze();
        const n = Mo(t),
            r = this.compiler || this.Compiler;
        return So("stringify", r), To(e), r(e, n);
    }
    use(e, ...t) {
        const n = this.attachers,
            r = this.namespace;
        if ((Ao("use", this.frozen), null == e));
        else if ("function" == typeof e) a(e, t);
        else {
            if ("object" != typeof e)
                throw new TypeError("Expected usable value, not `" + e + "`");
            Array.isArray(e) ? s(e) : i(e);
        }
        return this;
        function o(e) {
            if ("function" == typeof e) a(e, []);
            else {
                if ("object" != typeof e)
                    throw new TypeError(
                        "Expected usable value, not `" + e + "`"
                    );
                if (Array.isArray(e)) {
                    const [t, ...n] = e;
                    a(t, n);
                } else i(e);
            }
        }
        function i(e) {
            if (!("plugins" in e) && !("settings" in e))
                throw new Error(
                    "Expected usable value but received an empty preset, which is probably a mistake: presets typically come with `plugins` and sometimes with `settings`, but this has neither"
                );
            s(e.plugins),
                e.settings && (r.settings = so(!0, r.settings, e.settings));
        }
        function s(e) {
            let t = -1;
            if (null == e);
            else {
                if (!Array.isArray(e))
                    throw new TypeError(
                        "Expected a list of plugins, not `" + e + "`"
                    );
                for (; ++t < e.length; ) {
                    o(e[t]);
                }
            }
        }
        function a(e, t) {
            let r = -1,
                o = -1;
            for (; ++r < n.length; )
                if (n[r][0] === e) {
                    o = r;
                    break;
                }
            if (-1 === o) n.push([e, ...t]);
            else if (t.length > 0) {
                let [r, ...i] = t;
                const s = n[o][1];
                ao(s) && ao(r) && (r = so(!0, s, r)), (n[o] = [e, r, ...i]);
            }
        }
    }
}
const ko = new bo().freeze();
function Eo(e, t) {
    if ("function" != typeof t)
        throw new TypeError("Cannot `" + e + "` without `parser`");
}
function So(e, t) {
    if ("function" != typeof t)
        throw new TypeError("Cannot `" + e + "` without `compiler`");
}
function Ao(e, t) {
    if (t)
        throw new Error(
            "Cannot call `" +
                e +
                "` on a frozen processor.\nCreate a new processor first, by calling it: use `processor()` instead of `processor`."
        );
}
function To(e) {
    if (!ao(e) || "string" != typeof e.type)
        throw new TypeError("Expected node, got `" + e + "`");
}
function Lo(e, t, n) {
    if (!n)
        throw new Error("`" + e + "` finished async. Use `" + t + "` instead");
}
function Mo(e) {
    return (function (e) {
        return Boolean(
            e && "object" == typeof e && "message" in e && "messages" in e
        );
    })(e)
        ? e
        : new go(e);
}
const Po = [],
    jo = { allowDangerousHtml: !0 },
    No = /^(https?|ircs?|mailto|xmpp)$/i,
    Io = [
        { from: "astPlugins", id: "remove-buggy-html-in-markdown-parser" },
        {
            from: "allowDangerousHtml",
            id: "remove-buggy-html-in-markdown-parser",
        },
        {
            from: "allowNode",
            id: "replace-allownode-allowedtypes-and-disallowedtypes",
            to: "allowElement",
        },
        {
            from: "allowedTypes",
            id: "replace-allownode-allowedtypes-and-disallowedtypes",
            to: "allowedElements",
        },
        { from: "className", id: "remove-classname" },
        {
            from: "disallowedTypes",
            id: "replace-allownode-allowedtypes-and-disallowedtypes",
            to: "disallowedElements",
        },
        { from: "escapeHtml", id: "remove-buggy-html-in-markdown-parser" },
        { from: "includeElementIndex", id: "#remove-includeelementindex" },
        {
            from: "includeNodeIndex",
            id: "change-includenodeindex-to-includeelementindex",
        },
        { from: "linkTarget", id: "remove-linktarget" },
        {
            from: "plugins",
            id: "change-plugins-to-remarkplugins",
            to: "remarkPlugins",
        },
        { from: "rawSourcePos", id: "#remove-rawsourcepos" },
        {
            from: "renderers",
            id: "change-renderers-to-components",
            to: "components",
        },
        { from: "source", id: "change-source-to-children", to: "children" },
        { from: "sourcePos", id: "#remove-sourcepos" },
        {
            from: "transformImageUri",
            id: "#add-urltransform",
            to: "urlTransform",
        },
        {
            from: "transformLinkUri",
            id: "#add-urltransform",
            to: "urlTransform",
        },
    ];
function Do(e) {
    const t = (function (e) {
            const t = e.rehypePlugins || Po,
                n = e.remarkPlugins || Po,
                r = e.remarkRehypeOptions
                    ? { ...e.remarkRehypeOptions, ...jo }
                    : jo,
                o = ko().use(br).use(n).use(no, r).use(t);
            return o;
        })(e),
        n = (function (e) {
            const t = e.children || "",
                n = new go();
            "string" == typeof t && (n.value = t);
            return n;
        })(e);
    return (function (e, t) {
        const n = t.allowedElements,
            r = t.allowElement,
            o = t.components,
            i = t.disallowedElements,
            s = t.skipHtml,
            l = t.unwrapDisallowed,
            c = t.urlTransform || Vo;
        for (const a of Io)
            Object.hasOwn(t, a.from) && oe((a.from, a.to && a.to, a.id));
        return (
            qr(e, u),
            gt(e, {
                Fragment: a.Fragment,
                components: o,
                ignoreInvalidStyle: !0,
                jsx: a.jsx,
                jsxs: a.jsxs,
                passKeys: !0,
                passNode: !0,
            })
        );
        function u(e, t, o) {
            if ("raw" === e.type && o && "number" == typeof t)
                return (
                    s
                        ? o.children.splice(t, 1)
                        : (o.children[t] = { type: "text", value: e.value }),
                    t
                );
            if ("element" === e.type) {
                let t;
                for (t in At)
                    if (
                        Object.hasOwn(At, t) &&
                        Object.hasOwn(e.properties, t)
                    ) {
                        const n = e.properties[t],
                            r = At[t];
                        (null === r || r.includes(e.tagName)) &&
                            (e.properties[t] = c(String(n || ""), t, e));
                    }
            }
            if ("element" === e.type) {
                let s = n
                    ? !n.includes(e.tagName)
                    : !!i && i.includes(e.tagName);
                if (
                    (!s && r && "number" == typeof t && (s = !r(e, t, o)),
                    s && o && "number" == typeof t)
                )
                    return (
                        l && e.children
                            ? o.children.splice(t, 1, ...e.children)
                            : o.children.splice(t, 1),
                        t
                    );
            }
        }
    })(t.runSync(t.parse(n), n), e);
}
function Vo(e) {
    const t = e.indexOf(":"),
        n = e.indexOf("?"),
        r = e.indexOf("#"),
        o = e.indexOf("/");
    return -1 === t ||
        (-1 !== o && t > o) ||
        (-1 !== n && t > n) ||
        (-1 !== r && t > r) ||
        No.test(e.slice(0, t))
        ? e
        : "";
}
function Ro({ text: e, variant: t = "assistant" }) {
    const n = "user" === t;
    return a.jsx("div", {
        className:
            "text-text-100 leading-relaxed " +
            (n ? "font-base" : "font-claude-response-small"),
        children: a.jsx(Do, {
            components: {
                h1: ({ children: e }) =>
                    a.jsx("h1", {
                        className: "font-claude-response-title text-lg mb-2",
                        children: e,
                    }),
                h2: ({ children: e }) =>
                    a.jsx("h2", {
                        className:
                            "font-claude-response-heading text-base mb-2",
                        children: e,
                    }),
                h3: ({ children: e }) =>
                    a.jsx("h3", {
                        className:
                            "font-claude-response-subheading text-sm mb-2",
                        children: e,
                    }),
                p: ({ children: e }) =>
                    a.jsx("p", {
                        className:
                            (n
                                ? "mb-2 font-base"
                                : "mb-3 font-claude-response-small") +
                            " last:mb-0",
                        children: e,
                    }),
                ul: ({ children: e }) =>
                    a.jsx("ul", {
                        className:
                            (n ? "mb-2" : "mb-3") +
                            " last:mb-0 space-y-1 list-disc pl-5 font-claude-response-small",
                        children: e,
                    }),
                ol: ({ children: e }) =>
                    a.jsx("ol", {
                        className:
                            (n ? "mb-2" : "mb-3") +
                            " last:mb-0 space-y-1 list-decimal pl-5 font-claude-response-small",
                        children: e,
                    }),
                li: ({ children: e }) =>
                    a.jsx("li", {
                        className: "font-claude-response-small",
                        children: e,
                    }),
                code: ({ children: e, className: t }) => {
                    const r = !t,
                        o = String(e).replace(/\n$/, "");
                    return r
                        ? a.jsx("code", {
                              className:
                                  "bg-bg-200 px-1 py-0.5 rounded font-code-inline",
                              children: o,
                          })
                        : a.jsx("pre", {
                              className: `bg-bg-200 ${
                                  n ? "p-2" : "p-3"
                              } rounded-lg mb-3 last:mb-0 font-code whitespace-pre-wrap overflow-x-auto`,
                              children: a.jsx("code", { children: o }),
                          });
                },
                pre: ({ children: e }) => a.jsx(a.Fragment, { children: e }),
                blockquote: ({ children: e }) =>
                    a.jsx("blockquote", {
                        className:
                            "border-l-4 border-border-300 pl-3 italic text-text-300 mb-3",
                        children: e,
                    }),
                a: ({ href: e, children: t }) =>
                    a.jsx("a", {
                        href: e,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className:
                            "text-accent-main-100 underline hover:text-accent-main-200 transition-colors",
                        children: t,
                    }),
                strong: ({ children: e }) =>
                    a.jsx("strong", {
                        className: "font-semibold",
                        children: e,
                    }),
                em: ({ children: e }) =>
                    a.jsx("em", { className: "italic", children: e }),
                del: ({ children: e }) =>
                    a.jsx("del", {
                        className: "line-through text-text-400",
                        children: e,
                    }),
            },
            children: e,
        }),
    });
}
function _o({
    dataUrl: e,
    width: t,
    height: n,
    maxHeight: r = "200px",
    className: o = "",
}) {
    return a.jsxs("div", {
        className: o,
        children: [
            a.jsx("img", {
                src: e,
                alt: "Screenshot",
                className:
                    "max-w-full h-auto rounded border border-border-300 cursor-pointer hover:opacity-90 transition-opacity",
                style: { maxHeight: r },
                onClick: () => window.open(e, "_blank"),
                title: "Click to open in new tab",
            }),
            t &&
                n &&
                a.jsxs("div", {
                    className: "mt-1 text-xs text-text-300",
                    children: [t, "×", n],
                }),
        ],
    });
}
function Oo({ screenshot: e, coordinates: t, className: n = "" }) {
    const o = r.useRef(null),
        [i, s] = r.useState(1);
    return (
        r.useEffect(() => {
            const e = () => {
                    if (o.current) {
                        const e = o.current.width / o.current.naturalWidth,
                            t = o.current.height / o.current.naturalHeight;
                        s(Math.min(e, t));
                    }
                },
                t = o.current;
            if (t) {
                if (!t.complete)
                    return (
                        t.addEventListener("load", e),
                        () => t.removeEventListener("load", e)
                    );
                e();
            }
        }, [e]),
        a.jsxs("div", {
            className: `relative inline-block ${n}`,
            children: [
                a.jsx("img", {
                    ref: o,
                    src: e,
                    alt: "Screenshot with click location",
                    className:
                        "max-w-full max-h-[200px] border-[0.5px] border-border-200 rounded-[12px]",
                }),
                a.jsx("div", {
                    className:
                        "absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none rounded-full border-[0.5px] border-accent-secondary-100 w-[23px] h-[23px] bg-[#2C84DB4D]",
                    style: { left: t[0] * i + "px", top: t[1] * i + "px" },
                }),
            ],
        })
    );
}
function Ho({
    screenshot: e,
    startCoordinate: t,
    endCoordinate: n,
    className: o = "",
}) {
    const [i, s] = r.useState({ width: 0, height: 0 }),
        l = r.useRef(null);
    r.useEffect(() => {
        if (l.current) {
            const e = () => {
                l.current &&
                    s({
                        width: l.current.offsetWidth,
                        height: l.current.offsetHeight,
                    });
            };
            return (
                e(),
                window.addEventListener("resize", e),
                () => window.removeEventListener("resize", e)
            );
        }
    }, [e]);
    const [c, u] = t,
        [d, h] = n,
        p = i.width > 0 ? i.width / (l.current?.naturalWidth || i.width) : 1,
        f =
            i.height > 0
                ? i.height / (l.current?.naturalHeight || i.height)
                : 1,
        m = c * p,
        g = u * f,
        y = d * p,
        x = h * f;
    return a.jsxs("div", {
        className: `relative inline-block ${o}`,
        children: [
            a.jsx("img", {
                ref: l,
                src: e,
                alt: "Screenshot with drag path",
                className: "max-w-full h-auto",
                onLoad: () => {
                    l.current &&
                        s({
                            width: l.current.offsetWidth,
                            height: l.current.offsetHeight,
                        });
                },
            }),
            i.width > 0 &&
                a.jsxs(a.Fragment, {
                    children: [
                        a.jsxs("svg", {
                            className: "absolute pointer-events-none",
                            style: {
                                left: 0,
                                top: 0,
                                width: "100%",
                                height: "100%",
                                zIndex: 15,
                            },
                            children: [
                                a.jsx("defs", {
                                    children: a.jsx("marker", {
                                        id: "arrowhead",
                                        markerWidth: "10",
                                        markerHeight: "7",
                                        refX: "9",
                                        refY: "3.5",
                                        orient: "auto",
                                        children: a.jsx("polygon", {
                                            points: "0 0, 10 3.5, 0 7",
                                            fill: "#dc2626",
                                        }),
                                    }),
                                }),
                                a.jsx("line", {
                                    x1: m,
                                    y1: g,
                                    x2: y,
                                    y2: x,
                                    stroke: "#dc2626",
                                    strokeWidth: "2",
                                    markerEnd: "url(#arrowhead)",
                                }),
                            ],
                        }),
                        a.jsx("div", {
                            className:
                                "absolute bg-bg-000 border-2 border-accent-secondary-100 rounded-full",
                            style: {
                                left: `${m}px`,
                                top: `${g}px`,
                                width: "8px",
                                height: "8px",
                                transform: "translate(-50%, -50%)",
                                zIndex: 20,
                            },
                        }),
                        a.jsx("div", {
                            className:
                                "absolute bg-bg-000 border-2 border-danger-200 rounded-full",
                            style: {
                                left: `${y}px`,
                                top: `${x}px`,
                                width: "8px",
                                height: "8px",
                                transform: "translate(-50%, -50%)",
                                zIndex: 20,
                            },
                        }),
                    ],
                }),
        ],
    });
}
const Fo = new Map([
        [
            "bold",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M156,92a12,12,0,0,1,12-12h64a12,12,0,0,1,0,24H168A12,12,0,0,1,156,92Zm76,28H168a12,12,0,0,0,0,24h64a12,12,0,0,0,0-24Zm0,40H80a12,12,0,0,0,0,24H232a12,12,0,0,0,0-24Zm0,40H80a12,12,0,0,0,0,24H232a12,12,0,0,0,0-24ZM96,144a12,12,0,0,0,0-24H92V68h24v4a12,12,0,0,0,24,0V56a12,12,0,0,0-12-12H32A12,12,0,0,0,20,56V72a12,12,0,0,0,24,0V68H68v52H64a12,12,0,0,0,0,24Z",
                })
            ),
        ],
        [
            "duotone",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M232,104v96H80V168h48V104Z",
                    opacity: "0.2",
                }),
                r.createElement("path", {
                    d: "M128,96H232a8,8,0,0,1,0,16H128a8,8,0,0,1,0-16Zm104,32H128a8,8,0,0,0,0,16H232a8,8,0,0,0,0-16Zm0,32H80a8,8,0,0,0,0,16H232a8,8,0,0,0,0-16Zm0,32H80a8,8,0,0,0,0,16H232a8,8,0,0,0,0-16ZM96,144a8,8,0,0,0,0-16H88V64h32v8a8,8,0,0,0,16,0V56a8,8,0,0,0-8-8H32a8,8,0,0,0-8,8V72a8,8,0,0,0,16,0V64H72v64H64a8,8,0,0,0,0,16Z",
                })
            ),
        ],
        [
            "fill",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40ZM64,92a8,8,0,0,1-16,0V80a8,8,0,0,1,8-8h72a8,8,0,0,1,8,8V92a8,8,0,0,1-16,0V88H100v48h4a8,8,0,0,1,0,16H80a8,8,0,0,1,0-16h4V88H64Zm136,92H80a8,8,0,0,1,0-16H200a8,8,0,0,1,0,16Zm0-32H136a8,8,0,0,1,0-16h64a8,8,0,0,1,0,16Zm0-32H152a8,8,0,0,1,0-16h48a8,8,0,0,1,0,16Z",
                })
            ),
        ],
        [
            "light",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M128,98H232a6,6,0,0,1,0,12H128a6,6,0,0,1,0-12Zm104,32H128a6,6,0,0,0,0,12H232a6,6,0,0,0,0-12Zm0,32H80a6,6,0,0,0,0,12H232a6,6,0,0,0,0-12Zm0,32H80a6,6,0,0,0,0,12H232a6,6,0,0,0,0-12ZM96,142a6,6,0,0,0,0-12H86V62h36V72a6,6,0,0,0,12,0V56a6,6,0,0,0-6-6H32a6,6,0,0,0-6,6V72a6,6,0,0,0,12,0V62H74v68H64a6,6,0,0,0,0,12Z",
                })
            ),
        ],
        [
            "regular",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M128,96H232a8,8,0,0,1,0,16H128a8,8,0,0,1,0-16Zm104,32H128a8,8,0,0,0,0,16H232a8,8,0,0,0,0-16Zm0,32H80a8,8,0,0,0,0,16H232a8,8,0,0,0,0-16Zm0,32H80a8,8,0,0,0,0,16H232a8,8,0,0,0,0-16ZM96,144a8,8,0,0,0,0-16H88V64h32v8a8,8,0,0,0,16,0V56a8,8,0,0,0-8-8H32a8,8,0,0,0-8,8V72a8,8,0,0,0,16,0V64H72v64H64a8,8,0,0,0,0,16Z",
                })
            ),
        ],
        [
            "thin",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M128,100H232a4,4,0,0,1,0,8H128a4,4,0,0,1,0-8Zm104,32H128a4,4,0,0,0,0,8H232a4,4,0,0,0,0-8Zm0,32H80a4,4,0,0,0,0,8H232a4,4,0,0,0,0-8Zm0,32H80a4,4,0,0,0,0,8H232a4,4,0,0,0,0-8ZM96,140a4,4,0,0,0,0-8H84V60h40V72a4,4,0,0,0,8,0V56a4,4,0,0,0-4-4H32a4,4,0,0,0-4,4V72a4,4,0,0,0,8,0V60H76v72H64a4,4,0,0,0,0,8Z",
                })
            ),
        ],
    ]),
    Bo = new Map([
        [
            "bold",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M224.15,179.17l-46.83-46.82,37.93-13.51.76-.3a20,20,0,0,0-1.76-37.27L54.16,29A20,20,0,0,0,29,54.16L81.27,214.24A20,20,0,0,0,118.54,216c.11-.25.21-.5.3-.76l13.51-37.92,46.83,46.82a20,20,0,0,0,28.28,0l16.69-16.68A20,20,0,0,0,224.15,179.17Zm-30.83,25.17-48.48-48.48A20,20,0,0,0,130.7,150a20.66,20.66,0,0,0-3.74.35A20,20,0,0,0,112.35,162c-.11.25-.21.5-.3.76L100.4,195.5,54.29,54.29l141.21,46.1-32.71,11.66c-.26.09-.51.19-.76.3a20,20,0,0,0-6.17,32.48h0l48.49,48.48Z",
                })
            ),
        ],
        [
            "duotone",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M213.66,201,201,213.66a8,8,0,0,1-11.31,0l-51.31-51.31a8,8,0,0,0-13,2.46l-17.82,46.41a8,8,0,0,1-14.85-.71L40.41,50.44a8,8,0,0,1,10-10L210.51,92.68a8,8,0,0,1,.71,14.85l-46.41,17.82a8,8,0,0,0-2.46,13l51.31,51.31A8,8,0,0,1,213.66,201Z",
                    opacity: "0.2",
                }),
                r.createElement("path", {
                    d: "M168,132.69,214.08,115l.33-.13A16,16,0,0,0,213,85.07L52.92,32.8A15.95,15.95,0,0,0,32.8,52.92L85.07,213a15.82,15.82,0,0,0,14.41,11l.78,0a15.84,15.84,0,0,0,14.61-9.59l.13-.33L132.69,168,184,219.31a16,16,0,0,0,22.63,0l12.68-12.68a16,16,0,0,0,0-22.63ZM195.31,208,144,156.69a16,16,0,0,0-26,4.93c0,.11-.09.22-.13.32l-17.65,46L48,48l159.85,52.2-45.95,17.64-.32.13a16,16,0,0,0-4.93,26h0L208,195.31Z",
                })
            ),
        ],
        [
            "fill",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M220.49,207.8,207.8,220.49a12,12,0,0,1-17,0l-56.57-56.57L115,214.08l-.13.33A15.84,15.84,0,0,1,100.26,224l-.78,0a15.82,15.82,0,0,1-14.41-11L32.8,52.92A15.95,15.95,0,0,1,52.92,32.8L213,85.07a16,16,0,0,1,1.41,29.8l-.33.13-50.16,19.27,56.57,56.56A12,12,0,0,1,220.49,207.8Z",
                })
            ),
        ],
        [
            "light",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M166.59,134.1a1.91,1.91,0,0,1-.55-1.79,2,2,0,0,1,1.08-1.42l46.25-17.76.24-.1A14,14,0,0,0,212.38,87L52.29,34.7A13.95,13.95,0,0,0,34.7,52.29L87,212.38a13.82,13.82,0,0,0,12.6,9.6c.23,0,.46,0,.69,0A13.84,13.84,0,0,0,113,213.61a2.44,2.44,0,0,0,.1-.24l17.76-46.25a2,2,0,0,1,3.21-.53l51.31,51.31a14,14,0,0,0,19.8,0l12.69-12.69a14,14,0,0,0,0-19.8Zm42.82,62.63-12.68,12.68a2,2,0,0,1-2.83,0L142.59,158.1a14,14,0,0,0-22.74,4.32,2.44,2.44,0,0,0-.1.24L102,208.91a2,2,0,0,1-3.61-.26L46.11,48.57a1.87,1.87,0,0,1,.47-2A1.92,1.92,0,0,1,47.93,46a2.22,2.22,0,0,1,.64.1L208.65,98.38a2,2,0,0,1,.26,3.61l-46.25,17.76-.24.1a14,14,0,0,0-4.32,22.74h0l51.31,51.31A2,2,0,0,1,209.41,196.73Z",
                })
            ),
        ],
        [
            "regular",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M168,132.69,214.08,115l.33-.13A16,16,0,0,0,213,85.07L52.92,32.8A15.95,15.95,0,0,0,32.8,52.92L85.07,213a15.82,15.82,0,0,0,14.41,11l.78,0a15.84,15.84,0,0,0,14.61-9.59l.13-.33L132.69,168,184,219.31a16,16,0,0,0,22.63,0l12.68-12.68a16,16,0,0,0,0-22.63ZM195.31,208,144,156.69a16,16,0,0,0-26,4.93c0,.11-.09.22-.13.32l-17.65,46L48,48l159.85,52.2-45.95,17.64-.32.13a16,16,0,0,0-4.93,26h0L208,195.31Z",
                })
            ),
        ],
        [
            "thin",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M165.17,135.51a4,4,0,0,1,1.17-6.46l46.31-17.79.16-.06a12,12,0,0,0-1.05-22.33L51.67,36.6A12,12,0,0,0,36.6,51.67L88.87,211.76A11.86,11.86,0,0,0,99.67,220h.58a11.86,11.86,0,0,0,11-7.19l.06-.16,17.79-46.31a4,4,0,0,1,6.47-1.17l51.31,51.32a12,12,0,0,0,17,0l12.69-12.69a12,12,0,0,0,0-17Zm45.66,62.63-12.69,12.69a4,4,0,0,1-5.66,0l-51.31-51.31a12,12,0,0,0-8.48-3.52,12.13,12.13,0,0,0-2.24.21,12,12,0,0,0-8.77,7l-.06.16-17.79,46.31a4,4,0,0,1-7.36-.42L44.2,49.19a4,4,0,0,1,5-5L209.27,96.47a4,4,0,0,1,.42,7.36l-46.31,17.78-.16.07a12,12,0,0,0-3.71,19.49l51.32,51.31A4,4,0,0,1,210.83,198.14Z",
                })
            ),
        ],
    ]),
    Uo = new Map([
        [
            "bold",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M224.15,179.17l-46.82-46.82,37.92-13.51c.26-.09.51-.19.76-.3a20,20,0,0,0-1.76-37.27L54.16,29A20,20,0,0,0,29,54.16L81.27,214.24A20,20,0,0,0,118.54,216c.11-.25.21-.5.3-.76l13.51-37.92,46.83,46.82a20,20,0,0,0,28.28,0l16.69-16.68A20,20,0,0,0,224.15,179.17Zm-30.83,25.17-48.48-48.48A20,20,0,0,0,130.7,150a20.47,20.47,0,0,0-3.73.35A20,20,0,0,0,112.35,162c-.11.25-.2.5-.3.76L100.4,195.5,54.29,54.29,195.5,100.4l-32.71,11.65c-.25.09-.51.19-.76.3a20,20,0,0,0-6.16,32.48h0l48.48,48.48ZM84,16V12a12,12,0,0,1,24,0v4a12,12,0,0,1-24,0ZM12,108a12,12,0,0,1,0-24h4a12,12,0,0,1,0,24ZM120.62,24.21l4-12a12,12,0,0,1,22.77,7.58l-4,12a12,12,0,0,1-22.77-7.58Zm-81.23,104a12,12,0,0,1-7.59,15.17l-12,4a12,12,0,1,1-7.59-22.76l12-4A12,12,0,0,1,39.39,128.21Z",
                })
            ),
        ],
        [
            "duotone",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M213.66,201,201,213.66a8,8,0,0,1-11.31,0l-51.31-51.31a8,8,0,0,0-13,2.46l-17.82,46.41a8,8,0,0,1-14.85-.71L40.41,50.44a8,8,0,0,1,10-10L210.51,92.68a8,8,0,0,1,.71,14.85l-46.41,17.82a8,8,0,0,0-2.46,13l51.31,51.31A8,8,0,0,1,213.66,201Z",
                    opacity: "0.2",
                }),
                r.createElement("path", {
                    d: "M88,24V16a8,8,0,0,1,16,0v8a8,8,0,0,1-16,0ZM16,104h8a8,8,0,0,0,0-16H16a8,8,0,0,0,0,16ZM124.42,39.16a8,8,0,0,0,10.74-3.58l8-16a8,8,0,0,0-14.31-7.16l-8,16A8,8,0,0,0,124.42,39.16Zm-96,81.69-16,8a8,8,0,0,0,7.16,14.31l16-8a8,8,0,1,0-7.16-14.31ZM219.31,184a16,16,0,0,1,0,22.63l-12.68,12.68a16,16,0,0,1-22.63,0L132.7,168,115,214.09c0,.1-.08.21-.13.32a15.83,15.83,0,0,1-14.6,9.59l-.79,0a15.83,15.83,0,0,1-14.41-11L32.8,52.92A16,16,0,0,1,52.92,32.8L213,85.07a16,16,0,0,1,1.41,29.8l-.32.13L168,132.69ZM208,195.31,156.69,144h0a16,16,0,0,1,4.93-26l.32-.14,45.95-17.64L48,48l52.2,159.86,17.65-46c0-.11.08-.22.13-.33a16,16,0,0,1,11.69-9.34,16.72,16.72,0,0,1,3-.28,16,16,0,0,1,11.3,4.69L195.31,208Z",
                })
            ),
        ],
        [
            "fill",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M220.49,190.83a12,12,0,0,1,0,17L207.8,220.49a12,12,0,0,1-17,0l-56.56-56.57L115,214.09c0,.1-.08.21-.13.32a15.83,15.83,0,0,1-14.6,9.59l-.79,0a15.83,15.83,0,0,1-14.41-11L32.8,52.92A16,16,0,0,1,52.92,32.8L213,85.07a16,16,0,0,1,1.41,29.8l-.32.13-50.17,19.27ZM96,32a8,8,0,0,0,8-8V16a8,8,0,0,0-16,0v8A8,8,0,0,0,96,32ZM16,104h8a8,8,0,0,0,0-16H16a8,8,0,0,0,0,16ZM124.42,39.16a8,8,0,0,0,10.74-3.58l8-16a8,8,0,0,0-14.31-7.16l-8,16A8,8,0,0,0,124.42,39.16Zm-96,81.69-16,8a8,8,0,0,0,7.16,14.31l16-8a8,8,0,1,0-7.16-14.31Z",
                })
            ),
        ],
        [
            "light",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M90,24V16a6,6,0,0,1,12,0v8a6,6,0,0,1-12,0ZM16,102h8a6,6,0,0,0,0-12H16a6,6,0,0,0,0,12ZM125.32,37.37a6,6,0,0,0,8.05-2.69l8-16a6,6,0,0,0-10.74-5.37l-8,16A6,6,0,0,0,125.32,37.37Zm-96,85.26-16,8a6,6,0,0,0,5.36,10.74l16-8a6,6,0,1,0-5.36-10.74ZM217.9,185.41a14,14,0,0,1,0,19.8L205.21,217.9a14,14,0,0,1-19.8,0L134.1,166.59a2,2,0,0,0-3.21.54l-17.75,46.24a2.44,2.44,0,0,0-.1.24A13.85,13.85,0,0,1,100.26,222c-.23,0-.45,0-.68,0A13.85,13.85,0,0,1,87,212.38L34.7,52.3A14,14,0,0,1,52.3,34.7L212.38,87A14,14,0,0,1,213.61,113l-.24.09-46.25,17.76a2,2,0,0,0-.53,3.21Zm-8.49,8.49L158.1,142.59h0a14,14,0,0,1,4.32-22.74l.24-.1L208.91,102a2,2,0,0,0-.26-3.61L48.58,46.11a2.33,2.33,0,0,0-.65-.11,2,2,0,0,0-1.82,2.58L98.38,208.65a1.84,1.84,0,0,0,1.77,1.35,1.81,1.81,0,0,0,1.84-1.09l17.76-46.25.1-.24a14,14,0,0,1,22.74-4.32l51.31,51.31a2,2,0,0,0,2.83,0l12.68-12.68A2,2,0,0,0,209.41,193.9Z",
                })
            ),
        ],
        [
            "regular",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M88,24V16a8,8,0,0,1,16,0v8a8,8,0,0,1-16,0ZM16,104h8a8,8,0,0,0,0-16H16a8,8,0,0,0,0,16ZM124.42,39.16a8,8,0,0,0,10.74-3.58l8-16a8,8,0,0,0-14.31-7.16l-8,16A8,8,0,0,0,124.42,39.16Zm-96,81.69-16,8a8,8,0,0,0,7.16,14.31l16-8a8,8,0,1,0-7.16-14.31ZM219.31,184a16,16,0,0,1,0,22.63l-12.68,12.68a16,16,0,0,1-22.63,0L132.7,168,115,214.09c0,.1-.08.21-.13.32a15.83,15.83,0,0,1-14.6,9.59l-.79,0a15.83,15.83,0,0,1-14.41-11L32.8,52.92A16,16,0,0,1,52.92,32.8L213,85.07a16,16,0,0,1,1.41,29.8l-.32.13L168,132.69ZM208,195.31,156.69,144h0a16,16,0,0,1,4.93-26l.32-.14,45.95-17.64L48,48l52.2,159.86,17.65-46c0-.11.08-.22.13-.33a16,16,0,0,1,11.69-9.34,16.72,16.72,0,0,1,3-.28,16,16,0,0,1,11.3,4.69L195.31,208Z",
                })
            ),
        ],
        [
            "thin",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M92,24V16a4,4,0,0,1,8,0v8a4,4,0,0,1-8,0ZM16,100h8a4,4,0,0,0,0-8H16a4,4,0,0,0,0,8ZM126.21,35.58a4,4,0,0,0,5.37-1.79l8-16a4,4,0,0,0-7.16-3.58l-8,16A4,4,0,0,0,126.21,35.58Zm-96,88.84-16,8a4,4,0,0,0,3.58,7.16l16-8a4,4,0,1,0-3.58-7.16Zm186.28,62.41a12,12,0,0,1,0,17L203.8,216.49a12,12,0,0,1-17,0l-51.31-51.31a3.93,3.93,0,0,0-3.58-1.11,4,4,0,0,0-2.89,2.27l-17.78,46.31a.77.77,0,0,1-.07.16A11.85,11.85,0,0,1,100.26,220h-.59a11.88,11.88,0,0,1-10.8-8.23L36.6,51.68A12,12,0,0,1,51.68,36.6L211.76,88.87a12,12,0,0,1,1.05,22.33l-.16.07-46.31,17.78a4,4,0,0,0-1.17,6.47Zm-5.66,5.66-51.31-51.32a12,12,0,0,1,3.7-19.49l.16-.06,46.31-17.79a3.95,3.95,0,0,0-.42-7.35L49.2,44.21a4,4,0,0,0-5,5L96.48,209.27a4,4,0,0,0,7.36.42l17.78-46.31a1.11,1.11,0,0,1,.07-.16,12,12,0,0,1,8.76-7,12.21,12.21,0,0,1,2.24-.21,12,12,0,0,1,8.49,3.52l51.31,51.31a4,4,0,0,0,5.65,0l12.69-12.69A4,4,0,0,0,210.83,192.49Z",
                })
            ),
        ],
    ]),
    Zo = new Map([
        [
            "bold",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M144,12H112A68.07,68.07,0,0,0,44,80v96a68.07,68.07,0,0,0,68,68h32a68.07,68.07,0,0,0,68-68V80A68.07,68.07,0,0,0,144,12Zm44,68v20H140V36h4A44.05,44.05,0,0,1,188,80ZM112,36h4v64H68V80A44.05,44.05,0,0,1,112,36Zm32,184H112a44.05,44.05,0,0,1-44-44V124H188v52A44.05,44.05,0,0,1,144,220Z",
                })
            ),
        ],
        [
            "duotone",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M200,112v64a56,56,0,0,1-56,56H112a56,56,0,0,1-56-56V112Z",
                    opacity: "0.2",
                }),
                r.createElement("path", {
                    d: "M144,16H112A64.07,64.07,0,0,0,48,80v96a64.07,64.07,0,0,0,64,64h32a64.07,64.07,0,0,0,64-64V80A64.07,64.07,0,0,0,144,16Zm48,64v24H136V32h8A48.05,48.05,0,0,1,192,80ZM112,32h8v72H64V80A48.05,48.05,0,0,1,112,32Zm32,192H112a48.05,48.05,0,0,1-48-48V120H192v56A48.05,48.05,0,0,1,144,224Z",
                })
            ),
        ],
        [
            "fill",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M144,16H112A64.07,64.07,0,0,0,48,80v96a64.07,64.07,0,0,0,64,64h32a64.07,64.07,0,0,0,64-64V80A64.07,64.07,0,0,0,144,16Zm48,64v24H136V32h8A48.05,48.05,0,0,1,192,80ZM112,32h8v72H64V80A48.05,48.05,0,0,1,112,32Z",
                })
            ),
        ],
        [
            "light",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M144,18H112A62.07,62.07,0,0,0,50,80v96a62.07,62.07,0,0,0,62,62h32a62.07,62.07,0,0,0,62-62V80A62.07,62.07,0,0,0,144,18Zm50,62v26H134V30h10A50.06,50.06,0,0,1,194,80ZM112,30h10v76H62V80A50.06,50.06,0,0,1,112,30Zm32,196H112a50.06,50.06,0,0,1-50-50V118H194v58A50.06,50.06,0,0,1,144,226Z",
                })
            ),
        ],
        [
            "regular",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M144,16H112A64.07,64.07,0,0,0,48,80v96a64.07,64.07,0,0,0,64,64h32a64.07,64.07,0,0,0,64-64V80A64.07,64.07,0,0,0,144,16Zm48,64v24H136V32h8A48.05,48.05,0,0,1,192,80ZM112,32h8v72H64V80A48.05,48.05,0,0,1,112,32Zm32,192H112a48.05,48.05,0,0,1-48-48V120H192v56A48.05,48.05,0,0,1,144,224Z",
                })
            ),
        ],
        [
            "thin",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M144,20H112A60.07,60.07,0,0,0,52,80v96a60.07,60.07,0,0,0,60,60h32a60.07,60.07,0,0,0,60-60V80A60.07,60.07,0,0,0,144,20Zm52,60v28H132V28h12A52.06,52.06,0,0,1,196,80ZM112,28h12v80H60V80A52.06,52.06,0,0,1,112,28Zm32,200H112a52.06,52.06,0,0,1-52-52V116H196v60A52.06,52.06,0,0,1,144,228Z",
                })
            ),
        ],
    ]),
    zo = new Map([
        [
            "bold",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M238.7,102.46,62.81,37.21l-.25-.09A20,20,0,0,0,37.12,62.56l.09.25L102.46,238.7A20,20,0,0,0,121.3,252h.35a20,20,0,0,0,18.77-14.12l.09-.29,21.23-75.85,75.85-21.23.29-.09a20,20,0,0,0,.82-38Zm-89.93,38a12,12,0,0,0-8.32,8.32l-19.68,70.29L62.8,62.8l156.26,58Z",
                })
            ),
        ],
        [
            "duotone",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M234.35,129,152,152,129,234.35a8,8,0,0,1-15.21.27l-65.28-176A8,8,0,0,1,58.63,48.46l176,65.28A8,8,0,0,1,234.35,129Z",
                    opacity: "0.2",
                }),
                r.createElement("path", {
                    d: "M237.33,106.21,61.41,41l-.16-.05A16,16,0,0,0,40.9,61.25a1,1,0,0,0,.05.16l65.26,175.92A15.77,15.77,0,0,0,121.28,248h.3a15.77,15.77,0,0,0,15-11.29l.06-.2,21.84-78,78-21.84.2-.06a16,16,0,0,0,.62-30.38ZM149.84,144.3a8,8,0,0,0-5.54,5.54L121.3,232l-.06-.17L56,56l175.82,65.22.16.06Z",
                })
            ),
        ],
        [
            "fill",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M248,121.58a15.76,15.76,0,0,1-11.29,15l-.2.06-78,21.84-21.84,78-.06.2a15.77,15.77,0,0,1-15,11.29h-.3a15.77,15.77,0,0,1-15.07-10.67L41,61.41a1,1,0,0,1-.05-.16A16,16,0,0,1,61.25,40.9l.16.05,175.92,65.26A15.78,15.78,0,0,1,248,121.58Z",
                })
            ),
        ],
        [
            "light",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M236.65,108.1,60.72,42.83l-.13,0A14,14,0,0,0,42.78,60.59s0,.09,0,.13L108.1,236.65A13.77,13.77,0,0,0,121.28,246h.26a13.8,13.8,0,0,0,13.14-9.88l0-.15,22.14-79.1L236,134.73l.15,0a14,14,0,0,0,.53-26.58Zm-4,15.1-82.26,23a6,6,0,0,0-4.16,4.16l-23,82.26a1.85,1.85,0,0,1-1.86,1.36,1.82,1.82,0,0,1-1.92-1.35.61.61,0,0,0,0-.12L54.11,56.62a2,2,0,0,1,2.51-2.51l175.91,65.26.12,0a2,2,0,0,1,0,3.79Z",
                })
            ),
        ],
        [
            "regular",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M237.33,106.21,61.41,41l-.16-.05A16,16,0,0,0,40.9,61.25a1,1,0,0,0,.05.16l65.26,175.92A15.77,15.77,0,0,0,121.28,248h.3a15.77,15.77,0,0,0,15-11.29l.06-.2,21.84-78,78-21.84.2-.06a16,16,0,0,0,.62-30.38ZM149.84,144.3a8,8,0,0,0-5.54,5.54L121.3,232l-.06-.17L56,56l175.82,65.22.16.06Z",
                })
            ),
        ],
        [
            "thin",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M236,110,59.93,44.67A12,12,0,0,0,44.69,60L110,235.93A11.83,11.83,0,0,0,121.28,244h.22a11.82,11.82,0,0,0,11.26-8.47l0-.1,22.45-80.19,80.19-22.44.1,0A12,12,0,0,0,236,110Zm-2.79,15.12-82.3,23a4,4,0,0,0-2.78,2.77l-23,82.3a3.88,3.88,0,0,1-3.74,2.78,4,4,0,0,1-3.88-2.77L52.22,57.32a3.93,3.93,0,0,1,1-4.14A4,4,0,0,1,56,52a3.86,3.86,0,0,1,1.25.21l176.08,65.32a4,4,0,0,1-.09,7.59Z",
                })
            ),
        ],
    ]),
    $o = new Map([
        [
            "bold",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M156,40a12,12,0,0,1-12,12H112a12,12,0,0,1,0-24h32A12,12,0,0,1,156,40ZM144,204H112a12,12,0,0,0,0,24h32a12,12,0,0,0,0-24ZM204,52V72a12,12,0,0,0,24,0V48a20,20,0,0,0-20-20H184a12,12,0,0,0,0,24Zm12,48a12,12,0,0,0-12,12v32a12,12,0,0,0,24,0V112A12,12,0,0,0,216,100ZM40,156a12,12,0,0,0,12-12V112a12,12,0,0,0-24,0v32A12,12,0,0,0,40,156Zm32,48H52V184a12,12,0,0,0-24,0v24a20,20,0,0,0,20,20H72a12,12,0,0,0,0-24ZM72,28H48A20,20,0,0,0,28,48V72a12,12,0,0,0,24,0V52H72a12,12,0,0,0,0-24ZM240,204H228V192a12,12,0,0,0-24,0v12H192a12,12,0,0,0,0,24h12v12a12,12,0,0,0,24,0V228h12a12,12,0,0,0,0-24Z",
                })
            ),
        ],
        [
            "duotone",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M216,40V216H40V40Z",
                    opacity: "0.2",
                }),
                r.createElement("path", {
                    d: "M152,40a8,8,0,0,1-8,8H112a8,8,0,0,1,0-16h32A8,8,0,0,1,152,40Zm-8,168H112a8,8,0,0,0,0,16h32a8,8,0,0,0,0-16ZM208,48V72a8,8,0,0,0,16,0V48a16,16,0,0,0-16-16H184a8,8,0,0,0,0,16Zm8,56a8,8,0,0,0-8,8v32a8,8,0,0,0,16,0V112A8,8,0,0,0,216,104ZM40,152a8,8,0,0,0,8-8V112a8,8,0,0,0-16,0v32A8,8,0,0,0,40,152Zm32,56H48V184a8,8,0,0,0-16,0v24a16,16,0,0,0,16,16H72a8,8,0,0,0,0-16ZM72,32H48A16,16,0,0,0,32,48V72a8,8,0,0,0,16,0V48H72a8,8,0,0,0,0-16ZM240,208H224V192a8,8,0,0,0-16,0v16H192a8,8,0,0,0,0,16h16v16a8,8,0,0,0,16,0V224h16a8,8,0,0,0,0-16Z",
                })
            ),
        ],
        [
            "fill",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM56,72A16,16,0,0,1,72,56H96a8,8,0,0,1,0,16H72V96a8,8,0,0,1-16,0Zm56,112H72a16,16,0,0,1-16-16V136a8,8,0,0,1,16,0v32h40a8,8,0,0,1,0,16ZM128,64a8,8,0,0,1,8-8h32a16,16,0,0,1,16,16v40a8,8,0,0,1-16,0V72H136A8,8,0,0,1,128,64Zm72,120H184v16a8,8,0,0,1-16,0V184H152a8,8,0,0,1,0-16h16V152a8,8,0,0,1,16,0v16h16a8,8,0,0,1,0,16Z",
                })
            ),
        ],
        [
            "light",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M150,40a6,6,0,0,1-6,6H112a6,6,0,0,1,0-12h32A6,6,0,0,1,150,40Zm-6,170H112a6,6,0,0,0,0,12h32a6,6,0,0,0,0-12ZM210,48V72a6,6,0,0,0,12,0V48a14,14,0,0,0-14-14H184a6,6,0,0,0,0,12h24A2,2,0,0,1,210,48Zm6,58a6,6,0,0,0-6,6v32a6,6,0,0,0,12,0V112A6,6,0,0,0,216,106ZM40,150a6,6,0,0,0,6-6V112a6,6,0,0,0-12,0v32A6,6,0,0,0,40,150Zm32,60H48a2,2,0,0,1-2-2V184a6,6,0,0,0-12,0v24a14,14,0,0,0,14,14H72a6,6,0,0,0,0-12ZM72,34H48A14,14,0,0,0,34,48V72a6,6,0,0,0,12,0V48a2,2,0,0,1,2-2H72a6,6,0,0,0,0-12ZM240,210H222V192a6,6,0,0,0-12,0v18H192a6,6,0,0,0,0,12h18v18a6,6,0,0,0,12,0V222h18a6,6,0,0,0,0-12Z",
                })
            ),
        ],
        [
            "regular",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M152,40a8,8,0,0,1-8,8H112a8,8,0,0,1,0-16h32A8,8,0,0,1,152,40Zm-8,168H112a8,8,0,0,0,0,16h32a8,8,0,0,0,0-16ZM208,48V72a8,8,0,0,0,16,0V48a16,16,0,0,0-16-16H184a8,8,0,0,0,0,16Zm8,56a8,8,0,0,0-8,8v32a8,8,0,0,0,16,0V112A8,8,0,0,0,216,104ZM40,152a8,8,0,0,0,8-8V112a8,8,0,0,0-16,0v32A8,8,0,0,0,40,152Zm32,56H48V184a8,8,0,0,0-16,0v24a16,16,0,0,0,16,16H72a8,8,0,0,0,0-16ZM72,32H48A16,16,0,0,0,32,48V72a8,8,0,0,0,16,0V48H72a8,8,0,0,0,0-16ZM240,208H224V192a8,8,0,0,0-16,0v16H192a8,8,0,0,0,0,16h16v16a8,8,0,0,0,16,0V224h16a8,8,0,0,0,0-16Z",
                })
            ),
        ],
        [
            "thin",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M148,40a4,4,0,0,1-4,4H112a4,4,0,0,1,0-8h32A4,4,0,0,1,148,40Zm-4,172H112a4,4,0,0,0,0,8h32a4,4,0,0,0,0-8ZM212,48V72a4,4,0,0,0,8,0V48a12,12,0,0,0-12-12H184a4,4,0,0,0,0,8h24A4,4,0,0,1,212,48Zm4,60a4,4,0,0,0-4,4v32a4,4,0,0,0,8,0V112A4,4,0,0,0,216,108ZM40,148a4,4,0,0,0,4-4V112a4,4,0,0,0-8,0v32A4,4,0,0,0,40,148Zm32,64H48a4,4,0,0,1-4-4V184a4,4,0,0,0-8,0v24a12,12,0,0,0,12,12H72a4,4,0,0,0,0-8ZM72,36H48A12,12,0,0,0,36,48V72a4,4,0,0,0,8,0V48a4,4,0,0,1,4-4H72a4,4,0,0,0,0-8ZM240,212H220V192a4,4,0,0,0-8,0v20H192a4,4,0,0,0,0,8h20v20a4,4,0,0,0,8,0V220h20a4,4,0,0,0,0-8Z",
                })
            ),
        ],
    ]),
    Wo = new Map([
        [
            "bold",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M212,56V88a12,12,0,0,1-24,0V68H140V188h20a12,12,0,0,1,0,24H96a12,12,0,0,1,0-24h20V68H68V88a12,12,0,0,1-24,0V56A12,12,0,0,1,56,44H200A12,12,0,0,1,212,56Z",
                })
            ),
        ],
        [
            "duotone",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M200,56V184a16,16,0,0,1-16,16H72a16,16,0,0,1-16-16V56Z",
                    opacity: "0.2",
                }),
                r.createElement("path", {
                    d: "M208,56V88a8,8,0,0,1-16,0V64H136V192h24a8,8,0,0,1,0,16H96a8,8,0,0,1,0-16h24V64H64V88a8,8,0,0,1-16,0V56a8,8,0,0,1,8-8H200A8,8,0,0,1,208,56Z",
                })
            ),
        ],
        [
            "fill",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM184,96a8,8,0,0,1-16,0V88H136v88h12a8,8,0,0,1,0,16H108a8,8,0,0,1,0-16h12V88H88v8a8,8,0,0,1-16,0V80a8,8,0,0,1,8-8h96a8,8,0,0,1,8,8Z",
                })
            ),
        ],
        [
            "light",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M206,56V88a6,6,0,0,1-12,0V62H134V194h26a6,6,0,0,1,0,12H96a6,6,0,0,1,0-12h26V62H62V88a6,6,0,0,1-12,0V56a6,6,0,0,1,6-6H200A6,6,0,0,1,206,56Z",
                })
            ),
        ],
        [
            "regular",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M208,56V88a8,8,0,0,1-16,0V64H136V192h24a8,8,0,0,1,0,16H96a8,8,0,0,1,0-16h24V64H64V88a8,8,0,0,1-16,0V56a8,8,0,0,1,8-8H200A8,8,0,0,1,208,56Z",
                })
            ),
        ],
        [
            "thin",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M204,56V88a4,4,0,0,1-8,0V60H132V196h28a4,4,0,0,1,0,8H96a4,4,0,0,1,0-8h28V60H60V88a4,4,0,0,1-8,0V56a4,4,0,0,1,4-4H200A4,4,0,0,1,204,56Z",
                })
            ),
        ],
    ]),
    qo = new Map([
        [
            "bold",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M112,36a12,12,0,0,0-12,12V60H24A20,20,0,0,0,4,80v96a20,20,0,0,0,20,20h76v12a12,12,0,0,0,24,0V48A12,12,0,0,0,112,36ZM28,172V84h72v88ZM252,80v96a20,20,0,0,1-20,20H152a12,12,0,0,1,0-24h76V84H152a12,12,0,0,1,0-24h80A20,20,0,0,1,252,80ZM88,112a12,12,0,0,1-12,12v20a12,12,0,0,1-24,0V124a12,12,0,0,1,0-24H76A12,12,0,0,1,88,112Z",
                })
            ),
        ],
        [
            "duotone",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M240,80v96a8,8,0,0,1-8,8H24a8,8,0,0,1-8-8V80a8,8,0,0,1,8-8H232A8,8,0,0,1,240,80Z",
                    opacity: "0.2",
                }),
                r.createElement("path", {
                    d: "M112,40a8,8,0,0,0-8,8V64H24A16,16,0,0,0,8,80v96a16,16,0,0,0,16,16h80v16a8,8,0,0,0,16,0V48A8,8,0,0,0,112,40ZM24,176V80h80v96ZM248,80v96a16,16,0,0,1-16,16H144a8,8,0,0,1,0-16h88V80H144a8,8,0,0,1,0-16h88A16,16,0,0,1,248,80ZM88,112a8,8,0,0,1-8,8H72v24a8,8,0,0,1-16,0V120H48a8,8,0,0,1,0-16H80A8,8,0,0,1,88,112Z",
                })
            ),
        ],
        [
            "fill",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M248,80v96a16,16,0,0,1-16,16H140a4,4,0,0,1-4-4V68a4,4,0,0,1,4-4h92A16,16,0,0,1,248,80ZM120,48V208a8,8,0,0,1-16,0V192H24A16,16,0,0,1,8,176V80A16,16,0,0,1,24,64h80V48a8,8,0,0,1,16,0ZM88,112a8,8,0,0,0-8-8H48a8,8,0,0,0,0,16h8v24a8,8,0,0,0,16,0V120h8A8,8,0,0,0,88,112Z",
                })
            ),
        ],
        [
            "light",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M112,42a6,6,0,0,0-6,6V66H24A14,14,0,0,0,10,80v96a14,14,0,0,0,14,14h82v18a6,6,0,0,0,12,0V48A6,6,0,0,0,112,42ZM24,178a2,2,0,0,1-2-2V80a2,2,0,0,1,2-2h82V178ZM246,80v96a14,14,0,0,1-14,14H144a6,6,0,0,1,0-12h88a2,2,0,0,0,2-2V80a2,2,0,0,0-2-2H144a6,6,0,0,1,0-12h88A14,14,0,0,1,246,80ZM86,112a6,6,0,0,1-6,6H70v26a6,6,0,0,1-12,0V118H48a6,6,0,0,1,0-12H80A6,6,0,0,1,86,112Z",
                })
            ),
        ],
        [
            "regular",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M112,40a8,8,0,0,0-8,8V64H24A16,16,0,0,0,8,80v96a16,16,0,0,0,16,16h80v16a8,8,0,0,0,16,0V48A8,8,0,0,0,112,40ZM24,176V80h80v96ZM248,80v96a16,16,0,0,1-16,16H144a8,8,0,0,1,0-16h88V80H144a8,8,0,0,1,0-16h88A16,16,0,0,1,248,80ZM88,112a8,8,0,0,1-8,8H72v24a8,8,0,0,1-16,0V120H48a8,8,0,0,1,0-16H80A8,8,0,0,1,88,112Z",
                })
            ),
        ],
        [
            "thin",
            r.createElement(
                r.Fragment,
                null,
                r.createElement("path", {
                    d: "M112,44a4,4,0,0,0-4,4V68H24A12,12,0,0,0,12,80v96a12,12,0,0,0,12,12h84v20a4,4,0,0,0,8,0V48A4,4,0,0,0,112,44ZM24,180a4,4,0,0,1-4-4V80a4,4,0,0,1,4-4h84V180ZM244,80v96a12,12,0,0,1-12,12H144a4,4,0,0,1,0-8h88a4,4,0,0,0,4-4V80a4,4,0,0,0-4-4H144a4,4,0,0,1,0-8h88A12,12,0,0,1,244,80ZM84,112a4,4,0,0,1-4,4H68v28a4,4,0,0,1-8,0V116H48a4,4,0,0,1,0-8H80A4,4,0,0,1,84,112Z",
                })
            ),
        ],
    ]),
    Ko = r.createContext({
        color: "currentColor",
        size: "1em",
        weight: "regular",
        mirrored: !1,
    }),
    Yo = r.forwardRef((e, t) => {
        const {
                alt: n,
                color: o,
                size: i,
                weight: s,
                mirrored: a,
                children: l,
                weights: c,
                ...u
            } = e,
            {
                color: d = "currentColor",
                size: h,
                weight: p = "regular",
                mirrored: f = !1,
                ...m
            } = r.useContext(Ko);
        return r.createElement(
            "svg",
            {
                ref: t,
                xmlns: "http://www.w3.org/2000/svg",
                width: null != i ? i : h,
                height: null != i ? i : h,
                fill: null != o ? o : d,
                viewBox: "0 0 256 256",
                transform: a || f ? "scale(-1, 1)" : void 0,
                ...m,
                ...u,
            },
            !!n && r.createElement("title", null, n),
            l,
            c.get(null != s ? s : p)
        );
    });
Yo.displayName = "IconBase";
const Xo = r.forwardRef((e, t) =>
    r.createElement(Yo, { ref: t, ...e, weights: Fo })
);
Xo.displayName = "ArticleNyTimesIcon";
const Go = Xo,
    Qo = r.forwardRef((e, t) =>
        r.createElement(Yo, { ref: t, ...e, weights: Bo })
    );
Qo.displayName = "CursorIcon";
const Jo = Qo,
    ei = r.forwardRef((e, t) =>
        r.createElement(Yo, { ref: t, ...e, weights: Uo })
    );
ei.displayName = "CursorClickIcon";
const ti = ei,
    ni = r.forwardRef((e, t) =>
        r.createElement(Yo, { ref: t, ...e, weights: Zo })
    );
ni.displayName = "MouseIcon";
const ri = ni,
    oi = r.forwardRef((e, t) =>
        r.createElement(Yo, { ref: t, ...e, weights: zo })
    );
oi.displayName = "NavigationArrowIcon";
const ii = oi,
    si = r.forwardRef((e, t) =>
        r.createElement(Yo, { ref: t, ...e, weights: $o })
    );
si.displayName = "SelectionPlusIcon";
const ai = si,
    li = r.forwardRef((e, t) =>
        r.createElement(Yo, { ref: t, ...e, weights: Wo })
    );
li.displayName = "TextTIcon";
const ci = li,
    ui = r.forwardRef((e, t) =>
        r.createElement(Yo, { ref: t, ...e, weights: qo })
    );
ui.displayName = "TextboxIcon";
const di = ui,
    hi = { 12: 16, 16: 20, 20: 20, 24: 24, 28: 28, 32: 32 },
    pi = ({
        size: e = 20,
        vectorSizeOverride: t,
        className: n,
        alt: r,
        viewBox: o = "0 0 20 20",
        children: i,
    }) => {
        const s = t || hi[e],
            l = a.jsx("svg", {
                width: s,
                height: s,
                viewBox: o,
                fill: "currentColor",
                xmlns: "http://www.w3.org/2000/svg",
                className: "shrink-0",
                "aria-label": r,
                "aria-hidden": !r,
                children: i,
            });
        return t
            ? l
            : a.jsx("div", {
                  className: c("flex items-center justify-center", n),
                  style: { width: e, height: e },
                  children: l,
              });
    },
    fi = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M10 3C10.2761 3.00006 10.5 3.2239 10.5 3.5V15.293L14.6465 11.1465C14.8418 10.9514 15.1583 10.9513 15.3536 11.1465C15.5487 11.3417 15.5486 11.6583 15.3536 11.8535L10.3535 16.8535C10.2598 16.9473 10.1326 17 10 17C9.90062 17 9.8042 16.9703 9.72268 16.916L9.64651 16.8535L4.6465 11.8535C4.45138 11.6582 4.45128 11.3417 4.6465 11.1465C4.84172 10.9513 5.15827 10.9514 5.35353 11.1465L9.50003 15.293V3.5C9.50003 3.22386 9.72389 3 10 3Z",
            }),
        }),
    mi = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M8.14648 4.64648C8.34176 4.45136 8.6583 4.45127 8.85352 4.64648C9.04868 4.8417 9.04862 5.15826 8.85352 5.35352L4.70703 9.50001H16.5C16.7761 9.50001 17 9.72387 17 10C16.9999 10.2761 16.7761 10.5 16.5 10.5H4.70703L8.85352 14.6465C9.04863 14.8418 9.04873 15.1583 8.85352 15.3535C8.6583 15.5487 8.34174 15.5486 8.14648 15.3535L3.14648 10.3535C3.05274 10.2598 3.00003 10.1326 3 10C3 9.90061 3.02967 9.80418 3.08398 9.72267L3.14648 9.64649L8.14648 4.64648Z",
            }),
        }),
    gi = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M11.1465 4.64648C11.3417 4.45127 11.6582 4.45136 11.8535 4.64648L16.8535 9.64649L16.916 9.72267C16.9703 9.80418 17 9.90061 17 10C17 10.1326 16.9473 10.2598 16.8535 10.3535L11.8535 15.3535C11.6583 15.5486 11.3417 15.5487 11.1465 15.3535C10.9513 15.1583 10.9514 14.8418 11.1465 14.6465L15.293 10.5H3.5C3.2239 10.5 3.00006 10.2761 3 10C3 9.72387 3.22386 9.50001 3.5 9.50001H15.293L11.1465 5.35352C10.9514 5.15826 10.9513 4.8417 11.1465 4.64648Z",
            }),
        }),
    yi = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M10 3C10.1326 3.00003 10.2598 3.05274 10.3535 3.14648L15.3536 8.14648C15.5486 8.34174 15.5487 8.6583 15.3536 8.85352C15.1583 9.04873 14.8418 9.04863 14.6465 8.85352L10.5 4.70703V16.5C10.5 16.7761 10.2761 16.9999 10 17C9.72389 17 9.50003 16.7761 9.50003 16.5V4.70703L5.35353 8.85352C5.15827 9.04862 4.84172 9.04868 4.6465 8.85352C4.45128 8.6583 4.45138 8.34176 4.6465 8.14648L9.64651 3.14648L9.72268 3.08398C9.8042 3.02967 9.90062 3 10 3Z",
            }),
        }),
    xi = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M12 3C12.4721 3 12.9169 3.222 13.2002 3.59961L14.25 5H16.5C17.3284 5 18 5.67157 18 6.5V15.5C18 16.3284 17.3284 17 16.5 17H3.5C2.67157 17 2 16.3284 2 15.5V6.5C2 5.67157 2.67157 5 3.5 5H5.75L6.7998 3.59961L6.91309 3.46582C7.19443 3.17009 7.58677 3 8 3H12ZM8 4C7.88217 4 7.76948 4.04152 7.68066 4.11523L7.59961 4.2002L6.40039 5.7998C6.30596 5.92571 6.15738 6 6 6H3.5C3.22386 6 3 6.22386 3 6.5V15.5C3 15.7761 3.22386 16 3.5 16H16.5C16.7761 16 17 15.7761 17 15.5V6.5C17 6.22386 16.7761 6 16.5 6H14C13.8426 6 13.694 5.92571 13.5996 5.7998L12.4004 4.2002C12.306 4.07429 12.1574 4 12 4H8ZM10 7C11.933 7 13.5 8.567 13.5 10.5C13.5 12.433 11.933 14 10 14C8.067 14 6.5 12.433 6.5 10.5C6.5 8.567 8.067 7 10 7ZM10 8C8.61929 8 7.5 9.11929 7.5 10.5C7.5 11.8807 8.61929 13 10 13C11.3807 13 12.5 11.8807 12.5 10.5C12.5 9.11929 11.3807 8 10 8Z",
            }),
        }),
    vi = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M7.12771 5.16489C7.28926 4.98544 7.55225 4.95072 7.75273 5.0682L7.83477 5.12778L12.835 9.62788C12.9402 9.72264 12.9999 9.85833 13 9.99995C13 10.1063 12.9667 10.2093 12.9053 10.2939L12.835 10.372L7.83477 14.8721C7.62952 15.0567 7.31242 15.0402 7.12771 14.835C6.94336 14.6298 6.95983 14.3126 7.16482 14.128L11.7519 9.99995L7.16482 5.87193L7.09744 5.79674C6.95939 5.60969 6.96617 5.34444 7.12771 5.16489Z",
            }),
        }),
    Ci = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M10 2.5C14.1421 2.5 17.5 5.85786 17.5 10C17.5 14.1421 14.1421 17.5 10 17.5C5.85786 17.5 2.5 14.1421 2.5 10C2.5 5.85786 5.85786 2.5 10 2.5ZM10 3.5C6.41015 3.5 3.5 6.41015 3.5 10C3.5 13.5899 6.41015 16.5 10 16.5C13.5899 16.5 16.5 13.5899 16.5 10C16.5 6.41015 13.5899 3.5 10 3.5ZM10 5C10.2761 5 10.5 5.22386 10.5 5.5V9.66895L13.6973 11.04L13.7852 11.0898C13.9763 11.2224 14.0552 11.4751 13.96 11.6973C13.8647 11.9193 13.6272 12.0372 13.3994 11.9902L13.3027 11.96L9.80273 10.46C9.61896 10.3811 9.5 10.2 9.5 10V5.5C9.5 5.22386 9.72386 5 10 5Z",
            }),
        }),
    wi = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M10 4C14.0285 4 16.6432 7.30578 17.6602 8.86621L17.7402 8.99902C18.0858 9.62459 18.0858 10.3754 17.7402 11.001L17.6602 11.1338C16.6432 12.6942 14.0285 16 10 16C6.22298 16 3.68865 13.0942 2.54883 11.4453L2.33985 11.1338C1.88802 10.4404 1.88802 9.55955 2.33985 8.86621L2.54883 8.55469C3.68865 6.90581 6.22298 4 10 4ZM10 5C6.74739 5 4.47588 7.53 3.38086 9.11035L3.17774 9.41211C2.94217 9.77359 2.94217 10.2264 3.17774 10.5879L3.38086 10.8896C4.47588 12.47 6.74739 15 10 15C13.4691 15 15.8223 12.1222 16.8223 10.5879L16.8994 10.4482C17.0321 10.1621 17.0321 9.83791 16.8994 9.55176L16.8223 9.41211C15.8223 7.87782 13.4691 5 10 5ZM10 7C11.6569 7 13 8.34315 13 10C13 11.6569 11.6569 13 10 13C8.34315 13 7 11.6569 7 10C7 8.34315 8.34315 7 10 7ZM10 8C8.89543 8 8 8.89543 8 10C8 11.1046 8.89543 12 10 12C11.1046 12 12 11.1046 12 10C12 8.89543 11.1046 8 10 8Z",
            }),
        }),
    bi = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M11.5859 2C11.9837 2.00004 12.3652 2.15818 12.6465 2.43945L15.5605 5.35352C15.8418 5.63478 16 6.01629 16 6.41406V16.5C16 17.3284 15.3284 18 14.5 18H5.5C4.72334 18 4.08461 17.4097 4.00781 16.6533L4 16.5V3.5C4 2.67157 4.67157 2 5.5 2H11.5859ZM5.5 3C5.22386 3 5 3.22386 5 3.5V16.5C5 16.7761 5.22386 17 5.5 17H14.5C14.7761 17 15 16.7761 15 16.5V7H12.5C11.6716 7 11 6.32843 11 5.5V3H5.5ZM12.54 13.3037C12.6486 13.05 12.9425 12.9317 13.1963 13.04C13.45 13.1486 13.5683 13.4425 13.46 13.6963C13.1651 14.3853 12.589 15 11.7998 15C11.3132 14.9999 10.908 14.7663 10.5996 14.4258C10.2913 14.7661 9.88667 14.9999 9.40039 15C8.91365 15 8.50769 14.7665 8.19922 14.4258C7.89083 14.7661 7.48636 15 7 15C6.72386 15 6.5 14.7761 6.5 14.5C6.5 14.2239 6.72386 14 7 14C7.21245 14 7.51918 13.8199 7.74023 13.3037L7.77441 13.2373C7.86451 13.0913 8.02513 13 8.2002 13C8.40022 13.0001 8.58145 13.1198 8.66016 13.3037C8.88121 13.8198 9.18796 14 9.40039 14C9.61284 13.9998 9.9197 13.8197 10.1406 13.3037L10.1748 13.2373C10.2649 13.0915 10.4248 13.0001 10.5996 13C10.7997 13 10.9808 13.1198 11.0596 13.3037C11.2806 13.8198 11.5874 13.9999 11.7998 14C12.0122 14 12.319 13.8198 12.54 13.3037ZM12.54 9.30371C12.6486 9.05001 12.9425 8.93174 13.1963 9.04004C13.45 9.14863 13.5683 9.44253 13.46 9.69629C13.1651 10.3853 12.589 11 11.7998 11C11.3132 10.9999 10.908 10.7663 10.5996 10.4258C10.2913 10.7661 9.88667 10.9999 9.40039 11C8.91365 11 8.50769 10.7665 8.19922 10.4258C7.89083 10.7661 7.48636 11 7 11C6.72386 11 6.5 10.7761 6.5 10.5C6.5 10.2239 6.72386 10 7 10C7.21245 10 7.51918 9.8199 7.74023 9.30371L7.77441 9.2373C7.86451 9.09126 8.02513 9 8.2002 9C8.40022 9.00008 8.58145 9.11981 8.66016 9.30371C8.88121 9.8198 9.18796 10 9.40039 10C9.61284 9.99978 9.9197 9.81969 10.1406 9.30371L10.1748 9.2373C10.2649 9.09147 10.4248 9.00014 10.5996 9C10.7997 9 10.9808 9.11975 11.0596 9.30371C11.2806 9.8198 11.5874 9.99989 11.7998 10C12.0122 10 12.319 9.81985 12.54 9.30371ZM12 5.5C12 5.77614 12.2239 6 12.5 6H14.793L12 3.20703V5.5Z",
            }),
        }),
    ki = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M10.25 2C11.0283 2 11.6867 2.50842 11.9141 3.21094C12.1623 3.07581 12.4475 3 12.75 3C13.7165 3 14.5 3.7835 14.5 4.75V6.16992C14.7275 6.06176 14.9814 6 15.25 6C16.2165 6 17 6.7835 17 7.75V11.25C17 14.9779 13.9779 18 10.25 18C6.52208 18 3.5 14.9779 3.5 11.25V8C3.5 7.44772 3.94772 7 4.5 7H5C5.36464 7 5.70563 7.09906 6 7.26953V4.75C6 3.7835 6.7835 3 7.75 3C8.05224 3 8.33688 3.07606 8.58496 3.21094C8.81229 2.50827 9.47163 2 10.25 2ZM10.25 3C9.83579 3 9.5 3.33579 9.5 3.75V9.5C9.5 9.77614 9.27614 10 9 10C8.72386 10 8.5 9.77614 8.5 9.5V4.75C8.5 4.33579 8.16421 4 7.75 4C7.33579 4 7 4.33579 7 4.75V11.002C8.32553 11.0277 9.48461 11.8814 9.90918 13.1221L9.98535 13.3789L10 13.4785C10.0102 13.711 9.85565 13.9267 9.62109 13.9854C9.38677 14.0438 9.1493 13.9264 9.04883 13.7168L9.01465 13.6211L8.96289 13.4463C8.66901 12.5877 7.85929 12 6.93848 12H6.5C6.22386 12 6 11.7761 6 11.5V9C6 8.44772 5.55228 8 5 8H4.5V11.25C4.5 14.4256 7.07436 17 10.25 17C13.4256 17 16 14.4256 16 11.25V7.75C16 7.33579 15.6642 7 15.25 7C14.8358 7 14.5 7.33579 14.5 7.75V10.5C14.5 10.7761 14.2761 11 14 11C13.7239 11 13.5 10.7761 13.5 10.5V4.75C13.5 4.33579 13.1642 4 12.75 4C12.3358 4 12 4.33579 12 4.75V9.5C12 9.77614 11.7761 10 11.5 10C11.2239 10 11 9.77614 11 9.5V3.75C11 3.33579 10.6642 3 10.25 3Z",
            }),
        }),
    Ei = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M16.5 4C17.3284 4 18 4.67157 18 5.5V14.5C18 15.3284 17.3284 16 16.5 16H3.5C2.67157 16 2 15.3284 2 14.5V5.5C2 4.67157 2.67157 4 3.5 4H16.5ZM3.5 5C3.22386 5 3 5.22386 3 5.5V14.5C3 14.7761 3.22386 15 3.5 15H16.5C16.7761 15 17 14.7761 17 14.5V5.5C17 5.22386 16.7761 5 16.5 5H3.5ZM12.5 12C12.7761 12 13 12.2239 13 12.5C13 12.7761 12.7761 13 12.5 13H7.5C7.22386 13 7 12.7761 7 12.5C7 12.2239 7.22386 12 7.5 12H12.5ZM6.25 9.5C6.66421 9.5 7 9.83579 7 10.25C7 10.6642 6.66421 11 6.25 11C5.83579 11 5.5 10.6642 5.5 10.25C5.5 9.83579 5.83579 9.5 6.25 9.5ZM8.75 9.5C9.16421 9.5 9.5 9.83579 9.5 10.25C9.5 10.6642 9.16421 11 8.75 11C8.33579 11 8 10.6642 8 10.25C8 9.83579 8.33579 9.5 8.75 9.5ZM11.25 9.5C11.6642 9.5 12 9.83579 12 10.25C12 10.6642 11.6642 11 11.25 11C10.8358 11 10.5 10.6642 10.5 10.25C10.5 9.83579 10.8358 9.5 11.25 9.5ZM13.75 9.5C14.1642 9.5 14.5 9.83579 14.5 10.25C14.5 10.6642 14.1642 11 13.75 11C13.3358 11 13 10.6642 13 10.25C13 9.83579 13.3358 9.5 13.75 9.5ZM6.25 7C6.66421 7 7 7.33579 7 7.75C7 8.16421 6.66421 8.5 6.25 8.5C5.83579 8.5 5.5 8.16421 5.5 7.75C5.5 7.33579 5.83579 7 6.25 7ZM8.75 7C9.16421 7 9.5 7.33579 9.5 7.75C9.5 8.16421 9.16421 8.5 8.75 8.5C8.33579 8.5 8 8.16421 8 7.75C8 7.33579 8.33579 7 8.75 7ZM11.25 7C11.6642 7 12 7.33579 12 7.75C12 8.16421 11.6642 8.5 11.25 8.5C10.8358 8.5 10.5 8.16421 10.5 7.75C10.5 7.33579 10.8358 7 11.25 7ZM13.75 7C14.1642 7 14.5 7.33579 14.5 7.75C14.5 8.16421 14.1642 8.5 13.75 8.5C13.3358 8.5 13 8.16421 13 7.75C13 7.33579 13.3358 7 13.75 7Z",
            }),
        }),
    Si = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M8.5 2C12.0899 2 15 4.91015 15 8.5C15 10.1149 14.4094 11.5908 13.4346 12.7275L17.8535 17.1465L17.918 17.2246C18.0461 17.4187 18.0244 17.6827 17.8535 17.8535C17.6827 18.0244 17.4187 18.0461 17.2246 17.918L17.1465 17.8535L12.7275 13.4346C11.5908 14.4094 10.1149 15 8.5 15C4.91015 15 2 12.0899 2 8.5C2 4.91015 4.91015 2 8.5 2ZM8.5 3C5.46243 3 3 5.46243 3 8.5C3 11.5376 5.46243 14 8.5 14C11.5376 14 14 11.5376 14 8.5C14 5.46243 11.5376 3 8.5 3Z",
            }),
        }),
    Ai = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M10.5488 2C11.3503 2 12 2.64973 12 3.45117C12 3.64554 12.1376 3.85418 12.3848 3.95215C12.4534 3.97933 12.5215 4.00769 12.5889 4.03711L12.6797 4.06934C12.8914 4.12916 13.094 4.07583 13.2148 3.95508C13.7824 3.38817 14.7023 3.38882 15.2695 3.95605L16.0439 4.73047L16.1436 4.84082C16.6091 5.41137 16.5761 6.25346 16.0439 6.78516C15.9061 6.92297 15.8568 7.16748 15.9629 7.41016L16.0479 7.61523L16.0898 7.70215C16.1981 7.8943 16.3787 7.99998 16.5488 8C17.3503 8 18 8.64973 18 9.45117V10.5488C18 11.3503 17.3503 12 16.5488 12C16.3787 12 16.1982 12.1057 16.0898 12.2979L16.0479 12.3848C16.0206 12.4533 15.9923 12.5216 15.9629 12.5889C15.8567 12.8317 15.9059 13.0768 16.0439 13.2148C16.6113 13.7823 16.6113 14.7021 16.0439 15.2695L15.2695 16.0439C14.7021 16.6113 13.7823 16.6113 13.2148 16.0439C13.0941 15.9232 12.8914 15.87 12.6797 15.9297L12.5889 15.9629C12.5219 15.9921 12.4539 16.0198 12.3857 16.0469C12.1385 16.1449 12.0002 16.3534 12 16.5479C12 17.3496 11.3496 18 10.5479 18H9.45215C8.6504 18 8 17.3496 8 16.5479C7.99981 16.3776 7.89419 16.1969 7.70215 16.0889L7.61523 16.0469C7.5465 16.0197 7.4777 15.9914 7.41016 15.9619C7.16721 15.8561 6.92289 15.9062 6.78516 16.0439C6.25346 16.5761 5.41137 16.6091 4.84082 16.1436L4.73047 16.0439L3.95605 15.2695C3.38882 14.7023 3.38817 13.7824 3.95508 13.2148L4.00293 13.1582C4.089 13.0359 4.1206 12.8611 4.06934 12.6797L4.03711 12.5889C4.00769 12.5215 3.97933 12.4534 3.95215 12.3848C3.85418 12.1376 3.64554 12 3.45117 12C2.64973 12 2 11.3503 2 10.5488V9.45117C2 8.64973 2.64973 8 3.45117 8C3.64551 7.99998 3.85336 7.86221 3.95117 7.61523L4.03711 7.41016L4.06934 7.31934C4.12058 7.13786 4.0891 6.963 4.00293 6.84082L3.95508 6.78516C3.38796 6.21804 3.38796 5.29759 3.95508 4.73047L4.73047 3.95508L4.84082 3.85547C5.41121 3.39018 6.25345 3.42338 6.78516 3.95508C6.92296 4.09285 7.16718 4.14308 7.41016 4.03711C7.47794 4.00754 7.54625 3.97848 7.61523 3.95117C7.86221 3.85336 7.99998 3.64551 8 3.45117C8 2.64973 8.64973 2 9.45117 2H10.5488ZM9.45117 3C9.20202 3 9 3.20202 9 3.45117C8.99998 4.12476 8.54338 4.66017 7.9834 4.88184C7.92515 4.9049 7.86686 4.92814 7.80957 4.95312C7.25608 5.19449 6.55378 5.13969 6.07715 4.66309C5.92261 4.50854 5.68432 4.48855 5.50879 4.60449L5.43848 4.66309L4.66309 5.43848C4.48649 5.61507 4.48649 5.90055 4.66309 6.07715C5.10986 6.52395 5.18607 7.1692 4.99512 7.7041L4.95312 7.80957C4.92814 7.86686 4.9049 7.92515 4.88184 7.9834C4.66017 8.54338 4.12476 8.99998 3.45117 9C3.20202 9 3 9.20202 3 9.45117V10.5488C3 10.798 3.20202 11 3.45117 11C4.12476 11 4.65999 11.4569 4.88184 12.0166C4.90472 12.0743 4.92834 12.1317 4.95312 12.1885C5.1948 12.7421 5.13958 13.4449 4.66309 13.9219C4.48628 14.0988 4.48621 14.3856 4.66309 14.5625L5.4375 15.3369L5.50879 15.3955C5.6843 15.5112 5.92272 15.4914 6.07715 15.3369C6.55382 14.8599 7.25685 14.8044 7.81055 15.0459C7.86752 15.0707 7.92546 15.0943 7.9834 15.1172L8.08691 15.1631C8.59842 15.4071 8.99981 15.9165 9 16.5479C9 16.7973 9.20268 17 9.45215 17H10.5479C10.7973 17 11 16.7973 11 16.5479C11.0002 15.8742 11.4568 15.3391 12.0166 15.1172C12.0743 15.0943 12.1317 15.0707 12.1885 15.0459L12.2939 15.0039C12.8292 14.8126 13.4747 14.8898 13.9219 15.3369C14.0988 15.5138 14.3856 15.5138 14.5625 15.3369L15.3369 14.5625C15.5138 14.3856 15.5138 14.0988 15.3369 13.9219C14.86 13.445 14.8046 12.7424 15.0469 12.1885C15.0718 12.1315 15.0952 12.0735 15.1182 12.0156L15.1641 11.9121C15.4084 11.4013 15.9175 11 16.5488 11C16.798 11 17 10.798 17 10.5488V9.45117C17 9.20202 16.798 9 16.5488 9C15.9172 8.99998 15.4081 8.59825 15.1641 8.08691L15.1182 7.9834L15.0459 7.81055C14.8038 7.25675 14.8599 6.55381 15.3369 6.07715C15.4914 5.92272 15.5112 5.6843 15.3955 5.50879L15.3369 5.4375L14.5625 4.66309C14.4079 4.50844 14.169 4.48878 13.9932 4.60449L13.9219 4.66309C13.4449 5.13958 12.7421 5.1948 12.1885 4.95312L12.0166 4.88184C11.4569 4.65999 11 4.12476 11 3.45117C11 3.20202 10.798 3 10.5488 3H9.45117ZM10 7C11.6569 7 13 8.34315 13 10C13 11.6569 11.6569 13 10 13C8.34315 13 7 11.6569 7 10C7 8.34315 8.34315 7 10 7ZM10 8C8.89543 8 8 8.89543 8 10C8 11.1046 8.89543 12 10 12C11.1046 12 12 11.1046 12 10C12 8.89543 11.1046 8 10 8Z",
            }),
        }),
    Ti = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M12.6699 3C14.2586 3 15.6148 4.14871 15.876 5.71582L16.5566 9.79785C16.836 11.4741 15.5431 13 13.8438 13H11.6094L12.0117 15.0098C12.3211 16.5567 11.1381 17.9999 9.56055 18H9.32324C8.97898 18 8.66235 17.8236 8.48047 17.5391L8.41113 17.4102L6.89746 14.0459C6.59327 13.3699 6.02983 12.847 5.33789 12.5928L5.19824 12.5459L4.05859 12.1953C3.4294 12.0016 3.00013 11.42 3 10.7617V4.5C3 3.67157 3.67157 3 4.5 3H12.6699ZM4.5 4C4.22386 4 4 4.22386 4 4.5V10.7617C4.00013 10.981 4.14305 11.1746 4.35254 11.2393L5.49219 11.5898L5.68359 11.6543C6.62674 12.001 7.39486 12.7133 7.80957 13.6348L9.32324 17H9.56055C10.507 16.9999 11.2167 16.1341 11.0312 15.2061L10.5098 12.5977C10.4805 12.4509 10.5184 12.2984 10.6133 12.1826C10.7083 12.0669 10.8503 12 11 12H13.8438C14.9251 12 15.7481 11.0286 15.5703 9.96191L14.8896 5.87988C14.7087 4.79508 13.7697 4 12.6699 4H4.5Z",
            }),
        }),
    Li = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M9.56055 17C11.1381 16.9999 12.3211 15.5567 12.0117 14.0098L11.6094 12H13.8438C15.5431 12 16.836 10.4741 16.5566 8.79785L15.876 4.71582C15.6148 3.14873 14.2586 2 12.6699 2H4.5C3.67157 2 3 2.67157 3 3.5V9.76172C3.00013 10.42 3.4294 11.0016 4.05859 11.1953L5.19824 11.5459L5.33789 11.5928C6.02983 11.847 6.59327 12.3699 6.89746 13.0459L8.41113 16.4102L8.48047 16.5391C8.66235 16.8236 8.97898 17 9.32324 17H9.56055Z",
            }),
        }),
    Mi = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M9.56055 2C11.1381 2.00009 12.3211 3.44332 12.0117 4.99023L11.6094 7H13.8438C15.5431 7 16.836 8.52594 16.5566 10.2021L15.876 14.2842C15.6148 15.8513 14.2586 17 12.6699 17H4.5C3.67157 17 3 16.3284 3 15.5V9.23828C3.00013 8.57996 3.4294 7.99838 4.05859 7.80469L5.19824 7.4541L5.33789 7.40723C6.02983 7.15302 6.59327 6.63008 6.89746 5.9541L8.41113 2.58984L8.48047 2.46094C8.66235 2.17643 8.97898 2.00002 9.32324 2H9.56055ZM7.80957 6.36523C7.39486 7.2867 6.62674 7.99897 5.68359 8.3457L5.49219 8.41016L4.35254 8.76074C4.14305 8.82539 4.00013 9.01904 4 9.23828V15.5C4 15.7761 4.22386 16 4.5 16H12.6699C13.7697 16 14.7087 15.2049 14.8896 14.1201L15.5703 10.0381C15.7481 8.97141 14.9251 8 13.8438 8H11C10.8503 8 10.7083 7.9331 10.6133 7.81738C10.5184 7.70164 10.4805 7.54912 10.5098 7.40234L11.0312 4.79395C11.2167 3.86589 10.507 3.00009 9.56055 3H9.32324L7.80957 6.36523Z",
            }),
        }),
    Pi = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M9.56055 2C11.1381 2.00009 12.3211 3.44332 12.0117 4.99023L11.6094 7H13.8438C15.5431 7 16.836 8.52594 16.5566 10.2021L15.876 14.2842C15.6148 15.8513 14.2586 17 12.6699 17H4.5C3.67157 17 3 16.3284 3 15.5V9.23828C3.00013 8.57996 3.4294 7.99838 4.05859 7.80469L5.19824 7.4541L5.33789 7.40723C6.02983 7.15302 6.59327 6.63008 6.89746 5.9541L8.41113 2.58984L8.48047 2.46094C8.66235 2.17643 8.97898 2.00002 9.32324 2H9.56055Z",
            }),
        }),
    ji = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M8.70798 3.70804C9.25201 2.78523 10.5372 2.72763 11.1738 3.53519L11.292 3.70804L17.792 14.7383C18.3812 15.7382 17.6606 17 16.5 17H3.49995C2.33937 17 1.61881 15.7382 2.20795 14.7383L8.70798 3.70804ZM10.3916 4.15824C10.1794 3.88887 9.75069 3.90817 9.56931 4.21586L3.06928 15.2461C2.87297 15.5794 3.11314 16 3.49995 16H16.5C16.8869 16 17.1271 15.5794 16.9307 15.2461L10.4306 4.21586L10.3916 4.15824ZM9.99998 13C10.4142 13 10.75 13.3358 10.75 13.75C10.7499 14.1642 10.4142 14.5 9.99998 14.5C9.58582 14.5 9.25002 14.1642 9.24998 13.75C9.24998 13.3358 9.58579 13.0001 9.99998 13ZM9.99998 8.00003C10.2761 8.00003 10.5 8.22389 10.5 8.50003V11.5C10.4999 11.7761 10.2761 12 9.99998 12C9.72389 12 9.50003 11.7761 9.49998 11.5V8.50003C9.49998 8.22391 9.72386 8.00007 9.99998 8.00003Z",
            }),
        });
function Ni({ result: e, toolInfo: t, lastScreenshot: n, debugMode: o = !1 }) {
    const [i, s] = r.useState(!1),
        l =
            Array.isArray(e.content) &&
            e.content.some((e) => "image" === e.type),
        c = t
            ? (() => {
                  if ("computer" === t?.name) {
                      const n = t.input?.action,
                          r =
                              "string" == typeof e.content
                                  ? (() => {
                                        try {
                                            return JSON.parse(e.content);
                                        } catch {
                                            return null;
                                        }
                                    })()
                                  : null,
                          o = r?.action || n;
                      switch (o) {
                          case "screenshot":
                              return {
                                  icon: a.jsx(xi, {
                                      className: "w-4 h-4 text-text-300",
                                  }),
                                  text: "Take screenshot",
                              };
                          case "left_click":
                              return {
                                  icon: a.jsx("span", {
                                      className: "text-text-300",
                                      children: a.jsx(Jo, {
                                          size: 16,
                                          color: "currentColor",
                                      }),
                                  }),
                                  text: "Click",
                              };
                          case "right_click":
                              return {
                                  icon: a.jsx("span", {
                                      className: "text-text-300",
                                      children: a.jsx(ri, {
                                          size: 16,
                                          color: "currentColor",
                                      }),
                                  }),
                                  text: "Right-click",
                              };
                          case "double_click":
                              return {
                                  icon: a.jsx("span", {
                                      className: "text-text-300",
                                      children: a.jsx(ti, {
                                          size: 16,
                                          color: "currentColor",
                                      }),
                                  }),
                                  text: "Double-click",
                              };
                          case "triple_click":
                              return {
                                  icon: a.jsx("span", {
                                      className: "text-text-300",
                                      children: a.jsx(ti, {
                                          size: 16,
                                          color: "currentColor",
                                      }),
                                  }),
                                  text: "Triple-click",
                              };
                          case "type": {
                              const e = t.input?.text;
                              return {
                                  icon: a.jsx("span", {
                                      className: "text-text-300",
                                      children: a.jsx(ci, {
                                          weight: "light",
                                          size: 16,
                                          color: "currentColor",
                                      }),
                                  }),
                                  text: e
                                      ? `Type: "${e.substring(0, 30)}${
                                            e.length > 30 ? "..." : ""
                                        }"`
                                      : "Type text",
                              };
                          }
                          case "wait": {
                              const e = t.input?.duration;
                              return {
                                  icon: a.jsx(Ci, {
                                      className: "w-4 h-4 text-text-300",
                                  }),
                                  text: `Wait ${e} second${1 === e ? "" : "s"}`,
                              };
                          }
                          case "scroll": {
                              const e = t.input?.scroll_direction || "down";
                              return {
                                  icon:
                                      "up" === e
                                          ? a.jsx(yi, {
                                                className:
                                                    "w-4 h-4 text-text-300",
                                            })
                                          : "down" === e
                                          ? a.jsx(fi, {
                                                className:
                                                    "w-4 h-4 text-text-300",
                                            })
                                          : "left" === e
                                          ? a.jsx(mi, {
                                                className:
                                                    "w-4 h-4 text-text-300",
                                            })
                                          : "right" === e
                                          ? a.jsx(gi, {
                                                className:
                                                    "w-4 h-4 text-text-300",
                                            })
                                          : a.jsx(fi, {
                                                className:
                                                    "w-4 h-4 text-text-300",
                                            }),
                                  text: `Scroll ${e}`,
                              };
                          }
                          case "key": {
                              const e = t.input?.text;
                              return {
                                  icon: a.jsx(Ei, {
                                      className: "w-4 h-4 text-text-300",
                                  }),
                                  text: e ? `Press key: ${e}` : "Press key",
                              };
                          }
                          case "left_click_drag":
                              return {
                                  icon: a.jsx("span", {
                                      className: "text-text-300",
                                      children: a.jsx(ai, {
                                          size: 16,
                                          color: "currentColor",
                                      }),
                                  }),
                                  text: "Drag",
                              };
                          default:
                              return {
                                  icon: a.jsx(Ai, {
                                      className: "w-4 h-4 text-text-300",
                                  }),
                                  text: `Computer action: ${
                                      o || n || "Unknown"
                                  }`,
                              };
                      }
                  }
                  if ("screenshot" === t?.name)
                      return {
                          icon: a.jsx(xi, {
                              className: "w-4 h-4 text-text-300",
                          }),
                          text: "Take screenshot",
                      };
                  if ("read_page" === t?.name) {
                      const e = t.input?.filter ? ` (${t.input.filter})` : "";
                      return {
                          icon: a.jsx(bi, {
                              className: "w-4 h-4 text-text-300",
                          }),
                          text: `Read page${e}`,
                      };
                  }
                  if ("find" === t?.name) {
                      const e = t.input?.query;
                      return {
                          icon: a.jsx(Si, {
                              className: "w-4 h-4 text-text-300",
                          }),
                          text: e
                              ? `Find: "${e.substring(0, 30)}${
                                    e.length > 30 ? "..." : ""
                                }"`
                              : "Find element",
                      };
                  }
                  if ("get_page_text" === t?.name)
                      return {
                          icon: a.jsx("span", {
                              className: "text-text-300",
                              children: a.jsx(Go, {
                                  size: 16,
                                  color: "currentColor",
                              }),
                          }),
                          text: "Extract page text",
                      };
                  if ("scroll" === t?.name) {
                      const e = t.input;
                      let n = "Scroll",
                          r = a.jsx(fi, { className: "w-4 h-4 text-text-300" });
                      return (
                          e?.direction
                              ? ((n = `Scroll ${e.direction}`),
                                (r =
                                    "up" === e.direction
                                        ? a.jsx(yi, {
                                              className:
                                                  "w-4 h-4 text-text-300",
                                          })
                                        : "down" === e.direction
                                        ? a.jsx(fi, {
                                              className:
                                                  "w-4 h-4 text-text-300",
                                          })
                                        : "left" === e.direction
                                        ? a.jsx(mi, {
                                              className:
                                                  "w-4 h-4 text-text-300",
                                          })
                                        : "right" === e.direction
                                        ? a.jsx(gi, {
                                              className:
                                                  "w-4 h-4 text-text-300",
                                          })
                                        : a.jsx(fi, {
                                              className:
                                                  "w-4 h-4 text-text-300",
                                          })))
                              : e?.text
                              ? (n = `Scroll to: "${e.text.substring(0, 20)}${
                                    e.text.length > 20 ? "..." : ""
                                }"`)
                              : e?.ref && (n = "Scroll to element"),
                          { icon: r, text: n }
                      );
                  }
                  if ("key" === t?.name) {
                      const e =
                              t.input?.key
                                  ?.split(" ")
                                  .filter((e) => e.length > 0) || [],
                          n = e.length;
                      let r = "";
                      if (1 === n) r = `Press ${e[0]} key`;
                      else if (n <= 5) r = `Press keys: ${e.join(", ")}`;
                      else {
                          const t = {};
                          e.forEach((e) => {
                              t[e] = (t[e] || 0) + 1;
                          });
                          r = `Press ${n} keys: ${Object.entries(t)
                              .map(([e, t]) => (t > 1 ? `${e} ×${t}` : e))
                              .join(", ")}`;
                      }
                      return {
                          icon: a.jsx(Ei, {
                              className: "w-4 h-4 text-text-300",
                          }),
                          text: r,
                      };
                  }
                  if ("wait" === t?.name)
                      return {
                          icon: a.jsx(Ci, {
                              className: "w-4 h-4 text-text-300",
                          }),
                          text: `Wait ${t.input?.duration} second${
                              1 === t.input?.duration ? "" : "s"
                          }`,
                      };
                  if ("type" === t?.name)
                      return {
                          icon: a.jsx(ci, {
                              weight: "light",
                              size: 16,
                              className: "text-text-300",
                          }),
                          text: `Type: "${t.input?.text?.substring(0, 30)}${
                              t.input?.text?.length > 30 ? "..." : ""
                          }"`,
                      };
                  if ("form_input" === t?.name) {
                      const e = t.input?.value;
                      let n = "Set form value";
                      return (
                          e &&
                              (n = `Set input to "${String(e).substring(
                                  0,
                                  20
                              )}${String(e).length > 20 ? "..." : ""}"`),
                          {
                              icon: a.jsx("span", {
                                  className: "text-text-300",
                                  children: a.jsx(di, {
                                      size: 16,
                                      color: "currentColor",
                                  }),
                              }),
                              text: n,
                          }
                      );
                  }
                  if ("click" === t?.name) {
                      let e = "";
                      return (
                          (e = t.input?.text
                              ? `Click: "${t.input.text.substring(0, 30)}${
                                    t.input.text.length > 30 ? "..." : ""
                                }"`
                              : "Click"),
                          {
                              icon: a.jsx(Jo, {
                                  size: 16,
                                  className: "text-text-300",
                              }),
                              text: e,
                          }
                      );
                  }
                  return "navigate" === t?.name
                      ? {
                            icon: a.jsx("span", {
                                className: "text-text-300",
                                children: a.jsx(ii, {
                                    size: 16,
                                    color: "currentColor",
                                }),
                            }),
                            text: `Navigate to ${t.input?.url?.substring(
                                0,
                                30
                            )}${t.input?.url?.length > 30 ? "..." : ""}`,
                        }
                      : {
                            icon: a.jsx(Ai, {
                                className: "w-4 h-4 text-text-300",
                            }),
                            text: `Tool: ${t?.name || "Unknown"}`,
                        };
              })()
            : null,
        u =
            !c && e && l && !e.is_error
                ? {
                      icon: a.jsx(xi, { className: "w-4 h-4 text-text-300" }),
                      text: "Screenshot",
                  }
                : null,
        d = c || u;
    return a.jsxs("div", {
        className:
            "overflow-hidden border-[0.5px] border-border-200 rounded-[14px]",
        children: [
            a.jsxs("button", {
                onClick: o ? () => s(!i) : void 0,
                className:
                    "w-full px-4 py-2 bg-bg-100 transition-colors flex items-center justify-between text-left " +
                    (o ? "hover:bg-bg-200 cursor-pointer" : "cursor-default"),
                disabled: !o,
                children: [
                    a.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [
                            d?.icon,
                            a.jsx("span", {
                                className: "font-base text-text-300",
                                children: d?.text || "Tool Result",
                            }),
                        ],
                    }),
                    o &&
                        a.jsx(vi, {
                            className:
                                "w-4 h-4 text-text-400 transition-transform " +
                                (i ? "rotate-90" : ""),
                        }),
                ],
            }),
            o &&
                i &&
                a.jsx("div", {
                    className:
                        "p-4 bg-bg-000 border-t-[0.5px] border-border-200",
                    children: a.jsxs("div", {
                        className: "space-y-3",
                        children: [
                            t &&
                                a.jsxs("div", {
                                    className: "space-y-2",
                                    children: [
                                        a.jsxs("div", {
                                            children: [
                                                a.jsx("span", {
                                                    className:
                                                        "font-caption font-medium text-text-400",
                                                    children: "Tool ID:",
                                                }),
                                                a.jsx("code", {
                                                    className:
                                                        "ml-2 font-code-sm bg-bg-200 px-2 py-1 rounded text-text-200",
                                                    children:
                                                        t.id || e.tool_use_id,
                                                }),
                                            ],
                                        }),
                                        a.jsxs("div", {
                                            children: [
                                                a.jsx("span", {
                                                    className:
                                                        "font-caption font-medium text-text-400",
                                                    children: "Parameters:",
                                                }),
                                                a.jsx("pre", {
                                                    className:
                                                        "mt-1 font-code-sm bg-bg-200 p-2 rounded overflow-x-auto text-text-200",
                                                    children: JSON.stringify(
                                                        t.input,
                                                        null,
                                                        2
                                                    ),
                                                }),
                                            ],
                                        }),
                                    ],
                                }),
                            (("click" === t?.name && t?.input?.coordinate) ||
                                ("computer" === t?.name &&
                                    [
                                        "left_click",
                                        "right_click",
                                        "double_click",
                                        "triple_click",
                                    ].includes(t?.input?.action) &&
                                    t?.input?.coordinate)) &&
                                n &&
                                a.jsxs("div", {
                                    children: [
                                        a.jsx("span", {
                                            className:
                                                "font-caption font-medium text-text-400",
                                            children: "Click Location:",
                                        }),
                                        a.jsx(Oo, {
                                            screenshot: n,
                                            coordinates:
                                                (t.name, t.input.coordinate),
                                            className: "mt-1",
                                        }),
                                    ],
                                }),
                            "computer" === t?.name &&
                                "left_click_drag" === t?.input?.action &&
                                t?.input?.start_coordinate &&
                                t?.input?.coordinate &&
                                n &&
                                a.jsxs("div", {
                                    children: [
                                        a.jsx("span", {
                                            className:
                                                "font-caption font-medium text-text-400",
                                            children: "Drag Path:",
                                        }),
                                        a.jsx(Ho, {
                                            screenshot: n,
                                            startCoordinate:
                                                t.input.start_coordinate,
                                            endCoordinate: t.input.coordinate,
                                            className: "mt-1",
                                        }),
                                    ],
                                }),
                            a.jsxs("div", {
                                children: [
                                    a.jsx("span", {
                                        className:
                                            "font-caption font-medium text-text-400",
                                        children: "Result:",
                                    }),
                                    l
                                        ? a.jsx("div", {
                                              className: "mt-2",
                                              children: e.content.map(
                                                  (e, t) => {
                                                      if (
                                                          "image" === e.type &&
                                                          "base64" ===
                                                              e.source?.type
                                                      ) {
                                                          const n = `data:${e.source.media_type};base64,${e.source.data}`;
                                                          return a.jsx(
                                                              _o,
                                                              {
                                                                  dataUrl: n,
                                                                  className:
                                                                      "mt-2",
                                                              },
                                                              t
                                                          );
                                                      }
                                                      return "text" === e.type
                                                          ? a.jsx(
                                                                "pre",
                                                                {
                                                                    className:
                                                                        "mt-1 font-code-sm bg-bg-200 p-2 rounded overflow-x-auto text-text-200",
                                                                    children:
                                                                        e.text,
                                                                },
                                                                t
                                                            )
                                                          : null;
                                                  }
                                              ),
                                          })
                                        : a.jsx("pre", {
                                              className:
                                                  "mt-1 text-xs bg-bg-200 p-2 rounded overflow-x-auto text-text-200",
                                              children:
                                                  "string" == typeof e.content
                                                      ? e.content
                                                      : JSON.stringify(
                                                            e.content,
                                                            null,
                                                            2
                                                        ),
                                          }),
                                ],
                            }),
                        ],
                    }),
                }),
        ],
    });
}
/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ii = u("chevron-down", [
        ["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }],
    ]),
    Di = u("chevron-up", [["path", { d: "m18 15-6-6-6 6", key: "153udz" }]]),
    Vi = r.createContext({});
const Ri = "undefined" != typeof window,
    _i = Ri ? r.useLayoutEffect : r.useEffect,
    Oi = r.createContext(null);
function Hi(e, t) {
    -1 === e.indexOf(t) && e.push(t);
}
function Fi(e, t) {
    const n = e.indexOf(t);
    n > -1 && e.splice(n, 1);
}
const Bi = (e, t, n) => (n > t ? t : n < e ? e : n);
const Ui = {},
    Zi = (e) => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(e);
function zi(e) {
    return "object" == typeof e && null !== e;
}
const $i = (e) => /^0[^.\s]+$/u.test(e);
function Wi(e) {
    let t;
    return () => (void 0 === t && (t = e()), t);
}
const qi = (e) => e,
    Ki = (e, t) => (n) => t(e(n)),
    Yi = (...e) => e.reduce(Ki),
    Xi = (e, t, n) => {
        const r = t - e;
        return 0 === r ? 1 : (n - e) / r;
    };
class Gi {
    constructor() {
        this.subscriptions = [];
    }
    add(e) {
        return Hi(this.subscriptions, e), () => Fi(this.subscriptions, e);
    }
    notify(e, t, n) {
        const r = this.subscriptions.length;
        if (r)
            if (1 === r) this.subscriptions[0](e, t, n);
            else
                for (let o = 0; o < r; o++) {
                    const r = this.subscriptions[o];
                    r && r(e, t, n);
                }
    }
    getSize() {
        return this.subscriptions.length;
    }
    clear() {
        this.subscriptions.length = 0;
    }
}
const Qi = (e) => 1e3 * e,
    Ji = (e) => e / 1e3;
function es(e, t) {
    return t ? e * (1e3 / t) : 0;
}
const ts = (e, t, n) =>
    (((1 - 3 * n + 3 * t) * e + (3 * n - 6 * t)) * e + 3 * t) * e;
function ns(e, t, n, r) {
    if (e === t && n === r) return qi;
    const o = (t) =>
        (function (e, t, n, r, o) {
            let i,
                s,
                a = 0;
            do {
                (s = t + (n - t) / 2),
                    (i = ts(s, r, o) - e),
                    i > 0 ? (n = s) : (t = s);
            } while (Math.abs(i) > 1e-7 && ++a < 12);
            return s;
        })(t, 0, 1, e, n);
    return (e) => (0 === e || 1 === e ? e : ts(o(e), t, r));
}
const rs = (e) => (t) => t <= 0.5 ? e(2 * t) / 2 : (2 - e(2 * (1 - t))) / 2,
    os = (e) => (t) => 1 - e(1 - t),
    is = ns(0.33, 1.53, 0.69, 0.99),
    ss = os(is),
    as = rs(ss),
    ls = (e) =>
        (e *= 2) < 1 ? 0.5 * ss(e) : 0.5 * (2 - Math.pow(2, -10 * (e - 1))),
    cs = (e) => 1 - Math.sin(Math.acos(e)),
    us = os(cs),
    ds = rs(cs),
    hs = ns(0.42, 0, 1, 1),
    ps = ns(0, 0, 0.58, 1),
    fs = ns(0.42, 0, 0.58, 1),
    ms = (e) => Array.isArray(e) && "number" == typeof e[0],
    gs = {
        linear: qi,
        easeIn: hs,
        easeInOut: fs,
        easeOut: ps,
        circIn: cs,
        circInOut: ds,
        circOut: us,
        backIn: ss,
        backInOut: as,
        backOut: is,
        anticipate: ls,
    },
    ys = (e) => {
        if (ms(e)) {
            e.length;
            const [t, n, r, o] = e;
            return ns(t, n, r, o);
        }
        return "string" == typeof e ? gs[e] : e;
    },
    xs = [
        "setup",
        "read",
        "resolveKeyframes",
        "preUpdate",
        "update",
        "preRender",
        "render",
        "postRender",
    ];
function vs(e, t) {
    let n = !1,
        r = !0;
    const o = { delta: 0, timestamp: 0, isProcessing: !1 },
        i = () => (n = !0),
        s = xs.reduce(
            (e, t) => (
                (e[t] = (function (e) {
                    let t = new Set(),
                        n = new Set(),
                        r = !1,
                        o = !1;
                    const i = new WeakSet();
                    let s = { delta: 0, timestamp: 0, isProcessing: !1 };
                    function a(t) {
                        i.has(t) && (l.schedule(t), e()), t(s);
                    }
                    const l = {
                        schedule: (e, o = !1, s = !1) => {
                            const a = s && r ? t : n;
                            return o && i.add(e), a.has(e) || a.add(e), e;
                        },
                        cancel: (e) => {
                            n.delete(e), i.delete(e);
                        },
                        process: (e) => {
                            (s = e),
                                r
                                    ? (o = !0)
                                    : ((r = !0),
                                      ([t, n] = [n, t]),
                                      t.forEach(a),
                                      t.clear(),
                                      (r = !1),
                                      o && ((o = !1), l.process(e)));
                        },
                    };
                    return l;
                })(i)),
                e
            ),
            {}
        ),
        {
            setup: a,
            read: l,
            resolveKeyframes: c,
            preUpdate: u,
            update: d,
            preRender: h,
            render: p,
            postRender: f,
        } = s,
        m = () => {
            const i = Ui.useManualTiming ? o.timestamp : performance.now();
            (n = !1),
                Ui.useManualTiming ||
                    (o.delta = r
                        ? 1e3 / 60
                        : Math.max(Math.min(i - o.timestamp, 40), 1)),
                (o.timestamp = i),
                (o.isProcessing = !0),
                a.process(o),
                l.process(o),
                c.process(o),
                u.process(o),
                d.process(o),
                h.process(o),
                p.process(o),
                f.process(o),
                (o.isProcessing = !1),
                n && t && ((r = !1), e(m));
        };
    return {
        schedule: xs.reduce((t, i) => {
            const a = s[i];
            return (
                (t[i] = (t, i = !1, s = !1) => (
                    n || ((n = !0), (r = !0), o.isProcessing || e(m)),
                    a.schedule(t, i, s)
                )),
                t
            );
        }, {}),
        cancel: (e) => {
            for (let t = 0; t < xs.length; t++) s[xs[t]].cancel(e);
        },
        state: o,
        steps: s,
    };
}
const {
    schedule: Cs,
    cancel: ws,
    state: bs,
    steps: ks,
} = vs(
    "undefined" != typeof requestAnimationFrame ? requestAnimationFrame : qi,
    !0
);
let Es;
function Ss() {
    Es = void 0;
}
const As = {
        now: () => (
            void 0 === Es &&
                As.set(
                    bs.isProcessing || Ui.useManualTiming
                        ? bs.timestamp
                        : performance.now()
                ),
            Es
        ),
        set: (e) => {
            (Es = e), queueMicrotask(Ss);
        },
    },
    Ts = (e) => (t) => "string" == typeof t && t.startsWith(e),
    Ls = Ts("--"),
    Ms = Ts("var(--"),
    Ps = (e) => !!Ms(e) && js.test(e.split("/*")[0].trim()),
    js =
        /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu,
    Ns = {
        test: (e) => "number" == typeof e,
        parse: parseFloat,
        transform: (e) => e,
    },
    Is = { ...Ns, transform: (e) => Bi(0, 1, e) },
    Ds = { ...Ns, default: 1 },
    Vs = (e) => Math.round(1e5 * e) / 1e5,
    Rs = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;
const _s =
        /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
    Os = (e, t) => (n) =>
        Boolean(
            ("string" == typeof n && _s.test(n) && n.startsWith(e)) ||
                (t &&
                    !(function (e) {
                        return null == e;
                    })(n) &&
                    Object.prototype.hasOwnProperty.call(n, t))
        ),
    Hs = (e, t, n) => (r) => {
        if ("string" != typeof r) return r;
        const [o, i, s, a] = r.match(Rs);
        return {
            [e]: parseFloat(o),
            [t]: parseFloat(i),
            [n]: parseFloat(s),
            alpha: void 0 !== a ? parseFloat(a) : 1,
        };
    },
    Fs = { ...Ns, transform: (e) => Math.round(((e) => Bi(0, 255, e))(e)) },
    Bs = {
        test: Os("rgb", "red"),
        parse: Hs("red", "green", "blue"),
        transform: ({ red: e, green: t, blue: n, alpha: r = 1 }) =>
            "rgba(" +
            Fs.transform(e) +
            ", " +
            Fs.transform(t) +
            ", " +
            Fs.transform(n) +
            ", " +
            Vs(Is.transform(r)) +
            ")",
    };
const Us = {
        test: Os("#"),
        parse: function (e) {
            let t = "",
                n = "",
                r = "",
                o = "";
            return (
                e.length > 5
                    ? ((t = e.substring(1, 3)),
                      (n = e.substring(3, 5)),
                      (r = e.substring(5, 7)),
                      (o = e.substring(7, 9)))
                    : ((t = e.substring(1, 2)),
                      (n = e.substring(2, 3)),
                      (r = e.substring(3, 4)),
                      (o = e.substring(4, 5)),
                      (t += t),
                      (n += n),
                      (r += r),
                      (o += o)),
                {
                    red: parseInt(t, 16),
                    green: parseInt(n, 16),
                    blue: parseInt(r, 16),
                    alpha: o ? parseInt(o, 16) / 255 : 1,
                }
            );
        },
        transform: Bs.transform,
    },
    Zs = (e) => ({
        test: (t) =>
            "string" == typeof t && t.endsWith(e) && 1 === t.split(" ").length,
        parse: parseFloat,
        transform: (t) => `${t}${e}`,
    }),
    zs = Zs("deg"),
    $s = Zs("%"),
    Ws = Zs("px"),
    qs = Zs("vh"),
    Ks = Zs("vw"),
    Ys = (() => ({
        ...$s,
        parse: (e) => $s.parse(e) / 100,
        transform: (e) => $s.transform(100 * e),
    }))(),
    Xs = {
        test: Os("hsl", "hue"),
        parse: Hs("hue", "saturation", "lightness"),
        transform: ({ hue: e, saturation: t, lightness: n, alpha: r = 1 }) =>
            "hsla(" +
            Math.round(e) +
            ", " +
            $s.transform(Vs(t)) +
            ", " +
            $s.transform(Vs(n)) +
            ", " +
            Vs(Is.transform(r)) +
            ")",
    },
    Gs = {
        test: (e) => Bs.test(e) || Us.test(e) || Xs.test(e),
        parse: (e) =>
            Bs.test(e) ? Bs.parse(e) : Xs.test(e) ? Xs.parse(e) : Us.parse(e),
        transform: (e) =>
            "string" == typeof e
                ? e
                : e.hasOwnProperty("red")
                ? Bs.transform(e)
                : Xs.transform(e),
        getAnimatableNone: (e) => {
            const t = Gs.parse(e);
            return (t.alpha = 0), Gs.transform(t);
        },
    },
    Qs =
        /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
const Js = "number",
    ea = "color",
    ta =
        /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;
function na(e) {
    const t = e.toString(),
        n = [],
        r = { color: [], number: [], var: [] },
        o = [];
    let i = 0;
    const s = t
        .replace(
            ta,
            (e) => (
                Gs.test(e)
                    ? (r.color.push(i), o.push(ea), n.push(Gs.parse(e)))
                    : e.startsWith("var(")
                    ? (r.var.push(i), o.push("var"), n.push(e))
                    : (r.number.push(i), o.push(Js), n.push(parseFloat(e))),
                ++i,
                "${}"
            )
        )
        .split("${}");
    return { values: n, split: s, indexes: r, types: o };
}
function ra(e) {
    return na(e).values;
}
function oa(e) {
    const { split: t, types: n } = na(e),
        r = t.length;
    return (e) => {
        let o = "";
        for (let i = 0; i < r; i++)
            if (((o += t[i]), void 0 !== e[i])) {
                const t = n[i];
                o += t === Js ? Vs(e[i]) : t === ea ? Gs.transform(e[i]) : e[i];
            }
        return o;
    };
}
const ia = (e) =>
    "number" == typeof e ? 0 : Gs.test(e) ? Gs.getAnimatableNone(e) : e;
const sa = {
    test: function (e) {
        return (
            isNaN(e) &&
            "string" == typeof e &&
            (e.match(Rs)?.length || 0) + (e.match(Qs)?.length || 0) > 0
        );
    },
    parse: ra,
    createTransformer: oa,
    getAnimatableNone: function (e) {
        const t = ra(e);
        return oa(e)(t.map(ia));
    },
};
function aa(e, t, n) {
    return (
        n < 0 && (n += 1),
        n > 1 && (n -= 1),
        n < 1 / 6
            ? e + 6 * (t - e) * n
            : n < 0.5
            ? t
            : n < 2 / 3
            ? e + (t - e) * (2 / 3 - n) * 6
            : e
    );
}
function la(e, t) {
    return (n) => (n > 0 ? t : e);
}
const ca = (e, t, n) => e + (t - e) * n,
    ua = (e, t, n) => {
        const r = e * e,
            o = n * (t * t - r) + r;
        return o < 0 ? 0 : Math.sqrt(o);
    },
    da = [Us, Bs, Xs];
function ha(e) {
    const t = ((n = e), da.find((e) => e.test(n)));
    var n;
    if (!Boolean(t)) return !1;
    let r = t.parse(e);
    return (
        t === Xs &&
            (r = (function ({ hue: e, saturation: t, lightness: n, alpha: r }) {
                (e /= 360), (n /= 100);
                let o = 0,
                    i = 0,
                    s = 0;
                if ((t /= 100)) {
                    const r = n < 0.5 ? n * (1 + t) : n + t - n * t,
                        a = 2 * n - r;
                    (o = aa(a, r, e + 1 / 3)),
                        (i = aa(a, r, e)),
                        (s = aa(a, r, e - 1 / 3));
                } else o = i = s = n;
                return {
                    red: Math.round(255 * o),
                    green: Math.round(255 * i),
                    blue: Math.round(255 * s),
                    alpha: r,
                };
            })(r)),
        r
    );
}
const pa = (e, t) => {
        const n = ha(e),
            r = ha(t);
        if (!n || !r) return la(e, t);
        const o = { ...n };
        return (e) => (
            (o.red = ua(n.red, r.red, e)),
            (o.green = ua(n.green, r.green, e)),
            (o.blue = ua(n.blue, r.blue, e)),
            (o.alpha = ca(n.alpha, r.alpha, e)),
            Bs.transform(o)
        );
    },
    fa = new Set(["none", "hidden"]);
function ma(e, t) {
    return (n) => ca(e, t, n);
}
function ga(e) {
    return "number" == typeof e
        ? ma
        : "string" == typeof e
        ? Ps(e)
            ? la
            : Gs.test(e)
            ? pa
            : va
        : Array.isArray(e)
        ? ya
        : "object" == typeof e
        ? Gs.test(e)
            ? pa
            : xa
        : la;
}
function ya(e, t) {
    const n = [...e],
        r = n.length,
        o = e.map((e, n) => ga(e)(e, t[n]));
    return (e) => {
        for (let t = 0; t < r; t++) n[t] = o[t](e);
        return n;
    };
}
function xa(e, t) {
    const n = { ...e, ...t },
        r = {};
    for (const o in n)
        void 0 !== e[o] && void 0 !== t[o] && (r[o] = ga(e[o])(e[o], t[o]));
    return (e) => {
        for (const t in r) n[t] = r[t](e);
        return n;
    };
}
const va = (e, t) => {
    const n = sa.createTransformer(t),
        r = na(e),
        o = na(t);
    return r.indexes.var.length === o.indexes.var.length &&
        r.indexes.color.length === o.indexes.color.length &&
        r.indexes.number.length >= o.indexes.number.length
        ? (fa.has(e) && !o.values.length) || (fa.has(t) && !r.values.length)
            ? (function (e, t) {
                  return fa.has(e)
                      ? (n) => (n <= 0 ? e : t)
                      : (n) => (n >= 1 ? t : e);
              })(e, t)
            : Yi(
                  ya(
                      (function (e, t) {
                          const n = [],
                              r = { color: 0, var: 0, number: 0 };
                          for (let o = 0; o < t.values.length; o++) {
                              const i = t.types[o],
                                  s = e.indexes[i][r[i]],
                                  a = e.values[s] ?? 0;
                              (n[o] = a), r[i]++;
                          }
                          return n;
                      })(r, o),
                      o.values
                  ),
                  n
              )
        : la(e, t);
};
function Ca(e, t, n) {
    if ("number" == typeof e && "number" == typeof t && "number" == typeof n)
        return ca(e, t, n);
    return ga(e)(e, t);
}
const wa = (e) => {
        const t = ({ timestamp: t }) => e(t);
        return {
            start: (e = !0) => Cs.update(t, e),
            stop: () => ws(t),
            now: () => (bs.isProcessing ? bs.timestamp : As.now()),
        };
    },
    ba = (e, t, n = 10) => {
        let r = "";
        const o = Math.max(Math.round(t / n), 2);
        for (let i = 0; i < o; i++)
            r += Math.round(1e4 * e(i / (o - 1))) / 1e4 + ", ";
        return `linear(${r.substring(0, r.length - 2)})`;
    },
    ka = 2e4;
function Ea(e) {
    let t = 0;
    let n = e.next(t);
    for (; !n.done && t < ka; ) (t += 50), (n = e.next(t));
    return t >= ka ? 1 / 0 : t;
}
function Sa(e, t, n) {
    const r = Math.max(t - 5, 0);
    return es(n - e(r), t - r);
}
const Aa = 100,
    Ta = 10,
    La = 1,
    Ma = 0,
    Pa = 800,
    ja = 0.3,
    Na = 0.3,
    Ia = { granular: 0.01, default: 2 },
    Da = { granular: 0.005, default: 0.5 },
    Va = 0.01,
    Ra = 10,
    _a = 0.05,
    Oa = 1,
    Ha = 0.001;
function Fa({
    duration: e = Pa,
    bounce: t = ja,
    velocity: n = Ma,
    mass: r = La,
}) {
    let o,
        i,
        s = 1 - t;
    (s = Bi(_a, Oa, s)),
        (e = Bi(Va, Ra, Ji(e))),
        s < 1
            ? ((o = (t) => {
                  const r = t * s,
                      o = r * e,
                      i = r - n,
                      a = Ua(t, s),
                      l = Math.exp(-o);
                  return Ha - (i / a) * l;
              }),
              (i = (t) => {
                  const r = t * s * e,
                      i = r * n + n,
                      a = Math.pow(s, 2) * Math.pow(t, 2) * e,
                      l = Math.exp(-r),
                      c = Ua(Math.pow(t, 2), s);
                  return ((-o(t) + Ha > 0 ? -1 : 1) * ((i - a) * l)) / c;
              }))
            : ((o = (t) => Math.exp(-t * e) * ((t - n) * e + 1) - 0.001),
              (i = (t) => Math.exp(-t * e) * (e * e * (n - t))));
    const a = (function (e, t, n) {
        let r = n;
        for (let o = 1; o < Ba; o++) r -= e(r) / t(r);
        return r;
    })(o, i, 5 / e);
    if (((e = Qi(e)), isNaN(a)))
        return { stiffness: Aa, damping: Ta, duration: e };
    {
        const t = Math.pow(a, 2) * r;
        return { stiffness: t, damping: 2 * s * Math.sqrt(r * t), duration: e };
    }
}
const Ba = 12;
function Ua(e, t) {
    return e * Math.sqrt(1 - t * t);
}
const Za = ["duration", "bounce"],
    za = ["stiffness", "damping", "mass"];
function $a(e, t) {
    return t.some((t) => void 0 !== e[t]);
}
function Wa(e = Na, t = ja) {
    const n =
        "object" != typeof e
            ? { visualDuration: e, keyframes: [0, 1], bounce: t }
            : e;
    let { restSpeed: r, restDelta: o } = n;
    const i = n.keyframes[0],
        s = n.keyframes[n.keyframes.length - 1],
        a = { done: !1, value: i },
        {
            stiffness: l,
            damping: c,
            mass: u,
            duration: d,
            velocity: h,
            isResolvedFromDuration: p,
        } = (function (e) {
            let t = {
                velocity: Ma,
                stiffness: Aa,
                damping: Ta,
                mass: La,
                isResolvedFromDuration: !1,
                ...e,
            };
            if (!$a(e, za) && $a(e, Za))
                if (e.visualDuration) {
                    const n = e.visualDuration,
                        r = (2 * Math.PI) / (1.2 * n),
                        o = r * r,
                        i = 2 * Bi(0.05, 1, 1 - (e.bounce || 0)) * Math.sqrt(o);
                    t = { ...t, mass: La, stiffness: o, damping: i };
                } else {
                    const n = Fa(e);
                    (t = { ...t, ...n, mass: La }),
                        (t.isResolvedFromDuration = !0);
                }
            return t;
        })({ ...n, velocity: -Ji(n.velocity || 0) }),
        f = h || 0,
        m = c / (2 * Math.sqrt(l * u)),
        g = s - i,
        y = Ji(Math.sqrt(l / u)),
        x = Math.abs(g) < 5;
    let v;
    if (
        (r || (r = x ? Ia.granular : Ia.default),
        o || (o = x ? Da.granular : Da.default),
        m < 1)
    ) {
        const e = Ua(y, m);
        v = (t) => {
            const n = Math.exp(-m * y * t);
            return (
                s -
                n *
                    (((f + m * y * g) / e) * Math.sin(e * t) +
                        g * Math.cos(e * t))
            );
        };
    } else if (1 === m) v = (e) => s - Math.exp(-y * e) * (g + (f + y * g) * e);
    else {
        const e = y * Math.sqrt(m * m - 1);
        v = (t) => {
            const n = Math.exp(-m * y * t),
                r = Math.min(e * t, 300);
            return (
                s -
                (n * ((f + m * y * g) * Math.sinh(r) + e * g * Math.cosh(r))) /
                    e
            );
        };
    }
    const C = {
        calculatedDuration: (p && d) || null,
        next: (e) => {
            const t = v(e);
            if (p) a.done = e >= d;
            else {
                let n = 0 === e ? f : 0;
                m < 1 && (n = 0 === e ? Qi(f) : Sa(v, e, t));
                const i = Math.abs(n) <= r,
                    l = Math.abs(s - t) <= o;
                a.done = i && l;
            }
            return (a.value = a.done ? s : t), a;
        },
        toString: () => {
            const e = Math.min(Ea(C), ka),
                t = ba((t) => C.next(e * t).value, e, 30);
            return e + "ms " + t;
        },
        toTransition: () => {},
    };
    return C;
}
function qa({
    keyframes: e,
    velocity: t = 0,
    power: n = 0.8,
    timeConstant: r = 325,
    bounceDamping: o = 10,
    bounceStiffness: i = 500,
    modifyTarget: s,
    min: a,
    max: l,
    restDelta: c = 0.5,
    restSpeed: u,
}) {
    const d = e[0],
        h = { done: !1, value: d },
        p = (e) =>
            void 0 === a
                ? l
                : void 0 === l || Math.abs(a - e) < Math.abs(l - e)
                ? a
                : l;
    let f = n * t;
    const m = d + f,
        g = void 0 === s ? m : s(m);
    g !== m && (f = g - d);
    const y = (e) => -f * Math.exp(-e / r),
        x = (e) => g + y(e),
        v = (e) => {
            const t = y(e),
                n = x(e);
            (h.done = Math.abs(t) <= c), (h.value = h.done ? g : n);
        };
    let C, w;
    const b = (e) => {
        var t;
        ((t = h.value), (void 0 !== a && t < a) || (void 0 !== l && t > l)) &&
            ((C = e),
            (w = Wa({
                keyframes: [h.value, p(h.value)],
                velocity: Sa(x, e, h.value),
                damping: o,
                stiffness: i,
                restDelta: c,
                restSpeed: u,
            })));
    };
    return (
        b(0),
        {
            calculatedDuration: null,
            next: (e) => {
                let t = !1;
                return (
                    w || void 0 !== C || ((t = !0), v(e), b(e)),
                    void 0 !== C && e >= C ? w.next(e - C) : (!t && v(e), h)
                );
            },
        }
    );
}
function Ka(e, t, { clamp: n = !0, ease: r, mixer: o } = {}) {
    const i = e.length;
    if ((t.length, 1 === i)) return () => t[0];
    if (2 === i && t[0] === t[1]) return () => t[1];
    const s = e[0] === e[1];
    e[0] > e[i - 1] && ((e = [...e].reverse()), (t = [...t].reverse()));
    const a = (function (e, t, n) {
            const r = [],
                o = n || Ui.mix || Ca,
                i = e.length - 1;
            for (let s = 0; s < i; s++) {
                let n = o(e[s], e[s + 1]);
                if (t) {
                    const e = Array.isArray(t) ? t[s] || qi : t;
                    n = Yi(e, n);
                }
                r.push(n);
            }
            return r;
        })(t, r, o),
        l = a.length,
        c = (n) => {
            if (s && n < e[0]) return t[0];
            let r = 0;
            if (l > 1) for (; r < e.length - 2 && !(n < e[r + 1]); r++);
            const o = Xi(e[r], e[r + 1], n);
            return a[r](o);
        };
    return n ? (t) => c(Bi(e[0], e[i - 1], t)) : c;
}
function Ya(e) {
    const t = [0];
    return (
        (function (e, t) {
            const n = e[e.length - 1];
            for (let r = 1; r <= t; r++) {
                const o = Xi(0, t, r);
                e.push(ca(n, 1, o));
            }
        })(t, e.length - 1),
        t
    );
}
function Xa({
    duration: e = 300,
    keyframes: t,
    times: n,
    ease: r = "easeInOut",
}) {
    const o = ((e) => Array.isArray(e) && "number" != typeof e[0])(r)
            ? r.map(ys)
            : ys(r),
        i = { done: !1, value: t[0] },
        s = (function (e, t) {
            return e.map((e) => e * t);
        })(n && n.length === t.length ? n : Ya(t), e),
        a = Ka(s, t, {
            ease: Array.isArray(o)
                ? o
                : ((l = t),
                  (c = o),
                  l.map(() => c || fs).splice(0, l.length - 1)),
        });
    var l, c;
    return {
        calculatedDuration: e,
        next: (t) => ((i.value = a(t)), (i.done = t >= e), i),
    };
}
Wa.applyToOptions = (e) => {
    const t = (function (e, t = 100, n) {
        const r = n({ ...e, keyframes: [0, t] }),
            o = Math.min(Ea(r), ka);
        return {
            type: "keyframes",
            ease: (e) => r.next(o * e).value / t,
            duration: Ji(o),
        };
    })(e, 100, Wa);
    return (
        (e.ease = t.ease),
        (e.duration = Qi(t.duration)),
        (e.type = "keyframes"),
        e
    );
};
const Ga = (e) => null !== e;
function Qa(e, { repeat: t, repeatType: n = "loop" }, r, o = 1) {
    const i = e.filter(Ga),
        s = o < 0 || (t && "loop" !== n && t % 2 == 1) ? 0 : i.length - 1;
    return s && void 0 !== r ? r : i[s];
}
const Ja = { decay: qa, inertia: qa, tween: Xa, keyframes: Xa, spring: Wa };
function el(e) {
    "string" == typeof e.type && (e.type = Ja[e.type]);
}
class tl {
    constructor() {
        this.updateFinished();
    }
    get finished() {
        return this._finished;
    }
    updateFinished() {
        this._finished = new Promise((e) => {
            this.resolve = e;
        });
    }
    notifyFinished() {
        this.resolve();
    }
    then(e, t) {
        return this.finished.then(e, t);
    }
}
const nl = (e) => e / 100;
class rl extends tl {
    constructor(e) {
        super(),
            (this.state = "idle"),
            (this.startTime = null),
            (this.isStopped = !1),
            (this.currentTime = 0),
            (this.holdTime = null),
            (this.playbackSpeed = 1),
            (this.stop = () => {
                const { motionValue: e } = this.options;
                e && e.updatedAt !== As.now() && this.tick(As.now()),
                    (this.isStopped = !0),
                    "idle" !== this.state &&
                        (this.teardown(), this.options.onStop?.());
            }),
            (this.options = e),
            this.initAnimation(),
            this.play(),
            !1 === e.autoplay && this.pause();
    }
    initAnimation() {
        const { options: e } = this;
        el(e);
        const {
            type: t = Xa,
            repeat: n = 0,
            repeatDelay: r = 0,
            repeatType: o,
            velocity: i = 0,
        } = e;
        let { keyframes: s } = e;
        const a = t || Xa;
        a !== Xa &&
            "number" != typeof s[0] &&
            ((this.mixKeyframes = Yi(nl, Ca(s[0], s[1]))), (s = [0, 100]));
        const l = a({ ...e, keyframes: s });
        "mirror" === o &&
            (this.mirroredGenerator = a({
                ...e,
                keyframes: [...s].reverse(),
                velocity: -i,
            })),
            null === l.calculatedDuration && (l.calculatedDuration = Ea(l));
        const { calculatedDuration: c } = l;
        (this.calculatedDuration = c),
            (this.resolvedDuration = c + r),
            (this.totalDuration = this.resolvedDuration * (n + 1) - r),
            (this.generator = l);
    }
    updateTime(e) {
        const t = Math.round(e - this.startTime) * this.playbackSpeed;
        null !== this.holdTime
            ? (this.currentTime = this.holdTime)
            : (this.currentTime = t);
    }
    tick(e, t = !1) {
        const {
            generator: n,
            totalDuration: r,
            mixKeyframes: o,
            mirroredGenerator: i,
            resolvedDuration: s,
            calculatedDuration: a,
        } = this;
        if (null === this.startTime) return n.next(0);
        const {
            delay: l = 0,
            keyframes: c,
            repeat: u,
            repeatType: d,
            repeatDelay: h,
            type: p,
            onUpdate: f,
            finalKeyframe: m,
        } = this.options;
        this.speed > 0
            ? (this.startTime = Math.min(this.startTime, e))
            : this.speed < 0 &&
              (this.startTime = Math.min(e - r / this.speed, this.startTime)),
            t ? (this.currentTime = e) : this.updateTime(e);
        const g = this.currentTime - l * (this.playbackSpeed >= 0 ? 1 : -1),
            y = this.playbackSpeed >= 0 ? g < 0 : g > r;
        (this.currentTime = Math.max(g, 0)),
            "finished" === this.state &&
                null === this.holdTime &&
                (this.currentTime = r);
        let x = this.currentTime,
            v = n;
        if (u) {
            const e = Math.min(this.currentTime, r) / s;
            let t = Math.floor(e),
                n = e % 1;
            !n && e >= 1 && (n = 1), 1 === n && t--, (t = Math.min(t, u + 1));
            Boolean(t % 2) &&
                ("reverse" === d
                    ? ((n = 1 - n), h && (n -= h / s))
                    : "mirror" === d && (v = i)),
                (x = Bi(0, 1, n) * s);
        }
        const C = y ? { done: !1, value: c[0] } : v.next(x);
        o && (C.value = o(C.value));
        let { done: w } = C;
        y ||
            null === a ||
            (w =
                this.playbackSpeed >= 0
                    ? this.currentTime >= r
                    : this.currentTime <= 0);
        const b =
            null === this.holdTime &&
            ("finished" === this.state || ("running" === this.state && w));
        return (
            b && p !== qa && (C.value = Qa(c, this.options, m, this.speed)),
            f && f(C.value),
            b && this.finish(),
            C
        );
    }
    then(e, t) {
        return this.finished.then(e, t);
    }
    get duration() {
        return Ji(this.calculatedDuration);
    }
    get time() {
        return Ji(this.currentTime);
    }
    set time(e) {
        (e = Qi(e)),
            (this.currentTime = e),
            null === this.startTime ||
            null !== this.holdTime ||
            0 === this.playbackSpeed
                ? (this.holdTime = e)
                : this.driver &&
                  (this.startTime = this.driver.now() - e / this.playbackSpeed),
            this.driver?.start(!1);
    }
    get speed() {
        return this.playbackSpeed;
    }
    set speed(e) {
        this.updateTime(As.now());
        const t = this.playbackSpeed !== e;
        (this.playbackSpeed = e), t && (this.time = Ji(this.currentTime));
    }
    play() {
        if (this.isStopped) return;
        const { driver: e = wa, startTime: t } = this.options;
        this.driver || (this.driver = e((e) => this.tick(e))),
            this.options.onPlay?.();
        const n = this.driver.now();
        "finished" === this.state
            ? (this.updateFinished(), (this.startTime = n))
            : null !== this.holdTime
            ? (this.startTime = n - this.holdTime)
            : this.startTime || (this.startTime = t ?? n),
            "finished" === this.state &&
                this.speed < 0 &&
                (this.startTime += this.calculatedDuration),
            (this.holdTime = null),
            (this.state = "running"),
            this.driver.start();
    }
    pause() {
        (this.state = "paused"),
            this.updateTime(As.now()),
            (this.holdTime = this.currentTime);
    }
    complete() {
        "running" !== this.state && this.play(),
            (this.state = "finished"),
            (this.holdTime = null);
    }
    finish() {
        this.notifyFinished(),
            this.teardown(),
            (this.state = "finished"),
            this.options.onComplete?.();
    }
    cancel() {
        (this.holdTime = null),
            (this.startTime = 0),
            this.tick(0),
            this.teardown(),
            this.options.onCancel?.();
    }
    teardown() {
        (this.state = "idle"),
            this.stopDriver(),
            (this.startTime = this.holdTime = null);
    }
    stopDriver() {
        this.driver && (this.driver.stop(), (this.driver = void 0));
    }
    sample(e) {
        return (this.startTime = 0), this.tick(e, !0);
    }
    attachTimeline(e) {
        return (
            this.options.allowFlatten &&
                ((this.options.type = "keyframes"),
                (this.options.ease = "linear"),
                this.initAnimation()),
            this.driver?.stop(),
            e.observe(this)
        );
    }
}
const ol = (e) => (180 * e) / Math.PI,
    il = (e) => {
        const t = ol(Math.atan2(e[1], e[0]));
        return al(t);
    },
    sl = {
        x: 4,
        y: 5,
        translateX: 4,
        translateY: 5,
        scaleX: 0,
        scaleY: 3,
        scale: (e) => (Math.abs(e[0]) + Math.abs(e[3])) / 2,
        rotate: il,
        rotateZ: il,
        skewX: (e) => ol(Math.atan(e[1])),
        skewY: (e) => ol(Math.atan(e[2])),
        skew: (e) => (Math.abs(e[1]) + Math.abs(e[2])) / 2,
    },
    al = (e) => ((e %= 360) < 0 && (e += 360), e),
    ll = (e) => Math.sqrt(e[0] * e[0] + e[1] * e[1]),
    cl = (e) => Math.sqrt(e[4] * e[4] + e[5] * e[5]),
    ul = {
        x: 12,
        y: 13,
        z: 14,
        translateX: 12,
        translateY: 13,
        translateZ: 14,
        scaleX: ll,
        scaleY: cl,
        scale: (e) => (ll(e) + cl(e)) / 2,
        rotateX: (e) => al(ol(Math.atan2(e[6], e[5]))),
        rotateY: (e) => al(ol(Math.atan2(-e[2], e[0]))),
        rotateZ: il,
        rotate: il,
        skewX: (e) => ol(Math.atan(e[4])),
        skewY: (e) => ol(Math.atan(e[1])),
        skew: (e) => (Math.abs(e[1]) + Math.abs(e[4])) / 2,
    };
function dl(e) {
    return e.includes("scale") ? 1 : 0;
}
function hl(e, t) {
    if (!e || "none" === e) return dl(t);
    const n = e.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);
    let r, o;
    if (n) (r = ul), (o = n);
    else {
        const t = e.match(/^matrix\(([-\d.e\s,]+)\)$/u);
        (r = sl), (o = t);
    }
    if (!o) return dl(t);
    const i = r[t],
        s = o[1].split(",").map(pl);
    return "function" == typeof i ? i(s) : s[i];
}
function pl(e) {
    return parseFloat(e.trim());
}
const fl = [
        "transformPerspective",
        "x",
        "y",
        "z",
        "translateX",
        "translateY",
        "translateZ",
        "scale",
        "scaleX",
        "scaleY",
        "rotate",
        "rotateX",
        "rotateY",
        "rotateZ",
        "skew",
        "skewX",
        "skewY",
    ],
    ml = (() => new Set(fl))(),
    gl = (e) => e === Ns || e === Ws,
    yl = new Set(["x", "y", "z"]),
    xl = fl.filter((e) => !yl.has(e));
const vl = {
    width: ({ x: e }, { paddingLeft: t = "0", paddingRight: n = "0" }) =>
        e.max - e.min - parseFloat(t) - parseFloat(n),
    height: ({ y: e }, { paddingTop: t = "0", paddingBottom: n = "0" }) =>
        e.max - e.min - parseFloat(t) - parseFloat(n),
    top: (e, { top: t }) => parseFloat(t),
    left: (e, { left: t }) => parseFloat(t),
    bottom: ({ y: e }, { top: t }) => parseFloat(t) + (e.max - e.min),
    right: ({ x: e }, { left: t }) => parseFloat(t) + (e.max - e.min),
    x: (e, { transform: t }) => hl(t, "x"),
    y: (e, { transform: t }) => hl(t, "y"),
};
(vl.translateX = vl.x), (vl.translateY = vl.y);
const Cl = new Set();
let wl = !1,
    bl = !1,
    kl = !1;
function El() {
    if (bl) {
        const e = Array.from(Cl).filter((e) => e.needsMeasurement),
            t = new Set(e.map((e) => e.element)),
            n = new Map();
        t.forEach((e) => {
            const t = (function (e) {
                const t = [];
                return (
                    xl.forEach((n) => {
                        const r = e.getValue(n);
                        void 0 !== r &&
                            (t.push([n, r.get()]),
                            r.set(n.startsWith("scale") ? 1 : 0));
                    }),
                    t
                );
            })(e);
            t.length && (n.set(e, t), e.render());
        }),
            e.forEach((e) => e.measureInitialState()),
            t.forEach((e) => {
                e.render();
                const t = n.get(e);
                t &&
                    t.forEach(([t, n]) => {
                        e.getValue(t)?.set(n);
                    });
            }),
            e.forEach((e) => e.measureEndState()),
            e.forEach((e) => {
                void 0 !== e.suspendedScrollY &&
                    window.scrollTo(0, e.suspendedScrollY);
            });
    }
    (bl = !1), (wl = !1), Cl.forEach((e) => e.complete(kl)), Cl.clear();
}
function Sl() {
    Cl.forEach((e) => {
        e.readKeyframes(), e.needsMeasurement && (bl = !0);
    });
}
class Al {
    constructor(e, t, n, r, o, i = !1) {
        (this.state = "pending"),
            (this.isAsync = !1),
            (this.needsMeasurement = !1),
            (this.unresolvedKeyframes = [...e]),
            (this.onComplete = t),
            (this.name = n),
            (this.motionValue = r),
            (this.element = o),
            (this.isAsync = i);
    }
    scheduleResolve() {
        (this.state = "scheduled"),
            this.isAsync
                ? (Cl.add(this),
                  wl || ((wl = !0), Cs.read(Sl), Cs.resolveKeyframes(El)))
                : (this.readKeyframes(), this.complete());
    }
    readKeyframes() {
        const {
            unresolvedKeyframes: e,
            name: t,
            element: n,
            motionValue: r,
        } = this;
        if (null === e[0]) {
            const o = r?.get(),
                i = e[e.length - 1];
            if (void 0 !== o) e[0] = o;
            else if (n && t) {
                const r = n.readValue(t, i);
                null != r && (e[0] = r);
            }
            void 0 === e[0] && (e[0] = i), r && void 0 === o && r.set(e[0]);
        }
        !(function (e) {
            for (let t = 1; t < e.length; t++) e[t] ?? (e[t] = e[t - 1]);
        })(e);
    }
    setFinalKeyframe() {}
    measureInitialState() {}
    renderEndStyles() {}
    measureEndState() {}
    complete(e = !1) {
        (this.state = "complete"),
            this.onComplete(this.unresolvedKeyframes, this.finalKeyframe, e),
            Cl.delete(this);
    }
    cancel() {
        "scheduled" === this.state &&
            (Cl.delete(this), (this.state = "pending"));
    }
    resume() {
        "pending" === this.state && this.scheduleResolve();
    }
}
const Tl = Wi(() => void 0 !== window.ScrollTimeline),
    Ll = {};
function Ml(e, t) {
    const n = Wi(e);
    return () => Ll[t] ?? n();
}
const Pl = Ml(() => {
        try {
            document
                .createElement("div")
                .animate({ opacity: 0 }, { easing: "linear(0, 1)" });
        } catch (e) {
            return !1;
        }
        return !0;
    }, "linearEasing"),
    jl = ([e, t, n, r]) => `cubic-bezier(${e}, ${t}, ${n}, ${r})`,
    Nl = {
        linear: "linear",
        ease: "ease",
        easeIn: "ease-in",
        easeOut: "ease-out",
        easeInOut: "ease-in-out",
        circIn: jl([0, 0.65, 0.55, 1]),
        circOut: jl([0.55, 0, 1, 0.45]),
        backIn: jl([0.31, 0.01, 0.66, -0.59]),
        backOut: jl([0.33, 1.53, 0.69, 0.99]),
    };
function Il(e, t) {
    return e
        ? "function" == typeof e
            ? Pl()
                ? ba(e, t)
                : "ease-out"
            : ms(e)
            ? jl(e)
            : Array.isArray(e)
            ? e.map((e) => Il(e, t) || Nl.easeOut)
            : Nl[e]
        : void 0;
}
function Dl(
    e,
    t,
    n,
    {
        delay: r = 0,
        duration: o = 300,
        repeat: i = 0,
        repeatType: s = "loop",
        ease: a = "easeOut",
        times: l,
    } = {},
    c = void 0
) {
    const u = { [t]: n };
    l && (u.offset = l);
    const d = Il(a, o);
    Array.isArray(d) && (u.easing = d);
    const h = {
        delay: r,
        duration: o,
        easing: Array.isArray(d) ? "linear" : d,
        fill: "both",
        iterations: i + 1,
        direction: "reverse" === s ? "alternate" : "normal",
    };
    c && (h.pseudoElement = c);
    return e.animate(u, h);
}
function Vl(e) {
    return "function" == typeof e && "applyToOptions" in e;
}
class Rl extends tl {
    constructor(e) {
        if ((super(), (this.finishedTime = null), (this.isStopped = !1), !e))
            return;
        const {
            element: t,
            name: n,
            keyframes: r,
            pseudoElement: o,
            allowFlatten: i = !1,
            finalKeyframe: s,
            onComplete: a,
        } = e;
        (this.isPseudoElement = Boolean(o)),
            (this.allowFlatten = i),
            (this.options = e),
            e.type;
        const l = (function ({ type: e, ...t }) {
            return Vl(e) && Pl()
                ? e.applyToOptions(t)
                : (t.duration ?? (t.duration = 300),
                  t.ease ?? (t.ease = "easeOut"),
                  t);
        })(e);
        (this.animation = Dl(t, n, r, l, o)),
            !1 === l.autoplay && this.animation.pause(),
            (this.animation.onfinish = () => {
                if (((this.finishedTime = this.time), !o)) {
                    const e = Qa(r, this.options, s, this.speed);
                    this.updateMotionValue
                        ? this.updateMotionValue(e)
                        : (function (e, t, n) {
                              ((e) => e.startsWith("--"))(t)
                                  ? e.style.setProperty(t, n)
                                  : (e.style[t] = n);
                          })(t, n, e),
                        this.animation.cancel();
                }
                a?.(), this.notifyFinished();
            });
    }
    play() {
        this.isStopped ||
            (this.animation.play(),
            "finished" === this.state && this.updateFinished());
    }
    pause() {
        this.animation.pause();
    }
    complete() {
        this.animation.finish?.();
    }
    cancel() {
        try {
            this.animation.cancel();
        } catch (e) {}
    }
    stop() {
        if (this.isStopped) return;
        this.isStopped = !0;
        const { state: e } = this;
        "idle" !== e &&
            "finished" !== e &&
            (this.updateMotionValue
                ? this.updateMotionValue()
                : this.commitStyles(),
            this.isPseudoElement || this.cancel());
    }
    commitStyles() {
        this.isPseudoElement || this.animation.commitStyles?.();
    }
    get duration() {
        const e = this.animation.effect?.getComputedTiming?.().duration || 0;
        return Ji(Number(e));
    }
    get time() {
        return Ji(Number(this.animation.currentTime) || 0);
    }
    set time(e) {
        (this.finishedTime = null), (this.animation.currentTime = Qi(e));
    }
    get speed() {
        return this.animation.playbackRate;
    }
    set speed(e) {
        e < 0 && (this.finishedTime = null), (this.animation.playbackRate = e);
    }
    get state() {
        return null !== this.finishedTime
            ? "finished"
            : this.animation.playState;
    }
    get startTime() {
        return Number(this.animation.startTime);
    }
    set startTime(e) {
        this.animation.startTime = e;
    }
    attachTimeline({ timeline: e, observe: t }) {
        return (
            this.allowFlatten &&
                this.animation.effect?.updateTiming({ easing: "linear" }),
            (this.animation.onfinish = null),
            e && Tl() ? ((this.animation.timeline = e), qi) : t(this)
        );
    }
}
const _l = { anticipate: ls, backInOut: as, circInOut: ds };
function Ol(e) {
    "string" == typeof e.ease && e.ease in _l && (e.ease = _l[e.ease]);
}
class Hl extends Rl {
    constructor(e) {
        Ol(e),
            el(e),
            super(e),
            e.startTime && (this.startTime = e.startTime),
            (this.options = e);
    }
    updateMotionValue(e) {
        const {
            motionValue: t,
            onUpdate: n,
            onComplete: r,
            element: o,
            ...i
        } = this.options;
        if (!t) return;
        if (void 0 !== e) return void t.set(e);
        const s = new rl({ ...i, autoplay: !1 }),
            a = Qi(this.finishedTime ?? this.time);
        t.setWithVelocity(s.sample(a - 10).value, s.sample(a).value, 10),
            s.stop();
    }
}
const Fl = (e, t) =>
    "zIndex" !== t &&
    (!("number" != typeof e && !Array.isArray(e)) ||
        !(
            "string" != typeof e ||
            (!sa.test(e) && "0" !== e) ||
            e.startsWith("url(")
        ));
function Bl(e) {
    (e.duration = 0), e.type;
}
const Ul = new Set(["opacity", "clipPath", "filter", "transform"]),
    Zl = Wi(() => Object.hasOwnProperty.call(Element.prototype, "animate"));
class zl extends tl {
    constructor({
        autoplay: e = !0,
        delay: t = 0,
        type: n = "keyframes",
        repeat: r = 0,
        repeatDelay: o = 0,
        repeatType: i = "loop",
        keyframes: s,
        name: a,
        motionValue: l,
        element: c,
        ...u
    }) {
        super(),
            (this.stop = () => {
                this._animation &&
                    (this._animation.stop(), this.stopTimeline?.()),
                    this.keyframeResolver?.cancel();
            }),
            (this.createdAt = As.now());
        const d = {
                autoplay: e,
                delay: t,
                type: n,
                repeat: r,
                repeatDelay: o,
                repeatType: i,
                name: a,
                motionValue: l,
                element: c,
                ...u,
            },
            h = c?.KeyframeResolver || Al;
        (this.keyframeResolver = new h(
            s,
            (e, t, n) => this.onKeyframesResolved(e, t, d, !n),
            a,
            l,
            c
        )),
            this.keyframeResolver?.scheduleResolve();
    }
    onKeyframesResolved(e, t, n, r) {
        this.keyframeResolver = void 0;
        const {
            name: o,
            type: i,
            velocity: s,
            delay: a,
            isHandoff: l,
            onUpdate: c,
        } = n;
        (this.resolvedAt = As.now()),
            (function (e, t, n, r) {
                const o = e[0];
                if (null === o) return !1;
                if ("display" === t || "visibility" === t) return !0;
                const i = e[e.length - 1],
                    s = Fl(o, t),
                    a = Fl(i, t);
                return (
                    !(!s || !a) &&
                    ((function (e) {
                        const t = e[0];
                        if (1 === e.length) return !0;
                        for (let n = 0; n < e.length; n++)
                            if (e[n] !== t) return !0;
                    })(e) ||
                        (("spring" === n || Vl(n)) && r))
                );
            })(e, o, i, s) ||
                ((!Ui.instantAnimations && a) || c?.(Qa(e, n, t)),
                (e[0] = e[e.length - 1]),
                Bl(n),
                (n.repeat = 0));
        const u = {
                startTime: r
                    ? this.resolvedAt && this.resolvedAt - this.createdAt > 40
                        ? this.resolvedAt
                        : this.createdAt
                    : void 0,
                finalKeyframe: t,
                ...n,
                keyframes: e,
            },
            d =
                !l &&
                (function (e) {
                    const {
                            motionValue: t,
                            name: n,
                            repeatDelay: r,
                            repeatType: o,
                            damping: i,
                            type: s,
                        } = e,
                        a = t?.owner?.current;
                    if (!(a instanceof HTMLElement)) return !1;
                    const { onUpdate: l, transformTemplate: c } =
                        t.owner.getProps();
                    return (
                        Zl() &&
                        n &&
                        Ul.has(n) &&
                        ("transform" !== n || !c) &&
                        !l &&
                        !r &&
                        "mirror" !== o &&
                        0 !== i &&
                        "inertia" !== s
                    );
                })(u)
                    ? new Hl({ ...u, element: u.motionValue.owner.current })
                    : new rl(u);
        d.finished.then(() => this.notifyFinished()).catch(qi),
            this.pendingTimeline &&
                ((this.stopTimeline = d.attachTimeline(this.pendingTimeline)),
                (this.pendingTimeline = void 0)),
            (this._animation = d);
    }
    get finished() {
        return this._animation ? this.animation.finished : this._finished;
    }
    then(e, t) {
        return this.finished.finally(e).then(() => {});
    }
    get animation() {
        return (
            this._animation ||
                (this.keyframeResolver?.resume(),
                (kl = !0),
                Sl(),
                El(),
                (kl = !1)),
            this._animation
        );
    }
    get duration() {
        return this.animation.duration;
    }
    get time() {
        return this.animation.time;
    }
    set time(e) {
        this.animation.time = e;
    }
    get speed() {
        return this.animation.speed;
    }
    get state() {
        return this.animation.state;
    }
    set speed(e) {
        this.animation.speed = e;
    }
    get startTime() {
        return this.animation.startTime;
    }
    attachTimeline(e) {
        return (
            this._animation
                ? (this.stopTimeline = this.animation.attachTimeline(e))
                : (this.pendingTimeline = e),
            () => this.stop()
        );
    }
    play() {
        this.animation.play();
    }
    pause() {
        this.animation.pause();
    }
    complete() {
        this.animation.complete();
    }
    cancel() {
        this._animation && this.animation.cancel(),
            this.keyframeResolver?.cancel();
    }
}
const $l = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
function Wl(e, t, n = 1) {
    const [r, o] = (function (e) {
        const t = $l.exec(e);
        if (!t) return [,];
        const [, n, r, o] = t;
        return [`--${n ?? r}`, o];
    })(e);
    if (!r) return;
    const i = window.getComputedStyle(t).getPropertyValue(r);
    if (i) {
        const e = i.trim();
        return Zi(e) ? parseFloat(e) : e;
    }
    return Ps(o) ? Wl(o, t, n + 1) : o;
}
function ql(e, t) {
    return e?.[t] ?? e?.default ?? e;
}
const Kl = new Set([
        "width",
        "height",
        "top",
        "left",
        "right",
        "bottom",
        ...fl,
    ]),
    Yl = (e) => (t) => t.test(e),
    Xl = [
        Ns,
        Ws,
        $s,
        zs,
        Ks,
        qs,
        { test: (e) => "auto" === e, parse: (e) => e },
    ],
    Gl = (e) => Xl.find(Yl(e));
function Ql(e) {
    return "number" == typeof e
        ? 0 === e
        : null === e || "none" === e || "0" === e || $i(e);
}
const Jl = new Set(["brightness", "contrast", "saturate", "opacity"]);
function ec(e) {
    const [t, n] = e.slice(0, -1).split("(");
    if ("drop-shadow" === t) return e;
    const [r] = n.match(Rs) || [];
    if (!r) return e;
    const o = n.replace(r, "");
    let i = Jl.has(t) ? 1 : 0;
    return r !== n && (i *= 100), t + "(" + i + o + ")";
}
const tc = /\b([a-z-]*)\(.*?\)/gu,
    nc = {
        ...sa,
        getAnimatableNone: (e) => {
            const t = e.match(tc);
            return t ? t.map(ec).join(" ") : e;
        },
    },
    rc = { ...Ns, transform: Math.round },
    oc = {
        borderWidth: Ws,
        borderTopWidth: Ws,
        borderRightWidth: Ws,
        borderBottomWidth: Ws,
        borderLeftWidth: Ws,
        borderRadius: Ws,
        radius: Ws,
        borderTopLeftRadius: Ws,
        borderTopRightRadius: Ws,
        borderBottomRightRadius: Ws,
        borderBottomLeftRadius: Ws,
        width: Ws,
        maxWidth: Ws,
        height: Ws,
        maxHeight: Ws,
        top: Ws,
        right: Ws,
        bottom: Ws,
        left: Ws,
        padding: Ws,
        paddingTop: Ws,
        paddingRight: Ws,
        paddingBottom: Ws,
        paddingLeft: Ws,
        margin: Ws,
        marginTop: Ws,
        marginRight: Ws,
        marginBottom: Ws,
        marginLeft: Ws,
        backgroundPositionX: Ws,
        backgroundPositionY: Ws,
        ...{
            rotate: zs,
            rotateX: zs,
            rotateY: zs,
            rotateZ: zs,
            scale: Ds,
            scaleX: Ds,
            scaleY: Ds,
            scaleZ: Ds,
            skew: zs,
            skewX: zs,
            skewY: zs,
            distance: Ws,
            translateX: Ws,
            translateY: Ws,
            translateZ: Ws,
            x: Ws,
            y: Ws,
            z: Ws,
            perspective: Ws,
            transformPerspective: Ws,
            opacity: Is,
            originX: Ys,
            originY: Ys,
            originZ: Ws,
        },
        zIndex: rc,
        fillOpacity: Is,
        strokeOpacity: Is,
        numOctaves: rc,
    },
    ic = {
        ...oc,
        color: Gs,
        backgroundColor: Gs,
        outlineColor: Gs,
        fill: Gs,
        stroke: Gs,
        borderColor: Gs,
        borderTopColor: Gs,
        borderRightColor: Gs,
        borderBottomColor: Gs,
        borderLeftColor: Gs,
        filter: nc,
        WebkitFilter: nc,
    },
    sc = (e) => ic[e];
function ac(e, t) {
    let n = sc(e);
    return (
        n !== nc && (n = sa),
        n.getAnimatableNone ? n.getAnimatableNone(t) : void 0
    );
}
const lc = new Set(["auto", "none", "0"]);
class cc extends Al {
    constructor(e, t, n, r, o) {
        super(e, t, n, r, o, !0);
    }
    readKeyframes() {
        const { unresolvedKeyframes: e, element: t, name: n } = this;
        if (!t || !t.current) return;
        super.readKeyframes();
        for (let a = 0; a < e.length; a++) {
            let n = e[a];
            if ("string" == typeof n && ((n = n.trim()), Ps(n))) {
                const r = Wl(n, t.current);
                void 0 !== r && (e[a] = r),
                    a === e.length - 1 && (this.finalKeyframe = n);
            }
        }
        if ((this.resolveNoneKeyframes(), !Kl.has(n) || 2 !== e.length)) return;
        const [r, o] = e,
            i = Gl(r),
            s = Gl(o);
        if (i !== s)
            if (gl(i) && gl(s))
                for (let a = 0; a < e.length; a++) {
                    const t = e[a];
                    "string" == typeof t && (e[a] = parseFloat(t));
                }
            else vl[n] && (this.needsMeasurement = !0);
    }
    resolveNoneKeyframes() {
        const { unresolvedKeyframes: e, name: t } = this,
            n = [];
        for (let r = 0; r < e.length; r++)
            (null === e[r] || Ql(e[r])) && n.push(r);
        n.length &&
            (function (e, t, n) {
                let r,
                    o = 0;
                for (; o < e.length && !r; ) {
                    const t = e[o];
                    "string" == typeof t &&
                        !lc.has(t) &&
                        na(t).values.length &&
                        (r = e[o]),
                        o++;
                }
                if (r && n) for (const i of t) e[i] = ac(n, r);
            })(e, n, t);
    }
    measureInitialState() {
        const { element: e, unresolvedKeyframes: t, name: n } = this;
        if (!e || !e.current) return;
        "height" === n && (this.suspendedScrollY = window.pageYOffset),
            (this.measuredOrigin = vl[n](
                e.measureViewportBox(),
                window.getComputedStyle(e.current)
            )),
            (t[0] = this.measuredOrigin);
        const r = t[t.length - 1];
        void 0 !== r && e.getValue(n, r).jump(r, !1);
    }
    measureEndState() {
        const { element: e, name: t, unresolvedKeyframes: n } = this;
        if (!e || !e.current) return;
        const r = e.getValue(t);
        r && r.jump(this.measuredOrigin, !1);
        const o = n.length - 1,
            i = n[o];
        (n[o] = vl[t](
            e.measureViewportBox(),
            window.getComputedStyle(e.current)
        )),
            null !== i &&
                void 0 === this.finalKeyframe &&
                (this.finalKeyframe = i),
            this.removedTransforms?.length &&
                this.removedTransforms.forEach(([t, n]) => {
                    e.getValue(t).set(n);
                }),
            this.resolveNoneKeyframes();
    }
}
const uc = (e, t) => (t && "number" == typeof e ? t.transform(e) : e);
class dc {
    constructor(e, t = {}) {
        (this.canTrackVelocity = null),
            (this.events = {}),
            (this.updateAndNotify = (e) => {
                const t = As.now();
                if (
                    (this.updatedAt !== t && this.setPrevFrameValue(),
                    (this.prev = this.current),
                    this.setCurrent(e),
                    this.current !== this.prev &&
                        (this.events.change?.notify(this.current),
                        this.dependents))
                )
                    for (const n of this.dependents) n.dirty();
            }),
            (this.hasAnimated = !1),
            this.setCurrent(e),
            (this.owner = t.owner);
    }
    setCurrent(e) {
        var t;
        (this.current = e),
            (this.updatedAt = As.now()),
            null === this.canTrackVelocity &&
                void 0 !== e &&
                (this.canTrackVelocity =
                    ((t = this.current), !isNaN(parseFloat(t))));
    }
    setPrevFrameValue(e = this.current) {
        (this.prevFrameValue = e), (this.prevUpdatedAt = this.updatedAt);
    }
    onChange(e) {
        return this.on("change", e);
    }
    on(e, t) {
        this.events[e] || (this.events[e] = new Gi());
        const n = this.events[e].add(t);
        return "change" === e
            ? () => {
                  n(),
                      Cs.read(() => {
                          this.events.change.getSize() || this.stop();
                      });
              }
            : n;
    }
    clearListeners() {
        for (const e in this.events) this.events[e].clear();
    }
    attach(e, t) {
        (this.passiveEffect = e), (this.stopPassiveEffect = t);
    }
    set(e) {
        this.passiveEffect
            ? this.passiveEffect(e, this.updateAndNotify)
            : this.updateAndNotify(e);
    }
    setWithVelocity(e, t, n) {
        this.set(t),
            (this.prev = void 0),
            (this.prevFrameValue = e),
            (this.prevUpdatedAt = this.updatedAt - n);
    }
    jump(e, t = !0) {
        this.updateAndNotify(e),
            (this.prev = e),
            (this.prevUpdatedAt = this.prevFrameValue = void 0),
            t && this.stop(),
            this.stopPassiveEffect && this.stopPassiveEffect();
    }
    dirty() {
        this.events.change?.notify(this.current);
    }
    addDependent(e) {
        this.dependents || (this.dependents = new Set()),
            this.dependents.add(e);
    }
    removeDependent(e) {
        this.dependents && this.dependents.delete(e);
    }
    get() {
        return this.current;
    }
    getPrevious() {
        return this.prev;
    }
    getVelocity() {
        const e = As.now();
        if (
            !this.canTrackVelocity ||
            void 0 === this.prevFrameValue ||
            e - this.updatedAt > 30
        )
            return 0;
        const t = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
        return es(
            parseFloat(this.current) - parseFloat(this.prevFrameValue),
            t
        );
    }
    start(e) {
        return (
            this.stop(),
            new Promise((t) => {
                (this.hasAnimated = !0),
                    (this.animation = e(t)),
                    this.events.animationStart &&
                        this.events.animationStart.notify();
            }).then(() => {
                this.events.animationComplete &&
                    this.events.animationComplete.notify(),
                    this.clearAnimation();
            })
        );
    }
    stop() {
        this.animation &&
            (this.animation.stop(),
            this.events.animationCancel &&
                this.events.animationCancel.notify()),
            this.clearAnimation();
    }
    isAnimating() {
        return !!this.animation;
    }
    clearAnimation() {
        delete this.animation;
    }
    destroy() {
        this.dependents?.clear(),
            this.events.destroy?.notify(),
            this.clearListeners(),
            this.stop(),
            this.stopPassiveEffect && this.stopPassiveEffect();
    }
}
function hc(e, t) {
    return new dc(e, t);
}
const { schedule: pc } = vs(queueMicrotask, !1),
    fc = { x: !1, y: !1 };
function mc() {
    return fc.x || fc.y;
}
function gc(e, t) {
    const n = (function (e, t, n) {
            if (e instanceof EventTarget) return [e];
            if ("string" == typeof e) {
                let t = document;
                const r = n?.[e] ?? t.querySelectorAll(e);
                return r ? Array.from(r) : [];
            }
            return Array.from(e);
        })(e),
        r = new AbortController();
    return [n, { passive: !0, ...t, signal: r.signal }, () => r.abort()];
}
function yc(e) {
    return !("touch" === e.pointerType || mc());
}
const xc = (e, t) => !!t && (e === t || xc(e, t.parentElement)),
    vc = (e) =>
        "mouse" === e.pointerType
            ? "number" != typeof e.button || e.button <= 0
            : !1 !== e.isPrimary,
    Cc = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]);
const wc = new WeakSet();
function bc(e) {
    return (t) => {
        "Enter" === t.key && e(t);
    };
}
function kc(e, t) {
    e.dispatchEvent(
        new PointerEvent("pointer" + t, { isPrimary: !0, bubbles: !0 })
    );
}
function Ec(e) {
    return vc(e) && !mc();
}
function Sc(e, t, n = {}) {
    const [r, o, i] = gc(e, n),
        s = (e) => {
            const r = e.currentTarget;
            if (!Ec(e)) return;
            wc.add(r);
            const i = t(r, e),
                s = (e, t) => {
                    window.removeEventListener("pointerup", a),
                        window.removeEventListener("pointercancel", l),
                        wc.has(r) && wc.delete(r),
                        Ec(e) && "function" == typeof i && i(e, { success: t });
                },
                a = (e) => {
                    s(
                        e,
                        r === window ||
                            r === document ||
                            n.useGlobalTarget ||
                            xc(r, e.target)
                    );
                },
                l = (e) => {
                    s(e, !1);
                };
            window.addEventListener("pointerup", a, o),
                window.addEventListener("pointercancel", l, o);
        };
    return (
        r.forEach((e) => {
            var t;
            (n.useGlobalTarget ? window : e).addEventListener(
                "pointerdown",
                s,
                o
            ),
                zi((t = e)) &&
                    "offsetHeight" in t &&
                    (e.addEventListener("focus", (e) =>
                        ((e, t) => {
                            const n = e.currentTarget;
                            if (!n) return;
                            const r = bc(() => {
                                if (wc.has(n)) return;
                                kc(n, "down");
                                const e = bc(() => {
                                    kc(n, "up");
                                });
                                n.addEventListener("keyup", e, t),
                                    n.addEventListener(
                                        "blur",
                                        () => kc(n, "cancel"),
                                        t
                                    );
                            });
                            n.addEventListener("keydown", r, t),
                                n.addEventListener(
                                    "blur",
                                    () => n.removeEventListener("keydown", r),
                                    t
                                );
                        })(e, o)
                    ),
                    (function (e) {
                        return Cc.has(e.tagName) || -1 !== e.tabIndex;
                    })(e) ||
                        e.hasAttribute("tabindex") ||
                        (e.tabIndex = 0));
        }),
        i
    );
}
function Ac(e) {
    return zi(e) && "ownerSVGElement" in e;
}
const Tc = (e) => Boolean(e && e.getVelocity),
    Lc = [...Xl, Gs, sa],
    Mc = r.createContext({
        transformPagePoint: (e) => e,
        isStatic: !1,
        reducedMotion: "never",
    });
const Pc = r.createContext({ strict: !1 }),
    jc = {
        animation: [
            "animate",
            "variants",
            "whileHover",
            "whileTap",
            "exit",
            "whileInView",
            "whileFocus",
            "whileDrag",
        ],
        exit: ["exit"],
        drag: ["drag", "dragControls"],
        focus: ["whileFocus"],
        hover: ["whileHover", "onHoverStart", "onHoverEnd"],
        tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
        pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
        inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
        layout: ["layout", "layoutId"],
    },
    Nc = {};
for (const Dy in jc) Nc[Dy] = { isEnabled: (e) => jc[Dy].some((t) => !!e[t]) };
const Ic = new Set([
    "animate",
    "exit",
    "variants",
    "initial",
    "style",
    "values",
    "variants",
    "transition",
    "transformTemplate",
    "custom",
    "inherit",
    "onBeforeLayoutMeasure",
    "onAnimationStart",
    "onAnimationComplete",
    "onUpdate",
    "onDragStart",
    "onDrag",
    "onDragEnd",
    "onMeasureDragConstraints",
    "onDirectionLock",
    "onDragTransitionEnd",
    "_dragX",
    "_dragY",
    "onHoverStart",
    "onHoverEnd",
    "onViewportEnter",
    "onViewportLeave",
    "globalTapTarget",
    "ignoreStrict",
    "viewport",
]);
function Dc(e) {
    return (
        e.startsWith("while") ||
        (e.startsWith("drag") && "draggable" !== e) ||
        e.startsWith("layout") ||
        e.startsWith("onTap") ||
        e.startsWith("onPan") ||
        e.startsWith("onLayout") ||
        Ic.has(e)
    );
}
let Vc = (e) => !Dc(e);
try {
    "function" == typeof (Rc = require("@emotion/is-prop-valid").default) &&
        (Vc = (e) => (e.startsWith("on") ? !Dc(e) : Rc(e)));
} catch {}
var Rc;
const _c = r.createContext({});
function Oc(e) {
    return null !== e && "object" == typeof e && "function" == typeof e.start;
}
function Hc(e) {
    return "string" == typeof e || Array.isArray(e);
}
const Fc = [
        "animate",
        "whileInView",
        "whileFocus",
        "whileHover",
        "whileTap",
        "whileDrag",
        "exit",
    ],
    Bc = ["initial", ...Fc];
function Uc(e) {
    return Oc(e.animate) || Bc.some((t) => Hc(e[t]));
}
function Zc(e) {
    return Boolean(Uc(e) || e.variants);
}
function zc(e) {
    const { initial: t, animate: n } = (function (e, t) {
        if (Uc(e)) {
            const { initial: t, animate: n } = e;
            return {
                initial: !1 === t || Hc(t) ? t : void 0,
                animate: Hc(n) ? n : void 0,
            };
        }
        return !1 !== e.inherit ? t : {};
    })(e, r.useContext(_c));
    return r.useMemo(() => ({ initial: t, animate: n }), [$c(t), $c(n)]);
}
function $c(e) {
    return Array.isArray(e) ? e.join(" ") : e;
}
const Wc = {};
function qc(e, { layout: t, layoutId: n }) {
    return (
        ml.has(e) ||
        e.startsWith("origin") ||
        ((t || void 0 !== n) && (!!Wc[e] || "opacity" === e))
    );
}
const Kc = {
        x: "translateX",
        y: "translateY",
        z: "translateZ",
        transformPerspective: "perspective",
    },
    Yc = fl.length;
function Xc(e, t, n) {
    const { style: r, vars: o, transformOrigin: i } = e;
    let s = !1,
        a = !1;
    for (const l in t) {
        const e = t[l];
        if (ml.has(l)) s = !0;
        else if (Ls(l)) o[l] = e;
        else {
            const t = uc(e, oc[l]);
            l.startsWith("origin") ? ((a = !0), (i[l] = t)) : (r[l] = t);
        }
    }
    if (
        (t.transform ||
            (s || n
                ? (r.transform = (function (e, t, n) {
                      let r = "",
                          o = !0;
                      for (let i = 0; i < Yc; i++) {
                          const s = fl[i],
                              a = e[s];
                          if (void 0 === a) continue;
                          let l = !0;
                          if (
                              ((l =
                                  "number" == typeof a
                                      ? a === (s.startsWith("scale") ? 1 : 0)
                                      : 0 === parseFloat(a)),
                              !l || n)
                          ) {
                              const e = uc(a, oc[s]);
                              l || ((o = !1), (r += `${Kc[s] || s}(${e}) `)),
                                  n && (t[s] = e);
                          }
                      }
                      return (
                          (r = r.trim()),
                          n ? (r = n(t, o ? "" : r)) : o && (r = "none"),
                          r
                      );
                  })(t, e.transform, n))
                : r.transform && (r.transform = "none")),
        a)
    ) {
        const { originX: e = "50%", originY: t = "50%", originZ: n = 0 } = i;
        r.transformOrigin = `${e} ${t} ${n}`;
    }
}
const Gc = () => ({ style: {}, transform: {}, transformOrigin: {}, vars: {} });
function Qc(e, t, n) {
    for (const r in t) Tc(t[r]) || qc(r, n) || (e[r] = t[r]);
}
function Jc(e, t) {
    const n = {};
    return (
        Qc(n, e.style || {}, e),
        Object.assign(
            n,
            (function ({ transformTemplate: e }, t) {
                return r.useMemo(() => {
                    const n = {
                        style: {},
                        transform: {},
                        transformOrigin: {},
                        vars: {},
                    };
                    return Xc(n, t, e), Object.assign({}, n.vars, n.style);
                }, [t]);
            })(e, t)
        ),
        n
    );
}
function eu(e, t) {
    const n = {},
        r = Jc(e, t);
    return (
        e.drag &&
            !1 !== e.dragListener &&
            ((n.draggable = !1),
            (r.userSelect = r.WebkitUserSelect = r.WebkitTouchCallout = "none"),
            (r.touchAction =
                !0 === e.drag
                    ? "none"
                    : "pan-" + ("x" === e.drag ? "y" : "x"))),
        void 0 === e.tabIndex &&
            (e.onTap || e.onTapStart || e.whileTap) &&
            (n.tabIndex = 0),
        (n.style = r),
        n
    );
}
const tu = { offset: "stroke-dashoffset", array: "stroke-dasharray" },
    nu = { offset: "strokeDashoffset", array: "strokeDasharray" };
function ru(
    e,
    {
        attrX: t,
        attrY: n,
        attrScale: r,
        pathLength: o,
        pathSpacing: i = 1,
        pathOffset: s = 0,
        ...a
    },
    l,
    c,
    u
) {
    if ((Xc(e, a, c), l))
        return void (e.style.viewBox && (e.attrs.viewBox = e.style.viewBox));
    (e.attrs = e.style), (e.style = {});
    const { attrs: d, style: h } = e;
    d.transform && ((h.transform = d.transform), delete d.transform),
        (h.transform || d.transformOrigin) &&
            ((h.transformOrigin = d.transformOrigin ?? "50% 50%"),
            delete d.transformOrigin),
        h.transform &&
            ((h.transformBox = u?.transformBox ?? "fill-box"),
            delete d.transformBox),
        void 0 !== t && (d.x = t),
        void 0 !== n && (d.y = n),
        void 0 !== r && (d.scale = r),
        void 0 !== o &&
            (function (e, t, n = 1, r = 0, o = !0) {
                e.pathLength = 1;
                const i = o ? tu : nu;
                e[i.offset] = Ws.transform(-r);
                const s = Ws.transform(t),
                    a = Ws.transform(n);
                e[i.array] = `${s} ${a}`;
            })(d, o, i, s, !1);
}
const ou = () => ({
        style: {},
        transform: {},
        transformOrigin: {},
        vars: {},
        attrs: {},
    }),
    iu = (e) => "string" == typeof e && "svg" === e.toLowerCase();
function su(e, t, n, o) {
    const i = r.useMemo(() => {
        const n = {
            style: {},
            transform: {},
            transformOrigin: {},
            vars: {},
            attrs: {},
        };
        return (
            ru(n, t, iu(o), e.transformTemplate, e.style),
            { ...n.attrs, style: { ...n.style } }
        );
    }, [t]);
    if (e.style) {
        const t = {};
        Qc(t, e.style, e), (i.style = { ...t, ...i.style });
    }
    return i;
}
const au = [
    "animate",
    "circle",
    "defs",
    "desc",
    "ellipse",
    "g",
    "image",
    "line",
    "filter",
    "marker",
    "mask",
    "metadata",
    "path",
    "pattern",
    "polygon",
    "polyline",
    "rect",
    "stop",
    "switch",
    "symbol",
    "svg",
    "text",
    "tspan",
    "use",
    "view",
];
function lu(e) {
    return (
        "string" == typeof e &&
        !e.includes("-") &&
        !!(au.indexOf(e) > -1 || /[A-Z]/u.test(e))
    );
}
function cu(e, t, n, { latestValues: o }, i, s = !1) {
    const a = (lu(e) ? su : eu)(t, o, i, e),
        l = (function (e, t, n) {
            const r = {};
            for (const o in e)
                ("values" === o && "object" == typeof e.values) ||
                    ((Vc(o) ||
                        (!0 === n && Dc(o)) ||
                        (!t && !Dc(o)) ||
                        (e.draggable && o.startsWith("onDrag"))) &&
                        (r[o] = e[o]));
            return r;
        })(t, "string" == typeof e, s),
        c = e !== r.Fragment ? { ...l, ...a, ref: n } : {},
        { children: u } = t,
        d = r.useMemo(() => (Tc(u) ? u.get() : u), [u]);
    return r.createElement(e, { ...c, children: d });
}
function uu(e) {
    const t = [{}, {}];
    return (
        e?.values.forEach((e, n) => {
            (t[0][n] = e.get()), (t[1][n] = e.getVelocity());
        }),
        t
    );
}
function du(e, t, n, r) {
    if ("function" == typeof t) {
        const [o, i] = uu(r);
        t = t(void 0 !== n ? n : e.custom, o, i);
    }
    if (
        ("string" == typeof t && (t = e.variants && e.variants[t]),
        "function" == typeof t)
    ) {
        const [o, i] = uu(r);
        t = t(void 0 !== n ? n : e.custom, o, i);
    }
    return t;
}
function hu(e) {
    return Tc(e) ? e.get() : e;
}
function pu(e, t, n, r) {
    const o = {},
        i = r(e, {});
    for (const h in i) o[h] = hu(i[h]);
    let { initial: s, animate: a } = e;
    const l = Uc(e),
        c = Zc(e);
    t &&
        c &&
        !l &&
        !1 !== e.inherit &&
        (void 0 === s && (s = t.initial), void 0 === a && (a = t.animate));
    let u = !!n && !1 === n.initial;
    u = u || !1 === s;
    const d = u ? a : s;
    if (d && "boolean" != typeof d && !Oc(d)) {
        const t = Array.isArray(d) ? d : [d];
        for (let n = 0; n < t.length; n++) {
            const r = du(e, t[n]);
            if (r) {
                const { transitionEnd: e, transition: t, ...n } = r;
                for (const r in n) {
                    let e = n[r];
                    if (Array.isArray(e)) {
                        e = e[u ? e.length - 1 : 0];
                    }
                    null !== e && (o[r] = e);
                }
                for (const r in e) o[r] = e[r];
            }
        }
    }
    return o;
}
const fu = (e) => (t, n) => {
    const o = r.useContext(_c),
        i = r.useContext(Oi),
        s = () =>
            (function (
                { scrapeMotionValuesFromProps: e, createRenderState: t },
                n,
                r,
                o
            ) {
                return { latestValues: pu(n, r, o, e), renderState: t() };
            })(e, t, o, i);
    return n
        ? s()
        : (function (e) {
              const t = r.useRef(null);
              return null === t.current && (t.current = e()), t.current;
          })(s);
};
function mu(e, t, n) {
    const { style: r } = e,
        o = {};
    for (const i in r)
        (Tc(r[i]) ||
            (t.style && Tc(t.style[i])) ||
            qc(i, e) ||
            void 0 !== n?.getValue(i)?.liveStyle) &&
            (o[i] = r[i]);
    return o;
}
const gu = fu({ scrapeMotionValuesFromProps: mu, createRenderState: Gc });
function yu(e, t, n) {
    const r = mu(e, t, n);
    for (const o in e)
        if (Tc(e[o]) || Tc(t[o])) {
            r[
                -1 !== fl.indexOf(o)
                    ? "attr" + o.charAt(0).toUpperCase() + o.substring(1)
                    : o
            ] = e[o];
        }
    return r;
}
const xu = fu({ scrapeMotionValuesFromProps: yu, createRenderState: ou }),
    vu = Symbol.for("motionComponentSymbol");
function Cu(e) {
    return (
        e &&
        "object" == typeof e &&
        Object.prototype.hasOwnProperty.call(e, "current")
    );
}
function wu(e, t, n) {
    return r.useCallback(
        (r) => {
            r && e.onMount && e.onMount(r),
                t && (r ? t.mount(r) : t.unmount()),
                n && ("function" == typeof n ? n(r) : Cu(n) && (n.current = r));
        },
        [t]
    );
}
const bu = (e) => e.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase(),
    ku = "data-" + bu("framerAppearId"),
    Eu = r.createContext({});
function Su(e, t, n, o, i) {
    const { visualElement: s } = r.useContext(_c),
        a = r.useContext(Pc),
        l = r.useContext(Oi),
        c = r.useContext(Mc).reducedMotion,
        u = r.useRef(null);
    (o = o || a.renderer),
        !u.current &&
            o &&
            (u.current = o(e, {
                visualState: t,
                parent: s,
                props: n,
                presenceContext: l,
                blockInitialAnimation: !!l && !1 === l.initial,
                reducedMotionConfig: c,
            }));
    const d = u.current,
        h = r.useContext(Eu);
    !d ||
        d.projection ||
        !i ||
        ("html" !== d.type && "svg" !== d.type) ||
        (function (e, t, n, r) {
            const {
                layoutId: o,
                layout: i,
                drag: s,
                dragConstraints: a,
                layoutScroll: l,
                layoutRoot: c,
                layoutCrossfade: u,
            } = t;
            (e.projection = new n(
                e.latestValues,
                t["data-framer-portal-id"] ? void 0 : Au(e.parent)
            )),
                e.projection.setOptions({
                    layoutId: o,
                    layout: i,
                    alwaysMeasureLayout: Boolean(s) || (a && Cu(a)),
                    visualElement: e,
                    animationType: "string" == typeof i ? i : "both",
                    initialPromotionConfig: r,
                    crossfade: u,
                    layoutScroll: l,
                    layoutRoot: c,
                });
        })(u.current, n, i, h);
    const p = r.useRef(!1);
    r.useInsertionEffect(() => {
        d && p.current && d.update(n, l);
    });
    const f = n[ku],
        m = r.useRef(
            Boolean(f) &&
                !window.MotionHandoffIsComplete?.(f) &&
                window.MotionHasOptimisedAnimation?.(f)
        );
    return (
        _i(() => {
            d &&
                ((p.current = !0),
                (window.MotionIsMounted = !0),
                d.updateFeatures(),
                d.scheduleRenderMicrotask(),
                m.current &&
                    d.animationState &&
                    d.animationState.animateChanges());
        }),
        r.useEffect(() => {
            d &&
                (!m.current &&
                    d.animationState &&
                    d.animationState.animateChanges(),
                m.current &&
                    (queueMicrotask(() => {
                        window.MotionHandoffMarkAsComplete?.(f);
                    }),
                    (m.current = !1)),
                (d.enteringChildren = void 0));
        }),
        d
    );
}
function Au(e) {
    if (e)
        return !1 !== e.options.allowProjection ? e.projection : Au(e.parent);
}
function Tu(e, { forwardMotionProps: t = !1 } = {}, n, o) {
    n &&
        (function (e) {
            for (const t in e) Nc[t] = { ...Nc[t], ...e[t] };
        })(n);
    const i = lu(e) ? xu : gu;
    function s(n, s) {
        let l;
        const c = { ...r.useContext(Mc), ...n, layoutId: Lu(n) },
            { isStatic: u } = c,
            d = zc(n),
            h = i(n, u);
        if (!u && Ri) {
            r.useContext(Pc).strict;
            const t = (function (e) {
                const { drag: t, layout: n } = Nc;
                if (!t && !n) return {};
                const r = { ...t, ...n };
                return {
                    MeasureLayout:
                        t?.isEnabled(e) || n?.isEnabled(e)
                            ? r.MeasureLayout
                            : void 0,
                    ProjectionNode: r.ProjectionNode,
                };
            })(c);
            (l = t.MeasureLayout),
                (d.visualElement = Su(e, h, c, o, t.ProjectionNode));
        }
        return a.jsxs(_c.Provider, {
            value: d,
            children: [
                l && d.visualElement
                    ? a.jsx(l, { visualElement: d.visualElement, ...c })
                    : null,
                cu(e, n, wu(h, d.visualElement, s), h, u, t),
            ],
        });
    }
    s.displayName = `motion.${
        "string" == typeof e ? e : `create(${e.displayName ?? e.name ?? ""})`
    }`;
    const l = r.forwardRef(s);
    return (l[vu] = e), l;
}
function Lu({ layoutId: e }) {
    const t = r.useContext(Vi).id;
    return t && void 0 !== e ? t + "-" + e : e;
}
function Mu(e, t) {
    if ("undefined" == typeof Proxy) return Tu;
    const n = new Map(),
        r = (n, r) => Tu(n, r, e, t);
    return new Proxy((e, t) => r(e, t), {
        get: (o, i) =>
            "create" === i
                ? r
                : (n.has(i) || n.set(i, Tu(i, void 0, e, t)), n.get(i)),
    });
}
function Pu({ top: e, left: t, right: n, bottom: r }) {
    return { x: { min: t, max: n }, y: { min: e, max: r } };
}
function ju(e) {
    return void 0 === e || 1 === e;
}
function Nu({ scale: e, scaleX: t, scaleY: n }) {
    return !ju(e) || !ju(t) || !ju(n);
}
function Iu(e) {
    return (
        Nu(e) ||
        Du(e) ||
        e.z ||
        e.rotate ||
        e.rotateX ||
        e.rotateY ||
        e.skewX ||
        e.skewY
    );
}
function Du(e) {
    return Vu(e.x) || Vu(e.y);
}
function Vu(e) {
    return e && "0%" !== e;
}
function Ru(e, t, n) {
    return n + t * (e - n);
}
function _u(e, t, n, r, o) {
    return void 0 !== o && (e = Ru(e, o, r)), Ru(e, n, r) + t;
}
function Ou(e, t = 0, n = 1, r, o) {
    (e.min = _u(e.min, t, n, r, o)), (e.max = _u(e.max, t, n, r, o));
}
function Hu(e, { x: t, y: n }) {
    Ou(e.x, t.translate, t.scale, t.originPoint),
        Ou(e.y, n.translate, n.scale, n.originPoint);
}
const Fu = 0.999999999999,
    Bu = 1.0000000000001;
function Uu(e, t) {
    (e.min = e.min + t), (e.max = e.max + t);
}
function Zu(e, t, n, r, o = 0.5) {
    Ou(e, t, n, ca(e.min, e.max, o), r);
}
function zu(e, t) {
    Zu(e.x, t.x, t.scaleX, t.scale, t.originX),
        Zu(e.y, t.y, t.scaleY, t.scale, t.originY);
}
function $u(e, t) {
    return Pu(
        (function (e, t) {
            if (!t) return e;
            const n = t({ x: e.left, y: e.top }),
                r = t({ x: e.right, y: e.bottom });
            return { top: n.y, left: n.x, bottom: r.y, right: r.x };
        })(e.getBoundingClientRect(), t)
    );
}
const Wu = () => ({ x: { min: 0, max: 0 }, y: { min: 0, max: 0 } }),
    qu = { current: null },
    Ku = { current: !1 };
const Yu = new WeakMap();
const Xu = [
    "AnimationStart",
    "AnimationComplete",
    "Update",
    "BeforeLayoutMeasure",
    "LayoutMeasure",
    "LayoutAnimationStart",
    "LayoutAnimationComplete",
];
class Gu {
    scrapeMotionValuesFromProps(e, t, n) {
        return {};
    }
    constructor(
        {
            parent: e,
            props: t,
            presenceContext: n,
            reducedMotionConfig: r,
            blockInitialAnimation: o,
            visualState: i,
        },
        s = {}
    ) {
        (this.current = null),
            (this.children = new Set()),
            (this.isVariantNode = !1),
            (this.isControllingVariants = !1),
            (this.shouldReduceMotion = null),
            (this.values = new Map()),
            (this.KeyframeResolver = Al),
            (this.features = {}),
            (this.valueSubscriptions = new Map()),
            (this.prevMotionValues = {}),
            (this.events = {}),
            (this.propEventSubscriptions = {}),
            (this.notifyUpdate = () =>
                this.notify("Update", this.latestValues)),
            (this.render = () => {
                this.current &&
                    (this.triggerBuild(),
                    this.renderInstance(
                        this.current,
                        this.renderState,
                        this.props.style,
                        this.projection
                    ));
            }),
            (this.renderScheduledAt = 0),
            (this.scheduleRender = () => {
                const e = As.now();
                this.renderScheduledAt < e &&
                    ((this.renderScheduledAt = e),
                    Cs.render(this.render, !1, !0));
            });
        const { latestValues: a, renderState: l } = i;
        (this.latestValues = a),
            (this.baseTarget = { ...a }),
            (this.initialValues = t.initial ? { ...a } : {}),
            (this.renderState = l),
            (this.parent = e),
            (this.props = t),
            (this.presenceContext = n),
            (this.depth = e ? e.depth + 1 : 0),
            (this.reducedMotionConfig = r),
            (this.options = s),
            (this.blockInitialAnimation = Boolean(o)),
            (this.isControllingVariants = Uc(t)),
            (this.isVariantNode = Zc(t)),
            this.isVariantNode && (this.variantChildren = new Set()),
            (this.manuallyAnimateOnMount = Boolean(e && e.current));
        const { willChange: c, ...u } = this.scrapeMotionValuesFromProps(
            t,
            {},
            this
        );
        for (const d in u) {
            const e = u[d];
            void 0 !== a[d] && Tc(e) && e.set(a[d]);
        }
    }
    mount(e) {
        (this.current = e),
            Yu.set(e, this),
            this.projection &&
                !this.projection.instance &&
                this.projection.mount(e),
            this.parent &&
                this.isVariantNode &&
                !this.isControllingVariants &&
                (this.removeFromVariantTree =
                    this.parent.addVariantChild(this)),
            this.values.forEach((e, t) => this.bindToMotionValue(t, e)),
            Ku.current ||
                (function () {
                    if (((Ku.current = !0), Ri))
                        if (window.matchMedia) {
                            const e = window.matchMedia(
                                    "(prefers-reduced-motion)"
                                ),
                                t = () => (qu.current = e.matches);
                            e.addEventListener("change", t), t();
                        } else qu.current = !1;
                })(),
            (this.shouldReduceMotion =
                "never" !== this.reducedMotionConfig &&
                ("always" === this.reducedMotionConfig || qu.current)),
            this.parent?.addChild(this),
            this.update(this.props, this.presenceContext);
    }
    unmount() {
        this.projection && this.projection.unmount(),
            ws(this.notifyUpdate),
            ws(this.render),
            this.valueSubscriptions.forEach((e) => e()),
            this.valueSubscriptions.clear(),
            this.removeFromVariantTree && this.removeFromVariantTree(),
            this.parent?.removeChild(this);
        for (const e in this.events) this.events[e].clear();
        for (const e in this.features) {
            const t = this.features[e];
            t && (t.unmount(), (t.isMounted = !1));
        }
        this.current = null;
    }
    addChild(e) {
        this.children.add(e),
            this.enteringChildren ?? (this.enteringChildren = new Set()),
            this.enteringChildren.add(e);
    }
    removeChild(e) {
        this.children.delete(e),
            this.enteringChildren && this.enteringChildren.delete(e);
    }
    bindToMotionValue(e, t) {
        this.valueSubscriptions.has(e) && this.valueSubscriptions.get(e)();
        const n = ml.has(e);
        n && this.onBindTransform && this.onBindTransform();
        const r = t.on("change", (t) => {
            (this.latestValues[e] = t),
                this.props.onUpdate && Cs.preRender(this.notifyUpdate),
                n && this.projection && (this.projection.isTransformDirty = !0),
                this.scheduleRender();
        });
        let o;
        window.MotionCheckAppearSync &&
            (o = window.MotionCheckAppearSync(this, e, t)),
            this.valueSubscriptions.set(e, () => {
                r(), o && o(), t.owner && t.stop();
            });
    }
    sortNodePosition(e) {
        return this.current &&
            this.sortInstanceNodePosition &&
            this.type === e.type
            ? this.sortInstanceNodePosition(this.current, e.current)
            : 0;
    }
    updateFeatures() {
        let e = "animation";
        for (e in Nc) {
            const t = Nc[e];
            if (!t) continue;
            const { isEnabled: n, Feature: r } = t;
            if (
                (!this.features[e] &&
                    r &&
                    n(this.props) &&
                    (this.features[e] = new r(this)),
                this.features[e])
            ) {
                const t = this.features[e];
                t.isMounted ? t.update() : (t.mount(), (t.isMounted = !0));
            }
        }
    }
    triggerBuild() {
        this.build(this.renderState, this.latestValues, this.props);
    }
    measureViewportBox() {
        return this.current
            ? this.measureInstanceViewportBox(this.current, this.props)
            : { x: { min: 0, max: 0 }, y: { min: 0, max: 0 } };
    }
    getStaticValue(e) {
        return this.latestValues[e];
    }
    setStaticValue(e, t) {
        this.latestValues[e] = t;
    }
    update(e, t) {
        (e.transformTemplate || this.props.transformTemplate) &&
            this.scheduleRender(),
            (this.prevProps = this.props),
            (this.props = e),
            (this.prevPresenceContext = this.presenceContext),
            (this.presenceContext = t);
        for (let n = 0; n < Xu.length; n++) {
            const t = Xu[n];
            this.propEventSubscriptions[t] &&
                (this.propEventSubscriptions[t](),
                delete this.propEventSubscriptions[t]);
            const r = e["on" + t];
            r && (this.propEventSubscriptions[t] = this.on(t, r));
        }
        (this.prevMotionValues = (function (e, t, n) {
            for (const r in t) {
                const o = t[r],
                    i = n[r];
                if (Tc(o)) e.addValue(r, o);
                else if (Tc(i)) e.addValue(r, hc(o, { owner: e }));
                else if (i !== o)
                    if (e.hasValue(r)) {
                        const t = e.getValue(r);
                        !0 === t.liveStyle
                            ? t.jump(o)
                            : t.hasAnimated || t.set(o);
                    } else {
                        const t = e.getStaticValue(r);
                        e.addValue(r, hc(void 0 !== t ? t : o, { owner: e }));
                    }
            }
            for (const r in n) void 0 === t[r] && e.removeValue(r);
            return t;
        })(
            this,
            this.scrapeMotionValuesFromProps(e, this.prevProps, this),
            this.prevMotionValues
        )),
            this.handleChildMotionValue && this.handleChildMotionValue();
    }
    getProps() {
        return this.props;
    }
    getVariant(e) {
        return this.props.variants ? this.props.variants[e] : void 0;
    }
    getDefaultTransition() {
        return this.props.transition;
    }
    getTransformPagePoint() {
        return this.props.transformPagePoint;
    }
    getClosestVariantNode() {
        return this.isVariantNode
            ? this
            : this.parent
            ? this.parent.getClosestVariantNode()
            : void 0;
    }
    addVariantChild(e) {
        const t = this.getClosestVariantNode();
        if (t)
            return (
                t.variantChildren && t.variantChildren.add(e),
                () => t.variantChildren.delete(e)
            );
    }
    addValue(e, t) {
        const n = this.values.get(e);
        t !== n &&
            (n && this.removeValue(e),
            this.bindToMotionValue(e, t),
            this.values.set(e, t),
            (this.latestValues[e] = t.get()));
    }
    removeValue(e) {
        this.values.delete(e);
        const t = this.valueSubscriptions.get(e);
        t && (t(), this.valueSubscriptions.delete(e)),
            delete this.latestValues[e],
            this.removeValueFromRenderState(e, this.renderState);
    }
    hasValue(e) {
        return this.values.has(e);
    }
    getValue(e, t) {
        if (this.props.values && this.props.values[e])
            return this.props.values[e];
        let n = this.values.get(e);
        return (
            void 0 === n &&
                void 0 !== t &&
                ((n = hc(null === t ? void 0 : t, { owner: this })),
                this.addValue(e, n)),
            n
        );
    }
    readValue(e, t) {
        let n =
            void 0 === this.latestValues[e] && this.current
                ? this.getBaseTargetFromProps(this.props, e) ??
                  this.readValueFromInstance(this.current, e, this.options)
                : this.latestValues[e];
        var r;
        return (
            null != n &&
                ("string" == typeof n && (Zi(n) || $i(n))
                    ? (n = parseFloat(n))
                    : ((r = n),
                      !Lc.find(Yl(r)) && sa.test(t) && (n = ac(e, t))),
                this.setBaseTarget(e, Tc(n) ? n.get() : n)),
            Tc(n) ? n.get() : n
        );
    }
    setBaseTarget(e, t) {
        this.baseTarget[e] = t;
    }
    getBaseTarget(e) {
        const { initial: t } = this.props;
        let n;
        if ("string" == typeof t || "object" == typeof t) {
            const r = du(this.props, t, this.presenceContext?.custom);
            r && (n = r[e]);
        }
        if (t && void 0 !== n) return n;
        const r = this.getBaseTargetFromProps(this.props, e);
        return void 0 === r || Tc(r)
            ? void 0 !== this.initialValues[e] && void 0 === n
                ? void 0
                : this.baseTarget[e]
            : r;
    }
    on(e, t) {
        return (
            this.events[e] || (this.events[e] = new Gi()), this.events[e].add(t)
        );
    }
    notify(e, ...t) {
        this.events[e] && this.events[e].notify(...t);
    }
    scheduleRenderMicrotask() {
        pc.render(this.render);
    }
}
class Qu extends Gu {
    constructor() {
        super(...arguments), (this.KeyframeResolver = cc);
    }
    sortInstanceNodePosition(e, t) {
        return 2 & e.compareDocumentPosition(t) ? 1 : -1;
    }
    getBaseTargetFromProps(e, t) {
        return e.style ? e.style[t] : void 0;
    }
    removeValueFromRenderState(e, { vars: t, style: n }) {
        delete t[e], delete n[e];
    }
    handleChildMotionValue() {
        this.childSubscription &&
            (this.childSubscription(), delete this.childSubscription);
        const { children: e } = this.props;
        Tc(e) &&
            (this.childSubscription = e.on("change", (e) => {
                this.current && (this.current.textContent = `${e}`);
            }));
    }
}
function Ju(e, { style: t, vars: n }, r, o) {
    const i = e.style;
    let s;
    for (s in t) i[s] = t[s];
    for (s in (o?.applyProjectionStyles(i, r), n)) i.setProperty(s, n[s]);
}
class ed extends Qu {
    constructor() {
        super(...arguments), (this.type = "html"), (this.renderInstance = Ju);
    }
    readValueFromInstance(e, t) {
        if (ml.has(t))
            return this.projection?.isProjecting
                ? dl(t)
                : ((e, t) => {
                      const { transform: n = "none" } = getComputedStyle(e);
                      return hl(n, t);
                  })(e, t);
        {
            const r = ((n = e), window.getComputedStyle(n)),
                o = (Ls(t) ? r.getPropertyValue(t) : r[t]) || 0;
            return "string" == typeof o ? o.trim() : o;
        }
        var n;
    }
    measureInstanceViewportBox(e, { transformPagePoint: t }) {
        return $u(e, t);
    }
    build(e, t, n) {
        Xc(e, t, n.transformTemplate);
    }
    scrapeMotionValuesFromProps(e, t, n) {
        return mu(e, t, n);
    }
}
const td = new Set([
    "baseFrequency",
    "diffuseConstant",
    "kernelMatrix",
    "kernelUnitLength",
    "keySplines",
    "keyTimes",
    "limitingConeAngle",
    "markerHeight",
    "markerWidth",
    "numOctaves",
    "targetX",
    "targetY",
    "surfaceScale",
    "specularConstant",
    "specularExponent",
    "stdDeviation",
    "tableValues",
    "viewBox",
    "gradientTransform",
    "pathLength",
    "startOffset",
    "textLength",
    "lengthAdjust",
]);
class nd extends Qu {
    constructor() {
        super(...arguments),
            (this.type = "svg"),
            (this.isSVGTag = !1),
            (this.measureInstanceViewportBox = Wu);
    }
    getBaseTargetFromProps(e, t) {
        return e[t];
    }
    readValueFromInstance(e, t) {
        if (ml.has(t)) {
            const e = sc(t);
            return (e && e.default) || 0;
        }
        return (t = td.has(t) ? t : bu(t)), e.getAttribute(t);
    }
    scrapeMotionValuesFromProps(e, t, n) {
        return yu(e, t, n);
    }
    build(e, t, n) {
        ru(e, t, this.isSVGTag, n.transformTemplate, n.style);
    }
    renderInstance(e, t, n, r) {
        !(function (e, t, n, r) {
            Ju(e, t, void 0, r);
            for (const o in t.attrs)
                e.setAttribute(td.has(o) ? o : bu(o), t.attrs[o]);
        })(e, t, 0, r);
    }
    mount(e) {
        (this.isSVGTag = iu(e.tagName)), super.mount(e);
    }
}
const rd = (e, t) =>
    lu(e) ? new nd(t) : new ed(t, { allowProjection: e !== r.Fragment });
function od(e, t, n) {
    const r = e.getProps();
    return du(r, t, void 0 !== n ? n : r.custom, e);
}
const id = (e) => Array.isArray(e);
function sd(e, t, n) {
    e.hasValue(t) ? e.getValue(t).set(n) : e.addValue(t, hc(n));
}
function ad(e) {
    return id(e) ? e[e.length - 1] || 0 : e;
}
function ld(e, t) {
    const n = e.getValue("willChange");
    if (((r = n), Boolean(Tc(r) && r.add))) return n.add(t);
    if (!n && Ui.WillChange) {
        const n = new Ui.WillChange("auto");
        e.addValue("willChange", n), n.add(t);
    }
    var r;
}
function cd(e) {
    return e.props[ku];
}
const ud = (e) => null !== e;
const dd = { type: "spring", stiffness: 500, damping: 25, restSpeed: 10 },
    hd = { type: "keyframes", duration: 0.8 },
    pd = { type: "keyframes", ease: [0.25, 0.1, 0.35, 1], duration: 0.3 },
    fd = (e, { keyframes: t }) =>
        t.length > 2
            ? hd
            : ml.has(e)
            ? e.startsWith("scale")
                ? {
                      type: "spring",
                      stiffness: 550,
                      damping: 0 === t[1] ? 2 * Math.sqrt(550) : 30,
                      restSpeed: 10,
                  }
                : dd
            : pd;
const md =
    (e, t, n, r = {}, o, i) =>
    (s) => {
        const a = ql(r, e) || {},
            l = a.delay || r.delay || 0;
        let { elapsed: c = 0 } = r;
        c -= Qi(l);
        const u = {
            keyframes: Array.isArray(n) ? n : [null, n],
            ease: "easeOut",
            velocity: t.getVelocity(),
            ...a,
            delay: -c,
            onUpdate: (e) => {
                t.set(e), a.onUpdate && a.onUpdate(e);
            },
            onComplete: () => {
                s(), a.onComplete && a.onComplete();
            },
            name: e,
            motionValue: t,
            element: i ? void 0 : o,
        };
        (function ({
            when: e,
            delay: t,
            delayChildren: n,
            staggerChildren: r,
            staggerDirection: o,
            repeat: i,
            repeatType: s,
            repeatDelay: a,
            from: l,
            elapsed: c,
            ...u
        }) {
            return !!Object.keys(u).length;
        })(a) || Object.assign(u, fd(e, u)),
            u.duration && (u.duration = Qi(u.duration)),
            u.repeatDelay && (u.repeatDelay = Qi(u.repeatDelay)),
            void 0 !== u.from && (u.keyframes[0] = u.from);
        let d = !1;
        if (
            ((!1 === u.type || (0 === u.duration && !u.repeatDelay)) &&
                (Bl(u), 0 === u.delay && (d = !0)),
            (Ui.instantAnimations || Ui.skipAnimations) &&
                ((d = !0), Bl(u), (u.delay = 0)),
            (u.allowFlatten = !a.type && !a.ease),
            d && !i && void 0 !== t.get())
        ) {
            const e = (function (e, { repeat: t, repeatType: n = "loop" }) {
                const r = e.filter(ud);
                return r[t && "loop" !== n && t % 2 == 1 ? 0 : r.length - 1];
            })(u.keyframes, a);
            if (void 0 !== e)
                return void Cs.update(() => {
                    u.onUpdate(e), u.onComplete();
                });
        }
        return a.isSync ? new rl(u) : new zl(u);
    };
function gd({ protectedKeys: e, needsAnimating: t }, n) {
    const r = e.hasOwnProperty(n) && !0 !== t[n];
    return (t[n] = !1), r;
}
function yd(e, t, { delay: n = 0, transitionOverride: r, type: o } = {}) {
    let {
        transition: i = e.getDefaultTransition(),
        transitionEnd: s,
        ...a
    } = t;
    r && (i = r);
    const l = [],
        c = o && e.animationState && e.animationState.getState()[o];
    for (const u in a) {
        const t = e.getValue(u, e.latestValues[u] ?? null),
            r = a[u];
        if (void 0 === r || (c && gd(c, u))) continue;
        const o = { delay: n, ...ql(i || {}, u) },
            s = t.get();
        if (
            void 0 !== s &&
            !t.isAnimating &&
            !Array.isArray(r) &&
            r === s &&
            !o.velocity
        )
            continue;
        let d = !1;
        if (window.MotionHandoffAnimation) {
            const t = cd(e);
            if (t) {
                const e = window.MotionHandoffAnimation(t, u, Cs);
                null !== e && ((o.startTime = e), (d = !0));
            }
        }
        ld(e, u),
            t.start(
                md(
                    u,
                    t,
                    r,
                    e.shouldReduceMotion && Kl.has(u) ? { type: !1 } : o,
                    e,
                    d
                )
            );
        const h = t.animation;
        h && l.push(h);
    }
    return (
        s &&
            Promise.all(l).then(() => {
                Cs.update(() => {
                    s &&
                        (function (e, t) {
                            const n = od(e, t);
                            let {
                                transitionEnd: r = {},
                                transition: o = {},
                                ...i
                            } = n || {};
                            i = { ...i, ...r };
                            for (const s in i) sd(e, s, ad(i[s]));
                        })(e, s);
                });
            }),
        l
    );
}
function xd(e, t, n, r = 0, o = 1) {
    const i = Array.from(e)
            .sort((e, t) => e.sortNodePosition(t))
            .indexOf(t),
        s = e.size,
        a = (s - 1) * r;
    return "function" == typeof n ? n(i, s) : 1 === o ? i * r : a - i * r;
}
function vd(e, t, n = {}) {
    const r = od(e, t, "exit" === n.type ? e.presenceContext?.custom : void 0);
    let { transition: o = e.getDefaultTransition() || {} } = r || {};
    n.transitionOverride && (o = n.transitionOverride);
    const i = r ? () => Promise.all(yd(e, r, n)) : () => Promise.resolve(),
        s =
            e.variantChildren && e.variantChildren.size
                ? (r = 0) => {
                      const {
                          delayChildren: i = 0,
                          staggerChildren: s,
                          staggerDirection: a,
                      } = o;
                      return (function (e, t, n = 0, r = 0, o = 0, i = 1, s) {
                          const a = [];
                          for (const l of e.variantChildren)
                              l.notify("AnimationStart", t),
                                  a.push(
                                      vd(l, t, {
                                          ...s,
                                          delay:
                                              n +
                                              ("function" == typeof r ? 0 : r) +
                                              xd(e.variantChildren, l, r, o, i),
                                      }).then(() =>
                                          l.notify("AnimationComplete", t)
                                      )
                                  );
                          return Promise.all(a);
                      })(e, t, r, i, s, a, n);
                  }
                : () => Promise.resolve(),
        { when: a } = o;
    if (a) {
        const [e, t] = "beforeChildren" === a ? [i, s] : [s, i];
        return e().then(() => t());
    }
    return Promise.all([i(), s(n.delay)]);
}
function Cd(e, t) {
    if (!Array.isArray(t)) return !1;
    const n = t.length;
    if (n !== e.length) return !1;
    for (let r = 0; r < n; r++) if (t[r] !== e[r]) return !1;
    return !0;
}
const wd = Bc.length;
function bd(e) {
    if (!e) return;
    if (!e.isControllingVariants) {
        const t = (e.parent && bd(e.parent)) || {};
        return void 0 !== e.props.initial && (t.initial = e.props.initial), t;
    }
    const t = {};
    for (let n = 0; n < wd; n++) {
        const r = Bc[n],
            o = e.props[r];
        (Hc(o) || !1 === o) && (t[r] = o);
    }
    return t;
}
const kd = [...Fc].reverse(),
    Ed = Fc.length;
function Sd(e) {
    return (t) =>
        Promise.all(
            t.map(({ animation: t, options: n }) =>
                (function (e, t, n = {}) {
                    let r;
                    if ((e.notify("AnimationStart", t), Array.isArray(t))) {
                        const o = t.map((t) => vd(e, t, n));
                        r = Promise.all(o);
                    } else if ("string" == typeof t) r = vd(e, t, n);
                    else {
                        const o =
                            "function" == typeof t ? od(e, t, n.custom) : t;
                        r = Promise.all(yd(e, o, n));
                    }
                    return r.then(() => {
                        e.notify("AnimationComplete", t);
                    });
                })(e, t, n)
            )
        );
}
function Ad(e) {
    let t = Sd(e),
        n = Md(),
        r = !0;
    const o = (t) => (n, r) => {
        const o = od(e, r, "exit" === t ? e.presenceContext?.custom : void 0);
        if (o) {
            const { transition: e, transitionEnd: t, ...r } = o;
            n = { ...n, ...r, ...t };
        }
        return n;
    };
    function i(i) {
        const { props: s } = e,
            a = bd(e.parent) || {},
            l = [],
            c = new Set();
        let u = {},
            d = 1 / 0;
        for (let t = 0; t < Ed; t++) {
            const h = kd[t],
                p = n[h],
                f = void 0 !== s[h] ? s[h] : a[h],
                m = Hc(f),
                g = h === i ? p.isActive : null;
            !1 === g && (d = t);
            let y = f === a[h] && f !== s[h] && m;
            if (
                (y && r && e.manuallyAnimateOnMount && (y = !1),
                (p.protectedKeys = { ...u }),
                (!p.isActive && null === g) ||
                    (!f && !p.prevProp) ||
                    Oc(f) ||
                    "boolean" == typeof f)
            )
                continue;
            const x = Td(p.prevProp, f);
            let v = x || (h === i && p.isActive && !y && m) || (t > d && m),
                C = !1;
            const w = Array.isArray(f) ? f : [f];
            let b = w.reduce(o(h), {});
            !1 === g && (b = {});
            const { prevResolvedValues: k = {} } = p,
                E = { ...k, ...b },
                S = (t) => {
                    (v = !0),
                        c.has(t) && ((C = !0), c.delete(t)),
                        (p.needsAnimating[t] = !0);
                    const n = e.getValue(t);
                    n && (n.liveStyle = !1);
                };
            for (const e in E) {
                const t = b[e],
                    n = k[e];
                if (u.hasOwnProperty(e)) continue;
                let r = !1;
                (r = id(t) && id(n) ? !Cd(t, n) : t !== n),
                    r
                        ? null != t
                            ? S(e)
                            : c.add(e)
                        : void 0 !== t && c.has(e)
                        ? S(e)
                        : (p.protectedKeys[e] = !0);
            }
            (p.prevProp = f),
                (p.prevResolvedValues = b),
                p.isActive && (u = { ...u, ...b }),
                r && e.blockInitialAnimation && (v = !1);
            const A = y && x;
            v &&
                (!A || C) &&
                l.push(
                    ...w.map((t) => {
                        const n = { type: h };
                        if (
                            "string" == typeof t &&
                            r &&
                            !A &&
                            e.manuallyAnimateOnMount &&
                            e.parent
                        ) {
                            const { parent: r } = e,
                                o = od(r, t);
                            if (r.enteringChildren && o) {
                                const { delayChildren: t } = o.transition || {};
                                n.delay = xd(r.enteringChildren, e, t);
                            }
                        }
                        return { animation: t, options: n };
                    })
                );
        }
        if (c.size) {
            const t = {};
            if ("boolean" != typeof s.initial) {
                const n = od(
                    e,
                    Array.isArray(s.initial) ? s.initial[0] : s.initial
                );
                n && n.transition && (t.transition = n.transition);
            }
            c.forEach((n) => {
                const r = e.getBaseTarget(n),
                    o = e.getValue(n);
                o && (o.liveStyle = !0), (t[n] = r ?? null);
            }),
                l.push({ animation: t });
        }
        let h = Boolean(l.length);
        return (
            !r ||
                (!1 !== s.initial && s.initial !== s.animate) ||
                e.manuallyAnimateOnMount ||
                (h = !1),
            (r = !1),
            h ? t(l) : Promise.resolve()
        );
    }
    return {
        animateChanges: i,
        setActive: function (t, r) {
            if (n[t].isActive === r) return Promise.resolve();
            e.variantChildren?.forEach((e) =>
                e.animationState?.setActive(t, r)
            ),
                (n[t].isActive = r);
            const o = i(t);
            for (const e in n) n[e].protectedKeys = {};
            return o;
        },
        setAnimateFunction: function (n) {
            t = n(e);
        },
        getState: () => n,
        reset: () => {
            (n = Md()), (r = !0);
        },
    };
}
function Td(e, t) {
    return "string" == typeof t ? t !== e : !!Array.isArray(t) && !Cd(t, e);
}
function Ld(e = !1) {
    return {
        isActive: e,
        protectedKeys: {},
        needsAnimating: {},
        prevResolvedValues: {},
    };
}
function Md() {
    return {
        animate: Ld(!0),
        whileInView: Ld(),
        whileHover: Ld(),
        whileTap: Ld(),
        whileDrag: Ld(),
        whileFocus: Ld(),
        exit: Ld(),
    };
}
class Pd {
    constructor(e) {
        (this.isMounted = !1), (this.node = e);
    }
    update() {}
}
let jd = 0;
const Nd = {
    animation: {
        Feature: class extends Pd {
            constructor(e) {
                super(e), e.animationState || (e.animationState = Ad(e));
            }
            updateAnimationControlsSubscription() {
                const { animate: e } = this.node.getProps();
                Oc(e) && (this.unmountControls = e.subscribe(this.node));
            }
            mount() {
                this.updateAnimationControlsSubscription();
            }
            update() {
                const { animate: e } = this.node.getProps(),
                    { animate: t } = this.node.prevProps || {};
                e !== t && this.updateAnimationControlsSubscription();
            }
            unmount() {
                this.node.animationState.reset(), this.unmountControls?.();
            }
        },
    },
    exit: {
        Feature: class extends Pd {
            constructor() {
                super(...arguments), (this.id = jd++);
            }
            update() {
                if (!this.node.presenceContext) return;
                const { isPresent: e, onExitComplete: t } =
                        this.node.presenceContext,
                    { isPresent: n } = this.node.prevPresenceContext || {};
                if (!this.node.animationState || e === n) return;
                const r = this.node.animationState.setActive("exit", !e);
                t &&
                    !e &&
                    r.then(() => {
                        t(this.id);
                    });
            }
            mount() {
                const { register: e, onExitComplete: t } =
                    this.node.presenceContext || {};
                t && t(this.id), e && (this.unmount = e(this.id));
            }
            unmount() {}
        },
    },
};
function Id(e, t, n, r = { passive: !0 }) {
    return e.addEventListener(t, n, r), () => e.removeEventListener(t, n);
}
function Dd(e) {
    return { point: { x: e.pageX, y: e.pageY } };
}
function Vd(e, t, n, r) {
    return Id(
        e,
        t,
        (
            (e) => (t) =>
                vc(t) && e(t, Dd(t))
        )(n),
        r
    );
}
function Rd(e) {
    return e.max - e.min;
}
function _d(e, t, n, r = 0.5) {
    (e.origin = r),
        (e.originPoint = ca(t.min, t.max, e.origin)),
        (e.scale = Rd(n) / Rd(t)),
        (e.translate = ca(n.min, n.max, e.origin) - e.originPoint),
        ((e.scale >= 0.9999 && e.scale <= 1.0001) || isNaN(e.scale)) &&
            (e.scale = 1),
        ((e.translate >= -0.01 && e.translate <= 0.01) || isNaN(e.translate)) &&
            (e.translate = 0);
}
function Od(e, t, n, r) {
    _d(e.x, t.x, n.x, r ? r.originX : void 0),
        _d(e.y, t.y, n.y, r ? r.originY : void 0);
}
function Hd(e, t, n) {
    (e.min = n.min + t.min), (e.max = e.min + Rd(t));
}
function Fd(e, t, n) {
    (e.min = t.min - n.min), (e.max = e.min + Rd(t));
}
function Bd(e, t, n) {
    Fd(e.x, t.x, n.x), Fd(e.y, t.y, n.y);
}
function Ud(e) {
    return [e("x"), e("y")];
}
const Zd = ({ current: e }) => (e ? e.ownerDocument.defaultView : null),
    zd = (e, t) => Math.abs(e - t);
class $d {
    constructor(
        e,
        t,
        {
            transformPagePoint: n,
            contextWindow: r = window,
            dragSnapToOrigin: o = !1,
            distanceThreshold: i = 3,
        } = {}
    ) {
        if (
            ((this.startEvent = null),
            (this.lastMoveEvent = null),
            (this.lastMoveEventInfo = null),
            (this.handlers = {}),
            (this.contextWindow = window),
            (this.updatePoint = () => {
                if (!this.lastMoveEvent || !this.lastMoveEventInfo) return;
                const e = Kd(this.lastMoveEventInfo, this.history),
                    t = null !== this.startEvent,
                    n =
                        (function (e, t) {
                            const n = zd(e.x, t.x),
                                r = zd(e.y, t.y);
                            return Math.sqrt(n ** 2 + r ** 2);
                        })(e.offset, { x: 0, y: 0 }) >= this.distanceThreshold;
                if (!t && !n) return;
                const { point: r } = e,
                    { timestamp: o } = bs;
                this.history.push({ ...r, timestamp: o });
                const { onStart: i, onMove: s } = this.handlers;
                t ||
                    (i && i(this.lastMoveEvent, e),
                    (this.startEvent = this.lastMoveEvent)),
                    s && s(this.lastMoveEvent, e);
            }),
            (this.handlePointerMove = (e, t) => {
                (this.lastMoveEvent = e),
                    (this.lastMoveEventInfo = Wd(t, this.transformPagePoint)),
                    Cs.update(this.updatePoint, !0);
            }),
            (this.handlePointerUp = (e, t) => {
                this.end();
                const {
                    onEnd: n,
                    onSessionEnd: r,
                    resumeAnimation: o,
                } = this.handlers;
                if (
                    (this.dragSnapToOrigin && o && o(),
                    !this.lastMoveEvent || !this.lastMoveEventInfo)
                )
                    return;
                const i = Kd(
                    "pointercancel" === e.type
                        ? this.lastMoveEventInfo
                        : Wd(t, this.transformPagePoint),
                    this.history
                );
                this.startEvent && n && n(e, i), r && r(e, i);
            }),
            !vc(e))
        )
            return;
        (this.dragSnapToOrigin = o),
            (this.handlers = t),
            (this.transformPagePoint = n),
            (this.distanceThreshold = i),
            (this.contextWindow = r || window);
        const s = Wd(Dd(e), this.transformPagePoint),
            { point: a } = s,
            { timestamp: l } = bs;
        this.history = [{ ...a, timestamp: l }];
        const { onSessionStart: c } = t;
        c && c(e, Kd(s, this.history)),
            (this.removeListeners = Yi(
                Vd(this.contextWindow, "pointermove", this.handlePointerMove),
                Vd(this.contextWindow, "pointerup", this.handlePointerUp),
                Vd(this.contextWindow, "pointercancel", this.handlePointerUp)
            ));
    }
    updateHandlers(e) {
        this.handlers = e;
    }
    end() {
        this.removeListeners && this.removeListeners(), ws(this.updatePoint);
    }
}
function Wd(e, t) {
    return t ? { point: t(e.point) } : e;
}
function qd(e, t) {
    return { x: e.x - t.x, y: e.y - t.y };
}
function Kd({ point: e }, t) {
    return {
        point: e,
        delta: qd(e, Xd(t)),
        offset: qd(e, Yd(t)),
        velocity: Gd(t, 0.1),
    };
}
function Yd(e) {
    return e[0];
}
function Xd(e) {
    return e[e.length - 1];
}
function Gd(e, t) {
    if (e.length < 2) return { x: 0, y: 0 };
    let n = e.length - 1,
        r = null;
    const o = Xd(e);
    for (; n >= 0 && ((r = e[n]), !(o.timestamp - r.timestamp > Qi(t))); ) n--;
    if (!r) return { x: 0, y: 0 };
    const i = Ji(o.timestamp - r.timestamp);
    if (0 === i) return { x: 0, y: 0 };
    const s = { x: (o.x - r.x) / i, y: (o.y - r.y) / i };
    return s.x === 1 / 0 && (s.x = 0), s.y === 1 / 0 && (s.y = 0), s;
}
function Qd(e, t, n) {
    return {
        min: void 0 !== t ? e.min + t : void 0,
        max: void 0 !== n ? e.max + n - (e.max - e.min) : void 0,
    };
}
function Jd(e, t) {
    let n = t.min - e.min,
        r = t.max - e.max;
    return (
        t.max - t.min < e.max - e.min && ([n, r] = [r, n]), { min: n, max: r }
    );
}
const eh = 0.35;
function th(e, t, n) {
    return { min: nh(e, t), max: nh(e, n) };
}
function nh(e, t) {
    return "number" == typeof e ? e : e[t] || 0;
}
const rh = new WeakMap();
class oh {
    constructor(e) {
        (this.openDragLock = null),
            (this.isDragging = !1),
            (this.currentDirection = null),
            (this.originPoint = { x: 0, y: 0 }),
            (this.constraints = !1),
            (this.hasMutatedConstraints = !1),
            (this.elastic = { x: { min: 0, max: 0 }, y: { min: 0, max: 0 } }),
            (this.latestPointerEvent = null),
            (this.latestPanInfo = null),
            (this.visualElement = e);
    }
    start(e, { snapToCursor: t = !1, distanceThreshold: n } = {}) {
        const { presenceContext: r } = this.visualElement;
        if (r && !1 === r.isPresent) return;
        const { dragSnapToOrigin: o } = this.getProps();
        this.panSession = new $d(
            e,
            {
                onSessionStart: (e) => {
                    const { dragSnapToOrigin: n } = this.getProps();
                    n ? this.pauseAnimation() : this.stopAnimation(),
                        t && this.snapToCursor(Dd(e).point);
                },
                onStart: (e, t) => {
                    const {
                        drag: n,
                        dragPropagation: r,
                        onDragStart: o,
                    } = this.getProps();
                    if (
                        n &&
                        !r &&
                        (this.openDragLock && this.openDragLock(),
                        (this.openDragLock =
                            "x" === (i = n) || "y" === i
                                ? fc[i]
                                    ? null
                                    : ((fc[i] = !0),
                                      () => {
                                          fc[i] = !1;
                                      })
                                : fc.x || fc.y
                                ? null
                                : ((fc.x = fc.y = !0),
                                  () => {
                                      fc.x = fc.y = !1;
                                  })),
                        !this.openDragLock)
                    )
                        return;
                    var i;
                    (this.latestPointerEvent = e),
                        (this.latestPanInfo = t),
                        (this.isDragging = !0),
                        (this.currentDirection = null),
                        this.resolveConstraints(),
                        this.visualElement.projection &&
                            ((this.visualElement.projection.isAnimationBlocked =
                                !0),
                            (this.visualElement.projection.target = void 0)),
                        Ud((e) => {
                            let t = this.getAxisMotionValue(e).get() || 0;
                            if ($s.test(t)) {
                                const { projection: n } = this.visualElement;
                                if (n && n.layout) {
                                    const r = n.layout.layoutBox[e];
                                    if (r) {
                                        t = Rd(r) * (parseFloat(t) / 100);
                                    }
                                }
                            }
                            this.originPoint[e] = t;
                        }),
                        o && Cs.postRender(() => o(e, t)),
                        ld(this.visualElement, "transform");
                    const { animationState: s } = this.visualElement;
                    s && s.setActive("whileDrag", !0);
                },
                onMove: (e, t) => {
                    (this.latestPointerEvent = e), (this.latestPanInfo = t);
                    const {
                        dragPropagation: n,
                        dragDirectionLock: r,
                        onDirectionLock: o,
                        onDrag: i,
                    } = this.getProps();
                    if (!n && !this.openDragLock) return;
                    const { offset: s } = t;
                    if (r && null === this.currentDirection)
                        return (
                            (this.currentDirection = (function (e, t = 10) {
                                let n = null;
                                Math.abs(e.y) > t
                                    ? (n = "y")
                                    : Math.abs(e.x) > t && (n = "x");
                                return n;
                            })(s)),
                            void (
                                null !== this.currentDirection &&
                                o &&
                                o(this.currentDirection)
                            )
                        );
                    this.updateAxis("x", t.point, s),
                        this.updateAxis("y", t.point, s),
                        this.visualElement.render(),
                        i && i(e, t);
                },
                onSessionEnd: (e, t) => {
                    (this.latestPointerEvent = e),
                        (this.latestPanInfo = t),
                        this.stop(e, t),
                        (this.latestPointerEvent = null),
                        (this.latestPanInfo = null);
                },
                resumeAnimation: () =>
                    Ud(
                        (e) =>
                            "paused" === this.getAnimationState(e) &&
                            this.getAxisMotionValue(e).animation?.play()
                    ),
            },
            {
                transformPagePoint: this.visualElement.getTransformPagePoint(),
                dragSnapToOrigin: o,
                distanceThreshold: n,
                contextWindow: Zd(this.visualElement),
            }
        );
    }
    stop(e, t) {
        const n = e || this.latestPointerEvent,
            r = t || this.latestPanInfo,
            o = this.isDragging;
        if ((this.cancel(), !o || !r || !n)) return;
        const { velocity: i } = r;
        this.startAnimation(i);
        const { onDragEnd: s } = this.getProps();
        s && Cs.postRender(() => s(n, r));
    }
    cancel() {
        this.isDragging = !1;
        const { projection: e, animationState: t } = this.visualElement;
        e && (e.isAnimationBlocked = !1),
            this.panSession && this.panSession.end(),
            (this.panSession = void 0);
        const { dragPropagation: n } = this.getProps();
        !n &&
            this.openDragLock &&
            (this.openDragLock(), (this.openDragLock = null)),
            t && t.setActive("whileDrag", !1);
    }
    updateAxis(e, t, n) {
        const { drag: r } = this.getProps();
        if (!n || !ih(e, r, this.currentDirection)) return;
        const o = this.getAxisMotionValue(e);
        let i = this.originPoint[e] + n[e];
        this.constraints &&
            this.constraints[e] &&
            (i = (function (e, { min: t, max: n }, r) {
                return (
                    void 0 !== t && e < t
                        ? (e = r ? ca(t, e, r.min) : Math.max(e, t))
                        : void 0 !== n &&
                          e > n &&
                          (e = r ? ca(n, e, r.max) : Math.min(e, n)),
                    e
                );
            })(i, this.constraints[e], this.elastic[e])),
            o.set(i);
    }
    resolveConstraints() {
        const { dragConstraints: e, dragElastic: t } = this.getProps(),
            n =
                this.visualElement.projection &&
                !this.visualElement.projection.layout
                    ? this.visualElement.projection.measure(!1)
                    : this.visualElement.projection?.layout,
            r = this.constraints;
        e && Cu(e)
            ? this.constraints ||
              (this.constraints = this.resolveRefConstraints())
            : (this.constraints =
                  !(!e || !n) &&
                  (function (e, { top: t, left: n, bottom: r, right: o }) {
                      return { x: Qd(e.x, n, o), y: Qd(e.y, t, r) };
                  })(n.layoutBox, e)),
            (this.elastic = (function (e = eh) {
                return (
                    !1 === e ? (e = 0) : !0 === e && (e = eh),
                    { x: th(e, "left", "right"), y: th(e, "top", "bottom") }
                );
            })(t)),
            r !== this.constraints &&
                n &&
                this.constraints &&
                !this.hasMutatedConstraints &&
                Ud((e) => {
                    !1 !== this.constraints &&
                        this.getAxisMotionValue(e) &&
                        (this.constraints[e] = (function (e, t) {
                            const n = {};
                            return (
                                void 0 !== t.min && (n.min = t.min - e.min),
                                void 0 !== t.max && (n.max = t.max - e.min),
                                n
                            );
                        })(n.layoutBox[e], this.constraints[e]));
                });
    }
    resolveRefConstraints() {
        const { dragConstraints: e, onMeasureDragConstraints: t } =
            this.getProps();
        if (!e || !Cu(e)) return !1;
        const n = e.current,
            { projection: r } = this.visualElement;
        if (!r || !r.layout) return !1;
        const o = (function (e, t, n) {
            const r = $u(e, n),
                { scroll: o } = t;
            return o && (Uu(r.x, o.offset.x), Uu(r.y, o.offset.y)), r;
        })(n, r.root, this.visualElement.getTransformPagePoint());
        let i = (function (e, t) {
            return { x: Jd(e.x, t.x), y: Jd(e.y, t.y) };
        })(r.layout.layoutBox, o);
        if (t) {
            const e = t(
                (function ({ x: e, y: t }) {
                    return {
                        top: t.min,
                        right: e.max,
                        bottom: t.max,
                        left: e.min,
                    };
                })(i)
            );
            (this.hasMutatedConstraints = !!e), e && (i = Pu(e));
        }
        return i;
    }
    startAnimation(e) {
        const {
                drag: t,
                dragMomentum: n,
                dragElastic: r,
                dragTransition: o,
                dragSnapToOrigin: i,
                onDragTransitionEnd: s,
            } = this.getProps(),
            a = this.constraints || {},
            l = Ud((s) => {
                if (!ih(s, t, this.currentDirection)) return;
                let l = (a && a[s]) || {};
                i && (l = { min: 0, max: 0 });
                const c = r ? 200 : 1e6,
                    u = r ? 40 : 1e7,
                    d = {
                        type: "inertia",
                        velocity: n ? e[s] : 0,
                        bounceStiffness: c,
                        bounceDamping: u,
                        timeConstant: 750,
                        restDelta: 1,
                        restSpeed: 10,
                        ...o,
                        ...l,
                    };
                return this.startAxisValueAnimation(s, d);
            });
        return Promise.all(l).then(s);
    }
    startAxisValueAnimation(e, t) {
        const n = this.getAxisMotionValue(e);
        return (
            ld(this.visualElement, e),
            n.start(md(e, n, 0, t, this.visualElement, !1))
        );
    }
    stopAnimation() {
        Ud((e) => this.getAxisMotionValue(e).stop());
    }
    pauseAnimation() {
        Ud((e) => this.getAxisMotionValue(e).animation?.pause());
    }
    getAnimationState(e) {
        return this.getAxisMotionValue(e).animation?.state;
    }
    getAxisMotionValue(e) {
        const t = `_drag${e.toUpperCase()}`,
            n = this.visualElement.getProps(),
            r = n[t];
        return (
            r ||
            this.visualElement.getValue(
                e,
                (n.initial ? n.initial[e] : void 0) || 0
            )
        );
    }
    snapToCursor(e) {
        Ud((t) => {
            const { drag: n } = this.getProps();
            if (!ih(t, n, this.currentDirection)) return;
            const { projection: r } = this.visualElement,
                o = this.getAxisMotionValue(t);
            if (r && r.layout) {
                const { min: n, max: i } = r.layout.layoutBox[t];
                o.set(e[t] - ca(n, i, 0.5));
            }
        });
    }
    scalePositionWithinConstraints() {
        if (!this.visualElement.current) return;
        const { drag: e, dragConstraints: t } = this.getProps(),
            { projection: n } = this.visualElement;
        if (!Cu(t) || !n || !this.constraints) return;
        this.stopAnimation();
        const r = { x: 0, y: 0 };
        Ud((e) => {
            const t = this.getAxisMotionValue(e);
            if (t && !1 !== this.constraints) {
                const n = t.get();
                r[e] = (function (e, t) {
                    let n = 0.5;
                    const r = Rd(e),
                        o = Rd(t);
                    return (
                        o > r
                            ? (n = Xi(t.min, t.max - r, e.min))
                            : r > o && (n = Xi(e.min, e.max - o, t.min)),
                        Bi(0, 1, n)
                    );
                })({ min: n, max: n }, this.constraints[e]);
            }
        });
        const { transformTemplate: o } = this.visualElement.getProps();
        (this.visualElement.current.style.transform = o ? o({}, "") : "none"),
            n.root && n.root.updateScroll(),
            n.updateLayout(),
            this.resolveConstraints(),
            Ud((t) => {
                if (!ih(t, e, null)) return;
                const n = this.getAxisMotionValue(t),
                    { min: o, max: i } = this.constraints[t];
                n.set(ca(o, i, r[t]));
            });
    }
    addListeners() {
        if (!this.visualElement.current) return;
        rh.set(this.visualElement, this);
        const e = Vd(this.visualElement.current, "pointerdown", (e) => {
                const { drag: t, dragListener: n = !0 } = this.getProps();
                t && n && this.start(e);
            }),
            t = () => {
                const { dragConstraints: e } = this.getProps();
                Cu(e) &&
                    e.current &&
                    (this.constraints = this.resolveRefConstraints());
            },
            { projection: n } = this.visualElement,
            r = n.addEventListener("measure", t);
        n && !n.layout && (n.root && n.root.updateScroll(), n.updateLayout()),
            Cs.read(t);
        const o = Id(window, "resize", () =>
                this.scalePositionWithinConstraints()
            ),
            i = n.addEventListener(
                "didUpdate",
                ({ delta: e, hasLayoutChanged: t }) => {
                    this.isDragging &&
                        t &&
                        (Ud((t) => {
                            const n = this.getAxisMotionValue(t);
                            n &&
                                ((this.originPoint[t] += e[t].translate),
                                n.set(n.get() + e[t].translate));
                        }),
                        this.visualElement.render());
                }
            );
        return () => {
            o(), e(), r(), i && i();
        };
    }
    getProps() {
        const e = this.visualElement.getProps(),
            {
                drag: t = !1,
                dragDirectionLock: n = !1,
                dragPropagation: r = !1,
                dragConstraints: o = !1,
                dragElastic: i = eh,
                dragMomentum: s = !0,
            } = e;
        return {
            ...e,
            drag: t,
            dragDirectionLock: n,
            dragPropagation: r,
            dragConstraints: o,
            dragElastic: i,
            dragMomentum: s,
        };
    }
}
function ih(e, t, n) {
    return !((!0 !== t && t !== e) || (null !== n && n !== e));
}
const sh = (e) => (t, n) => {
    e && Cs.postRender(() => e(t, n));
};
const ah = { hasAnimatedSinceResize: !0, hasEverUpdated: !1 };
function lh(e, t) {
    return t.max === t.min ? 0 : (e / (t.max - t.min)) * 100;
}
const ch = {
        correct: (e, t) => {
            if (!t.target) return e;
            if ("string" == typeof e) {
                if (!Ws.test(e)) return e;
                e = parseFloat(e);
            }
            return `${lh(e, t.target.x)}% ${lh(e, t.target.y)}%`;
        },
    },
    uh = {
        correct: (e, { treeScale: t, projectionDelta: n }) => {
            const r = e,
                o = sa.parse(e);
            if (o.length > 5) return r;
            const i = sa.createTransformer(e),
                s = "number" != typeof o[0] ? 1 : 0,
                a = n.x.scale * t.x,
                l = n.y.scale * t.y;
            (o[0 + s] /= a), (o[1 + s] /= l);
            const c = ca(a, l, 0.5);
            return (
                "number" == typeof o[2 + s] && (o[2 + s] /= c),
                "number" == typeof o[3 + s] && (o[3 + s] /= c),
                i(o)
            );
        },
    };
let dh = !1;
class hh extends r.Component {
    componentDidMount() {
        const {
                visualElement: e,
                layoutGroup: t,
                switchLayoutGroup: n,
                layoutId: r,
            } = this.props,
            { projection: o } = e;
        !(function (e) {
            for (const t in e)
                (Wc[t] = e[t]), Ls(t) && (Wc[t].isCSSVariable = !0);
        })(fh),
            o &&
                (t.group && t.group.add(o),
                n && n.register && r && n.register(o),
                dh && o.root.didUpdate(),
                o.addEventListener("animationComplete", () => {
                    this.safeToRemove();
                }),
                o.setOptions({
                    ...o.options,
                    onExitComplete: () => this.safeToRemove(),
                })),
            (ah.hasEverUpdated = !0);
    }
    getSnapshotBeforeUpdate(e) {
        const {
                layoutDependency: t,
                visualElement: n,
                drag: r,
                isPresent: o,
            } = this.props,
            { projection: i } = n;
        return i
            ? ((i.isPresent = o),
              (dh = !0),
              r || e.layoutDependency !== t || void 0 === t || e.isPresent !== o
                  ? i.willUpdate()
                  : this.safeToRemove(),
              e.isPresent !== o &&
                  (o
                      ? i.promote()
                      : i.relegate() ||
                        Cs.postRender(() => {
                            const e = i.getStack();
                            (e && e.members.length) || this.safeToRemove();
                        })),
              null)
            : null;
    }
    componentDidUpdate() {
        const { projection: e } = this.props.visualElement;
        e &&
            (e.root.didUpdate(),
            pc.postRender(() => {
                !e.currentAnimation && e.isLead() && this.safeToRemove();
            }));
    }
    componentWillUnmount() {
        const {
                visualElement: e,
                layoutGroup: t,
                switchLayoutGroup: n,
            } = this.props,
            { projection: r } = e;
        (dh = !0),
            r &&
                (r.scheduleCheckAfterUnmount(),
                t && t.group && t.group.remove(r),
                n && n.deregister && n.deregister(r));
    }
    safeToRemove() {
        const { safeToRemove: e } = this.props;
        e && e();
    }
    render() {
        return null;
    }
}
function ph(e) {
    const [t, n] = (function (e = !0) {
            const t = r.useContext(Oi);
            if (null === t) return [!0, null];
            const { isPresent: n, onExitComplete: o, register: i } = t,
                s = r.useId();
            r.useEffect(() => {
                if (e) return i(s);
            }, [e]);
            const a = r.useCallback(() => e && o && o(s), [s, o, e]);
            return !n && o ? [!1, a] : [!0];
        })(),
        o = r.useContext(Vi);
    return a.jsx(hh, {
        ...e,
        layoutGroup: o,
        switchLayoutGroup: r.useContext(Eu),
        isPresent: t,
        safeToRemove: n,
    });
}
const fh = {
    borderRadius: {
        ...ch,
        applyTo: [
            "borderTopLeftRadius",
            "borderTopRightRadius",
            "borderBottomLeftRadius",
            "borderBottomRightRadius",
        ],
    },
    borderTopLeftRadius: ch,
    borderTopRightRadius: ch,
    borderBottomLeftRadius: ch,
    borderBottomRightRadius: ch,
    boxShadow: uh,
};
const mh = (e, t) => e.depth - t.depth;
class gh {
    constructor() {
        (this.children = []), (this.isDirty = !1);
    }
    add(e) {
        Hi(this.children, e), (this.isDirty = !0);
    }
    remove(e) {
        Fi(this.children, e), (this.isDirty = !0);
    }
    forEach(e) {
        this.isDirty && this.children.sort(mh),
            (this.isDirty = !1),
            this.children.forEach(e);
    }
}
const yh = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
    xh = yh.length,
    vh = (e) => ("string" == typeof e ? parseFloat(e) : e),
    Ch = (e) => "number" == typeof e || Ws.test(e);
function wh(e, t) {
    return void 0 !== e[t] ? e[t] : e.borderRadius;
}
const bh = Eh(0, 0.5, us),
    kh = Eh(0.5, 0.95, qi);
function Eh(e, t, n) {
    return (r) => (r < e ? 0 : r > t ? 1 : n(Xi(e, t, r)));
}
function Sh(e, t) {
    (e.min = t.min), (e.max = t.max);
}
function Ah(e, t) {
    Sh(e.x, t.x), Sh(e.y, t.y);
}
function Th(e, t) {
    (e.translate = t.translate),
        (e.scale = t.scale),
        (e.originPoint = t.originPoint),
        (e.origin = t.origin);
}
function Lh(e, t, n, r, o) {
    return (
        (e = Ru((e -= t), 1 / n, r)), void 0 !== o && (e = Ru(e, 1 / o, r)), e
    );
}
function Mh(e, t, [n, r, o], i, s) {
    !(function (e, t = 0, n = 1, r = 0.5, o, i = e, s = e) {
        $s.test(t) &&
            ((t = parseFloat(t)), (t = ca(s.min, s.max, t / 100) - s.min));
        if ("number" != typeof t) return;
        let a = ca(i.min, i.max, r);
        e === i && (a -= t),
            (e.min = Lh(e.min, t, n, a, o)),
            (e.max = Lh(e.max, t, n, a, o));
    })(e, t[n], t[r], t[o], t.scale, i, s);
}
const Ph = ["x", "scaleX", "originX"],
    jh = ["y", "scaleY", "originY"];
function Nh(e, t, n, r) {
    Mh(e.x, t, Ph, n ? n.x : void 0, r ? r.x : void 0),
        Mh(e.y, t, jh, n ? n.y : void 0, r ? r.y : void 0);
}
function Ih(e) {
    return 0 === e.translate && 1 === e.scale;
}
function Dh(e) {
    return Ih(e.x) && Ih(e.y);
}
function Vh(e, t) {
    return e.min === t.min && e.max === t.max;
}
function Rh(e, t) {
    return (
        Math.round(e.min) === Math.round(t.min) &&
        Math.round(e.max) === Math.round(t.max)
    );
}
function _h(e, t) {
    return Rh(e.x, t.x) && Rh(e.y, t.y);
}
function Oh(e) {
    return Rd(e.x) / Rd(e.y);
}
function Hh(e, t) {
    return (
        e.translate === t.translate &&
        e.scale === t.scale &&
        e.originPoint === t.originPoint
    );
}
class Fh {
    constructor() {
        this.members = [];
    }
    add(e) {
        Hi(this.members, e), e.scheduleRender();
    }
    remove(e) {
        if (
            (Fi(this.members, e),
            e === this.prevLead && (this.prevLead = void 0),
            e === this.lead)
        ) {
            const e = this.members[this.members.length - 1];
            e && this.promote(e);
        }
    }
    relegate(e) {
        const t = this.members.findIndex((t) => e === t);
        if (0 === t) return !1;
        let n;
        for (let r = t; r >= 0; r--) {
            const e = this.members[r];
            if (!1 !== e.isPresent) {
                n = e;
                break;
            }
        }
        return !!n && (this.promote(n), !0);
    }
    promote(e, t) {
        const n = this.lead;
        if (e !== n && ((this.prevLead = n), (this.lead = e), e.show(), n)) {
            n.instance && n.scheduleRender(),
                e.scheduleRender(),
                (e.resumeFrom = n),
                t && (e.resumeFrom.preserveOpacity = !0),
                n.snapshot &&
                    ((e.snapshot = n.snapshot),
                    (e.snapshot.latestValues =
                        n.animationValues || n.latestValues)),
                e.root && e.root.isUpdating && (e.isLayoutDirty = !0);
            const { crossfade: r } = e.options;
            !1 === r && n.hide();
        }
    }
    exitAnimationComplete() {
        this.members.forEach((e) => {
            const { options: t, resumingFrom: n } = e;
            t.onExitComplete && t.onExitComplete(),
                n && n.options.onExitComplete && n.options.onExitComplete();
        });
    }
    scheduleRender() {
        this.members.forEach((e) => {
            e.instance && e.scheduleRender(!1);
        });
    }
    removeLeadSnapshot() {
        this.lead && this.lead.snapshot && (this.lead.snapshot = void 0);
    }
}
const Bh = ["", "X", "Y", "Z"];
let Uh = 0;
function Zh(e, t, n, r) {
    const { latestValues: o } = t;
    o[e] && ((n[e] = o[e]), t.setStaticValue(e, 0), r && (r[e] = 0));
}
function zh(e) {
    if (((e.hasCheckedOptimisedAppear = !0), e.root === e)) return;
    const { visualElement: t } = e.options;
    if (!t) return;
    const n = cd(t);
    if (window.MotionHasOptimisedAnimation(n, "transform")) {
        const { layout: t, layoutId: r } = e.options;
        window.MotionCancelOptimisedAnimation(n, "transform", Cs, !(t || r));
    }
    const { parent: r } = e;
    r && !r.hasCheckedOptimisedAppear && zh(r);
}
function $h({
    attachResizeListener: e,
    defaultParent: t,
    measureScroll: n,
    checkIsScrollRoot: r,
    resetTransform: o,
}) {
    return class {
        constructor(e = {}, n = t?.()) {
            (this.id = Uh++),
                (this.animationId = 0),
                (this.animationCommitId = 0),
                (this.children = new Set()),
                (this.options = {}),
                (this.isTreeAnimating = !1),
                (this.isAnimationBlocked = !1),
                (this.isLayoutDirty = !1),
                (this.isProjectionDirty = !1),
                (this.isSharedProjectionDirty = !1),
                (this.isTransformDirty = !1),
                (this.updateManuallyBlocked = !1),
                (this.updateBlockedByResize = !1),
                (this.isUpdating = !1),
                (this.isSVG = !1),
                (this.needsReset = !1),
                (this.shouldResetTransform = !1),
                (this.hasCheckedOptimisedAppear = !1),
                (this.treeScale = { x: 1, y: 1 }),
                (this.eventHandlers = new Map()),
                (this.hasTreeAnimated = !1),
                (this.updateScheduled = !1),
                (this.scheduleUpdate = () => this.update()),
                (this.projectionUpdateScheduled = !1),
                (this.checkUpdateFailed = () => {
                    this.isUpdating &&
                        ((this.isUpdating = !1), this.clearAllSnapshots());
                }),
                (this.updateProjection = () => {
                    (this.projectionUpdateScheduled = !1),
                        this.nodes.forEach(Kh),
                        this.nodes.forEach(tp),
                        this.nodes.forEach(np),
                        this.nodes.forEach(Yh);
                }),
                (this.resolvedRelativeTargetAt = 0),
                (this.hasProjected = !1),
                (this.isVisible = !0),
                (this.animationProgress = 0),
                (this.sharedNodes = new Map()),
                (this.latestValues = e),
                (this.root = n ? n.root || n : this),
                (this.path = n ? [...n.path, n] : []),
                (this.parent = n),
                (this.depth = n ? n.depth + 1 : 0);
            for (let t = 0; t < this.path.length; t++)
                this.path[t].shouldResetTransform = !0;
            this.root === this && (this.nodes = new gh());
        }
        addEventListener(e, t) {
            return (
                this.eventHandlers.has(e) ||
                    this.eventHandlers.set(e, new Gi()),
                this.eventHandlers.get(e).add(t)
            );
        }
        notifyListeners(e, ...t) {
            const n = this.eventHandlers.get(e);
            n && n.notify(...t);
        }
        hasListeners(e) {
            return this.eventHandlers.has(e);
        }
        mount(t) {
            if (this.instance) return;
            var n;
            (this.isSVG = Ac(t) && !(Ac((n = t)) && "svg" === n.tagName)),
                (this.instance = t);
            const { layoutId: r, layout: o, visualElement: i } = this.options;
            if (
                (i && !i.current && i.mount(t),
                this.root.nodes.add(this),
                this.parent && this.parent.children.add(this),
                this.root.hasTreeAnimated &&
                    (o || r) &&
                    (this.isLayoutDirty = !0),
                e)
            ) {
                let n,
                    r = 0;
                const o = () => (this.root.updateBlockedByResize = !1);
                Cs.read(() => {
                    r = window.innerWidth;
                }),
                    e(t, () => {
                        const e = window.innerWidth;
                        e !== r &&
                            ((r = e),
                            (this.root.updateBlockedByResize = !0),
                            n && n(),
                            (n = (function (e, t) {
                                const n = As.now(),
                                    r = ({ timestamp: o }) => {
                                        const i = o - n;
                                        i >= t && (ws(r), e(i - t));
                                    };
                                return Cs.setup(r, !0), () => ws(r);
                            })(o, 250)),
                            ah.hasAnimatedSinceResize &&
                                ((ah.hasAnimatedSinceResize = !1),
                                this.nodes.forEach(ep)));
                    });
            }
            r && this.root.registerSharedNode(r, this),
                !1 !== this.options.animate &&
                    i &&
                    (r || o) &&
                    this.addEventListener(
                        "didUpdate",
                        ({
                            delta: e,
                            hasLayoutChanged: t,
                            hasRelativeLayoutChanged: n,
                            layout: r,
                        }) => {
                            if (this.isTreeAnimationBlocked())
                                return (
                                    (this.target = void 0),
                                    void (this.relativeTarget = void 0)
                                );
                            const o =
                                    this.options.transition ||
                                    i.getDefaultTransition() ||
                                    lp,
                                {
                                    onLayoutAnimationStart: s,
                                    onLayoutAnimationComplete: a,
                                } = i.getProps(),
                                l =
                                    !this.targetLayout ||
                                    !_h(this.targetLayout, r),
                                c = !t && n;
                            if (
                                this.options.layoutRoot ||
                                this.resumeFrom ||
                                c ||
                                (t && (l || !this.currentAnimation))
                            ) {
                                this.resumeFrom &&
                                    ((this.resumingFrom = this.resumeFrom),
                                    (this.resumingFrom.resumingFrom = void 0));
                                const t = {
                                    ...ql(o, "layout"),
                                    onPlay: s,
                                    onComplete: a,
                                };
                                (i.shouldReduceMotion ||
                                    this.options.layoutRoot) &&
                                    ((t.delay = 0), (t.type = !1)),
                                    this.startAnimation(t),
                                    this.setAnimationOrigin(e, c);
                            } else
                                t || ep(this),
                                    this.isLead() &&
                                        this.options.onExitComplete &&
                                        this.options.onExitComplete();
                            this.targetLayout = r;
                        }
                    );
        }
        unmount() {
            this.options.layoutId && this.willUpdate(),
                this.root.nodes.remove(this);
            const e = this.getStack();
            e && e.remove(this),
                this.parent && this.parent.children.delete(this),
                (this.instance = void 0),
                this.eventHandlers.clear(),
                ws(this.updateProjection);
        }
        blockUpdate() {
            this.updateManuallyBlocked = !0;
        }
        unblockUpdate() {
            this.updateManuallyBlocked = !1;
        }
        isUpdateBlocked() {
            return this.updateManuallyBlocked || this.updateBlockedByResize;
        }
        isTreeAnimationBlocked() {
            return (
                this.isAnimationBlocked ||
                (this.parent && this.parent.isTreeAnimationBlocked()) ||
                !1
            );
        }
        startUpdate() {
            this.isUpdateBlocked() ||
                ((this.isUpdating = !0),
                this.nodes && this.nodes.forEach(rp),
                this.animationId++);
        }
        getTransformTemplate() {
            const { visualElement: e } = this.options;
            return e && e.getProps().transformTemplate;
        }
        willUpdate(e = !0) {
            if (((this.root.hasTreeAnimated = !0), this.root.isUpdateBlocked()))
                return void (
                    this.options.onExitComplete && this.options.onExitComplete()
                );
            if (
                (window.MotionCancelOptimisedAnimation &&
                    !this.hasCheckedOptimisedAppear &&
                    zh(this),
                !this.root.isUpdating && this.root.startUpdate(),
                this.isLayoutDirty)
            )
                return;
            this.isLayoutDirty = !0;
            for (let o = 0; o < this.path.length; o++) {
                const e = this.path[o];
                (e.shouldResetTransform = !0),
                    e.updateScroll("snapshot"),
                    e.options.layoutRoot && e.willUpdate(!1);
            }
            const { layoutId: t, layout: n } = this.options;
            if (void 0 === t && !n) return;
            const r = this.getTransformTemplate();
            (this.prevTransformTemplateValue = r
                ? r(this.latestValues, "")
                : void 0),
                this.updateSnapshot(),
                e && this.notifyListeners("willUpdate");
        }
        update() {
            this.updateScheduled = !1;
            if (this.isUpdateBlocked())
                return (
                    this.unblockUpdate(),
                    this.clearAllSnapshots(),
                    void this.nodes.forEach(Gh)
                );
            if (this.animationId <= this.animationCommitId)
                return void this.nodes.forEach(Qh);
            (this.animationCommitId = this.animationId),
                this.isUpdating
                    ? ((this.isUpdating = !1),
                      this.nodes.forEach(Jh),
                      this.nodes.forEach(Wh),
                      this.nodes.forEach(qh))
                    : this.nodes.forEach(Qh),
                this.clearAllSnapshots();
            const e = As.now();
            (bs.delta = Bi(0, 1e3 / 60, e - bs.timestamp)),
                (bs.timestamp = e),
                (bs.isProcessing = !0),
                ks.update.process(bs),
                ks.preRender.process(bs),
                ks.render.process(bs),
                (bs.isProcessing = !1);
        }
        didUpdate() {
            this.updateScheduled ||
                ((this.updateScheduled = !0), pc.read(this.scheduleUpdate));
        }
        clearAllSnapshots() {
            this.nodes.forEach(Xh), this.sharedNodes.forEach(op);
        }
        scheduleUpdateProjection() {
            this.projectionUpdateScheduled ||
                ((this.projectionUpdateScheduled = !0),
                Cs.preRender(this.updateProjection, !1, !0));
        }
        scheduleCheckAfterUnmount() {
            Cs.postRender(() => {
                this.isLayoutDirty
                    ? this.root.didUpdate()
                    : this.root.checkUpdateFailed();
            });
        }
        updateSnapshot() {
            !this.snapshot &&
                this.instance &&
                ((this.snapshot = this.measure()),
                !this.snapshot ||
                    Rd(this.snapshot.measuredBox.x) ||
                    Rd(this.snapshot.measuredBox.y) ||
                    (this.snapshot = void 0));
        }
        updateLayout() {
            if (!this.instance) return;
            if (
                (this.updateScroll(),
                !(
                    (this.options.alwaysMeasureLayout && this.isLead()) ||
                    this.isLayoutDirty
                ))
            )
                return;
            if (this.resumeFrom && !this.resumeFrom.instance)
                for (let n = 0; n < this.path.length; n++) {
                    this.path[n].updateScroll();
                }
            const e = this.layout;
            (this.layout = this.measure(!1)),
                (this.layoutCorrected = {
                    x: { min: 0, max: 0 },
                    y: { min: 0, max: 0 },
                }),
                (this.isLayoutDirty = !1),
                (this.projectionDelta = void 0),
                this.notifyListeners("measure", this.layout.layoutBox);
            const { visualElement: t } = this.options;
            t &&
                t.notify(
                    "LayoutMeasure",
                    this.layout.layoutBox,
                    e ? e.layoutBox : void 0
                );
        }
        updateScroll(e = "measure") {
            let t = Boolean(this.options.layoutScroll && this.instance);
            if (
                (this.scroll &&
                    this.scroll.animationId === this.root.animationId &&
                    this.scroll.phase === e &&
                    (t = !1),
                t && this.instance)
            ) {
                const t = r(this.instance);
                this.scroll = {
                    animationId: this.root.animationId,
                    phase: e,
                    isRoot: t,
                    offset: n(this.instance),
                    wasRoot: this.scroll ? this.scroll.isRoot : t,
                };
            }
        }
        resetTransform() {
            if (!o) return;
            const e =
                    this.isLayoutDirty ||
                    this.shouldResetTransform ||
                    this.options.alwaysMeasureLayout,
                t = this.projectionDelta && !Dh(this.projectionDelta),
                n = this.getTransformTemplate(),
                r = n ? n(this.latestValues, "") : void 0,
                i = r !== this.prevTransformTemplateValue;
            e &&
                this.instance &&
                (t || Iu(this.latestValues) || i) &&
                (o(this.instance, r),
                (this.shouldResetTransform = !1),
                this.scheduleRender());
        }
        measure(e = !0) {
            const t = this.measurePageBox();
            let n = this.removeElementScroll(t);
            var r;
            return (
                e && (n = this.removeTransform(n)),
                dp((r = n).x),
                dp(r.y),
                {
                    animationId: this.root.animationId,
                    measuredBox: t,
                    layoutBox: n,
                    latestValues: {},
                    source: this.id,
                }
            );
        }
        measurePageBox() {
            const { visualElement: e } = this.options;
            if (!e) return { x: { min: 0, max: 0 }, y: { min: 0, max: 0 } };
            const t = e.measureViewportBox();
            if (!(this.scroll?.wasRoot || this.path.some(pp))) {
                const { scroll: e } = this.root;
                e && (Uu(t.x, e.offset.x), Uu(t.y, e.offset.y));
            }
            return t;
        }
        removeElementScroll(e) {
            const t = { x: { min: 0, max: 0 }, y: { min: 0, max: 0 } };
            if ((Ah(t, e), this.scroll?.wasRoot)) return t;
            for (let n = 0; n < this.path.length; n++) {
                const r = this.path[n],
                    { scroll: o, options: i } = r;
                r !== this.root &&
                    o &&
                    i.layoutScroll &&
                    (o.wasRoot && Ah(t, e),
                    Uu(t.x, o.offset.x),
                    Uu(t.y, o.offset.y));
            }
            return t;
        }
        applyTransform(e, t = !1) {
            const n = { x: { min: 0, max: 0 }, y: { min: 0, max: 0 } };
            Ah(n, e);
            for (let r = 0; r < this.path.length; r++) {
                const e = this.path[r];
                !t &&
                    e.options.layoutScroll &&
                    e.scroll &&
                    e !== e.root &&
                    zu(n, { x: -e.scroll.offset.x, y: -e.scroll.offset.y }),
                    Iu(e.latestValues) && zu(n, e.latestValues);
            }
            return Iu(this.latestValues) && zu(n, this.latestValues), n;
        }
        removeTransform(e) {
            const t = { x: { min: 0, max: 0 }, y: { min: 0, max: 0 } };
            Ah(t, e);
            for (let n = 0; n < this.path.length; n++) {
                const e = this.path[n];
                if (!e.instance) continue;
                if (!Iu(e.latestValues)) continue;
                Nu(e.latestValues) && e.updateSnapshot();
                const r = Wu();
                Ah(r, e.measurePageBox()),
                    Nh(
                        t,
                        e.latestValues,
                        e.snapshot ? e.snapshot.layoutBox : void 0,
                        r
                    );
            }
            return Iu(this.latestValues) && Nh(t, this.latestValues), t;
        }
        setTargetDelta(e) {
            (this.targetDelta = e),
                this.root.scheduleUpdateProjection(),
                (this.isProjectionDirty = !0);
        }
        setOptions(e) {
            this.options = {
                ...this.options,
                ...e,
                crossfade: void 0 === e.crossfade || e.crossfade,
            };
        }
        clearMeasurements() {
            (this.scroll = void 0),
                (this.layout = void 0),
                (this.snapshot = void 0),
                (this.prevTransformTemplateValue = void 0),
                (this.targetDelta = void 0),
                (this.target = void 0),
                (this.isLayoutDirty = !1);
        }
        forceRelativeParentToResolveTarget() {
            this.relativeParent &&
                this.relativeParent.resolvedRelativeTargetAt !== bs.timestamp &&
                this.relativeParent.resolveTargetDelta(!0);
        }
        resolveTargetDelta(e = !1) {
            const t = this.getLead();
            this.isProjectionDirty ||
                (this.isProjectionDirty = t.isProjectionDirty),
                this.isTransformDirty ||
                    (this.isTransformDirty = t.isTransformDirty),
                this.isSharedProjectionDirty ||
                    (this.isSharedProjectionDirty = t.isSharedProjectionDirty);
            const n = Boolean(this.resumingFrom) || this !== t;
            if (
                !(
                    e ||
                    (n && this.isSharedProjectionDirty) ||
                    this.isProjectionDirty ||
                    this.parent?.isProjectionDirty ||
                    this.attemptToResolveRelativeTarget ||
                    this.root.updateBlockedByResize
                )
            )
                return;
            const { layout: r, layoutId: o } = this.options;
            if (this.layout && (r || o)) {
                if (
                    ((this.resolvedRelativeTargetAt = bs.timestamp),
                    !this.targetDelta && !this.relativeTarget)
                ) {
                    const e = this.getClosestProjectingParent();
                    e && e.layout && 1 !== this.animationProgress
                        ? ((this.relativeParent = e),
                          this.forceRelativeParentToResolveTarget(),
                          (this.relativeTarget = {
                              x: { min: 0, max: 0 },
                              y: { min: 0, max: 0 },
                          }),
                          (this.relativeTargetOrigin = {
                              x: { min: 0, max: 0 },
                              y: { min: 0, max: 0 },
                          }),
                          Bd(
                              this.relativeTargetOrigin,
                              this.layout.layoutBox,
                              e.layout.layoutBox
                          ),
                          Ah(this.relativeTarget, this.relativeTargetOrigin))
                        : (this.relativeParent = this.relativeTarget = void 0);
                }
                var i, s, a;
                if (this.relativeTarget || this.targetDelta)
                    if (
                        (this.target ||
                            ((this.target = {
                                x: { min: 0, max: 0 },
                                y: { min: 0, max: 0 },
                            }),
                            (this.targetWithTransforms = {
                                x: { min: 0, max: 0 },
                                y: { min: 0, max: 0 },
                            })),
                        this.relativeTarget &&
                        this.relativeTargetOrigin &&
                        this.relativeParent &&
                        this.relativeParent.target
                            ? (this.forceRelativeParentToResolveTarget(),
                              (i = this.target),
                              (s = this.relativeTarget),
                              (a = this.relativeParent.target),
                              Hd(i.x, s.x, a.x),
                              Hd(i.y, s.y, a.y))
                            : this.targetDelta
                            ? (Boolean(this.resumingFrom)
                                  ? (this.target = this.applyTransform(
                                        this.layout.layoutBox
                                    ))
                                  : Ah(this.target, this.layout.layoutBox),
                              Hu(this.target, this.targetDelta))
                            : Ah(this.target, this.layout.layoutBox),
                        this.attemptToResolveRelativeTarget)
                    ) {
                        this.attemptToResolveRelativeTarget = !1;
                        const e = this.getClosestProjectingParent();
                        e &&
                        Boolean(e.resumingFrom) ===
                            Boolean(this.resumingFrom) &&
                        !e.options.layoutScroll &&
                        e.target &&
                        1 !== this.animationProgress
                            ? ((this.relativeParent = e),
                              this.forceRelativeParentToResolveTarget(),
                              (this.relativeTarget = {
                                  x: { min: 0, max: 0 },
                                  y: { min: 0, max: 0 },
                              }),
                              (this.relativeTargetOrigin = {
                                  x: { min: 0, max: 0 },
                                  y: { min: 0, max: 0 },
                              }),
                              Bd(
                                  this.relativeTargetOrigin,
                                  this.target,
                                  e.target
                              ),
                              Ah(
                                  this.relativeTarget,
                                  this.relativeTargetOrigin
                              ))
                            : (this.relativeParent = this.relativeTarget =
                                  void 0);
                    }
            }
        }
        getClosestProjectingParent() {
            if (
                this.parent &&
                !Nu(this.parent.latestValues) &&
                !Du(this.parent.latestValues)
            )
                return this.parent.isProjecting()
                    ? this.parent
                    : this.parent.getClosestProjectingParent();
        }
        isProjecting() {
            return Boolean(
                (this.relativeTarget ||
                    this.targetDelta ||
                    this.options.layoutRoot) &&
                    this.layout
            );
        }
        calcProjection() {
            const e = this.getLead(),
                t = Boolean(this.resumingFrom) || this !== e;
            let n = !0;
            if (
                ((this.isProjectionDirty || this.parent?.isProjectionDirty) &&
                    (n = !1),
                t &&
                    (this.isSharedProjectionDirty || this.isTransformDirty) &&
                    (n = !1),
                this.resolvedRelativeTargetAt === bs.timestamp && (n = !1),
                n)
            )
                return;
            const { layout: r, layoutId: o } = this.options;
            if (
                ((this.isTreeAnimating = Boolean(
                    (this.parent && this.parent.isTreeAnimating) ||
                        this.currentAnimation ||
                        this.pendingAnimation
                )),
                this.isTreeAnimating ||
                    (this.targetDelta = this.relativeTarget = void 0),
                !this.layout || (!r && !o))
            )
                return;
            Ah(this.layoutCorrected, this.layout.layoutBox);
            const i = this.treeScale.x,
                s = this.treeScale.y;
            !(function (e, t, n, r = !1) {
                const o = n.length;
                if (!o) return;
                let i, s;
                t.x = t.y = 1;
                for (let a = 0; a < o; a++) {
                    (i = n[a]), (s = i.projectionDelta);
                    const { visualElement: o } = i.options;
                    (o &&
                        o.props.style &&
                        "contents" === o.props.style.display) ||
                        (r &&
                            i.options.layoutScroll &&
                            i.scroll &&
                            i !== i.root &&
                            zu(e, {
                                x: -i.scroll.offset.x,
                                y: -i.scroll.offset.y,
                            }),
                        s && ((t.x *= s.x.scale), (t.y *= s.y.scale), Hu(e, s)),
                        r && Iu(i.latestValues) && zu(e, i.latestValues));
                }
                t.x < Bu && t.x > Fu && (t.x = 1),
                    t.y < Bu && t.y > Fu && (t.y = 1);
            })(this.layoutCorrected, this.treeScale, this.path, t),
                !e.layout ||
                    e.target ||
                    (1 === this.treeScale.x && 1 === this.treeScale.y) ||
                    ((e.target = e.layout.layoutBox),
                    (e.targetWithTransforms = {
                        x: { min: 0, max: 0 },
                        y: { min: 0, max: 0 },
                    }));
            const { target: a } = e;
            a
                ? (this.projectionDelta && this.prevProjectionDelta
                      ? (Th(this.prevProjectionDelta.x, this.projectionDelta.x),
                        Th(this.prevProjectionDelta.y, this.projectionDelta.y))
                      : this.createProjectionDeltas(),
                  Od(
                      this.projectionDelta,
                      this.layoutCorrected,
                      a,
                      this.latestValues
                  ),
                  (this.treeScale.x === i &&
                      this.treeScale.y === s &&
                      Hh(this.projectionDelta.x, this.prevProjectionDelta.x) &&
                      Hh(this.projectionDelta.y, this.prevProjectionDelta.y)) ||
                      ((this.hasProjected = !0),
                      this.scheduleRender(),
                      this.notifyListeners("projectionUpdate", a)))
                : this.prevProjectionDelta &&
                  (this.createProjectionDeltas(), this.scheduleRender());
        }
        hide() {
            this.isVisible = !1;
        }
        show() {
            this.isVisible = !0;
        }
        scheduleRender(e = !0) {
            if ((this.options.visualElement?.scheduleRender(), e)) {
                const e = this.getStack();
                e && e.scheduleRender();
            }
            this.resumingFrom &&
                !this.resumingFrom.instance &&
                (this.resumingFrom = void 0);
        }
        createProjectionDeltas() {
            (this.prevProjectionDelta = {
                x: { translate: 0, scale: 1, origin: 0, originPoint: 0 },
                y: { translate: 0, scale: 1, origin: 0, originPoint: 0 },
            }),
                (this.projectionDelta = {
                    x: { translate: 0, scale: 1, origin: 0, originPoint: 0 },
                    y: { translate: 0, scale: 1, origin: 0, originPoint: 0 },
                }),
                (this.projectionDeltaWithTransform = {
                    x: { translate: 0, scale: 1, origin: 0, originPoint: 0 },
                    y: { translate: 0, scale: 1, origin: 0, originPoint: 0 },
                });
        }
        setAnimationOrigin(e, t = !1) {
            const n = this.snapshot,
                r = n ? n.latestValues : {},
                o = { ...this.latestValues },
                i = {
                    x: { translate: 0, scale: 1, origin: 0, originPoint: 0 },
                    y: { translate: 0, scale: 1, origin: 0, originPoint: 0 },
                };
            (this.relativeParent && this.relativeParent.options.layoutRoot) ||
                (this.relativeTarget = this.relativeTargetOrigin = void 0),
                (this.attemptToResolveRelativeTarget = !t);
            const s = { x: { min: 0, max: 0 }, y: { min: 0, max: 0 } },
                a =
                    (n ? n.source : void 0) !==
                    (this.layout ? this.layout.source : void 0),
                l = this.getStack(),
                c = !l || l.members.length <= 1,
                u = Boolean(
                    a &&
                        !c &&
                        !0 === this.options.crossfade &&
                        !this.path.some(ap)
                );
            let d;
            (this.animationProgress = 0),
                (this.mixTargetDelta = (t) => {
                    const n = t / 1e3;
                    var l, h, p, f, m, g;
                    ip(i.x, e.x, n),
                        ip(i.y, e.y, n),
                        this.setTargetDelta(i),
                        this.relativeTarget &&
                            this.relativeTargetOrigin &&
                            this.layout &&
                            this.relativeParent &&
                            this.relativeParent.layout &&
                            (Bd(
                                s,
                                this.layout.layoutBox,
                                this.relativeParent.layout.layoutBox
                            ),
                            (p = this.relativeTarget),
                            (f = this.relativeTargetOrigin),
                            (m = s),
                            (g = n),
                            sp(p.x, f.x, m.x, g),
                            sp(p.y, f.y, m.y, g),
                            d &&
                                ((l = this.relativeTarget),
                                (h = d),
                                Vh(l.x, h.x) && Vh(l.y, h.y)) &&
                                (this.isProjectionDirty = !1),
                            d ||
                                (d = {
                                    x: { min: 0, max: 0 },
                                    y: { min: 0, max: 0 },
                                }),
                            Ah(d, this.relativeTarget)),
                        a &&
                            ((this.animationValues = o),
                            (function (e, t, n, r, o, i) {
                                o
                                    ? ((e.opacity = ca(
                                          0,
                                          n.opacity ?? 1,
                                          bh(r)
                                      )),
                                      (e.opacityExit = ca(
                                          t.opacity ?? 1,
                                          0,
                                          kh(r)
                                      )))
                                    : i &&
                                      (e.opacity = ca(
                                          t.opacity ?? 1,
                                          n.opacity ?? 1,
                                          r
                                      ));
                                for (let s = 0; s < xh; s++) {
                                    const o = `border${yh[s]}Radius`;
                                    let i = wh(t, o),
                                        a = wh(n, o);
                                    (void 0 === i && void 0 === a) ||
                                        (i || (i = 0),
                                        a || (a = 0),
                                        0 === i || 0 === a || Ch(i) === Ch(a)
                                            ? ((e[o] = Math.max(
                                                  ca(vh(i), vh(a), r),
                                                  0
                                              )),
                                              ($s.test(a) || $s.test(i)) &&
                                                  (e[o] += "%"))
                                            : (e[o] = a));
                                }
                                (t.rotate || n.rotate) &&
                                    (e.rotate = ca(
                                        t.rotate || 0,
                                        n.rotate || 0,
                                        r
                                    ));
                            })(o, r, this.latestValues, n, u, c)),
                        this.root.scheduleUpdateProjection(),
                        this.scheduleRender(),
                        (this.animationProgress = n);
                }),
                this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0);
        }
        startAnimation(e) {
            this.notifyListeners("animationStart"),
                this.currentAnimation?.stop(),
                this.resumingFrom?.currentAnimation?.stop(),
                this.pendingAnimation &&
                    (ws(this.pendingAnimation),
                    (this.pendingAnimation = void 0)),
                (this.pendingAnimation = Cs.update(() => {
                    (ah.hasAnimatedSinceResize = !0),
                        this.motionValue || (this.motionValue = hc(0)),
                        (this.currentAnimation = (function (e, t, n) {
                            const r = Tc(e) ? e : hc(e);
                            return r.start(md("", r, t, n)), r.animation;
                        })(this.motionValue, [0, 1e3], {
                            ...e,
                            velocity: 0,
                            isSync: !0,
                            onUpdate: (t) => {
                                this.mixTargetDelta(t),
                                    e.onUpdate && e.onUpdate(t);
                            },
                            onStop: () => {},
                            onComplete: () => {
                                e.onComplete && e.onComplete(),
                                    this.completeAnimation();
                            },
                        })),
                        this.resumingFrom &&
                            (this.resumingFrom.currentAnimation =
                                this.currentAnimation),
                        (this.pendingAnimation = void 0);
                }));
        }
        completeAnimation() {
            this.resumingFrom &&
                ((this.resumingFrom.currentAnimation = void 0),
                (this.resumingFrom.preserveOpacity = void 0));
            const e = this.getStack();
            e && e.exitAnimationComplete(),
                (this.resumingFrom =
                    this.currentAnimation =
                    this.animationValues =
                        void 0),
                this.notifyListeners("animationComplete");
        }
        finishAnimation() {
            this.currentAnimation &&
                (this.mixTargetDelta && this.mixTargetDelta(1e3),
                this.currentAnimation.stop()),
                this.completeAnimation();
        }
        applyTransformsToTarget() {
            const e = this.getLead();
            let {
                targetWithTransforms: t,
                target: n,
                layout: r,
                latestValues: o,
            } = e;
            if (t && n && r) {
                if (
                    this !== e &&
                    this.layout &&
                    r &&
                    hp(
                        this.options.animationType,
                        this.layout.layoutBox,
                        r.layoutBox
                    )
                ) {
                    n = this.target || {
                        x: { min: 0, max: 0 },
                        y: { min: 0, max: 0 },
                    };
                    const t = Rd(this.layout.layoutBox.x);
                    (n.x.min = e.target.x.min), (n.x.max = n.x.min + t);
                    const r = Rd(this.layout.layoutBox.y);
                    (n.y.min = e.target.y.min), (n.y.max = n.y.min + r);
                }
                Ah(t, n),
                    zu(t, o),
                    Od(
                        this.projectionDeltaWithTransform,
                        this.layoutCorrected,
                        t,
                        o
                    );
            }
        }
        registerSharedNode(e, t) {
            this.sharedNodes.has(e) || this.sharedNodes.set(e, new Fh());
            this.sharedNodes.get(e).add(t);
            const n = t.options.initialPromotionConfig;
            t.promote({
                transition: n ? n.transition : void 0,
                preserveFollowOpacity:
                    n && n.shouldPreserveFollowOpacity
                        ? n.shouldPreserveFollowOpacity(t)
                        : void 0,
            });
        }
        isLead() {
            const e = this.getStack();
            return !e || e.lead === this;
        }
        getLead() {
            const { layoutId: e } = this.options;
            return (e && this.getStack()?.lead) || this;
        }
        getPrevLead() {
            const { layoutId: e } = this.options;
            return e ? this.getStack()?.prevLead : void 0;
        }
        getStack() {
            const { layoutId: e } = this.options;
            if (e) return this.root.sharedNodes.get(e);
        }
        promote({
            needsReset: e,
            transition: t,
            preserveFollowOpacity: n,
        } = {}) {
            const r = this.getStack();
            r && r.promote(this, n),
                e && ((this.projectionDelta = void 0), (this.needsReset = !0)),
                t && this.setOptions({ transition: t });
        }
        relegate() {
            const e = this.getStack();
            return !!e && e.relegate(this);
        }
        resetSkewAndRotation() {
            const { visualElement: e } = this.options;
            if (!e) return;
            let t = !1;
            const { latestValues: n } = e;
            if (
                ((n.z ||
                    n.rotate ||
                    n.rotateX ||
                    n.rotateY ||
                    n.rotateZ ||
                    n.skewX ||
                    n.skewY) &&
                    (t = !0),
                !t)
            )
                return;
            const r = {};
            n.z && Zh("z", e, r, this.animationValues);
            for (let o = 0; o < Bh.length; o++)
                Zh(`rotate${Bh[o]}`, e, r, this.animationValues),
                    Zh(`skew${Bh[o]}`, e, r, this.animationValues);
            e.render();
            for (const o in r)
                e.setStaticValue(o, r[o]),
                    this.animationValues && (this.animationValues[o] = r[o]);
            e.scheduleRender();
        }
        applyProjectionStyles(e, t) {
            if (!this.instance || this.isSVG) return;
            if (!this.isVisible) return void (e.visibility = "hidden");
            const n = this.getTransformTemplate();
            if (this.needsReset)
                return (
                    (this.needsReset = !1),
                    (e.visibility = ""),
                    (e.opacity = ""),
                    (e.pointerEvents = hu(t?.pointerEvents) || ""),
                    void (e.transform = n ? n(this.latestValues, "") : "none")
                );
            const r = this.getLead();
            if (!this.projectionDelta || !this.layout || !r.target)
                return (
                    this.options.layoutId &&
                        ((e.opacity =
                            void 0 !== this.latestValues.opacity
                                ? this.latestValues.opacity
                                : 1),
                        (e.pointerEvents = hu(t?.pointerEvents) || "")),
                    void (
                        this.hasProjected &&
                        !Iu(this.latestValues) &&
                        ((e.transform = n ? n({}, "") : "none"),
                        (this.hasProjected = !1))
                    )
                );
            e.visibility = "";
            const o = r.animationValues || r.latestValues;
            this.applyTransformsToTarget();
            let i = (function (e, t, n) {
                let r = "";
                const o = e.x.translate / t.x,
                    i = e.y.translate / t.y,
                    s = n?.z || 0;
                if (
                    ((o || i || s) &&
                        (r = `translate3d(${o}px, ${i}px, ${s}px) `),
                    (1 === t.x && 1 === t.y) ||
                        (r += `scale(${1 / t.x}, ${1 / t.y}) `),
                    n)
                ) {
                    const {
                        transformPerspective: e,
                        rotate: t,
                        rotateX: o,
                        rotateY: i,
                        skewX: s,
                        skewY: a,
                    } = n;
                    e && (r = `perspective(${e}px) ${r}`),
                        t && (r += `rotate(${t}deg) `),
                        o && (r += `rotateX(${o}deg) `),
                        i && (r += `rotateY(${i}deg) `),
                        s && (r += `skewX(${s}deg) `),
                        a && (r += `skewY(${a}deg) `);
                }
                const a = e.x.scale * t.x,
                    l = e.y.scale * t.y;
                return (
                    (1 === a && 1 === l) || (r += `scale(${a}, ${l})`),
                    r || "none"
                );
            })(this.projectionDeltaWithTransform, this.treeScale, o);
            n && (i = n(o, i)), (e.transform = i);
            const { x: s, y: a } = this.projectionDelta;
            (e.transformOrigin = `${100 * s.origin}% ${100 * a.origin}% 0`),
                r.animationValues
                    ? (e.opacity =
                          r === this
                              ? o.opacity ?? this.latestValues.opacity ?? 1
                              : this.preserveOpacity
                              ? this.latestValues.opacity
                              : o.opacityExit)
                    : (e.opacity =
                          r === this
                              ? void 0 !== o.opacity
                                  ? o.opacity
                                  : ""
                              : void 0 !== o.opacityExit
                              ? o.opacityExit
                              : 0);
            for (const l in Wc) {
                if (void 0 === o[l]) continue;
                const { correct: t, applyTo: n, isCSSVariable: s } = Wc[l],
                    a = "none" === i ? o[l] : t(o[l], r);
                if (n) {
                    const t = n.length;
                    for (let r = 0; r < t; r++) e[n[r]] = a;
                } else
                    s
                        ? (this.options.visualElement.renderState.vars[l] = a)
                        : (e[l] = a);
            }
            this.options.layoutId &&
                (e.pointerEvents =
                    r === this ? hu(t?.pointerEvents) || "" : "none");
        }
        clearSnapshot() {
            this.resumeFrom = this.snapshot = void 0;
        }
        resetTree() {
            this.root.nodes.forEach((e) => e.currentAnimation?.stop()),
                this.root.nodes.forEach(Gh),
                this.root.sharedNodes.clear();
        }
    };
}
function Wh(e) {
    e.updateLayout();
}
function qh(e) {
    const t = e.resumeFrom?.snapshot || e.snapshot;
    if (e.isLead() && e.layout && t && e.hasListeners("didUpdate")) {
        const { layoutBox: n, measuredBox: r } = e.layout,
            { animationType: o } = e.options,
            i = t.source !== e.layout.source;
        "size" === o
            ? Ud((e) => {
                  const r = i ? t.measuredBox[e] : t.layoutBox[e],
                      o = Rd(r);
                  (r.min = n[e].min), (r.max = r.min + o);
              })
            : hp(o, t.layoutBox, n) &&
              Ud((r) => {
                  const o = i ? t.measuredBox[r] : t.layoutBox[r],
                      s = Rd(n[r]);
                  (o.max = o.min + s),
                      e.relativeTarget &&
                          !e.currentAnimation &&
                          ((e.isProjectionDirty = !0),
                          (e.relativeTarget[r].max =
                              e.relativeTarget[r].min + s));
              });
        const s = {
            x: { translate: 0, scale: 1, origin: 0, originPoint: 0 },
            y: { translate: 0, scale: 1, origin: 0, originPoint: 0 },
        };
        Od(s, n, t.layoutBox);
        const a = {
            x: { translate: 0, scale: 1, origin: 0, originPoint: 0 },
            y: { translate: 0, scale: 1, origin: 0, originPoint: 0 },
        };
        i
            ? Od(a, e.applyTransform(r, !0), t.measuredBox)
            : Od(a, n, t.layoutBox);
        const l = !Dh(s);
        let c = !1;
        if (!e.resumeFrom) {
            const r = e.getClosestProjectingParent();
            if (r && !r.resumeFrom) {
                const { snapshot: o, layout: i } = r;
                if (o && i) {
                    const s = { x: { min: 0, max: 0 }, y: { min: 0, max: 0 } };
                    Bd(s, t.layoutBox, o.layoutBox);
                    const a = { x: { min: 0, max: 0 }, y: { min: 0, max: 0 } };
                    Bd(a, n, i.layoutBox),
                        _h(s, a) || (c = !0),
                        r.options.layoutRoot &&
                            ((e.relativeTarget = a),
                            (e.relativeTargetOrigin = s),
                            (e.relativeParent = r));
                }
            }
        }
        e.notifyListeners("didUpdate", {
            layout: n,
            snapshot: t,
            delta: a,
            layoutDelta: s,
            hasLayoutChanged: l,
            hasRelativeLayoutChanged: c,
        });
    } else if (e.isLead()) {
        const { onExitComplete: t } = e.options;
        t && t();
    }
    e.options.transition = void 0;
}
function Kh(e) {
    e.parent &&
        (e.isProjecting() || (e.isProjectionDirty = e.parent.isProjectionDirty),
        e.isSharedProjectionDirty ||
            (e.isSharedProjectionDirty = Boolean(
                e.isProjectionDirty ||
                    e.parent.isProjectionDirty ||
                    e.parent.isSharedProjectionDirty
            )),
        e.isTransformDirty || (e.isTransformDirty = e.parent.isTransformDirty));
}
function Yh(e) {
    e.isProjectionDirty = e.isSharedProjectionDirty = e.isTransformDirty = !1;
}
function Xh(e) {
    e.clearSnapshot();
}
function Gh(e) {
    e.clearMeasurements();
}
function Qh(e) {
    e.isLayoutDirty = !1;
}
function Jh(e) {
    const { visualElement: t } = e.options;
    t && t.getProps().onBeforeLayoutMeasure && t.notify("BeforeLayoutMeasure"),
        e.resetTransform();
}
function ep(e) {
    e.finishAnimation(),
        (e.targetDelta = e.relativeTarget = e.target = void 0),
        (e.isProjectionDirty = !0);
}
function tp(e) {
    e.resolveTargetDelta();
}
function np(e) {
    e.calcProjection();
}
function rp(e) {
    e.resetSkewAndRotation();
}
function op(e) {
    e.removeLeadSnapshot();
}
function ip(e, t, n) {
    (e.translate = ca(t.translate, 0, n)),
        (e.scale = ca(t.scale, 1, n)),
        (e.origin = t.origin),
        (e.originPoint = t.originPoint);
}
function sp(e, t, n, r) {
    (e.min = ca(t.min, n.min, r)), (e.max = ca(t.max, n.max, r));
}
function ap(e) {
    return e.animationValues && void 0 !== e.animationValues.opacityExit;
}
const lp = { duration: 0.45, ease: [0.4, 0, 0.1, 1] },
    cp = (e) =>
        "undefined" != typeof navigator &&
        navigator.userAgent &&
        navigator.userAgent.toLowerCase().includes(e),
    up = cp("applewebkit/") && !cp("chrome/") ? Math.round : qi;
function dp(e) {
    (e.min = up(e.min)), (e.max = up(e.max));
}
function hp(e, t, n) {
    return (
        "position" === e ||
        ("preserve-aspect" === e &&
            ((r = Oh(t)), (o = Oh(n)), (i = 0.2), !(Math.abs(r - o) <= i)))
    );
    var r, o, i;
}
function pp(e) {
    return e !== e.root && e.scroll?.wasRoot;
}
const fp = $h({
        attachResizeListener: (e, t) => Id(e, "resize", t),
        measureScroll: () => ({
            x: document.documentElement.scrollLeft || document.body.scrollLeft,
            y: document.documentElement.scrollTop || document.body.scrollTop,
        }),
        checkIsScrollRoot: () => !0,
    }),
    mp = { current: void 0 },
    gp = $h({
        measureScroll: (e) => ({ x: e.scrollLeft, y: e.scrollTop }),
        defaultParent: () => {
            if (!mp.current) {
                const e = new fp({});
                e.mount(window),
                    e.setOptions({ layoutScroll: !0 }),
                    (mp.current = e);
            }
            return mp.current;
        },
        resetTransform: (e, t) => {
            e.style.transform = void 0 !== t ? t : "none";
        },
        checkIsScrollRoot: (e) =>
            Boolean("fixed" === window.getComputedStyle(e).position),
    }),
    yp = {
        pan: {
            Feature: class extends Pd {
                constructor() {
                    super(...arguments), (this.removePointerDownListener = qi);
                }
                onPointerDown(e) {
                    this.session = new $d(e, this.createPanHandlers(), {
                        transformPagePoint: this.node.getTransformPagePoint(),
                        contextWindow: Zd(this.node),
                    });
                }
                createPanHandlers() {
                    const {
                        onPanSessionStart: e,
                        onPanStart: t,
                        onPan: n,
                        onPanEnd: r,
                    } = this.node.getProps();
                    return {
                        onSessionStart: sh(e),
                        onStart: sh(t),
                        onMove: n,
                        onEnd: (e, t) => {
                            delete this.session,
                                r && Cs.postRender(() => r(e, t));
                        },
                    };
                }
                mount() {
                    this.removePointerDownListener = Vd(
                        this.node.current,
                        "pointerdown",
                        (e) => this.onPointerDown(e)
                    );
                }
                update() {
                    this.session &&
                        this.session.updateHandlers(this.createPanHandlers());
                }
                unmount() {
                    this.removePointerDownListener(),
                        this.session && this.session.end();
                }
            },
        },
        drag: {
            Feature: class extends Pd {
                constructor(e) {
                    super(e),
                        (this.removeGroupControls = qi),
                        (this.removeListeners = qi),
                        (this.controls = new oh(e));
                }
                mount() {
                    const { dragControls: e } = this.node.getProps();
                    e &&
                        (this.removeGroupControls = e.subscribe(this.controls)),
                        (this.removeListeners =
                            this.controls.addListeners() || qi);
                }
                unmount() {
                    this.removeGroupControls(), this.removeListeners();
                }
            },
            ProjectionNode: gp,
            MeasureLayout: ph,
        },
    };
function xp(e, t, n) {
    const { props: r } = e;
    e.animationState &&
        r.whileHover &&
        e.animationState.setActive("whileHover", "Start" === n);
    const o = r["onHover" + n];
    o && Cs.postRender(() => o(t, Dd(t)));
}
function vp(e, t, n) {
    const { props: r } = e;
    if (e.current instanceof HTMLButtonElement && e.current.disabled) return;
    e.animationState &&
        r.whileTap &&
        e.animationState.setActive("whileTap", "Start" === n);
    const o = r["onTap" + ("End" === n ? "" : n)];
    o && Cs.postRender(() => o(t, Dd(t)));
}
const Cp = new WeakMap(),
    wp = new WeakMap(),
    bp = (e) => {
        const t = Cp.get(e.target);
        t && t(e);
    },
    kp = (e) => {
        e.forEach(bp);
    };
function Ep(e, t, n) {
    const r = (function ({ root: e, ...t }) {
        const n = e || document;
        wp.has(n) || wp.set(n, {});
        const r = wp.get(n),
            o = JSON.stringify(t);
        return (
            r[o] || (r[o] = new IntersectionObserver(kp, { root: e, ...t })),
            r[o]
        );
    })(t);
    return (
        Cp.set(e, n),
        r.observe(e),
        () => {
            Cp.delete(e), r.unobserve(e);
        }
    );
}
const Sp = { some: 0, all: 1 };
const Ap = Mu(
    {
        ...Nd,
        ...{
            inView: {
                Feature: class extends Pd {
                    constructor() {
                        super(...arguments),
                            (this.hasEnteredView = !1),
                            (this.isInView = !1);
                    }
                    startObserver() {
                        this.unmount();
                        const { viewport: e = {} } = this.node.getProps(),
                            {
                                root: t,
                                margin: n,
                                amount: r = "some",
                                once: o,
                            } = e,
                            i = {
                                root: t ? t.current : void 0,
                                rootMargin: n,
                                threshold: "number" == typeof r ? r : Sp[r],
                            };
                        return Ep(this.node.current, i, (e) => {
                            const { isIntersecting: t } = e;
                            if (this.isInView === t) return;
                            if (
                                ((this.isInView = t),
                                o && !t && this.hasEnteredView)
                            )
                                return;
                            t && (this.hasEnteredView = !0),
                                this.node.animationState &&
                                    this.node.animationState.setActive(
                                        "whileInView",
                                        t
                                    );
                            const { onViewportEnter: n, onViewportLeave: r } =
                                    this.node.getProps(),
                                i = t ? n : r;
                            i && i(e);
                        });
                    }
                    mount() {
                        this.startObserver();
                    }
                    update() {
                        if ("undefined" == typeof IntersectionObserver) return;
                        const { props: e, prevProps: t } = this.node;
                        ["amount", "margin", "root"].some(
                            (function (
                                { viewport: e = {} },
                                { viewport: t = {} } = {}
                            ) {
                                return (n) => e[n] !== t[n];
                            })(e, t)
                        ) && this.startObserver();
                    }
                    unmount() {}
                },
            },
            tap: {
                Feature: class extends Pd {
                    mount() {
                        const { current: e } = this.node;
                        e &&
                            (this.unmount = Sc(
                                e,
                                (e, t) => (
                                    vp(this.node, t, "Start"),
                                    (e, { success: t }) =>
                                        vp(this.node, e, t ? "End" : "Cancel")
                                ),
                                {
                                    useGlobalTarget:
                                        this.node.props.globalTapTarget,
                                }
                            ));
                    }
                    unmount() {}
                },
            },
            focus: {
                Feature: class extends Pd {
                    constructor() {
                        super(...arguments), (this.isActive = !1);
                    }
                    onFocus() {
                        let e = !1;
                        try {
                            e = this.node.current.matches(":focus-visible");
                        } catch (t) {
                            e = !0;
                        }
                        e &&
                            this.node.animationState &&
                            (this.node.animationState.setActive(
                                "whileFocus",
                                !0
                            ),
                            (this.isActive = !0));
                    }
                    onBlur() {
                        this.isActive &&
                            this.node.animationState &&
                            (this.node.animationState.setActive(
                                "whileFocus",
                                !1
                            ),
                            (this.isActive = !1));
                    }
                    mount() {
                        this.unmount = Yi(
                            Id(this.node.current, "focus", () =>
                                this.onFocus()
                            ),
                            Id(this.node.current, "blur", () => this.onBlur())
                        );
                    }
                    unmount() {}
                },
            },
            hover: {
                Feature: class extends Pd {
                    mount() {
                        const { current: e } = this.node;
                        e &&
                            (this.unmount = (function (e, t, n = {}) {
                                const [r, o, i] = gc(e, n),
                                    s = (e) => {
                                        if (!yc(e)) return;
                                        const { target: n } = e,
                                            r = t(n, e);
                                        if ("function" != typeof r || !n)
                                            return;
                                        const i = (e) => {
                                            yc(e) &&
                                                (r(e),
                                                n.removeEventListener(
                                                    "pointerleave",
                                                    i
                                                ));
                                        };
                                        n.addEventListener(
                                            "pointerleave",
                                            i,
                                            o
                                        );
                                    };
                                return (
                                    r.forEach((e) => {
                                        e.addEventListener(
                                            "pointerenter",
                                            s,
                                            o
                                        );
                                    }),
                                    i
                                );
                            })(
                                e,
                                (e, t) => (
                                    xp(this.node, t, "Start"),
                                    (e) => xp(this.node, e, "End")
                                )
                            ));
                    }
                    unmount() {}
                },
            },
        },
        ...yp,
        ...{ layout: { ProjectionNode: gp, MeasureLayout: ph } },
    },
    rd
);
function Tp(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
    return function (r) {
        if ((e?.(r), !1 === n || !r.defaultPrevented)) return t?.(r);
    };
}
function Lp(e, t) {
    if ("function" == typeof e) return e(t);
    null != e && (e.current = t);
}
function Mp(...e) {
    return (t) => {
        let n = !1;
        const r = e.map((e) => {
            const r = Lp(e, t);
            return n || "function" != typeof r || (n = !0), r;
        });
        if (n)
            return () => {
                for (let t = 0; t < r.length; t++) {
                    const n = r[t];
                    "function" == typeof n ? n() : Lp(e[t], null);
                }
            };
    };
}
function Pp(...e) {
    return r.useCallback(Mp(...e), e);
}
function jp(e, t = []) {
    let n = [];
    const o = () => {
        const t = n.map((e) => r.createContext(e));
        return function (n) {
            const o = n?.[e] || t;
            return r.useMemo(
                () => ({ [`__scope${e}`]: { ...n, [e]: o } }),
                [n, o]
            );
        };
    };
    return (
        (o.scopeName = e),
        [
            function (t, o) {
                const i = r.createContext(o),
                    s = n.length;
                n = [...n, o];
                const l = (t) => {
                    const { scope: n, children: o, ...l } = t,
                        c = n?.[e]?.[s] || i,
                        u = r.useMemo(() => l, Object.values(l));
                    return a.jsx(c.Provider, { value: u, children: o });
                };
                return (
                    (l.displayName = t + "Provider"),
                    [
                        l,
                        function (n, a) {
                            const l = a?.[e]?.[s] || i,
                                c = r.useContext(l);
                            if (c) return c;
                            if (void 0 !== o) return o;
                            throw new Error(
                                `\`${n}\` must be used within \`${t}\``
                            );
                        },
                    ]
                );
            },
            Np(o, ...t),
        ]
    );
}
function Np(...e) {
    const t = e[0];
    if (1 === e.length) return t;
    const n = () => {
        const n = e.map((e) => ({ useScope: e(), scopeName: e.scopeName }));
        return function (e) {
            const o = n.reduce(
                (t, { useScope: n, scopeName: r }) => ({
                    ...t,
                    ...n(e)[`__scope${r}`],
                }),
                {}
            );
            return r.useMemo(() => ({ [`__scope${t.scopeName}`]: o }), [o]);
        };
    };
    return (n.scopeName = t.scopeName), n;
}
var Ip = d();
const Dp = T(Ip);
function Vp(e) {
    const t = Rp(e),
        n = r.forwardRef((e, n) => {
            const { children: o, ...i } = e,
                s = r.Children.toArray(o),
                l = s.find(Hp);
            if (l) {
                const e = l.props.children,
                    o = s.map((t) =>
                        t === l
                            ? r.Children.count(e) > 1
                                ? r.Children.only(null)
                                : r.isValidElement(e)
                                ? e.props.children
                                : null
                            : t
                    );
                return a.jsx(t, {
                    ...i,
                    ref: n,
                    children: r.isValidElement(e)
                        ? r.cloneElement(e, void 0, o)
                        : null,
                });
            }
            return a.jsx(t, { ...i, ref: n, children: o });
        });
    return (n.displayName = `${e}.Slot`), n;
}
function Rp(e) {
    const t = r.forwardRef((e, t) => {
        const { children: n, ...o } = e;
        if (r.isValidElement(n)) {
            const e = (function (e) {
                    let t = Object.getOwnPropertyDescriptor(
                            e.props,
                            "ref"
                        )?.get,
                        n = t && "isReactWarning" in t && t.isReactWarning;
                    if (n) return e.ref;
                    if (
                        ((t = Object.getOwnPropertyDescriptor(e, "ref")?.get),
                        (n = t && "isReactWarning" in t && t.isReactWarning),
                        n)
                    )
                        return e.props.ref;
                    return e.props.ref || e.ref;
                })(n),
                i = (function (e, t) {
                    const n = { ...t };
                    for (const r in t) {
                        const o = e[r],
                            i = t[r];
                        /^on[A-Z]/.test(r)
                            ? o && i
                                ? (n[r] = (...e) => {
                                      const t = i(...e);
                                      return o(...e), t;
                                  })
                                : o && (n[r] = o)
                            : "style" === r
                            ? (n[r] = { ...o, ...i })
                            : "className" === r &&
                              (n[r] = [o, i].filter(Boolean).join(" "));
                    }
                    return { ...e, ...n };
                })(o, n.props);
            return (
                n.type !== r.Fragment && (i.ref = t ? Mp(t, e) : e),
                r.cloneElement(n, i)
            );
        }
        return r.Children.count(n) > 1 ? r.Children.only(null) : null;
    });
    return (t.displayName = `${e}.SlotClone`), t;
}
var _p = Symbol("radix.slottable");
function Op(e) {
    const t = ({ children: e }) => a.jsx(a.Fragment, { children: e });
    return (t.displayName = `${e}.Slottable`), (t.__radixId = _p), t;
}
function Hp(e) {
    return (
        r.isValidElement(e) &&
        "function" == typeof e.type &&
        "__radixId" in e.type &&
        e.type.__radixId === _p
    );
}
var Fp = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul",
].reduce((e, t) => {
    const n = Vp(`Primitive.${t}`),
        o = r.forwardRef((e, r) => {
            const { asChild: o, ...i } = e,
                s = o ? n : t;
            return (
                "undefined" != typeof window &&
                    (window[Symbol.for("radix-ui")] = !0),
                a.jsx(s, { ...i, ref: r })
            );
        });
    return (o.displayName = `Primitive.${t}`), { ...e, [t]: o };
}, {});
function Bp(e) {
    const t = r.useRef(e);
    return (
        r.useEffect(() => {
            t.current = e;
        }),
        r.useMemo(
            () =>
                (...e) =>
                    t.current?.(...e),
            []
        )
    );
}
var Up,
    Zp = "dismissableLayer.update",
    zp = "dismissableLayer.pointerDownOutside",
    $p = "dismissableLayer.focusOutside",
    Wp = r.createContext({
        layers: new Set(),
        layersWithOutsidePointerEventsDisabled: new Set(),
        branches: new Set(),
    }),
    qp = r.forwardRef((e, t) => {
        const {
                disableOutsidePointerEvents: n = !1,
                onEscapeKeyDown: o,
                onPointerDownOutside: i,
                onFocusOutside: s,
                onInteractOutside: l,
                onDismiss: c,
                ...u
            } = e,
            d = r.useContext(Wp),
            [h, p] = r.useState(null),
            f = h?.ownerDocument ?? globalThis?.document,
            [, m] = r.useState({}),
            g = Pp(t, (e) => p(e)),
            y = Array.from(d.layers),
            [x] = [...d.layersWithOutsidePointerEventsDisabled].slice(-1),
            v = y.indexOf(x),
            C = h ? y.indexOf(h) : -1,
            w = d.layersWithOutsidePointerEventsDisabled.size > 0,
            b = C >= v,
            k = (function (e, t = globalThis?.document) {
                const n = Bp(e),
                    o = r.useRef(!1),
                    i = r.useRef(() => {});
                return (
                    r.useEffect(() => {
                        const e = (e) => {
                                if (e.target && !o.current) {
                                    let r = function () {
                                        Yp(zp, n, o, { discrete: !0 });
                                    };
                                    const o = { originalEvent: e };
                                    "touch" === e.pointerType
                                        ? (t.removeEventListener(
                                              "click",
                                              i.current
                                          ),
                                          (i.current = r),
                                          t.addEventListener(
                                              "click",
                                              i.current,
                                              { once: !0 }
                                          ))
                                        : r();
                                } else
                                    t.removeEventListener("click", i.current);
                                o.current = !1;
                            },
                            r = window.setTimeout(() => {
                                t.addEventListener("pointerdown", e);
                            }, 0);
                        return () => {
                            window.clearTimeout(r),
                                t.removeEventListener("pointerdown", e),
                                t.removeEventListener("click", i.current);
                        };
                    }, [t, n]),
                    { onPointerDownCapture: () => (o.current = !0) }
                );
            })((e) => {
                const t = e.target,
                    n = [...d.branches].some((e) => e.contains(t));
                b && !n && (i?.(e), l?.(e), e.defaultPrevented || c?.());
            }, f),
            E = (function (e, t = globalThis?.document) {
                const n = Bp(e),
                    o = r.useRef(!1);
                return (
                    r.useEffect(() => {
                        const e = (e) => {
                            if (e.target && !o.current) {
                                Yp(
                                    $p,
                                    n,
                                    { originalEvent: e },
                                    { discrete: !1 }
                                );
                            }
                        };
                        return (
                            t.addEventListener("focusin", e),
                            () => t.removeEventListener("focusin", e)
                        );
                    }, [t, n]),
                    {
                        onFocusCapture: () => (o.current = !0),
                        onBlurCapture: () => (o.current = !1),
                    }
                );
            })((e) => {
                const t = e.target;
                [...d.branches].some((e) => e.contains(t)) ||
                    (s?.(e), l?.(e), e.defaultPrevented || c?.());
            }, f);
        return (
            (function (e, t = globalThis?.document) {
                const n = Bp(e);
                r.useEffect(() => {
                    const e = (e) => {
                        "Escape" === e.key && n(e);
                    };
                    return (
                        t.addEventListener("keydown", e, { capture: !0 }),
                        () =>
                            t.removeEventListener("keydown", e, { capture: !0 })
                    );
                }, [n, t]);
            })((e) => {
                C === d.layers.size - 1 &&
                    (o?.(e),
                    !e.defaultPrevented && c && (e.preventDefault(), c()));
            }, f),
            r.useEffect(() => {
                if (h)
                    return (
                        n &&
                            (0 ===
                                d.layersWithOutsidePointerEventsDisabled.size &&
                                ((Up = f.body.style.pointerEvents),
                                (f.body.style.pointerEvents = "none")),
                            d.layersWithOutsidePointerEventsDisabled.add(h)),
                        d.layers.add(h),
                        Kp(),
                        () => {
                            n &&
                                1 ===
                                    d.layersWithOutsidePointerEventsDisabled
                                        .size &&
                                (f.body.style.pointerEvents = Up);
                        }
                    );
            }, [h, f, n, d]),
            r.useEffect(
                () => () => {
                    h &&
                        (d.layers.delete(h),
                        d.layersWithOutsidePointerEventsDisabled.delete(h),
                        Kp());
                },
                [h, d]
            ),
            r.useEffect(() => {
                const e = () => m({});
                return (
                    document.addEventListener(Zp, e),
                    () => document.removeEventListener(Zp, e)
                );
            }, []),
            a.jsx(Fp.div, {
                ...u,
                ref: g,
                style: {
                    pointerEvents: w ? (b ? "auto" : "none") : void 0,
                    ...e.style,
                },
                onFocusCapture: Tp(e.onFocusCapture, E.onFocusCapture),
                onBlurCapture: Tp(e.onBlurCapture, E.onBlurCapture),
                onPointerDownCapture: Tp(
                    e.onPointerDownCapture,
                    k.onPointerDownCapture
                ),
            })
        );
    });
qp.displayName = "DismissableLayer";
function Kp() {
    const e = new CustomEvent(Zp);
    document.dispatchEvent(e);
}
function Yp(e, t, n, { discrete: r }) {
    const o = n.originalEvent.target,
        i = new CustomEvent(e, { bubbles: !1, cancelable: !0, detail: n });
    t && o.addEventListener(e, t, { once: !0 }),
        r
            ? (function (e, t) {
                  e && Ip.flushSync(() => e.dispatchEvent(t));
              })(o, i)
            : o.dispatchEvent(i);
}
r.forwardRef((e, t) => {
    const n = r.useContext(Wp),
        o = r.useRef(null),
        i = Pp(t, o);
    return (
        r.useEffect(() => {
            const e = o.current;
            if (e)
                return (
                    n.branches.add(e),
                    () => {
                        n.branches.delete(e);
                    }
                );
        }, [n.branches]),
        a.jsx(Fp.div, { ...e, ref: i })
    );
}).displayName = "DismissableLayerBranch";
var Xp = globalThis?.document ? r.useLayoutEffect : () => {},
    Gp = h[" useId ".trim().toString()] || (() => {}),
    Qp = 0;
const Jp = ["top", "right", "bottom", "left"],
    ef = Math.min,
    tf = Math.max,
    nf = Math.round,
    rf = Math.floor,
    of = (e) => ({ x: e, y: e }),
    sf = { left: "right", right: "left", bottom: "top", top: "bottom" },
    af = { start: "end", end: "start" };
function lf(e, t, n) {
    return tf(e, ef(t, n));
}
function cf(e, t) {
    return "function" == typeof e ? e(t) : e;
}
function uf(e) {
    return e.split("-")[0];
}
function df(e) {
    return e.split("-")[1];
}
function hf(e) {
    return "x" === e ? "y" : "x";
}
function pf(e) {
    return "y" === e ? "height" : "width";
}
const ff = new Set(["top", "bottom"]);
function mf(e) {
    return ff.has(uf(e)) ? "y" : "x";
}
function gf(e) {
    return hf(mf(e));
}
function yf(e) {
    return e.replace(/start|end/g, (e) => af[e]);
}
const xf = ["left", "right"],
    vf = ["right", "left"],
    Cf = ["top", "bottom"],
    wf = ["bottom", "top"];
function bf(e, t, n, r) {
    const o = df(e);
    let i = (function (e, t, n) {
        switch (e) {
            case "top":
            case "bottom":
                return n ? (t ? vf : xf) : t ? xf : vf;
            case "left":
            case "right":
                return t ? Cf : wf;
            default:
                return [];
        }
    })(uf(e), "start" === n, r);
    return (
        o && ((i = i.map((e) => e + "-" + o)), t && (i = i.concat(i.map(yf)))),
        i
    );
}
function kf(e) {
    return e.replace(/left|right|bottom|top/g, (e) => sf[e]);
}
function Ef(e) {
    return "number" != typeof e
        ? (function (e) {
              return { top: 0, right: 0, bottom: 0, left: 0, ...e };
          })(e)
        : { top: e, right: e, bottom: e, left: e };
}
function Sf(e) {
    const { x: t, y: n, width: r, height: o } = e;
    return {
        width: r,
        height: o,
        top: n,
        left: t,
        right: t + r,
        bottom: n + o,
        x: t,
        y: n,
    };
}
function Af(e, t, n) {
    let { reference: r, floating: o } = e;
    const i = mf(t),
        s = gf(t),
        a = pf(s),
        l = uf(t),
        c = "y" === i,
        u = r.x + r.width / 2 - o.width / 2,
        d = r.y + r.height / 2 - o.height / 2,
        h = r[a] / 2 - o[a] / 2;
    let p;
    switch (l) {
        case "top":
            p = { x: u, y: r.y - o.height };
            break;
        case "bottom":
            p = { x: u, y: r.y + r.height };
            break;
        case "right":
            p = { x: r.x + r.width, y: d };
            break;
        case "left":
            p = { x: r.x - o.width, y: d };
            break;
        default:
            p = { x: r.x, y: r.y };
    }
    switch (df(t)) {
        case "start":
            p[s] -= h * (n && c ? -1 : 1);
            break;
        case "end":
            p[s] += h * (n && c ? -1 : 1);
    }
    return p;
}
async function Tf(e, t) {
    var n;
    void 0 === t && (t = {});
    const { x: r, y: o, platform: i, rects: s, elements: a, strategy: l } = e,
        {
            boundary: c = "clippingAncestors",
            rootBoundary: u = "viewport",
            elementContext: d = "floating",
            altBoundary: h = !1,
            padding: p = 0,
        } = cf(t, e),
        f = Ef(p),
        m = a[h ? ("floating" === d ? "reference" : "floating") : d],
        g = Sf(
            await i.getClippingRect({
                element:
                    null ==
                        (n = await (null == i.isElement
                            ? void 0
                            : i.isElement(m))) || n
                        ? m
                        : m.contextElement ||
                          (await (null == i.getDocumentElement
                              ? void 0
                              : i.getDocumentElement(a.floating))),
                boundary: c,
                rootBoundary: u,
                strategy: l,
            })
        ),
        y =
            "floating" === d
                ? {
                      x: r,
                      y: o,
                      width: s.floating.width,
                      height: s.floating.height,
                  }
                : s.reference,
        x = await (null == i.getOffsetParent
            ? void 0
            : i.getOffsetParent(a.floating)),
        v = ((await (null == i.isElement ? void 0 : i.isElement(x))) &&
            (await (null == i.getScale ? void 0 : i.getScale(x)))) || {
            x: 1,
            y: 1,
        },
        C = Sf(
            i.convertOffsetParentRelativeRectToViewportRelativeRect
                ? await i.convertOffsetParentRelativeRectToViewportRelativeRect(
                      { elements: a, rect: y, offsetParent: x, strategy: l }
                  )
                : y
        );
    return {
        top: (g.top - C.top + f.top) / v.y,
        bottom: (C.bottom - g.bottom + f.bottom) / v.y,
        left: (g.left - C.left + f.left) / v.x,
        right: (C.right - g.right + f.right) / v.x,
    };
}
function Lf(e, t) {
    return {
        top: e.top - t.height,
        right: e.right - t.width,
        bottom: e.bottom - t.height,
        left: e.left - t.width,
    };
}
function Mf(e) {
    return Jp.some((t) => e[t] >= 0);
}
const Pf = new Set(["left", "top"]);
function jf() {
    return "undefined" != typeof window;
}
function Nf(e) {
    return Vf(e) ? (e.nodeName || "").toLowerCase() : "#document";
}
function If(e) {
    var t;
    return (
        (null == e || null == (t = e.ownerDocument) ? void 0 : t.defaultView) ||
        window
    );
}
function Df(e) {
    var t;
    return null ==
        (t = (Vf(e) ? e.ownerDocument : e.document) || window.document)
        ? void 0
        : t.documentElement;
}
function Vf(e) {
    return !!jf() && (e instanceof Node || e instanceof If(e).Node);
}
function Rf(e) {
    return !!jf() && (e instanceof Element || e instanceof If(e).Element);
}
function _f(e) {
    return (
        !!jf() && (e instanceof HTMLElement || e instanceof If(e).HTMLElement)
    );
}
function Of(e) {
    return (
        !(!jf() || "undefined" == typeof ShadowRoot) &&
        (e instanceof ShadowRoot || e instanceof If(e).ShadowRoot)
    );
}
const Hf = new Set(["inline", "contents"]);
function Ff(e) {
    const { overflow: t, overflowX: n, overflowY: r, display: o } = Qf(e);
    return /auto|scroll|overlay|hidden|clip/.test(t + r + n) && !Hf.has(o);
}
const Bf = new Set(["table", "td", "th"]);
function Uf(e) {
    return Bf.has(Nf(e));
}
const Zf = [":popover-open", ":modal"];
function zf(e) {
    return Zf.some((t) => {
        try {
            return e.matches(t);
        } catch (n) {
            return !1;
        }
    });
}
const $f = ["transform", "translate", "scale", "rotate", "perspective"],
    Wf = ["transform", "translate", "scale", "rotate", "perspective", "filter"],
    qf = ["paint", "layout", "strict", "content"];
function Kf(e) {
    const t = Yf(),
        n = Rf(e) ? Qf(e) : e;
    return (
        $f.some((e) => !!n[e] && "none" !== n[e]) ||
        (!!n.containerType && "normal" !== n.containerType) ||
        (!t && !!n.backdropFilter && "none" !== n.backdropFilter) ||
        (!t && !!n.filter && "none" !== n.filter) ||
        Wf.some((e) => (n.willChange || "").includes(e)) ||
        qf.some((e) => (n.contain || "").includes(e))
    );
}
function Yf() {
    return (
        !("undefined" == typeof CSS || !CSS.supports) &&
        CSS.supports("-webkit-backdrop-filter", "none")
    );
}
const Xf = new Set(["html", "body", "#document"]);
function Gf(e) {
    return Xf.has(Nf(e));
}
function Qf(e) {
    return If(e).getComputedStyle(e);
}
function Jf(e) {
    return Rf(e)
        ? { scrollLeft: e.scrollLeft, scrollTop: e.scrollTop }
        : { scrollLeft: e.scrollX, scrollTop: e.scrollY };
}
function em(e) {
    if ("html" === Nf(e)) return e;
    const t = e.assignedSlot || e.parentNode || (Of(e) && e.host) || Df(e);
    return Of(t) ? t.host : t;
}
function tm(e) {
    const t = em(e);
    return Gf(t)
        ? e.ownerDocument
            ? e.ownerDocument.body
            : e.body
        : _f(t) && Ff(t)
        ? t
        : tm(t);
}
function nm(e, t, n) {
    var r;
    void 0 === t && (t = []), void 0 === n && (n = !0);
    const o = tm(e),
        i = o === (null == (r = e.ownerDocument) ? void 0 : r.body),
        s = If(o);
    if (i) {
        const e = rm(s);
        return t.concat(
            s,
            s.visualViewport || [],
            Ff(o) ? o : [],
            e && n ? nm(e) : []
        );
    }
    return t.concat(o, nm(o, [], n));
}
function rm(e) {
    return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null;
}
function om(e) {
    const t = Qf(e);
    let n = parseFloat(t.width) || 0,
        r = parseFloat(t.height) || 0;
    const o = _f(e),
        i = o ? e.offsetWidth : n,
        s = o ? e.offsetHeight : r,
        a = nf(n) !== i || nf(r) !== s;
    return a && ((n = i), (r = s)), { width: n, height: r, $: a };
}
function im(e) {
    return Rf(e) ? e : e.contextElement;
}
function sm(e) {
    const t = im(e);
    if (!_f(t)) return of(1);
    const n = t.getBoundingClientRect(),
        { width: r, height: o, $: i } = om(t);
    let s = (i ? nf(n.width) : n.width) / r,
        a = (i ? nf(n.height) : n.height) / o;
    return (
        (s && Number.isFinite(s)) || (s = 1),
        (a && Number.isFinite(a)) || (a = 1),
        { x: s, y: a }
    );
}
const am = of(0);
function lm(e) {
    const t = If(e);
    return Yf() && t.visualViewport
        ? { x: t.visualViewport.offsetLeft, y: t.visualViewport.offsetTop }
        : am;
}
function cm(e, t, n, r) {
    void 0 === t && (t = !1), void 0 === n && (n = !1);
    const o = e.getBoundingClientRect(),
        i = im(e);
    let s = of(1);
    t && (r ? Rf(r) && (s = sm(r)) : (s = sm(e)));
    const a = (function (e, t, n) {
        return void 0 === t && (t = !1), !(!n || (t && n !== If(e))) && t;
    })(i, n, r)
        ? lm(i)
        : of(0);
    let l = (o.left + a.x) / s.x,
        c = (o.top + a.y) / s.y,
        u = o.width / s.x,
        d = o.height / s.y;
    if (i) {
        const e = If(i),
            t = r && Rf(r) ? If(r) : r;
        let n = e,
            o = rm(n);
        for (; o && r && t !== n; ) {
            const e = sm(o),
                t = o.getBoundingClientRect(),
                r = Qf(o),
                i = t.left + (o.clientLeft + parseFloat(r.paddingLeft)) * e.x,
                s = t.top + (o.clientTop + parseFloat(r.paddingTop)) * e.y;
            (l *= e.x),
                (c *= e.y),
                (u *= e.x),
                (d *= e.y),
                (l += i),
                (c += s),
                (n = If(o)),
                (o = rm(n));
        }
    }
    return Sf({ width: u, height: d, x: l, y: c });
}
function um(e, t) {
    const n = Jf(e).scrollLeft;
    return t ? t.left + n : cm(Df(e)).left + n;
}
function dm(e, t, n) {
    void 0 === n && (n = !1);
    const r = e.getBoundingClientRect();
    return {
        x: r.left + t.scrollLeft - (n ? 0 : um(e, r)),
        y: r.top + t.scrollTop,
    };
}
const hm = new Set(["absolute", "fixed"]);
function pm(e, t, n) {
    let r;
    if ("viewport" === t)
        r = (function (e, t) {
            const n = If(e),
                r = Df(e),
                o = n.visualViewport;
            let i = r.clientWidth,
                s = r.clientHeight,
                a = 0,
                l = 0;
            if (o) {
                (i = o.width), (s = o.height);
                const e = Yf();
                (!e || (e && "fixed" === t)) &&
                    ((a = o.offsetLeft), (l = o.offsetTop));
            }
            return { width: i, height: s, x: a, y: l };
        })(e, n);
    else if ("document" === t)
        r = (function (e) {
            const t = Df(e),
                n = Jf(e),
                r = e.ownerDocument.body,
                o = tf(
                    t.scrollWidth,
                    t.clientWidth,
                    r.scrollWidth,
                    r.clientWidth
                ),
                i = tf(
                    t.scrollHeight,
                    t.clientHeight,
                    r.scrollHeight,
                    r.clientHeight
                );
            let s = -n.scrollLeft + um(e);
            const a = -n.scrollTop;
            return (
                "rtl" === Qf(r).direction &&
                    (s += tf(t.clientWidth, r.clientWidth) - o),
                { width: o, height: i, x: s, y: a }
            );
        })(Df(e));
    else if (Rf(t))
        r = (function (e, t) {
            const n = cm(e, !0, "fixed" === t),
                r = n.top + e.clientTop,
                o = n.left + e.clientLeft,
                i = _f(e) ? sm(e) : of(1);
            return {
                width: e.clientWidth * i.x,
                height: e.clientHeight * i.y,
                x: o * i.x,
                y: r * i.y,
            };
        })(t, n);
    else {
        const n = lm(e);
        r = { x: t.x - n.x, y: t.y - n.y, width: t.width, height: t.height };
    }
    return Sf(r);
}
function fm(e, t) {
    const n = em(e);
    return (
        !(n === t || !Rf(n) || Gf(n)) &&
        ("fixed" === Qf(n).position || fm(n, t))
    );
}
function mm(e, t, n) {
    const r = _f(t),
        o = Df(t),
        i = "fixed" === n,
        s = cm(e, !0, i, t);
    let a = { scrollLeft: 0, scrollTop: 0 };
    const l = of(0);
    function c() {
        l.x = um(o);
    }
    if (r || (!r && !i))
        if ((("body" !== Nf(t) || Ff(o)) && (a = Jf(t)), r)) {
            const e = cm(t, !0, i, t);
            (l.x = e.x + t.clientLeft), (l.y = e.y + t.clientTop);
        } else o && c();
    i && !r && o && c();
    const u = !o || r || i ? of(0) : dm(o, a);
    return {
        x: s.left + a.scrollLeft - l.x - u.x,
        y: s.top + a.scrollTop - l.y - u.y,
        width: s.width,
        height: s.height,
    };
}
function gm(e) {
    return "static" === Qf(e).position;
}
function ym(e, t) {
    if (!_f(e) || "fixed" === Qf(e).position) return null;
    if (t) return t(e);
    let n = e.offsetParent;
    return Df(e) === n && (n = n.ownerDocument.body), n;
}
function xm(e, t) {
    const n = If(e);
    if (zf(e)) return n;
    if (!_f(e)) {
        let t = em(e);
        for (; t && !Gf(t); ) {
            if (Rf(t) && !gm(t)) return t;
            t = em(t);
        }
        return n;
    }
    let r = ym(e, t);
    for (; r && Uf(r) && gm(r); ) r = ym(r, t);
    return r && Gf(r) && gm(r) && !Kf(r)
        ? n
        : r ||
              (function (e) {
                  let t = em(e);
                  for (; _f(t) && !Gf(t); ) {
                      if (Kf(t)) return t;
                      if (zf(t)) return null;
                      t = em(t);
                  }
                  return null;
              })(e) ||
              n;
}
const vm = {
    convertOffsetParentRelativeRectToViewportRelativeRect: function (e) {
        let { elements: t, rect: n, offsetParent: r, strategy: o } = e;
        const i = "fixed" === o,
            s = Df(r),
            a = !!t && zf(t.floating);
        if (r === s || (a && i)) return n;
        let l = { scrollLeft: 0, scrollTop: 0 },
            c = of(1);
        const u = of(0),
            d = _f(r);
        if (
            (d || (!d && !i)) &&
            (("body" !== Nf(r) || Ff(s)) && (l = Jf(r)), _f(r))
        ) {
            const e = cm(r);
            (c = sm(r)), (u.x = e.x + r.clientLeft), (u.y = e.y + r.clientTop);
        }
        const h = !s || d || i ? of(0) : dm(s, l, !0);
        return {
            width: n.width * c.x,
            height: n.height * c.y,
            x: n.x * c.x - l.scrollLeft * c.x + u.x + h.x,
            y: n.y * c.y - l.scrollTop * c.y + u.y + h.y,
        };
    },
    getDocumentElement: Df,
    getClippingRect: function (e) {
        let { element: t, boundary: n, rootBoundary: r, strategy: o } = e;
        const i = [
                ...("clippingAncestors" === n
                    ? zf(t)
                        ? []
                        : (function (e, t) {
                              const n = t.get(e);
                              if (n) return n;
                              let r = nm(e, [], !1).filter(
                                      (e) => Rf(e) && "body" !== Nf(e)
                                  ),
                                  o = null;
                              const i = "fixed" === Qf(e).position;
                              let s = i ? em(e) : e;
                              for (; Rf(s) && !Gf(s); ) {
                                  const t = Qf(s),
                                      n = Kf(s);
                                  n || "fixed" !== t.position || (o = null),
                                      (
                                          i
                                              ? !n && !o
                                              : (!n &&
                                                    "static" === t.position &&
                                                    o &&
                                                    hm.has(o.position)) ||
                                                (Ff(s) && !n && fm(e, s))
                                      )
                                          ? (r = r.filter((e) => e !== s))
                                          : (o = t),
                                      (s = em(s));
                              }
                              return t.set(e, r), r;
                          })(t, this._c)
                    : [].concat(n)),
                r,
            ],
            s = i[0],
            a = i.reduce((e, n) => {
                const r = pm(t, n, o);
                return (
                    (e.top = tf(r.top, e.top)),
                    (e.right = ef(r.right, e.right)),
                    (e.bottom = ef(r.bottom, e.bottom)),
                    (e.left = tf(r.left, e.left)),
                    e
                );
            }, pm(t, s, o));
        return {
            width: a.right - a.left,
            height: a.bottom - a.top,
            x: a.left,
            y: a.top,
        };
    },
    getOffsetParent: xm,
    getElementRects: async function (e) {
        const t = this.getOffsetParent || xm,
            n = this.getDimensions,
            r = await n(e.floating);
        return {
            reference: mm(e.reference, await t(e.floating), e.strategy),
            floating: { x: 0, y: 0, width: r.width, height: r.height },
        };
    },
    getClientRects: function (e) {
        return Array.from(e.getClientRects());
    },
    getDimensions: function (e) {
        const { width: t, height: n } = om(e);
        return { width: t, height: n };
    },
    getScale: sm,
    isElement: Rf,
    isRTL: function (e) {
        return "rtl" === Qf(e).direction;
    },
};
function Cm(e, t) {
    return (
        e.x === t.x &&
        e.y === t.y &&
        e.width === t.width &&
        e.height === t.height
    );
}
function wm(e, t, n, r) {
    void 0 === r && (r = {});
    const {
            ancestorScroll: o = !0,
            ancestorResize: i = !0,
            elementResize: s = "function" == typeof ResizeObserver,
            layoutShift: a = "function" == typeof IntersectionObserver,
            animationFrame: l = !1,
        } = r,
        c = im(e),
        u = o || i ? [...(c ? nm(c) : []), ...nm(t)] : [];
    u.forEach((e) => {
        o && e.addEventListener("scroll", n, { passive: !0 }),
            i && e.addEventListener("resize", n);
    });
    const d =
        c && a
            ? (function (e, t) {
                  let n,
                      r = null;
                  const o = Df(e);
                  function i() {
                      var e;
                      clearTimeout(n),
                          null == (e = r) || e.disconnect(),
                          (r = null);
                  }
                  return (
                      (function s(a, l) {
                          void 0 === a && (a = !1),
                              void 0 === l && (l = 1),
                              i();
                          const c = e.getBoundingClientRect(),
                              { left: u, top: d, width: h, height: p } = c;
                          if ((a || t(), !h || !p)) return;
                          const f = {
                              rootMargin:
                                  -rf(d) +
                                  "px " +
                                  -rf(o.clientWidth - (u + h)) +
                                  "px " +
                                  -rf(o.clientHeight - (d + p)) +
                                  "px " +
                                  -rf(u) +
                                  "px",
                              threshold: tf(0, ef(1, l)) || 1,
                          };
                          let m = !0;
                          function g(t) {
                              const r = t[0].intersectionRatio;
                              if (r !== l) {
                                  if (!m) return s();
                                  r
                                      ? s(!1, r)
                                      : (n = setTimeout(() => {
                                            s(!1, 1e-7);
                                        }, 1e3));
                              }
                              1 !== r ||
                                  Cm(c, e.getBoundingClientRect()) ||
                                  s(),
                                  (m = !1);
                          }
                          try {
                              r = new IntersectionObserver(g, {
                                  ...f,
                                  root: o.ownerDocument,
                              });
                          } catch (y) {
                              r = new IntersectionObserver(g, f);
                          }
                          r.observe(e);
                      })(!0),
                      i
                  );
              })(c, n)
            : null;
    let h,
        p = -1,
        f = null;
    s &&
        ((f = new ResizeObserver((e) => {
            let [r] = e;
            r &&
                r.target === c &&
                f &&
                (f.unobserve(t),
                cancelAnimationFrame(p),
                (p = requestAnimationFrame(() => {
                    var e;
                    null == (e = f) || e.observe(t);
                }))),
                n();
        })),
        c && !l && f.observe(c),
        f.observe(t));
    let m = l ? cm(e) : null;
    return (
        l &&
            (function t() {
                const r = cm(e);
                m && !Cm(m, r) && n();
                (m = r), (h = requestAnimationFrame(t));
            })(),
        n(),
        () => {
            var e;
            u.forEach((e) => {
                o && e.removeEventListener("scroll", n),
                    i && e.removeEventListener("resize", n);
            }),
                null == d || d(),
                null == (e = f) || e.disconnect(),
                (f = null),
                l && cancelAnimationFrame(h);
        }
    );
}
const bm = function (e) {
        return (
            void 0 === e && (e = 0),
            {
                name: "offset",
                options: e,
                async fn(t) {
                    var n, r;
                    const { x: o, y: i, placement: s, middlewareData: a } = t,
                        l = await (async function (e, t) {
                            const {
                                    placement: n,
                                    platform: r,
                                    elements: o,
                                } = e,
                                i = await (null == r.isRTL
                                    ? void 0
                                    : r.isRTL(o.floating)),
                                s = uf(n),
                                a = df(n),
                                l = "y" === mf(n),
                                c = Pf.has(s) ? -1 : 1,
                                u = i && l ? -1 : 1,
                                d = cf(t, e);
                            let {
                                mainAxis: h,
                                crossAxis: p,
                                alignmentAxis: f,
                            } = "number" == typeof d
                                ? {
                                      mainAxis: d,
                                      crossAxis: 0,
                                      alignmentAxis: null,
                                  }
                                : {
                                      mainAxis: d.mainAxis || 0,
                                      crossAxis: d.crossAxis || 0,
                                      alignmentAxis: d.alignmentAxis,
                                  };
                            return (
                                a &&
                                    "number" == typeof f &&
                                    (p = "end" === a ? -1 * f : f),
                                l
                                    ? { x: p * u, y: h * c }
                                    : { x: h * c, y: p * u }
                            );
                        })(t, e);
                    return s ===
                        (null == (n = a.offset) ? void 0 : n.placement) &&
                        null != (r = a.arrow) &&
                        r.alignmentOffset
                        ? {}
                        : {
                              x: o + l.x,
                              y: i + l.y,
                              data: { ...l, placement: s },
                          };
                },
            }
        );
    },
    km = function (e) {
        return (
            void 0 === e && (e = {}),
            {
                name: "shift",
                options: e,
                async fn(t) {
                    const { x: n, y: r, placement: o } = t,
                        {
                            mainAxis: i = !0,
                            crossAxis: s = !1,
                            limiter: a = {
                                fn: (e) => {
                                    let { x: t, y: n } = e;
                                    return { x: t, y: n };
                                },
                            },
                            ...l
                        } = cf(e, t),
                        c = { x: n, y: r },
                        u = await Tf(t, l),
                        d = mf(uf(o)),
                        h = hf(d);
                    let p = c[h],
                        f = c[d];
                    if (i) {
                        const e = "y" === h ? "bottom" : "right";
                        p = lf(p + u["y" === h ? "top" : "left"], p, p - u[e]);
                    }
                    if (s) {
                        const e = "y" === d ? "bottom" : "right";
                        f = lf(f + u["y" === d ? "top" : "left"], f, f - u[e]);
                    }
                    const m = a.fn({ ...t, [h]: p, [d]: f });
                    return {
                        ...m,
                        data: {
                            x: m.x - n,
                            y: m.y - r,
                            enabled: { [h]: i, [d]: s },
                        },
                    };
                },
            }
        );
    },
    Em = function (e) {
        return (
            void 0 === e && (e = {}),
            {
                name: "flip",
                options: e,
                async fn(t) {
                    var n, r;
                    const {
                            placement: o,
                            middlewareData: i,
                            rects: s,
                            initialPlacement: a,
                            platform: l,
                            elements: c,
                        } = t,
                        {
                            mainAxis: u = !0,
                            crossAxis: d = !0,
                            fallbackPlacements: h,
                            fallbackStrategy: p = "bestFit",
                            fallbackAxisSideDirection: f = "none",
                            flipAlignment: m = !0,
                            ...g
                        } = cf(e, t);
                    if (null != (n = i.arrow) && n.alignmentOffset) return {};
                    const y = uf(o),
                        x = mf(a),
                        v = uf(a) === a,
                        C = await (null == l.isRTL
                            ? void 0
                            : l.isRTL(c.floating)),
                        w =
                            h ||
                            (v || !m
                                ? [kf(a)]
                                : (function (e) {
                                      const t = kf(e);
                                      return [yf(e), t, yf(t)];
                                  })(a)),
                        b = "none" !== f;
                    !h && b && w.push(...bf(a, m, f, C));
                    const k = [a, ...w],
                        E = await Tf(t, g),
                        S = [];
                    let A = (null == (r = i.flip) ? void 0 : r.overflows) || [];
                    if ((u && S.push(E[y]), d)) {
                        const e = (function (e, t, n) {
                            void 0 === n && (n = !1);
                            const r = df(e),
                                o = gf(e),
                                i = pf(o);
                            let s =
                                "x" === o
                                    ? r === (n ? "end" : "start")
                                        ? "right"
                                        : "left"
                                    : "start" === r
                                    ? "bottom"
                                    : "top";
                            return (
                                t.reference[i] > t.floating[i] && (s = kf(s)),
                                [s, kf(s)]
                            );
                        })(o, s, C);
                        S.push(E[e[0]], E[e[1]]);
                    }
                    if (
                        ((A = [...A, { placement: o, overflows: S }]),
                        !S.every((e) => e <= 0))
                    ) {
                        var T, L;
                        const e =
                                ((null == (T = i.flip) ? void 0 : T.index) ||
                                    0) + 1,
                            t = k[e];
                        if (t) {
                            if (
                                !("alignment" === d && x !== mf(t)) ||
                                A.every(
                                    (e) =>
                                        mf(e.placement) !== x ||
                                        e.overflows[0] > 0
                                )
                            )
                                return {
                                    data: { index: e, overflows: A },
                                    reset: { placement: t },
                                };
                        }
                        let n =
                            null ==
                            (L = A.filter((e) => e.overflows[0] <= 0).sort(
                                (e, t) => e.overflows[1] - t.overflows[1]
                            )[0])
                                ? void 0
                                : L.placement;
                        if (!n)
                            switch (p) {
                                case "bestFit": {
                                    var M;
                                    const e =
                                        null ==
                                        (M = A.filter((e) => {
                                            if (b) {
                                                const t = mf(e.placement);
                                                return t === x || "y" === t;
                                            }
                                            return !0;
                                        })
                                            .map((e) => [
                                                e.placement,
                                                e.overflows
                                                    .filter((e) => e > 0)
                                                    .reduce((e, t) => e + t, 0),
                                            ])
                                            .sort((e, t) => e[1] - t[1])[0])
                                            ? void 0
                                            : M[0];
                                    e && (n = e);
                                    break;
                                }
                                case "initialPlacement":
                                    n = a;
                            }
                        if (o !== n) return { reset: { placement: n } };
                    }
                    return {};
                },
            }
        );
    },
    Sm = function (e) {
        return (
            void 0 === e && (e = {}),
            {
                name: "size",
                options: e,
                async fn(t) {
                    var n, r;
                    const {
                            placement: o,
                            rects: i,
                            platform: s,
                            elements: a,
                        } = t,
                        { apply: l = () => {}, ...c } = cf(e, t),
                        u = await Tf(t, c),
                        d = uf(o),
                        h = df(o),
                        p = "y" === mf(o),
                        { width: f, height: m } = i.floating;
                    let g, y;
                    "top" === d || "bottom" === d
                        ? ((g = d),
                          (y =
                              h ===
                              ((await (null == s.isRTL
                                  ? void 0
                                  : s.isRTL(a.floating)))
                                  ? "start"
                                  : "end")
                                  ? "left"
                                  : "right"))
                        : ((y = d), (g = "end" === h ? "top" : "bottom"));
                    const x = m - u.top - u.bottom,
                        v = f - u.left - u.right,
                        C = ef(m - u[g], x),
                        w = ef(f - u[y], v),
                        b = !t.middlewareData.shift;
                    let k = C,
                        E = w;
                    if (
                        (null != (n = t.middlewareData.shift) &&
                            n.enabled.x &&
                            (E = v),
                        null != (r = t.middlewareData.shift) &&
                            r.enabled.y &&
                            (k = x),
                        b && !h)
                    ) {
                        const e = tf(u.left, 0),
                            t = tf(u.right, 0),
                            n = tf(u.top, 0),
                            r = tf(u.bottom, 0);
                        p
                            ? (E =
                                  f -
                                  2 *
                                      (0 !== e || 0 !== t
                                          ? e + t
                                          : tf(u.left, u.right)))
                            : (k =
                                  m -
                                  2 *
                                      (0 !== n || 0 !== r
                                          ? n + r
                                          : tf(u.top, u.bottom)));
                    }
                    await l({ ...t, availableWidth: E, availableHeight: k });
                    const S = await s.getDimensions(a.floating);
                    return f !== S.width || m !== S.height
                        ? { reset: { rects: !0 } }
                        : {};
                },
            }
        );
    },
    Am = function (e) {
        return (
            void 0 === e && (e = {}),
            {
                name: "hide",
                options: e,
                async fn(t) {
                    const { rects: n } = t,
                        { strategy: r = "referenceHidden", ...o } = cf(e, t);
                    switch (r) {
                        case "referenceHidden": {
                            const e = Lf(
                                await Tf(t, {
                                    ...o,
                                    elementContext: "reference",
                                }),
                                n.reference
                            );
                            return {
                                data: {
                                    referenceHiddenOffsets: e,
                                    referenceHidden: Mf(e),
                                },
                            };
                        }
                        case "escaped": {
                            const e = Lf(
                                await Tf(t, { ...o, altBoundary: !0 }),
                                n.floating
                            );
                            return {
                                data: { escapedOffsets: e, escaped: Mf(e) },
                            };
                        }
                        default:
                            return {};
                    }
                },
            }
        );
    },
    Tm = (e) => ({
        name: "arrow",
        options: e,
        async fn(t) {
            const {
                    x: n,
                    y: r,
                    placement: o,
                    rects: i,
                    platform: s,
                    elements: a,
                    middlewareData: l,
                } = t,
                { element: c, padding: u = 0 } = cf(e, t) || {};
            if (null == c) return {};
            const d = Ef(u),
                h = { x: n, y: r },
                p = gf(o),
                f = pf(p),
                m = await s.getDimensions(c),
                g = "y" === p,
                y = g ? "top" : "left",
                x = g ? "bottom" : "right",
                v = g ? "clientHeight" : "clientWidth",
                C = i.reference[f] + i.reference[p] - h[p] - i.floating[f],
                w = h[p] - i.reference[p],
                b = await (null == s.getOffsetParent
                    ? void 0
                    : s.getOffsetParent(c));
            let k = b ? b[v] : 0;
            (k && (await (null == s.isElement ? void 0 : s.isElement(b)))) ||
                (k = a.floating[v] || i.floating[f]);
            const E = C / 2 - w / 2,
                S = k / 2 - m[f] / 2 - 1,
                A = ef(d[y], S),
                T = ef(d[x], S),
                L = A,
                M = k - m[f] - T,
                P = k / 2 - m[f] / 2 + E,
                j = lf(L, P, M),
                N =
                    !l.arrow &&
                    null != df(o) &&
                    P !== j &&
                    i.reference[f] / 2 - (P < L ? A : T) - m[f] / 2 < 0,
                I = N ? (P < L ? P - L : P - M) : 0;
            return {
                [p]: h[p] + I,
                data: {
                    [p]: j,
                    centerOffset: P - j - I,
                    ...(N && { alignmentOffset: I }),
                },
                reset: N,
            };
        },
    }),
    Lm = function (e) {
        return (
            void 0 === e && (e = {}),
            {
                options: e,
                fn(t) {
                    const {
                            x: n,
                            y: r,
                            placement: o,
                            rects: i,
                            middlewareData: s,
                        } = t,
                        {
                            offset: a = 0,
                            mainAxis: l = !0,
                            crossAxis: c = !0,
                        } = cf(e, t),
                        u = { x: n, y: r },
                        d = mf(o),
                        h = hf(d);
                    let p = u[h],
                        f = u[d];
                    const m = cf(a, t),
                        g =
                            "number" == typeof m
                                ? { mainAxis: m, crossAxis: 0 }
                                : { mainAxis: 0, crossAxis: 0, ...m };
                    if (l) {
                        const e = "y" === h ? "height" : "width",
                            t = i.reference[h] - i.floating[e] + g.mainAxis,
                            n = i.reference[h] + i.reference[e] - g.mainAxis;
                        p < t ? (p = t) : p > n && (p = n);
                    }
                    if (c) {
                        var y, x;
                        const e = "y" === h ? "width" : "height",
                            t = Pf.has(uf(o)),
                            n =
                                i.reference[d] -
                                i.floating[e] +
                                ((t &&
                                    (null == (y = s.offset) ? void 0 : y[d])) ||
                                    0) +
                                (t ? 0 : g.crossAxis),
                            r =
                                i.reference[d] +
                                i.reference[e] +
                                (t
                                    ? 0
                                    : (null == (x = s.offset)
                                          ? void 0
                                          : x[d]) || 0) -
                                (t ? g.crossAxis : 0);
                        f < n ? (f = n) : f > r && (f = r);
                    }
                    return { [h]: p, [d]: f };
                },
            }
        );
    },
    Mm = (e, t, n) => {
        const r = new Map(),
            o = { platform: vm, ...n },
            i = { ...o.platform, _c: r };
        return (async (e, t, n) => {
            const {
                    placement: r = "bottom",
                    strategy: o = "absolute",
                    middleware: i = [],
                    platform: s,
                } = n,
                a = i.filter(Boolean),
                l = await (null == s.isRTL ? void 0 : s.isRTL(t));
            let c = await s.getElementRects({
                    reference: e,
                    floating: t,
                    strategy: o,
                }),
                { x: u, y: d } = Af(c, r, l),
                h = r,
                p = {},
                f = 0;
            for (let m = 0; m < a.length; m++) {
                const { name: n, fn: i } = a[m],
                    {
                        x: g,
                        y: y,
                        data: x,
                        reset: v,
                    } = await i({
                        x: u,
                        y: d,
                        initialPlacement: r,
                        placement: h,
                        strategy: o,
                        middlewareData: p,
                        rects: c,
                        platform: s,
                        elements: { reference: e, floating: t },
                    });
                (u = null != g ? g : u),
                    (d = null != y ? y : d),
                    (p = { ...p, [n]: { ...p[n], ...x } }),
                    v &&
                        f <= 50 &&
                        (f++,
                        "object" == typeof v &&
                            (v.placement && (h = v.placement),
                            v.rects &&
                                (c =
                                    !0 === v.rects
                                        ? await s.getElementRects({
                                              reference: e,
                                              floating: t,
                                              strategy: o,
                                          })
                                        : v.rects),
                            ({ x: u, y: d } = Af(c, h, l))),
                        (m = -1));
            }
            return { x: u, y: d, placement: h, strategy: o, middlewareData: p };
        })(e, t, { ...o, platform: i });
    };
var Pm = "undefined" != typeof document ? r.useLayoutEffect : function () {};
function jm(e, t) {
    if (e === t) return !0;
    if (typeof e != typeof t) return !1;
    if ("function" == typeof e && e.toString() === t.toString()) return !0;
    let n, r, o;
    if (e && t && "object" == typeof e) {
        if (Array.isArray(e)) {
            if (((n = e.length), n !== t.length)) return !1;
            for (r = n; 0 !== r--; ) if (!jm(e[r], t[r])) return !1;
            return !0;
        }
        if (((o = Object.keys(e)), (n = o.length), n !== Object.keys(t).length))
            return !1;
        for (r = n; 0 !== r--; )
            if (!{}.hasOwnProperty.call(t, o[r])) return !1;
        for (r = n; 0 !== r--; ) {
            const n = o[r];
            if (("_owner" !== n || !e.$$typeof) && !jm(e[n], t[n])) return !1;
        }
        return !0;
    }
    return e != e && t != t;
}
function Nm(e) {
    if ("undefined" == typeof window) return 1;
    return (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function Im(e, t) {
    const n = Nm(e);
    return Math.round(t * n) / n;
}
function Dm(e) {
    const t = r.useRef(e);
    return (
        Pm(() => {
            t.current = e;
        }),
        t
    );
}
const Vm = (e) => ({
        name: "arrow",
        options: e,
        fn(t) {
            const { element: n, padding: r } =
                "function" == typeof e ? e(t) : e;
            return n && ((o = n), {}.hasOwnProperty.call(o, "current"))
                ? null != n.current
                    ? Tm({ element: n.current, padding: r }).fn(t)
                    : {}
                : n
                ? Tm({ element: n, padding: r }).fn(t)
                : {};
            var o;
        },
    }),
    Rm = (e, t) => ({ ...km(e), options: [e, t] }),
    _m = (e, t) => ({ ...Lm(e), options: [e, t] }),
    Om = (e, t) => ({ ...Em(e), options: [e, t] }),
    Hm = (e, t) => ({ ...Sm(e), options: [e, t] }),
    Fm = (e, t) => ({ ...Am(e), options: [e, t] }),
    Bm = (e, t) => ({ ...Vm(e), options: [e, t] });
var Um = r.forwardRef((e, t) => {
    const { children: n, width: r = 10, height: o = 5, ...i } = e;
    return a.jsx(Fp.svg, {
        ...i,
        ref: t,
        width: r,
        height: o,
        viewBox: "0 0 30 10",
        preserveAspectRatio: "none",
        children: e.asChild
            ? n
            : a.jsx("polygon", { points: "0,0 30,0 15,10" }),
    });
});
Um.displayName = "Arrow";
var Zm = Um;
var zm = "Popper",
    [$m, Wm] = jp(zm),
    [qm, Km] = $m(zm),
    Ym = (e) => {
        const { __scopePopper: t, children: n } = e,
            [o, i] = r.useState(null);
        return a.jsx(qm, {
            scope: t,
            anchor: o,
            onAnchorChange: i,
            children: n,
        });
    };
Ym.displayName = zm;
var Xm = "PopperAnchor",
    Gm = r.forwardRef((e, t) => {
        const { __scopePopper: n, virtualRef: o, ...i } = e,
            s = Km(Xm, n),
            l = r.useRef(null),
            c = Pp(t, l);
        return (
            r.useEffect(() => {
                s.onAnchorChange(o?.current || l.current);
            }),
            o ? null : a.jsx(Fp.div, { ...i, ref: c })
        );
    });
Gm.displayName = Xm;
var Qm = "PopperContent",
    [Jm, eg] = $m(Qm),
    tg = r.forwardRef((e, t) => {
        const {
                __scopePopper: n,
                side: o = "bottom",
                sideOffset: i = 0,
                align: s = "center",
                alignOffset: l = 0,
                arrowPadding: c = 0,
                avoidCollisions: u = !0,
                collisionBoundary: d = [],
                collisionPadding: h = 0,
                sticky: p = "partial",
                hideWhenDetached: f = !1,
                updatePositionStrategy: m = "optimized",
                onPlaced: g,
                ...y
            } = e,
            x = Km(Qm, n),
            [v, C] = r.useState(null),
            w = Pp(t, (e) => C(e)),
            [b, k] = r.useState(null),
            E = (function (e) {
                const [t, n] = r.useState(void 0);
                return (
                    Xp(() => {
                        if (e) {
                            n({ width: e.offsetWidth, height: e.offsetHeight });
                            const t = new ResizeObserver((t) => {
                                if (!Array.isArray(t)) return;
                                if (!t.length) return;
                                const r = t[0];
                                let o, i;
                                if ("borderBoxSize" in r) {
                                    const e = r.borderBoxSize,
                                        t = Array.isArray(e) ? e[0] : e;
                                    (o = t.inlineSize), (i = t.blockSize);
                                } else
                                    (o = e.offsetWidth), (i = e.offsetHeight);
                                n({ width: o, height: i });
                            });
                            return (
                                t.observe(e, { box: "border-box" }),
                                () => t.unobserve(e)
                            );
                        }
                        n(void 0);
                    }, [e]),
                    t
                );
            })(b),
            S = E?.width ?? 0,
            A = E?.height ?? 0,
            T = o + ("center" !== s ? "-" + s : ""),
            L =
                "number" == typeof h
                    ? h
                    : { top: 0, right: 0, bottom: 0, left: 0, ...h },
            M = Array.isArray(d) ? d : [d],
            P = M.length > 0,
            j = { padding: L, boundary: M.filter(ig), altBoundary: P },
            {
                refs: N,
                floatingStyles: I,
                placement: D,
                isPositioned: V,
                middlewareData: R,
            } = (function (e) {
                void 0 === e && (e = {});
                const {
                        placement: t = "bottom",
                        strategy: n = "absolute",
                        middleware: o = [],
                        platform: i,
                        elements: { reference: s, floating: a } = {},
                        transform: l = !0,
                        whileElementsMounted: c,
                        open: u,
                    } = e,
                    [d, h] = r.useState({
                        x: 0,
                        y: 0,
                        strategy: n,
                        placement: t,
                        middlewareData: {},
                        isPositioned: !1,
                    }),
                    [p, f] = r.useState(o);
                jm(p, o) || f(o);
                const [m, g] = r.useState(null),
                    [y, x] = r.useState(null),
                    v = r.useCallback((e) => {
                        e !== k.current && ((k.current = e), g(e));
                    }, []),
                    C = r.useCallback((e) => {
                        e !== E.current && ((E.current = e), x(e));
                    }, []),
                    w = s || m,
                    b = a || y,
                    k = r.useRef(null),
                    E = r.useRef(null),
                    S = r.useRef(d),
                    A = null != c,
                    T = Dm(c),
                    L = Dm(i),
                    M = Dm(u),
                    P = r.useCallback(() => {
                        if (!k.current || !E.current) return;
                        const e = { placement: t, strategy: n, middleware: p };
                        L.current && (e.platform = L.current),
                            Mm(k.current, E.current, e).then((e) => {
                                const t = {
                                    ...e,
                                    isPositioned: !1 !== M.current,
                                };
                                j.current &&
                                    !jm(S.current, t) &&
                                    ((S.current = t),
                                    Ip.flushSync(() => {
                                        h(t);
                                    }));
                            });
                    }, [p, t, n, L, M]);
                Pm(() => {
                    !1 === u &&
                        S.current.isPositioned &&
                        ((S.current.isPositioned = !1),
                        h((e) => ({ ...e, isPositioned: !1 })));
                }, [u]);
                const j = r.useRef(!1);
                Pm(
                    () => (
                        (j.current = !0),
                        () => {
                            j.current = !1;
                        }
                    ),
                    []
                ),
                    Pm(() => {
                        if (
                            (w && (k.current = w), b && (E.current = b), w && b)
                        ) {
                            if (T.current) return T.current(w, b, P);
                            P();
                        }
                    }, [w, b, P, T, A]);
                const N = r.useMemo(
                        () => ({
                            reference: k,
                            floating: E,
                            setReference: v,
                            setFloating: C,
                        }),
                        [v, C]
                    ),
                    I = r.useMemo(
                        () => ({ reference: w, floating: b }),
                        [w, b]
                    ),
                    D = r.useMemo(() => {
                        const e = { position: n, left: 0, top: 0 };
                        if (!I.floating) return e;
                        const t = Im(I.floating, d.x),
                            r = Im(I.floating, d.y);
                        return l
                            ? {
                                  ...e,
                                  transform:
                                      "translate(" + t + "px, " + r + "px)",
                                  ...(Nm(I.floating) >= 1.5 && {
                                      willChange: "transform",
                                  }),
                              }
                            : { position: n, left: t, top: r };
                    }, [n, l, I.floating, d.x, d.y]);
                return r.useMemo(
                    () => ({
                        ...d,
                        update: P,
                        refs: N,
                        elements: I,
                        floatingStyles: D,
                    }),
                    [d, P, N, I, D]
                );
            })({
                strategy: "fixed",
                placement: T,
                whileElementsMounted: (...e) =>
                    wm(...e, { animationFrame: "always" === m }),
                elements: { reference: x.anchor },
                middleware: [
                    ((_ = { mainAxis: i + A, alignmentAxis: l }),
                    { ...bm(_), options: [_, O] }),
                    u &&
                        Rm({
                            mainAxis: !0,
                            crossAxis: !1,
                            limiter: "partial" === p ? _m() : void 0,
                            ...j,
                        }),
                    u && Om({ ...j }),
                    Hm({
                        ...j,
                        apply: ({
                            elements: e,
                            rects: t,
                            availableWidth: n,
                            availableHeight: r,
                        }) => {
                            const { width: o, height: i } = t.reference,
                                s = e.floating.style;
                            s.setProperty(
                                "--radix-popper-available-width",
                                `${n}px`
                            ),
                                s.setProperty(
                                    "--radix-popper-available-height",
                                    `${r}px`
                                ),
                                s.setProperty(
                                    "--radix-popper-anchor-width",
                                    `${o}px`
                                ),
                                s.setProperty(
                                    "--radix-popper-anchor-height",
                                    `${i}px`
                                );
                        },
                    }),
                    b && Bm({ element: b, padding: c }),
                    sg({ arrowWidth: S, arrowHeight: A }),
                    f && Fm({ strategy: "referenceHidden", ...j }),
                ],
            });
        var _, O;
        const [H, F] = ag(D),
            B = Bp(g);
        Xp(() => {
            V && B?.();
        }, [V, B]);
        const U = R.arrow?.x,
            Z = R.arrow?.y,
            z = 0 !== R.arrow?.centerOffset,
            [$, W] = r.useState();
        return (
            Xp(() => {
                v && W(window.getComputedStyle(v).zIndex);
            }, [v]),
            a.jsx("div", {
                ref: N.setFloating,
                "data-radix-popper-content-wrapper": "",
                style: {
                    ...I,
                    transform: V ? I.transform : "translate(0, -200%)",
                    minWidth: "max-content",
                    zIndex: $,
                    "--radix-popper-transform-origin": [
                        R.transformOrigin?.x,
                        R.transformOrigin?.y,
                    ].join(" "),
                    ...(R.hide?.referenceHidden && {
                        visibility: "hidden",
                        pointerEvents: "none",
                    }),
                },
                dir: e.dir,
                children: a.jsx(Jm, {
                    scope: n,
                    placedSide: H,
                    onArrowChange: k,
                    arrowX: U,
                    arrowY: Z,
                    shouldHideArrow: z,
                    children: a.jsx(Fp.div, {
                        "data-side": H,
                        "data-align": F,
                        ...y,
                        ref: w,
                        style: { ...y.style, animation: V ? void 0 : "none" },
                    }),
                }),
            })
        );
    });
tg.displayName = Qm;
var ng = "PopperArrow",
    rg = { top: "bottom", right: "left", bottom: "top", left: "right" },
    og = r.forwardRef(function (e, t) {
        const { __scopePopper: n, ...r } = e,
            o = eg(ng, n),
            i = rg[o.placedSide];
        return a.jsx("span", {
            ref: o.onArrowChange,
            style: {
                position: "absolute",
                left: o.arrowX,
                top: o.arrowY,
                [i]: 0,
                transformOrigin: {
                    top: "",
                    right: "0 0",
                    bottom: "center 0",
                    left: "100% 0",
                }[o.placedSide],
                transform: {
                    top: "translateY(100%)",
                    right: "translateY(50%) rotate(90deg) translateX(-50%)",
                    bottom: "rotate(180deg)",
                    left: "translateY(50%) rotate(-90deg) translateX(50%)",
                }[o.placedSide],
                visibility: o.shouldHideArrow ? "hidden" : void 0,
            },
            children: a.jsx(Zm, {
                ...r,
                ref: t,
                style: { ...r.style, display: "block" },
            }),
        });
    });
function ig(e) {
    return null !== e;
}
og.displayName = ng;
var sg = (e) => ({
    name: "transformOrigin",
    options: e,
    fn(t) {
        const { placement: n, rects: r, middlewareData: o } = t,
            i = 0 !== o.arrow?.centerOffset,
            s = i ? 0 : e.arrowWidth,
            a = i ? 0 : e.arrowHeight,
            [l, c] = ag(n),
            u = { start: "0%", center: "50%", end: "100%" }[c],
            d = (o.arrow?.x ?? 0) + s / 2,
            h = (o.arrow?.y ?? 0) + a / 2;
        let p = "",
            f = "";
        return (
            "bottom" === l
                ? ((p = i ? u : `${d}px`), (f = -a + "px"))
                : "top" === l
                ? ((p = i ? u : `${d}px`), (f = `${r.floating.height + a}px`))
                : "right" === l
                ? ((p = -a + "px"), (f = i ? u : `${h}px`))
                : "left" === l &&
                  ((p = `${r.floating.width + a}px`), (f = i ? u : `${h}px`)),
            { data: { x: p, y: f } }
        );
    },
});
function ag(e) {
    const [t, n = "center"] = e.split("-");
    return [t, n];
}
var lg = Ym,
    cg = Gm,
    ug = tg,
    dg = og,
    hg = r.forwardRef((e, t) => {
        const { container: n, ...o } = e,
            [i, s] = r.useState(!1);
        Xp(() => s(!0), []);
        const l = n || (i && globalThis?.document?.body);
        return l ? Dp.createPortal(a.jsx(Fp.div, { ...o, ref: t }), l) : null;
    });
hg.displayName = "Portal";
var pg = (e) => {
    const { present: t, children: n } = e,
        o = (function (e) {
            const [t, n] = r.useState(),
                o = r.useRef(null),
                i = r.useRef(e),
                s = r.useRef("none"),
                a = e ? "mounted" : "unmounted",
                [l, c] = (function (e, t) {
                    return r.useReducer((e, n) => t[e][n] ?? e, e);
                })(a, {
                    mounted: {
                        UNMOUNT: "unmounted",
                        ANIMATION_OUT: "unmountSuspended",
                    },
                    unmountSuspended: {
                        MOUNT: "mounted",
                        ANIMATION_END: "unmounted",
                    },
                    unmounted: { MOUNT: "mounted" },
                });
            return (
                r.useEffect(() => {
                    const e = fg(o.current);
                    s.current = "mounted" === l ? e : "none";
                }, [l]),
                Xp(() => {
                    const t = o.current,
                        n = i.current;
                    if (n !== e) {
                        const r = s.current,
                            o = fg(t);
                        if (e) c("MOUNT");
                        else if ("none" === o || "none" === t?.display)
                            c("UNMOUNT");
                        else {
                            c(n && r !== o ? "ANIMATION_OUT" : "UNMOUNT");
                        }
                        i.current = e;
                    }
                }, [e, c]),
                Xp(() => {
                    if (t) {
                        let e;
                        const n = t.ownerDocument.defaultView ?? window,
                            r = (r) => {
                                const s = fg(o.current).includes(
                                    r.animationName
                                );
                                if (
                                    r.target === t &&
                                    s &&
                                    (c("ANIMATION_END"), !i.current)
                                ) {
                                    const r = t.style.animationFillMode;
                                    (t.style.animationFillMode = "forwards"),
                                        (e = n.setTimeout(() => {
                                            "forwards" ===
                                                t.style.animationFillMode &&
                                                (t.style.animationFillMode = r);
                                        }));
                                }
                            },
                            a = (e) => {
                                e.target === t && (s.current = fg(o.current));
                            };
                        return (
                            t.addEventListener("animationstart", a),
                            t.addEventListener("animationcancel", r),
                            t.addEventListener("animationend", r),
                            () => {
                                n.clearTimeout(e),
                                    t.removeEventListener("animationstart", a),
                                    t.removeEventListener("animationcancel", r),
                                    t.removeEventListener("animationend", r);
                            }
                        );
                    }
                    c("ANIMATION_END");
                }, [t, c]),
                {
                    isPresent: ["mounted", "unmountSuspended"].includes(l),
                    ref: r.useCallback((e) => {
                        (o.current = e ? getComputedStyle(e) : null), n(e);
                    }, []),
                }
            );
        })(t),
        i =
            "function" == typeof n
                ? n({ present: o.isPresent })
                : r.Children.only(n),
        s = Pp(
            o.ref,
            (function (e) {
                let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get,
                    n = t && "isReactWarning" in t && t.isReactWarning;
                if (n) return e.ref;
                if (
                    ((t = Object.getOwnPropertyDescriptor(e, "ref")?.get),
                    (n = t && "isReactWarning" in t && t.isReactWarning),
                    n)
                )
                    return e.props.ref;
                return e.props.ref || e.ref;
            })(i)
        );
    return "function" == typeof n || o.isPresent
        ? r.cloneElement(i, { ref: s })
        : null;
};
function fg(e) {
    return e?.animationName || "none";
}
pg.displayName = "Presence";
var mg = h[" useInsertionEffect ".trim().toString()] || Xp;
function gg({ prop: e, defaultProp: t, onChange: n = () => {}, caller: o }) {
    const [i, s, a] = (function ({ defaultProp: e, onChange: t }) {
            const [n, o] = r.useState(e),
                i = r.useRef(n),
                s = r.useRef(t);
            return (
                mg(() => {
                    s.current = t;
                }, [t]),
                r.useEffect(() => {
                    i.current !== n && (s.current?.(n), (i.current = n));
                }, [n, i]),
                [n, o, s]
            );
        })({ defaultProp: t, onChange: n }),
        l = void 0 !== e,
        c = l ? e : i;
    {
        const t = r.useRef(void 0 !== e);
        r.useEffect(() => {
            const e = t.current;
            if (e !== l) {
            }
            t.current = l;
        }, [l, o]);
    }
    const u = r.useCallback(
        (t) => {
            if (l) {
                const n = (function (e) {
                    return "function" == typeof e;
                })(t)
                    ? t(e)
                    : t;
                n !== e && a.current?.(n);
            } else s(t);
        },
        [l, e, s, a]
    );
    return [c, u];
}
var yg = Object.freeze({
        position: "absolute",
        border: 0,
        width: 1,
        height: 1,
        padding: 0,
        margin: -1,
        overflow: "hidden",
        clip: "rect(0, 0, 0, 0)",
        whiteSpace: "nowrap",
        wordWrap: "normal",
    }),
    xg = r.forwardRef((e, t) =>
        a.jsx(Fp.span, { ...e, ref: t, style: { ...yg, ...e.style } })
    );
xg.displayName = "VisuallyHidden";
var vg = xg,
    [Cg, wg] = jp("Tooltip", [Wm]),
    bg = Wm(),
    kg = "TooltipProvider",
    Eg = 700,
    Sg = "tooltip.open",
    [Ag, Tg] = Cg(kg),
    Lg = (e) => {
        const {
                __scopeTooltip: t,
                delayDuration: n = Eg,
                skipDelayDuration: o = 300,
                disableHoverableContent: i = !1,
                children: s,
            } = e,
            l = r.useRef(!0),
            c = r.useRef(!1),
            u = r.useRef(0);
        return (
            r.useEffect(() => {
                const e = u.current;
                return () => window.clearTimeout(e);
            }, []),
            a.jsx(Ag, {
                scope: t,
                isOpenDelayedRef: l,
                delayDuration: n,
                onOpen: r.useCallback(() => {
                    window.clearTimeout(u.current), (l.current = !1);
                }, []),
                onClose: r.useCallback(() => {
                    window.clearTimeout(u.current),
                        (u.current = window.setTimeout(
                            () => (l.current = !0),
                            o
                        ));
                }, [o]),
                isPointerInTransitRef: c,
                onPointerInTransitChange: r.useCallback((e) => {
                    c.current = e;
                }, []),
                disableHoverableContent: i,
                children: s,
            })
        );
    };
Lg.displayName = kg;
var Mg = "Tooltip",
    [Pg, jg] = Cg(Mg),
    Ng = (e) => {
        const {
                __scopeTooltip: t,
                children: n,
                open: o,
                defaultOpen: i,
                onOpenChange: s,
                disableHoverableContent: l,
                delayDuration: c,
            } = e,
            u = Tg(Mg, e.__scopeTooltip),
            d = bg(t),
            [h, p] = r.useState(null),
            f = (function (e) {
                const [t, n] = r.useState(Gp());
                return (
                    Xp(() => {
                        n((e) => e ?? String(Qp++));
                    }, [e]),
                    t ? `radix-${t}` : ""
                );
            })(),
            m = r.useRef(0),
            g = l ?? u.disableHoverableContent,
            y = c ?? u.delayDuration,
            x = r.useRef(!1),
            [v, C] = gg({
                prop: o,
                defaultProp: i ?? !1,
                onChange: (e) => {
                    e
                        ? (u.onOpen(),
                          document.dispatchEvent(new CustomEvent(Sg)))
                        : u.onClose(),
                        s?.(e);
                },
                caller: Mg,
            }),
            w = r.useMemo(
                () =>
                    v
                        ? x.current
                            ? "delayed-open"
                            : "instant-open"
                        : "closed",
                [v]
            ),
            b = r.useCallback(() => {
                window.clearTimeout(m.current),
                    (m.current = 0),
                    (x.current = !1),
                    C(!0);
            }, [C]),
            k = r.useCallback(() => {
                window.clearTimeout(m.current), (m.current = 0), C(!1);
            }, [C]),
            E = r.useCallback(() => {
                window.clearTimeout(m.current),
                    (m.current = window.setTimeout(() => {
                        (x.current = !0), C(!0), (m.current = 0);
                    }, y));
            }, [y, C]);
        return (
            r.useEffect(
                () => () => {
                    m.current &&
                        (window.clearTimeout(m.current), (m.current = 0));
                },
                []
            ),
            a.jsx(lg, {
                ...d,
                children: a.jsx(Pg, {
                    scope: t,
                    contentId: f,
                    open: v,
                    stateAttribute: w,
                    trigger: h,
                    onTriggerChange: p,
                    onTriggerEnter: r.useCallback(() => {
                        u.isOpenDelayedRef.current ? E() : b();
                    }, [u.isOpenDelayedRef, E, b]),
                    onTriggerLeave: r.useCallback(() => {
                        g
                            ? k()
                            : (window.clearTimeout(m.current), (m.current = 0));
                    }, [k, g]),
                    onOpen: b,
                    onClose: k,
                    disableHoverableContent: g,
                    children: n,
                }),
            })
        );
    };
Ng.displayName = Mg;
var Ig = "TooltipTrigger",
    Dg = r.forwardRef((e, t) => {
        const { __scopeTooltip: n, ...o } = e,
            i = jg(Ig, n),
            s = Tg(Ig, n),
            l = bg(n),
            c = Pp(t, r.useRef(null), i.onTriggerChange),
            u = r.useRef(!1),
            d = r.useRef(!1),
            h = r.useCallback(() => (u.current = !1), []);
        return (
            r.useEffect(
                () => () => document.removeEventListener("pointerup", h),
                [h]
            ),
            a.jsx(cg, {
                asChild: !0,
                ...l,
                children: a.jsx(Fp.button, {
                    "aria-describedby": i.open ? i.contentId : void 0,
                    "data-state": i.stateAttribute,
                    ...o,
                    ref: c,
                    onPointerMove: Tp(e.onPointerMove, (e) => {
                        "touch" !== e.pointerType &&
                            (d.current ||
                                s.isPointerInTransitRef.current ||
                                (i.onTriggerEnter(), (d.current = !0)));
                    }),
                    onPointerLeave: Tp(e.onPointerLeave, () => {
                        i.onTriggerLeave(), (d.current = !1);
                    }),
                    onPointerDown: Tp(e.onPointerDown, () => {
                        i.open && i.onClose(),
                            (u.current = !0),
                            document.addEventListener("pointerup", h, {
                                once: !0,
                            });
                    }),
                    onFocus: Tp(e.onFocus, () => {
                        u.current || i.onOpen();
                    }),
                    onBlur: Tp(e.onBlur, i.onClose),
                    onClick: Tp(e.onClick, i.onClose),
                }),
            })
        );
    });
Dg.displayName = Ig;
var Vg = "TooltipPortal",
    [Rg, _g] = Cg(Vg, { forceMount: void 0 }),
    Og = (e) => {
        const {
                __scopeTooltip: t,
                forceMount: n,
                children: r,
                container: o,
            } = e,
            i = jg(Vg, t);
        return a.jsx(Rg, {
            scope: t,
            forceMount: n,
            children: a.jsx(pg, {
                present: n || i.open,
                children: a.jsx(hg, { asChild: !0, container: o, children: r }),
            }),
        });
    };
Og.displayName = Vg;
var Hg = "TooltipContent",
    Fg = r.forwardRef((e, t) => {
        const n = _g(Hg, e.__scopeTooltip),
            { forceMount: r = n.forceMount, side: o = "top", ...i } = e,
            s = jg(Hg, e.__scopeTooltip);
        return a.jsx(pg, {
            present: r || s.open,
            children: s.disableHoverableContent
                ? a.jsx($g, { side: o, ...i, ref: t })
                : a.jsx(Bg, { side: o, ...i, ref: t }),
        });
    }),
    Bg = r.forwardRef((e, t) => {
        const n = jg(Hg, e.__scopeTooltip),
            o = Tg(Hg, e.__scopeTooltip),
            i = r.useRef(null),
            s = Pp(t, i),
            [l, c] = r.useState(null),
            { trigger: u, onClose: d } = n,
            h = i.current,
            { onPointerInTransitChange: p } = o,
            f = r.useCallback(() => {
                c(null), p(!1);
            }, [p]),
            m = r.useCallback(
                (e, t) => {
                    const n = e.currentTarget,
                        r = { x: e.clientX, y: e.clientY },
                        o = (function (e, t, n = 5) {
                            const r = [];
                            switch (t) {
                                case "top":
                                    r.push(
                                        { x: e.x - n, y: e.y + n },
                                        { x: e.x + n, y: e.y + n }
                                    );
                                    break;
                                case "bottom":
                                    r.push(
                                        { x: e.x - n, y: e.y - n },
                                        { x: e.x + n, y: e.y - n }
                                    );
                                    break;
                                case "left":
                                    r.push(
                                        { x: e.x + n, y: e.y - n },
                                        { x: e.x + n, y: e.y + n }
                                    );
                                    break;
                                case "right":
                                    r.push(
                                        { x: e.x - n, y: e.y - n },
                                        { x: e.x - n, y: e.y + n }
                                    );
                            }
                            return r;
                        })(
                            r,
                            (function (e, t) {
                                const n = Math.abs(t.top - e.y),
                                    r = Math.abs(t.bottom - e.y),
                                    o = Math.abs(t.right - e.x),
                                    i = Math.abs(t.left - e.x);
                                switch (Math.min(n, r, o, i)) {
                                    case i:
                                        return "left";
                                    case o:
                                        return "right";
                                    case n:
                                        return "top";
                                    case r:
                                        return "bottom";
                                    default:
                                        throw new Error("unreachable");
                                }
                            })(r, n.getBoundingClientRect())
                        ),
                        i = (function (e) {
                            const t = e.slice();
                            return (
                                t.sort((e, t) =>
                                    e.x < t.x
                                        ? -1
                                        : e.x > t.x
                                        ? 1
                                        : e.y < t.y
                                        ? -1
                                        : e.y > t.y
                                        ? 1
                                        : 0
                                ),
                                (function (e) {
                                    if (e.length <= 1) return e.slice();
                                    const t = [];
                                    for (let r = 0; r < e.length; r++) {
                                        const n = e[r];
                                        for (; t.length >= 2; ) {
                                            const e = t[t.length - 1],
                                                r = t[t.length - 2];
                                            if (
                                                !(
                                                    (e.x - r.x) * (n.y - r.y) >=
                                                    (e.y - r.y) * (n.x - r.x)
                                                )
                                            )
                                                break;
                                            t.pop();
                                        }
                                        t.push(n);
                                    }
                                    t.pop();
                                    const n = [];
                                    for (let r = e.length - 1; r >= 0; r--) {
                                        const t = e[r];
                                        for (; n.length >= 2; ) {
                                            const e = n[n.length - 1],
                                                r = n[n.length - 2];
                                            if (
                                                !(
                                                    (e.x - r.x) * (t.y - r.y) >=
                                                    (e.y - r.y) * (t.x - r.x)
                                                )
                                            )
                                                break;
                                            n.pop();
                                        }
                                        n.push(t);
                                    }
                                    return (
                                        n.pop(),
                                        1 === t.length &&
                                        1 === n.length &&
                                        t[0].x === n[0].x &&
                                        t[0].y === n[0].y
                                            ? t
                                            : t.concat(n)
                                    );
                                })(t)
                            );
                        })([
                            ...o,
                            ...(function (e) {
                                const {
                                    top: t,
                                    right: n,
                                    bottom: r,
                                    left: o,
                                } = e;
                                return [
                                    { x: o, y: t },
                                    { x: n, y: t },
                                    { x: n, y: r },
                                    { x: o, y: r },
                                ];
                            })(t.getBoundingClientRect()),
                        ]);
                    c(i), p(!0);
                },
                [p]
            );
        return (
            r.useEffect(() => () => f(), [f]),
            r.useEffect(() => {
                if (u && h) {
                    const e = (e) => m(e, h),
                        t = (e) => m(e, u);
                    return (
                        u.addEventListener("pointerleave", e),
                        h.addEventListener("pointerleave", t),
                        () => {
                            u.removeEventListener("pointerleave", e),
                                h.removeEventListener("pointerleave", t);
                        }
                    );
                }
            }, [u, h, m, f]),
            r.useEffect(() => {
                if (l) {
                    const e = (e) => {
                        const t = e.target,
                            n = { x: e.clientX, y: e.clientY },
                            r = u?.contains(t) || h?.contains(t),
                            o = !(function (e, t) {
                                const { x: n, y: r } = e;
                                let o = !1;
                                for (
                                    let i = 0, s = t.length - 1;
                                    i < t.length;
                                    s = i++
                                ) {
                                    const e = t[i],
                                        a = t[s],
                                        l = e.x,
                                        c = e.y,
                                        u = a.x,
                                        d = a.y;
                                    c > r != d > r &&
                                        n < ((u - l) * (r - c)) / (d - c) + l &&
                                        (o = !o);
                                }
                                return o;
                            })(n, l);
                        r ? f() : o && (f(), d());
                    };
                    return (
                        document.addEventListener("pointermove", e),
                        () => document.removeEventListener("pointermove", e)
                    );
                }
            }, [u, h, l, d, f]),
            a.jsx($g, { ...e, ref: s })
        );
    }),
    [Ug, Zg] = Cg(Mg, { isInside: !1 }),
    zg = Op("TooltipContent"),
    $g = r.forwardRef((e, t) => {
        const {
                __scopeTooltip: n,
                children: o,
                "aria-label": i,
                onEscapeKeyDown: s,
                onPointerDownOutside: l,
                ...c
            } = e,
            u = jg(Hg, n),
            d = bg(n),
            { onClose: h } = u;
        return (
            r.useEffect(
                () => (
                    document.addEventListener(Sg, h),
                    () => document.removeEventListener(Sg, h)
                ),
                [h]
            ),
            r.useEffect(() => {
                if (u.trigger) {
                    const e = (e) => {
                        const t = e.target;
                        t?.contains(u.trigger) && h();
                    };
                    return (
                        window.addEventListener("scroll", e, { capture: !0 }),
                        () =>
                            window.removeEventListener("scroll", e, {
                                capture: !0,
                            })
                    );
                }
            }, [u.trigger, h]),
            a.jsx(qp, {
                asChild: !0,
                disableOutsidePointerEvents: !1,
                onEscapeKeyDown: s,
                onPointerDownOutside: l,
                onFocusOutside: (e) => e.preventDefault(),
                onDismiss: h,
                children: a.jsxs(ug, {
                    "data-state": u.stateAttribute,
                    ...d,
                    ...c,
                    ref: t,
                    style: {
                        ...c.style,
                        "--radix-tooltip-content-transform-origin":
                            "var(--radix-popper-transform-origin)",
                        "--radix-tooltip-content-available-width":
                            "var(--radix-popper-available-width)",
                        "--radix-tooltip-content-available-height":
                            "var(--radix-popper-available-height)",
                        "--radix-tooltip-trigger-width":
                            "var(--radix-popper-anchor-width)",
                        "--radix-tooltip-trigger-height":
                            "var(--radix-popper-anchor-height)",
                    },
                    children: [
                        a.jsx(zg, { children: o }),
                        a.jsx(Ug, {
                            scope: n,
                            isInside: !0,
                            children: a.jsx(vg, {
                                id: u.contentId,
                                role: "tooltip",
                                children: i || o,
                            }),
                        }),
                    ],
                }),
            })
        );
    });
Fg.displayName = Hg;
var Wg = "TooltipArrow";
r.forwardRef((e, t) => {
    const { __scopeTooltip: n, ...r } = e,
        o = bg(n);
    return Zg(Wg, n).isInside ? null : a.jsx(dg, { ...o, ...r, ref: t });
}).displayName = Wg;
var qg = Lg,
    Kg = Ng,
    Yg = Dg,
    Xg = Og,
    Gg = Fg;
function Qg({
    children: e,
    tooltipContent: t,
    contentStyle: n = "default",
    side: r = "top",
    sideOffset: o,
    align: i,
    className: s,
    delayDuration: l = 200,
    ...u
}) {
    const d = Jg[n];
    return a.jsx(qg, {
        delayDuration: l,
        children: a.jsxs(Kg, {
            ...u,
            children: [
                a.jsx(Yg, { asChild: !0, children: e }),
                a.jsx(Xg, {
                    children: a.jsx("span", {
                        children: a.jsx(d, {
                            className: c(s, !t && "hidden"),
                            sideOffset: o ?? 5,
                            side: r,
                            align: i,
                            children: t,
                        }),
                    }),
                }),
            ],
        }),
    });
}
const Jg = {
    default: ({ children: e, className: t, ...n }) =>
        a.jsx(Gg, {
            ...n,
            className: c(
                "px-2",
                "py-1",
                "text-xs",
                "font-normal",
                "font-styrene",
                "leading-tight",
                "rounded-md",
                "shadow-md",
                "text-oncolor-100",
                "bg-always-black/80",
                "backdrop-blur",
                "break-words",
                "z-50",
                "max-w-[13rem]",
                "[*:disabled_&]:hidden",
                t
            ),
            children: e,
        }),
    citation: ({ children: e, className: t, ...n }) =>
        a.jsx(Gg, {
            ...n,
            className: c("max-w-[337px]", "z-50", "[*:disabled_&]:hidden", t),
            children: a.jsx(Ap.div, {
                initial: { opacity: 0, scale: 0.95 },
                animate: { opacity: 1, scale: 1 },
                transition: { duration: 0.2 },
                className:
                    "p-1 font-styrene text-text-200 bg-bg-100 break-words border-[0.5px] border-border-300/25 max-h-[300px] shadow-[0_4px_20px_0_rgba(0,0,0,0.04)] rounded-lg overflow-y-auto",
                children: e,
            }),
        }),
    inputMenu: ({ children: e, className: t, ...n }) =>
        a.jsx(Gg, {
            ...n,
            className: c(
                "p-1",
                "font-styrene",
                "font-bold",
                "text-xs",
                "rounded-lg",
                "shadow-md",
                "text-oncolor-100",
                "bg-always-black/80",
                "backdrop-blur",
                "break-words",
                "z-50",
                "max-w-[13rem]",
                "[*:disabled_&]:hidden",
                t
            ),
            children: e,
        }),
    sampleImage: ({ children: e, className: t, ...n }) =>
        a.jsx(Gg, {
            ...n,
            className: c(
                "p-1",
                "font-styrene",
                "text-sm",
                "border-border-300",
                "border-[0.5px]",
                "rounded-lg",
                "shadow-[0_4px_20px_0_rgba(0,0,0,0.04)]",
                "text-text-100",
                "bg-bg-100",
                "break-words",
                "z-50",
                "max-w-[13rem]",
                "[*:disabled_&]:hidden",
                t
            ),
            children: e,
        }),
};
function ey({
    message: e,
    previousMessages: t = [],
    isLastMessage: o = !1,
    isStreaming: i = !1,
    submittedFeedback: s = null,
    onThumbsUp: l,
    onThumbsDown: u,
    showThumbs: d = !1,
}) {
    const [h, p] = r.useState(!1),
        [f, m] = r.useState(!1),
        [g, y] = r.useState(!1),
        [x, v] = r.useState(!1),
        { value: C } = n.useFeatureGate("crochet_default_debug_mode");
    r.useEffect(() => {
        S(A.DEBUG_MODE).then((e) => {
            v(void 0 !== e ? e : C || !1);
        });
        const e = (e) => {
            void 0 !== e[A.DEBUG_MODE]?.newValue && v(e[A.DEBUG_MODE].newValue);
        };
        return (
            chrome.storage.onChanged.addListener(e),
            () => {
                chrome.storage.onChanged.removeListener(e);
            }
        );
    }, [C]);
    const w = Array.isArray(e.content)
            ? e.content.filter((e) => "text" === e.type)
            : [],
        b =
            "string" == typeof e.content
                ? e.content
                : w.map((e) => e.text).join("");
    if ("user" === e.role) {
        const n = Array.isArray(e.content)
                ? e.content.filter((e) => "tool_result" === e.type)
                : [],
            r = new Map();
        let o = null;
        return (
            [...t, e].forEach((e) => {
                "assistant" === e.role &&
                    Array.isArray(e.content) &&
                    e.content.forEach((e) => {
                        "tool_use" === e.type &&
                            e.id &&
                            r.set(e.id, {
                                name: e.name,
                                input: e.input,
                                id: e.id,
                            });
                    }),
                    "user" === e.role &&
                        Array.isArray(e.content) &&
                        e.content.forEach((e) => {
                            "tool_result" === e.type &&
                                Array.isArray(e.content) &&
                                e.content.forEach((e) => {
                                    "image" === e.type &&
                                        "base64" === e.source?.type &&
                                        (o = `data:${e.source.media_type};base64,${e.source.data}`);
                                });
                        });
            }),
            a.jsx("div", {
                className: "flex justify-end",
                children: a.jsxs("div", {
                    className: c(
                        "relative break-words",
                        0 == n.length
                            ? "max-w-[75%] px-4 py-3 bg-bg-300 rounded-[24px]"
                            : "w-full"
                    ),
                    onMouseEnter: () => m(!0),
                    onMouseLeave: () => m(!1),
                    children: [
                        b &&
                            a.jsxs("div", {
                                className: c(
                                    "relative",
                                    n.length > 0 &&
                                        "max-w-[75%] ml-auto px-4 py-3 bg-bg-300 rounded-[24px]",
                                    !h &&
                                        b.length > 500 &&
                                        "max-h-[360px] overflow-hidden"
                                ),
                                children: [
                                    a.jsx(Ro, { text: b, variant: "user" }),
                                    !h &&
                                        b.length > 500 &&
                                        a.jsx("div", {
                                            className:
                                                "absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-bg-300 to-transparent pointer-events-none",
                                        }),
                                    b.length > 500 &&
                                        (f || h) &&
                                        a.jsx("button", {
                                            onClick: () => p(!h),
                                            className:
                                                "absolute bottom-2 right-2 p-1.5 bg-bg-500 hover:bg-bg-400 rounded-full transition-colors",
                                            "aria-label": h
                                                ? "Collapse message"
                                                : "Expand message",
                                            children: h
                                                ? a.jsx(Di, {
                                                      className:
                                                          "w-4 h-4 text-text-300",
                                                  })
                                                : a.jsx(Ii, {
                                                      className:
                                                          "w-4 h-4 text-text-300",
                                                  }),
                                        }),
                                ],
                            }),
                        n.length > 0 &&
                            a.jsx("div", {
                                className: "space-y-2",
                                children: n.map((e, t) => {
                                    const n = e.tool_use_id
                                        ? r.get(e.tool_use_id)
                                        : void 0;
                                    return a.jsx(
                                        Ni,
                                        {
                                            result: e,
                                            toolName: n?.name,
                                            toolInfo: n,
                                            lastScreenshot: o,
                                            debugMode: x,
                                        },
                                        e.tool_use_id || t
                                    );
                                }),
                            }),
                    ],
                }),
            })
        );
    }
    if (!b) return null;
    const k = d && l && u && ((o && !i) || (!o && g));
    return a.jsx("div", {
        className: "flex items-start",
        onMouseEnter: () => y(!0),
        onMouseLeave: () => y(!1),
        children: a.jsxs("div", {
            className: "max-w-4xl claude-response w-full break-words",
            children: [
                a.jsx(Ro, { text: b, variant: "assistant" }),
                d &&
                    a.jsx("div", {
                        className: "h-7 flex items-center",
                        children:
                            k &&
                            a.jsxs("div", {
                                className:
                                    "flex items-center gap-0.5 mt-2 -ml-1.5",
                                children: [
                                    a.jsx(Qg, {
                                        tooltipContent:
                                            "Give positive feedback",
                                        side: "bottom",
                                        children: a.jsx("button", {
                                            onClick: l,
                                            className:
                                                "p-1.5 rounded transition-colors " +
                                                ("positive" === s
                                                    ? "text-text-100"
                                                    : "text-text-300 hover:bg-bg-200 hover:text-text-100"),
                                            "aria-label": "Good response",
                                            children:
                                                "positive" === s
                                                    ? a.jsx(Pi, { size: 12 })
                                                    : a.jsx(Mi, { size: 12 }),
                                        }),
                                    }),
                                    a.jsx(Qg, {
                                        tooltipContent:
                                            "Give negative feedback",
                                        side: "bottom",
                                        children: a.jsx("button", {
                                            onClick: u,
                                            className:
                                                "p-1.5 rounded transition-colors " +
                                                ("negative" === s
                                                    ? "text-text-100"
                                                    : "text-text-300 hover:bg-bg-200 hover:text-text-100"),
                                            "aria-label": "Bad response",
                                            children:
                                                "negative" === s
                                                    ? a.jsx(Li, { size: 12 })
                                                    : a.jsx(Ti, { size: 12 }),
                                        }),
                                    }),
                                ],
                            }),
                    }),
            ],
        }),
    });
}
const ty = () => {
        const e = r.useRef(null);
        r.useEffect(() => {
            let t;
            if (e.current && "function" == typeof e.current.animate) {
                const n = 9,
                    r = 90,
                    o = Array.from({ length: n }, (e, t) => ({
                        transform: `translateY(-${t * (100 / n)}%)`,
                    }));
                t = e.current?.animate(o, {
                    duration: r * o.length,
                    iterations: 1 / 0,
                    easing: `steps(${o.length}, jump-none)`,
                });
            }
            return () => {
                t?.cancel();
            };
        }, []);
        return a.jsx("div", {
            className: "inline-block w-8 select-none overflow-hidden",
            style: { aspectRatio: 1, color: "var(--color-accent-brand)" },
            children: a.jsx("div", {
                ref: e,
                className: "[&>svg]:block [&>svg]:w-full [&>svg]:fill-current",
                children: a.jsx(ny, {}),
            }),
        });
    },
    ny = () =>
        a.jsx("svg", {
            viewBox: "0 0 100 900",
            children: a.jsx("path", {
                d: "m44.724 38.665 8.894-3.265 8.894 1.352 5.588 7.745-1.956 11.57-6.147 5.833h-14.11l-4.423-4.06-1.164-5.83 1.164-7.512zM48.35 133c.36.48 2.65 3.434 3.75 4.85v-14.7l1.45-3.55 2.75-.6h1.25l.75.6c.167.767.5 2.34.5 2.5s.3 2.067.45 3l-.65 3.9-1.35 6.9-.5 3.75 2.5-3.3 4.65-6.65 2.25-2.4 2.4.2 1.9.25.55 2.45.3 3c-.267.817-.84 2.47-1 2.55s-1.767 3.667-2.55 5.45l-1.8 3.25-.85 2.1 2.95-.55 4.25-1.55 2.4-.65 3.8 1.3 1.55 1.45.25 2.1-.4 1.05-3.95 2-4 .8-2.6.5-1.3.6 3.9.2h3.65l3.15.95 1.15 1.05.55 1.45-.55 1.9-1.15.95-1.6.35-1.2-.35-5.65-1.25-4.35-.95-1.65-.15-.25.4 1.05 1 2.25 2.4 3.35 3.1 2.4 1.75.4 1.5-.2 1.85-.7.4h-1.45l-2.8-2.25-2.65-2.05-2.6-1.95-1.7-.95 1.15 1.7 3.55 5.1.35 2.3-.9 2.3-1.05 1.05-3.1.45-2-2.85-2.1-3.05-2.8-4.65-.85 2.95-1.05 4.6c-.45 1.534-1.37 4.62-1.45 4.7s-.933.834-1.35 1.2l-2.35.3-1.75-1.3-.5-1c.25-.883.75-2.67.75-2.75s.767-3.2 1.15-4.75l1.1-4.2h-.35l-3 3.5L41.3 173l-1.4 1.35-2.45-.7-.8-1.05-.2-1.15 1.3-2.2 1.55-1.8 1.6-2.15 2.15-3.25.65-1.05-3.8 1.45-3.25 1.35-3.55 1.95-2.25.55-1.5-.55-1.7-.9-.15-1.05.3-.8c.667-1 2.02-3.01 2.1-3.05s2.067-1.55 3.05-2.3l2.55-1.5 3.95-1.9.85-.45-.4-.3-3.25-.2c-1.533-.183-4.65-.55-4.85-.55s-2.583-.1-3.75-.15l-2.7-.4-1.75-.5-.6-1.65.35-.9 1.4-.5 1.85-.6c.717-.066 2.17-.2 2.25-.2.1 0 3.8.25 4.25.35.36.08 2.217.034 3.1 0l2.95-.35v-.4l-1.1-.9-.85-1.05-2.9-2.25-6.9-5.4-1.1-.8-.45-1.75.35-.9 2-1.55 1.25-.2 3.1 1.4 4.65 2.2 1.95.9.95.45.45-.45v-.75l-.8-1.6-1.7-3.8-1.4-3.75.2-1.55.9-1.35 3.4-.7 2.5 1.55.6 1.45c1.217 1.917 3.74 5.87 4.1 6.35M27.5 227.7l9.85 5.85-4.1-9.3-2.35-5.8-.4-3.5 1.45-2.1 3-1.55 2.4 2.05 2.7 3.85 1.95 4.15 4.5 10.2 2.95 5.3 2.05-3.3V222.2l.35-8 .5-2.6 1-2.35 2.35-1.35 2.1-.5.9 2.6 1.1 3.35-1.1 6.3v13.05l1.45 2.85 5.05-7.25 6-9 1.45-.85 2.45-.55 2.45 1.4 1.55 1.35-2.6 6.7-4.95 9.5-4.2 7.15.5.5 5.65-1.2 10.35-2.65 2.75-.5 2 .5 2 .95.55 2.4-.95 1.8-5.75 3.7-5.35 1.2-4.55 1.25L71.4 253l3.15.85 8.15 1.1 4.75.45 2.05 2 .95 2.1-.95 1.75-2.9 2-3.9-1.15-6.2-1.55-4.7-1.05h-5.55l3 3.3 3.4 3.25 4.9 4.65 3.75 3.05.65 1.45v1.95l-1.25 1.05-2.45 1.45-4.75-4.45-5.25-5.45-4.45-3.7.7 1.85 6.15 10.3.9 1.8.25 3.15-.6 1.55-1.95 1.25-4.05-5.25-6.1-8.15-4.75-5.7-1.25 13.45-1.4 6.1-3.25 2.45-1.95-.6-1-2.3 1-8.8.3-5.55-.3-4.75-2.35 2.9-5.6 7.4-3.75 5.25-3.25 1.75-2.75-1-1.3-1.3 4.5-7.2 2.2-3.3 4.35-8.55v-.7l-3.75 1.55-2.25 1.5-4.5 2.4-5.8 3.45-3.4.75-2.1-1.05-.75-1.4.75-2.8.75-1.35 6.8-3.45 12.3-7.2.75-1.2H36.2l-8.15.55-10.55-.55-4.3.55-1.95-.55-1.65-2.25v-1.55l2.2-1.7 6.25-.55 10-.6 5.5-.7 2.1-.65-6.85-3.45-5.5-2.95-8.85-4.5-1.25-2.85v-4.9l.6-1 5.05-1.2 3.35.7zm-7.878 138.799 19.675-11.033.325-.966-.325-.539h-.973l-3.297-.2-11.243-.301-9.73-.401-9.46-.502-2.378-.501L0 349.097l.216-1.455 2-1.354 2.865.251 6.324.451 9.514.652 6.865.402L38 349.097h1.622l.216-.652-.54-.401-.433-.402-9.838-6.67-10.649-7.021-5.567-4.062-2.973-2.056-1.514-1.906-.648-4.212 2.702-3.009 3.676.25.919.251 3.73 2.859 7.946 6.168 10.378 7.623 1.514 1.254.609-.411.093-.291-.703-1.154-5.621-10.18-6-10.381-2.703-4.313-.703-2.558c-.272-1.073-.432-1.961-.432-3.059l3.081-4.213 1.73-.551 4.162.551 1.73 1.505 2.594 5.917 4.163 9.278 6.486 12.638 1.892 3.761 1.027 3.461.378 1.053h.649v-.602l.54-7.121.974-8.726.972-11.234.325-3.16 1.567-3.811 3.136-2.056 2.432 1.153 2 2.859-.27 1.855-1.19 7.724-2.324 12.086-1.513 8.124h.864l1.028-1.053 4.108-5.416 6.865-8.626 3.026-3.41 3.568-3.762 2.27-1.805h4.325l3.135 4.714-1.406 4.865-4.432 5.617-3.676 4.764-5.27 7.061-3.27 5.677.293.469.788-.068 11.892-2.557 6.432-1.154 7.676-1.304 3.46 1.605.378 1.655-1.352 3.36-8.216 2.006-9.621 1.956-14.328 3.373-.159.128.187.277 6.462.585 2.756.151h6.757l12.595.952 3.297 2.157L100 360.13l-.324 2.056-5.081 2.558-6.811-1.605-15.946-3.812-5.46-1.354h-.756v.452l4.54 4.463 8.379 7.523 10.432 9.729.54 2.407-1.35 1.906-1.406-.201-9.19-6.92-3.567-3.11-8-6.77h-.54v.702l1.837 2.708 9.784 14.694.487 4.514-.703 1.454-2.54.903-2.757-.502-5.784-8.074-5.892-9.027-4.757-8.124-.574.362-2.831 30.229-1.298 1.555L47.405 400l-2.54-1.906-1.352-3.11 1.352-6.168 1.621-8.024 1.298-6.369 1.189-7.924.726-2.647-.064-.177-.58.097-5.974 8.193L34 384.252l-7.19 7.673-1.729.702-2.973-1.554.27-2.759 1.676-2.457L34 373.219l6-7.873 3.95-4.646-.1-.45-.234-.096-26.427 17.228-4.703.601-2.054-1.905.27-3.11.974-1.003zm0 100 19.675-11.033.325-.966-.325-.539h-.973l-3.297-.2-11.243-.301-9.73-.401-9.46-.502-2.378-.501L0 449.097l.216-1.455 2-1.354 2.865.251 6.324.451 9.514.652 6.865.402L38 449.097h1.622l.216-.652-.54-.401-.433-.402-9.838-6.67-10.649-7.021-5.567-4.062-2.973-2.056-1.514-1.906-.648-4.212 2.702-3.009 3.676.25.919.251 3.73 2.859 7.946 6.168 10.378 7.623 1.514 1.254.609-.411.093-.291-.703-1.154-5.621-10.18-6-10.381-2.703-4.313-.703-2.558c-.272-1.073-.432-1.961-.432-3.059l3.081-4.213 1.73-.551 4.162.551 1.73 1.505 2.594 5.917 4.163 9.278 6.486 12.638 1.892 3.761 1.027 3.461.378 1.053h.649v-.602l.54-7.121.974-8.726.972-11.234.325-3.16 1.567-3.811 3.136-2.056 2.432 1.153 2 2.859-.27 1.855-1.19 7.724-2.324 12.086-1.513 8.124h.864l1.028-1.053 4.108-5.416 6.865-8.626 3.026-3.41 3.568-3.762 2.27-1.805h4.325l3.135 4.714-1.406 4.865-4.432 5.617-3.676 4.764-5.27 7.061-3.27 5.677.293.469.788-.068 11.892-2.557 6.432-1.154 7.676-1.304 3.46 1.605.378 1.655-1.352 3.36-8.216 2.006-9.621 1.956-14.328 3.373-.159.128.187.277 6.462.585 2.756.151h6.757l12.595.952 3.297 2.157L100 460.13l-.324 2.056-5.081 2.558-6.811-1.605-15.946-3.812-5.46-1.354h-.756v.452l4.54 4.463 8.379 7.523 10.432 9.729.54 2.407-1.35 1.906-1.406-.201-9.19-6.92-3.567-3.11-8-6.77h-.54v.702l1.837 2.708 9.784 14.694.487 4.514-.703 1.454-2.54.903-2.757-.502-5.784-8.074-5.892-9.027-4.757-8.124-.574.362-2.831 30.229-1.298 1.555L47.405 500l-2.54-1.906-1.352-3.11 1.352-6.168 1.621-8.024 1.298-6.369 1.189-7.924.726-2.647-.064-.177-.58.097-5.974 8.193L34 484.252l-7.19 7.673-1.729.702-2.973-1.554.27-2.759 1.676-2.457L34 473.219l6-7.873 3.95-4.646-.1-.45-.234-.096-26.427 17.228-4.703.601-2.054-1.905.27-3.11.974-1.003zM30.25 529.6l7.2 3.799-1.7-4.049-5.3-11.451-.2-1.6.2-2.9 4.45-2 2.55 2.25 4.2 7.1 3.75 7.501 2.1 5.049 2.05 3.35 1.9-2.85V521.95l.45-8.951 1.4-3.5 1.75-1.5 2.4-.45.65.9 1.4 4.55c-.117 1.967-.4 5.97-.6 6.25s-.283 7.184-.3 10.601l.3 2.65 1.05 2.899h.4l4.1-6.049 3.85-5.451 3.25-5 2.45-.9h1.7l1.15.6 2.05 1.9L77.45 526l-5.55 10.149-3.6 6.351-.8 1.599.8.351 3.95-.75 7.35-1.95 4.95-1.3 2.2-.351 1.85.351 1.7.75.7 2.05v1.5l-1.2 1.299-5.55 3.451-5 1.349c-1.9.484-5.73 1.461-5.85 1.5-.12.04-1.383.417-2 .601l3.7.7 9.65 1.25 2 .25 1.85 1.199 1.45 1.95.45 1-1.45 2.401-2.8 1.399-4.05-.699-9.05-2.25-2-.351c-1.05-.166-3.17-.5-3.25-.5h-1.8l1.4 1.601 1.95 1.949 5.25 5.051c1.85 1.6 5.56 4.81 5.6 4.85.04.039.883.983 1.3 1.45l.25 1.65-.65 2.35-2.2 1.199-.95-.1-2-1.599-2.2-2.1c-1.05-1.017-3.15-3.07-3.15-3.15s-.933-.934-1.4-1.351l-3.55-3.3-2.2-1.849 1.15 2.5 3.05 4.75 2.95 5.099c.233.684.7 2.091.7 2.25 0 .161.2 1.767.3 2.551l-.4 1.65-1.8 1.25-1.85-2.05-3.3-4.551-6.1-8.1-3.05-4.099h-.85l-.9 9.449-1.65 10.101-3.6 2.399-1.8-.85-.6-2.299.9-9.351v-5.35l-.3-4.099-4.25 4.949-4.35 6.351-2.55 3.45-3.1 2-2.6-.85-1.85-1.15 1.85-3.151 4.15-6.65 2.95-6.249 1.8-3.65-4.4 1.549-4.5 2.601-7.05 4.6-2.95.75-2.2-.75-1.2-1.5 1.2-4.3 17.35-9.45 2.75-2.151H11.7L9.6 550.9l-.4-1.2 2.5-1.7 6.1-.85 9.35-.5 6.05-.551 3.05-.649-3.05-1.351-6.05-3.05-11-5.65-2.75-1.5-.55-2.049v-4.551L13.4 526l5.7-1.801 4.2 1zM46.9 632.149c.783 1.184 2.35 3.68 2.35 4.2l2.5-2.85v-20.3l.9-2.85 1.45-1.95 3.5-1 1.8 5.15v2.35l-1 9.9v6.9l1.5 4.2 2.95-4.2 7.15-10.5 1.9-2.25 2.95-1 1.9.6 2.25 1.85-1.15 3.7-1.1 3.5-4.85 8.3-4.05 8.25H70l7.85-1.75 6.8-1.75 3.1-.5 2.75 1.15.55 2.2-.55 1.45-3.65 2.9-2.6 1.4-2.6 1.05-5.7 1.6-4.7 1.4 6.85.75 8.75 1.1 2 1.55 1.65 2.7-1.15 2.25-3.5 1.2-9.9-2.1-4.7-.85-5.2-.5 1.1 1.35 4.75 4.45 7.1 6.5 2.65 2.65v2.9l-1.5 1.55-2.05.5-2.8-2.05-4.05-4.1-4.55-4.7-3.05-2.35.65 1.4 5.05 7.95 1.9 3.85.65 3.65-1.1 1.85-1.45.85-1.5-1.9-5.4-6.5-5.75-7.95-2.15-2.25-.95 9.25-1.85 10.45-3.4 2.15-1.75-.45-.85-2.15.35-5.05.5-10.7-.1-3.5-3.45 3.85-6.05 8.4-2 3.1-3 1.35-2.5-.8-1.7-1.15 5.25-9.25 3.95-7.35 1.8-3.05-3.25 1.15-12.95 7.6-3.25.8-2.2-.35-1.25-2.05 1.25-4.1 1.9-.8 11.15-6 4.4-2.6 3.1-1.75-2.15-.75h-15.9l-6.15.75-3.05-2.15-1.05-2.25 2.95-1.8 8.4-.8 9.45-.7 6.15-.8-6.85-3.4-11.35-5.8-4.65-2.85-1.15-5.3 1.15-2.75 5.55-1.35 5.6 1.35 7.8 5.1 4.55 2.95-3.4-8.05-3.4-7.5v-3.05l.8-1.7 3.6-1.95 2.4 1.95 2.85 3.95 3.65 7.65zm.95 100.1 4.1 5.15v-3.8l.25-9.4v-1.6l1.35-2.95 3.15-.7 1.05.15.85 1.15.55 4.9-.3 2.05-1.6 9-.6 3.6 2.95-4.1 5.55-7.1 1-1.2 3.35.25 1.2.45.55 5.25-.4 1.5-2.7 5.7-3 6 1.2-.4 4.9-1.3 2.55-.75h1.75l3 1 1.5 1.45v2.1l-.35 1.05-3.85 2.2-4 .65-3.9 1.1 3.3.4h4.3l3.4.65.75.85.35 2.5-.35 1.4-2.7.95-5.75-1.3-4.75-1.15-2.1-.3-.3.4 1.7 1.85 4.7 4.65 2.7 1.95.25 1.65-.25 1.9h-2.1l-1.3-1.05-3.15-2.5-3.25-2.25-2-1.35 1.45 2.45 2.95 4.2.55 1.3v2l-1 1.95-1.6.6-2.6.3-2.25-3.2-3.1-5.2-1.35-1.95-.45.9-1.05 5.9-1.7 5.2-.9 1.2-2.55.45-2.45-1.65.35-2.55 1.65-6.3.65-3.8-.65.85-3.55 4.5-3.4 4.05h-1.45l-1.8-.7-.45-1.65.45-1.7 2.45-3 2.9-3.95 1.05-1.7v-.35l-1.25.35-3.5 1.5-2.8 1.1-4.7 2.25h-.85l-2.7-1.4-.3-.85.3-1.35 1.75-2.35 3.25-2.45 2.45-1.65 5.2-2.55-4.1-.5-7.45-.35-2.05-.4-2.35-.3-.95-.4-.55-1.8.55-.85 2.5-.9 1.25-.15 4.3.15h5.15l2.5-.25.2-.3-2.25-1.7-5.35-4.45-4.7-3.8-.9-1.65v-1.25l1.25-1.25 1.2-.8 1.8.35 2.7 1.4 4 1.55 2.5 1.4.75-.6-.25-1.1-3-6.75-.45-1.8.95-2.85 3.7-.5 2.15 1.1 2.45 4.6zm1.05 101.1 5.5 2.85 1.05-1.95 1.55-.9 1.95.35 1.45 1.5 1.15 1.85.5 2.1 1.45-1.2 1.05-.55h1.95l1.6 2.8.6 1.25-.6 3.05-1.6 3 .2.9 2.4 1.2 2.05 2v.5l-1.85 3.4-2.8 2 3.1 3.65-.9 1.65-2.9 1.9-3.1-.4-.65.4-.15 2.7-3.75 1.35-2.4-1.35-3.25 2.65-1.6-.55-2-3.6-1.15 1.5-2.15 1.65-2.3-.55-.75-2.6.75-4.35-4.4.9-3.95-2v-1.8l3.1-3.45-2.05-.65-2.2-2.95v-2.4l3.45-3-2.3-4.35 1.05-3 1.25-.9 5.3 1.5.75-3.7 2.3-2.4z",
            }),
        }),
    ry = ({ size: e = 16, className: t = "" }) =>
        a.jsx("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: e,
            height: e,
            viewBox: "0 0 16 16",
            fill: "none",
            className: t,
            children: a.jsx("path", {
                d: "M14.4999 7C14.4987 8.06051 14.0769 9.07725 13.3271 9.82715C12.5772 10.577 11.5604 10.9988 10.4999 11H3.20678L5.35366 13.1462C5.44748 13.2401 5.50018 13.3673 5.50018 13.5C5.50018 13.6327 5.44748 13.7599 5.35366 13.8538C5.25984 13.9476 5.13259 14.0003 4.99991 14.0003C4.86722 14.0003 4.73998 13.9476 4.64615 13.8538L1.64615 10.8538C1.59967 10.8073 1.56279 10.7522 1.53763 10.6915C1.51246 10.6308 1.49951 10.5657 1.49951 10.5C1.49951 10.4343 1.51246 10.3692 1.53763 10.3085C1.56279 10.2478 1.59967 10.1927 1.64615 10.1462L4.64615 7.14625C4.73998 7.05243 4.86722 6.99972 4.99991 6.99972C5.13259 6.99972 5.25984 7.05243 5.35366 7.14625C5.44748 7.24007 5.50018 7.36732 5.50018 7.5C5.50018 7.63268 5.44748 7.75993 5.35366 7.85375L3.20678 10H10.4999C11.2956 10 12.0586 9.68393 12.6212 9.12132C13.1838 8.55871 13.4999 7.79565 13.4999 7C13.4999 6.20435 13.1838 5.44129 12.6212 4.87868C12.0586 4.31607 11.2956 4 10.4999 4H4.99991C4.8673 4 4.74012 3.94732 4.64635 3.85355C4.55258 3.75979 4.49991 3.63261 4.49991 3.5C4.49991 3.36739 4.55258 3.24021 4.64635 3.14645C4.74012 3.05268 4.8673 3 4.99991 3H10.4999C11.5604 3.00116 12.5772 3.42296 13.3271 4.17285C14.0769 4.92275 14.4987 5.93949 14.4999 7Z",
                fill: "currentColor",
            }),
        }),
    oy = ({ size: e = 16, className: t = "" }) =>
        a.jsx("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: e,
            height: e,
            viewBox: "0 0 16 16",
            fill: "none",
            className: t,
            children: a.jsx("path", {
                d: "M11.25 9H10V7H11.25C11.695 7 12.13 6.86804 12.5 6.62081C12.87 6.37357 13.1584 6.02217 13.3287 5.61104C13.499 5.1999 13.5436 4.7475 13.4568 4.31105C13.37 3.87459 13.1557 3.47368 12.841 3.15901C12.5263 2.84434 12.1254 2.63005 11.689 2.54323C11.2525 2.45642 10.8001 2.50097 10.389 2.67127C9.97783 2.84157 9.62643 3.12996 9.37919 3.49997C9.13196 3.86998 9 4.30499 9 4.75V6H7V4.75C7 4.30499 6.86804 3.86998 6.62081 3.49997C6.37357 3.12996 6.02217 2.84157 5.61104 2.67127C5.1999 2.50097 4.7475 2.45642 4.31105 2.54323C3.87459 2.63005 3.47368 2.84434 3.15901 3.15901C2.84434 3.47368 2.63005 3.87459 2.54323 4.31105C2.45642 4.7475 2.50097 5.1999 2.67127 5.61104C2.84157 6.02217 3.12996 6.37357 3.49997 6.62081C3.86998 6.86804 4.30499 7 4.75 7H6V9H4.75C4.30499 9 3.86998 9.13196 3.49997 9.37919C3.12996 9.62643 2.84157 9.97783 2.67127 10.389C2.50097 10.8001 2.45642 11.2525 2.54323 11.689C2.63005 12.1254 2.84434 12.5263 3.15901 12.841C3.47368 13.1557 3.87459 13.37 4.31105 13.4568C4.7475 13.5436 5.1999 13.499 5.61104 13.3287C6.02217 13.1584 6.37357 12.87 6.62081 12.5C6.86804 12.13 7 11.695 7 11.25V10H9V11.25C9 11.695 9.13196 12.13 9.37919 12.5C9.62643 12.87 9.97783 13.1584 10.389 13.3287C10.8001 13.499 11.2525 13.5436 11.689 13.4568C12.1254 13.37 12.5263 13.1557 12.841 12.841C13.1557 12.5263 13.37 12.1254 13.4568 11.689C13.5436 11.2525 13.499 10.8001 13.3287 10.389C13.1584 9.97783 12.87 9.62643 12.5 9.37919C12.13 9.13196 11.695 9 11.25 9ZM10 4.75C10 4.50277 10.0733 4.2611 10.2107 4.05554C10.348 3.84998 10.5432 3.68976 10.7716 3.59515C11.0001 3.50054 11.2514 3.47579 11.4939 3.52402C11.7363 3.57225 11.9591 3.6913 12.1339 3.86612C12.3087 4.04093 12.4278 4.26366 12.476 4.50614C12.5242 4.74861 12.4995 4.99995 12.4049 5.22836C12.3102 5.45676 12.15 5.65199 11.9445 5.78934C11.7389 5.92669 11.4972 6 11.25 6H10V4.75ZM3.5 4.75C3.5 4.41848 3.6317 4.10054 3.86612 3.86612C4.10054 3.6317 4.41848 3.5 4.75 3.5C5.08152 3.5 5.39946 3.6317 5.63388 3.86612C5.8683 4.10054 6 4.41848 6 4.75V6H4.75C4.41848 6 4.10054 5.8683 3.86612 5.63388C3.6317 5.39946 3.5 5.08152 3.5 4.75ZM6 11.25C6 11.4972 5.92669 11.7389 5.78934 11.9445C5.65199 12.15 5.45676 12.3102 5.22836 12.4049C4.99995 12.4995 4.74861 12.5242 4.50614 12.476C4.26366 12.4278 4.04093 12.3087 3.86612 12.1339C3.6913 11.9591 3.57225 11.7363 3.52402 11.4939C3.47579 11.2514 3.50054 11.0001 3.59515 10.7716C3.68976 10.5432 3.84998 10.348 4.05554 10.2107C4.2611 10.0733 4.50277 10 4.75 10H6V11.25ZM7 7H9V9H7V7ZM11.25 12.5C10.9185 12.5 10.6005 12.3683 10.3661 12.1339C10.1317 11.8995 10 11.5815 10 11.25V10H11.25C11.5815 10 11.8995 10.1317 12.1339 10.3661C12.3683 10.6005 12.5 10.9185 12.5 11.25C12.5 11.5815 12.3683 11.8995 12.1339 12.1339C11.8995 12.3683 11.5815 12.5 11.25 12.5Z",
                fill: "currentColor",
            }),
        }),
    iy = ({ className: e = "" }) =>
        a.jsx("svg", {
            width: "21",
            height: "10",
            viewBox: "0 0 21 10",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            className: e,
            children: a.jsx("path", {
                d: "M1.748 1.776V4.266H4.748V5.322H1.748V7.944H5.402V9H0.356V0.719999H5.336L5.18 1.776H1.748ZM12.7773 6.66C12.7773 7.148 12.6513 7.582 12.3993 7.962C12.1513 8.338 11.7913 8.632 11.3193 8.844C10.8513 9.056 10.2853 9.162 9.62131 9.162C8.94931 9.162 8.35931 9.062 7.85131 8.862C7.34731 8.658 6.92131 8.388 6.57331 8.052L7.33531 7.2C7.63131 7.468 7.96531 7.68 8.33731 7.836C8.70931 7.988 9.13531 8.064 9.61531 8.064C9.92731 8.064 10.2133 8.016 10.4733 7.92C10.7333 7.82 10.9413 7.672 11.0973 7.476C11.2533 7.276 11.3313 7.026 11.3313 6.726C11.3313 6.482 11.2813 6.276 11.1813 6.108C11.0813 5.94 10.9073 5.788 10.6593 5.652C10.4153 5.516 10.0733 5.384 9.63331 5.256C9.04931 5.08 8.55931 4.884 8.16331 4.668C7.76731 4.452 7.46731 4.194 7.26331 3.894C7.06331 3.59 6.96331 3.222 6.96331 2.79C6.96331 2.342 7.08531 1.95 7.32931 1.614C7.57731 1.278 7.91531 1.018 8.34331 0.834C8.77531 0.645999 9.26331 0.551999 9.80731 0.551999C10.4073 0.551999 10.9313 0.638 11.3793 0.81C11.8273 0.982 12.2273 1.228 12.5793 1.548L11.8473 2.376C11.5553 2.12 11.2413 1.934 10.9053 1.818C10.5733 1.702 10.2353 1.644 9.89131 1.644C9.61131 1.644 9.35731 1.684 9.12931 1.764C8.90131 1.844 8.72131 1.962 8.58931 2.118C8.45731 2.274 8.39131 2.472 8.39131 2.712C8.39131 2.924 8.44931 3.106 8.56531 3.258C8.68531 3.41 8.88531 3.552 9.16531 3.684C9.44931 3.812 9.83731 3.95 10.3293 4.098C10.7933 4.234 11.2093 4.402 11.5773 4.602C11.9493 4.802 12.2413 5.064 12.4533 5.388C12.6693 5.712 12.7773 6.136 12.7773 6.66ZM17.6866 0.551999C18.2466 0.551999 18.7186 0.625999 19.1026 0.774C19.4906 0.918 19.8506 1.126 20.1826 1.398L19.4566 2.262C19.2086 2.054 18.9426 1.9 18.6586 1.8C18.3746 1.7 18.0726 1.65 17.7526 1.65C17.3406 1.65 16.9606 1.754 16.6126 1.962C16.2646 2.17 15.9846 2.508 15.7726 2.976C15.5646 3.444 15.4606 4.068 15.4606 4.848C15.4606 5.612 15.5606 6.228 15.7606 6.696C15.9606 7.164 16.2346 7.504 16.5826 7.716C16.9306 7.928 17.3206 8.034 17.7526 8.034C18.1966 8.034 18.5646 7.962 18.8566 7.818C19.1486 7.67 19.4066 7.504 19.6306 7.32L20.3026 8.178C20.0266 8.446 19.6766 8.678 19.2526 8.874C18.8286 9.066 18.3126 9.162 17.7046 9.162C17.0046 9.162 16.3746 8.998 15.8146 8.67C15.2586 8.338 14.8186 7.852 14.4946 7.212C14.1746 6.572 14.0146 5.784 14.0146 4.848C14.0146 3.92 14.1806 3.138 14.5126 2.502C14.8446 1.862 15.2886 1.378 15.8446 1.05C16.4006 0.717999 17.0146 0.551999 17.6866 0.551999Z",
                fill: "currentColor",
            }),
        }),
    sy = ({
        tool: e,
        url: n,
        screenshot: o,
        coordinate: i,
        typeText: s,
        fromDomain: l,
        toDomain: c,
        onAllow: u,
        onDeny: d,
        disableAlwaysAllow: h = !1,
    }) => {
        const [m, g] = r.useState(null);
        let y = "";
        try {
            const e = new URL(n);
            y = e.host;
        } catch {
            y = n;
        }
        const x = r.useMemo(
                () =>
                    e === t.DOMAIN_TRANSITION
                        ? {
                              type: "domain_transition",
                              fromDomain: l,
                              toDomain: c,
                          }
                        : { type: "netloc", netloc: y },
                [e, l, c, y]
            ),
            v = r.useCallback(() => {
                u(p.ONCE, x);
            }, [u, x]),
            C = r.useCallback(() => {
                h || u(p.ALWAYS, x);
            }, [u, x, h]);
        return (
            r.useEffect(() => {
                const e = (e) => {
                    (e.metaKey || e.ctrlKey) && "Enter" === e.key
                        ? (e.preventDefault(),
                          h ||
                              (g("always"),
                              setTimeout(() => {
                                  C();
                              }, 150)))
                        : "Enter" === e.key
                        ? (e.preventDefault(),
                          g("once"),
                          setTimeout(() => {
                              v();
                          }, 150))
                        : "Escape" === e.key &&
                          (e.preventDefault(),
                          g("deny"),
                          setTimeout(() => {
                              d();
                          }, 150));
                };
                return (
                    window.addEventListener("keydown", e),
                    () => window.removeEventListener("keydown", e)
                );
            }, [C, v, d, h]),
            a.jsxs("div", {
                className: "bg-bg-000 rounded-[14px]",
                children: [
                    a.jsxs("div", {
                        className: "flex items-center gap-2 py-[10px] px-4",
                        children: [
                            a.jsx(ki, { size: 20, className: "text-text-100" }),
                            a.jsx("h3", {
                                className:
                                    "font-styrene text-[14px] font-normal leading-[140%] text-text-100",
                                children: "Permission required",
                            }),
                        ],
                    }),
                    a.jsx("div", {
                        className: "border-t border-border-300 mb-4",
                    }),
                    a.jsxs("div", {
                        className: "space-y-4 px-4",
                        children: [
                            a.jsx("div", {
                                children:
                                    e === t.DOMAIN_TRANSITION && l && c
                                        ? a.jsx(a.Fragment, {
                                              children: a.jsxs("p", {
                                                  className:
                                                      "font-base-bold text-text-100",
                                                  children: [
                                                      "Claude paused due to a navigation from",
                                                      " ",
                                                      a.jsx("strong", {
                                                          children: l,
                                                      }),
                                                      " to ",
                                                      a.jsx("strong", {
                                                          children: c,
                                                      }),
                                                  ],
                                              }),
                                          })
                                        : a.jsxs(a.Fragment, {
                                              children: [
                                                  a.jsxs("p", {
                                                      className:
                                                          "font-base-bold text-text-100",
                                                      children: [
                                                          "Claude wants to ",
                                                          f(e),
                                                          ":",
                                                      ],
                                                  }),
                                                  a.jsx("p", {
                                                      className:
                                                          "font-claude-response-code text-text-200",
                                                      children: y,
                                                  }),
                                              ],
                                          }),
                            }),
                            e === t.CLICK &&
                                o &&
                                i &&
                                a.jsx("div", {
                                    children: a.jsx(Oo, {
                                        screenshot: o,
                                        coordinates: i,
                                        className: "mx-auto",
                                    }),
                                }),
                            e === t.TYPE &&
                                s &&
                                a.jsxs("div", {
                                    children: [
                                        a.jsx("p", {
                                            className:
                                                "font-base-bold text-text-100 mb-2",
                                            children: "Text to be typed:",
                                        }),
                                        a.jsx("div", {
                                            className:
                                                "p-3 bg-bg-100 border border-border-200 rounded-lg",
                                            children: a.jsx("code", {
                                                className:
                                                    "font-claude-response-code text-text-200 whitespace-pre-wrap break-all",
                                                children: s,
                                            }),
                                        }),
                                    ],
                                }),
                        ],
                    }),
                    a.jsxs("div", {
                        className:
                            "px-3 py-[10px] space-y-[5px] mt-[10px] mb-0.5",
                        children: [
                            a.jsxs(ay, {
                                onClick: v,
                                isActive: "once" === m,
                                children: [
                                    a.jsx("span", {
                                        children:
                                            e === t.DOMAIN_TRANSITION
                                                ? "Continue"
                                                : "Allow this action",
                                    }),
                                    a.jsx(ry, { className: "text-text-500" }),
                                ],
                            }),
                            a.jsxs(ay, {
                                onClick: d,
                                isActive: "deny" === m,
                                children: [
                                    a.jsx("span", {
                                        children:
                                            e === t.DOMAIN_TRANSITION
                                                ? "Stop"
                                                : "Decline",
                                    }),
                                    a.jsx(iy, { className: "text-text-500" }),
                                ],
                            }),
                            a.jsx("div", {
                                className:
                                    "border-t-[0.5px] border-border-300 my-3 -mx-3",
                            }),
                            h
                                ? a.jsx("p", {
                                      className:
                                          "font-small text-text-500 text-[9px] px-1 mt-1",
                                      children:
                                          "Site-level permissions are disabled for this site.",
                                  })
                                : a.jsxs(ay, {
                                      onClick: C,
                                      isActive: "always" === m,
                                      height: "55px",
                                      children: [
                                          a.jsxs("div", {
                                              className:
                                                  "flex flex-col items-start",
                                              children: [
                                                  a.jsx("span", {
                                                      children:
                                                          e ===
                                                          t.DOMAIN_TRANSITION
                                                              ? "Always continue"
                                                              : "Always allow actions on this site",
                                                  }),
                                                  a.jsx("span", {
                                                      className:
                                                          "font-styrene text-[12px] font-normal leading-[140%] tracking-[-0.24px] text-text-500",
                                                      children:
                                                          e ===
                                                          t.DOMAIN_TRANSITION
                                                              ? "When navigating between these sites"
                                                              : "Browse, click, and type",
                                                  }),
                                              ],
                                          }),
                                          a.jsxs("span", {
                                              className:
                                                  "flex items-center gap-0.5",
                                              children: [
                                                  a.jsx(oy, {
                                                      className:
                                                          "text-text-500",
                                                  }),
                                                  a.jsx(ry, {
                                                      className:
                                                          "text-text-500",
                                                  }),
                                              ],
                                          }),
                                      ],
                                  }),
                            a.jsxs("p", {
                                className:
                                    "font-small text-text-500 text-[10px] px-1 mt-1",
                                children: [
                                    "Claude will not purchase items, create accounts, or bypass captchas without input. Revoke site permissions in",
                                    " ",
                                    a.jsx("button", {
                                        onClick: () =>
                                            chrome.runtime.openOptionsPage(),
                                        className:
                                            "underline hover:text-text-400",
                                        children: "settings",
                                    }),
                                    ".",
                                ],
                            }),
                        ],
                    }),
                ],
            })
        );
    },
    ay = ({ onClick: e, children: t, isActive: n = !1, height: r }) =>
        a.jsx("button", {
            onClick: e,
            className: `w-full font-base flex min-w-[75px] px-[14px] py-[3px] justify-between items-center gap-2 rounded-lg border-[0.5px] transition-colors font-medium text-text-100 ${
                n
                    ? "bg-bg-300 border-border-400"
                    : "border-border-200 hover:bg-bg-100"
            } ${r ? "" : "h-8"}`,
            style: r ? { height: r } : void 0,
            children: t,
        }),
    ly = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M13.4996 3.5C13.7758 3.5 13.9996 3.72386 13.9996 4C13.9996 4.27614 13.7758 4.5 13.4996 4.5H12.9996V8.84375L16.7965 14.3672C17.7085 15.6942 16.7583 17.5 15.1481 17.5H4.8511C3.24107 17.4998 2.2909 15.6941 3.20265 14.3672L6.99956 8.84375V4.5H6.49956C6.22353 4.49986 5.99955 4.27606 5.99955 4C5.99955 3.72394 6.22353 3.50014 6.49956 3.5H13.4996ZM4.02688 14.9336C3.57109 15.597 4.04619 16.4998 4.8511 16.5H15.1481C15.9532 16.5 16.4283 15.5971 15.9723 14.9336L14.9869 13.5H5.01224L4.02688 14.9336ZM7.99957 9C7.99957 9.10111 7.96894 9.19987 7.91168 9.2832L5.69974 12.5H14.2994L12.0875 9.2832C12.0303 9.1999 11.9996 9.10107 11.9996 9V4.5H7.99957V9Z",
            }),
        }),
    cy =
        "https://support.anthropic.com/en/articles/12012173-getting-started-with-claude-for-chrome",
    uy = ({ onAccept: e }) =>
        a.jsx("div", {
            className:
                "w-full h-screen bg-bg-100 flex items-center justify-center p-5",
            children: a.jsxs("div", {
                className: "max-w-[520px] w-full",
                children: [
                    a.jsxs("h1", {
                        className: "text-center text-text-300 mb-[22px]",
                        style: {
                            fontFamily: "Copernicus, var(--font-ui-serif)",
                            fontSize: "26px",
                            fontWeight: 500,
                            lineHeight: "130%",
                            letterSpacing: "-0.65px",
                        },
                        children: [
                            "Claude can now",
                            a.jsx("br", {}),
                            "control your browser",
                        ],
                    }),
                    a.jsxs("div", {
                        className:
                            "border border-border-300 rounded-[24px] mb-[22px]",
                        children: [
                            a.jsxs("div", {
                                className: "flex gap-3 pt-5 pb-4 px-4",
                                children: [
                                    a.jsx("div", {
                                        className: "mt-0.5",
                                        children: a.jsx(wi, {
                                            size: 20,
                                            className: "text-text-100",
                                        }),
                                    }),
                                    a.jsx("p", {
                                        className:
                                            "text-[12px] text-text-300 flex-1 leading-[140%]",
                                        children:
                                            "Claude can view the URL of tabs where the panel is open and take screenshots when responding. For privacy, avoid using Claude on sensitive sites like health and dating platforms.",
                                    }),
                                ],
                            }),
                            a.jsx("div", {
                                className:
                                    "border-t-[0.5px] border-border-300 px-4",
                            }),
                            a.jsxs("div", {
                                className: "flex gap-3 py-4 px-4",
                                children: [
                                    a.jsx("div", {
                                        className: "mt-0.5",
                                        children: a.jsx(ly, {
                                            size: 20,
                                            className: "text-text-100",
                                        }),
                                    }),
                                    a.jsx("p", {
                                        className:
                                            "text-[12px] text-text-300 flex-1 leading-[140%]",
                                        children:
                                            "This is a beta feature with unique risks distinct from other Claude products. You are fully responsible for all risks associated with use of this product.",
                                    }),
                                ],
                            }),
                            a.jsx("div", {
                                className:
                                    "border-t-[0.5px] border-border-300 px-4",
                            }),
                            a.jsxs("div", {
                                className: "flex gap-3 pt-4 pb-5 px-4",
                                children: [
                                    a.jsx("div", {
                                        className: "mt-0.5",
                                        children: a.jsx(ji, {
                                            size: 20,
                                            className: "text-danger-000",
                                        }),
                                    }),
                                    a.jsx("div", {
                                        className: "flex-1",
                                        children: a.jsxs("p", {
                                            className:
                                                "text-[12px] text-danger-000 leading-[140%]",
                                            children: [
                                                "Malicious code buried in sites may override your instructions in order to steal your data, inject malware into your systems, or take over your system to attack other users.",
                                                " ",
                                                a.jsx("button", {
                                                    onClick: () => {
                                                        chrome.tabs.create({
                                                            url: cy,
                                                        });
                                                    },
                                                    className:
                                                        "text-danger-000 underline hover:no-underline focus:outline-none",
                                                    children: "Learn more",
                                                }),
                                            ],
                                        }),
                                    }),
                                ],
                            }),
                        ],
                    }),
                    a.jsx("div", {
                        className: "flex justify-end",
                        children: a.jsx("button", {
                            onClick: e,
                            className:
                                "px-4 py-2.5 rounded-[14px] bg-text-100 hover:bg-text-200 active:bg-text-000 text-bg-100 font-button transition-all hover:shadow-md",
                            children: "I understand",
                        }),
                    }),
                ],
            }),
        }),
    dy = ({ currentVersion: e, minSupportedVersion: t }) =>
        a.jsx("div", {
            className:
                "flex flex-col items-center justify-center min-h-screen bg-bg-100 p-4",
            children: a.jsx("div", {
                className: "max-w-md w-full",
                children: a.jsx("div", {
                    className:
                        "bg-bg-000 rounded-xl shadow-sm border border-border-200 p-6",
                    children: a.jsxs("div", {
                        className: "flex flex-col items-center text-center",
                        children: [
                            a.jsx("div", {
                                className:
                                    "w-12 h-12 bg-danger-900 rounded-full flex items-center justify-center mb-3",
                                children: a.jsx(m, {
                                    className: "w-6 h-6 text-danger-200",
                                }),
                            }),
                            a.jsx("h2", {
                                className: "font-xl-bold text-text-100 mb-2",
                                children: "Extension Update Required",
                            }),
                            a.jsxs("p", {
                                className: "font-base-sm text-text-300 mb-4",
                                children: [
                                    "Your extension version (",
                                    e,
                                    ") is no longer supported. Please update to version ",
                                    t,
                                    " or later to continue using Claude.",
                                ],
                            }),
                            a.jsx("button", {
                                onClick: () => {
                                    chrome.runtime.reload();
                                },
                                className:
                                    "w-full px-4 py-2 bg-accent-main-200 text-oncolor-100 font-button-lg rounded-lg hover:bg-accent-main-100 transition-colors",
                                children: "Update Extension",
                            }),
                            a.jsx("p", {
                                className: "font-caption text-text-400 mt-3",
                                children:
                                    "Clicking the button will reload the extension to apply any pending updates.",
                            }),
                        ],
                    }),
                }),
            }),
        });
function hy() {
    const [e, t] = r.useState(!1);
    return (
        r.useEffect(() => {
            (() => {
                const e =
                    window.matchMedia &&
                    window.matchMedia("(prefers-color-scheme: dark)").matches;
                t(e);
            })();
            const e = window.matchMedia("(prefers-color-scheme: dark)"),
                n = (e) => {
                    t(e.matches);
                };
            return (
                e.addEventListener("change", n),
                () => {
                    e.removeEventListener("change", n);
                }
            );
        }, []),
        e
    );
}
const py_CantAcessPage = () => {
    const e = hy();
    return a.jsx("div", {
        className:
            "flex flex-col items-center justify-center h-screen bg-bg-100 p-8",
        children: a.jsxs("div", {
            className: "max-w-md text-center",
            children: [
                a.jsx("div", {
                    className:
                        "w-12 h-12 flex items-center justify-center mx-auto",
                    children: a.jsx("img", {
                        src: e
                            ? "/assets/darkshield-C5QZAT-q.svg"
                            : "/assets/lightshield-Dx3kyqnQ.svg",
                        alt: "Shield",
                        className: "w-12 h-12",
                    }),
                }),
                a.jsx("h2", {
                    className: "font-large-bold text-text-100 mt-[22px]",
                    children: "Can't access this page",
                }),
                a.jsx("p", {
                    className: "font-base text-text-300 mt-[7px]",
                    children:
                        "Claude cannot assist with the content on this page for safety reasons.",
                }),
                a.jsx("button", {
                    onClick: () => {
                        chrome.tabs.update({ url: "https://claude.ai" });
                    },
                    className:
                        "mt-[22px] px-[14px] py-[3px] border border-border-300 rounded-lg hover:bg-bg-200 transition-colors font-base-bold text-text-100",
                    children: "Go to Claude",
                }),
            ],
        }),
    });
};
async function fy() {
    return (
        !0 ===
        (await (async function () {
            return (await chrome.storage.local.get(A.SKIP_ALL_PERMISSIONS))[
                A.SKIP_ALL_PERMISSIONS
            ];
        })())
    );
}
async function my(e) {
    await (async function (e) {
        await chrome.storage.local.set({ [A.SKIP_ALL_PERMISSIONS]: e });
    })(e);
}
const gy = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("path", {
                d: "M10 2.5C14.1421 2.5 17.5 5.85786 17.5 10C17.5 14.1421 14.1421 17.5 10 17.5H3C2.79779 17.5 2.61549 17.3782 2.53809 17.1914C2.4607 17.0046 2.50349 16.7895 2.64648 16.6465L4.35547 14.9365C3.20124 13.6175 2.5 11.8906 2.5 10C2.5 5.85786 5.85786 2.5 10 2.5ZM10 3.5C6.41015 3.5 3.5 6.41015 3.5 10C3.5 11.7952 4.22659 13.4199 5.40332 14.5967L5.46582 14.6729C5.52017 14.7544 5.5498 14.8508 5.5498 14.9502C5.5498 15.0828 5.49709 15.2099 5.40332 15.3037L4.20703 16.5H10C13.5899 16.5 16.5 13.5899 16.5 10C16.5 6.41015 13.5899 3.5 10 3.5ZM12.1213 7.87868C12.3166 8.07394 12.3166 8.39052 12.1213 8.58579L10.7071 10L12.1213 11.4142C12.3166 11.6095 12.3166 11.9261 12.1213 12.1213C11.9261 12.3166 11.6095 12.3166 11.4142 12.1213L10 10.7071L8.58579 12.1213C8.39052 12.3166 8.07394 12.3166 7.87868 12.1213C7.68342 11.9261 7.68342 11.6095 7.87868 11.4142L9.29289 10L7.87868 8.58579C7.68342 8.39052 7.68342 8.07394 7.87868 7.87868C8.07394 7.68342 8.39052 7.68342 8.58579 7.87868L10 9.29289L11.4142 7.87868C11.6095 7.68342 11.9261 7.68342 12.1213 7.87868Z",
            }),
        }),
    yy = (e) =>
        a.jsx(pi, {
            ...e,
            children: a.jsx("g", {
                transform: "translate(3, 3) scale(0.875)",
                children: a.jsx("path", {
                    d: "M12.5 2.125C12.4006 2.125 12.3052 2.16451 12.2348 2.23483C12.1645 2.30516 12.125 2.40054 12.125 2.5V7.0525L4.46064 2.25875C4.32815 2.17596 4.17591 2.13015 4.01973 2.12609C3.86355 2.12202 3.70913 2.15984 3.57251 2.23563C3.43642 2.30948 3.32291 2.41889 3.2441 2.55218C3.1653 2.68547 3.12414 2.83766 3.12501 2.9925V13.0075C3.12414 13.1623 3.1653 13.3145 3.2441 13.4478C3.32291 13.5811 3.43642 13.6905 3.57251 13.7644C3.70913 13.8402 3.86355 13.878 4.01973 13.8739C4.17591 13.8698 4.32815 13.824 4.46064 13.7413L12.125 8.94812V13.5C12.125 13.5995 12.1645 13.6948 12.2348 13.7652C12.3052 13.8355 12.4006 13.875 12.5 13.875C12.5995 13.875 12.6949 13.8355 12.7652 13.7652C12.8355 13.6948 12.875 13.5995 12.875 13.5V2.5C12.875 2.40054 12.8355 2.30516 12.7652 2.23483C12.6949 2.16451 12.5995 2.125 12.5 2.125ZM12.07 8.0975L4.06251 13.1056C4.04379 13.1171 4.02238 13.1234 4.00043 13.1239C3.97849 13.1245 3.95679 13.1193 3.93751 13.1088C3.91863 13.0995 3.90274 13.085 3.89169 13.0671C3.88063 13.0492 3.87485 13.0285 3.87501 13.0075V2.9925C3.87485 2.97145 3.88063 2.95079 3.89169 2.93288C3.90274 2.91497 3.91863 2.90054 3.93751 2.89125C3.95667 2.88071 3.97815 2.87513 4.00001 2.875C4.0222 2.87579 4.04377 2.88248 4.06251 2.89438L12.07 7.9025C12.0868 7.91261 12.1008 7.9269 12.1104 7.94399C12.1201 7.96107 12.1252 7.98037 12.1252 8C12.1252 8.01963 12.1201 8.03893 12.1104 8.05601C12.1008 8.0731 12.0868 8.08739 12.07 8.0975Z",
                }),
            }),
        }),
    xy = ({ className: e = "" }) =>
        a.jsxs("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "44",
            height: "54",
            viewBox: "0 0 44 54",
            fill: "none",
            className: e,
            children: [
                a.jsx("path", {
                    d: "M21.7123 19.6053C21.6411 19.4884 18.9303 14.7128 19.6611 10.6981C20.3919 6.6834 24.1296 1.49002 29.3189 1.1021C34.5083 0.714185 39.3603 1.8108 41.5565 8.03863C43.7527 14.2665 40.9756 20.59 36.2422 22.2772C31.5089 23.9644 27.0316 23.0655 27.0316 23.0655C27.0316 23.0655 26.6706 17.9629 26.5919 16.9844C26.5132 16.0059 24.5244 15.2487 23.8947 15.6888C23.2651 16.129 22.8191 16.4373 22.6043 17.5265C22.3894 18.6156 21.7123 19.6028 21.7123 19.6028V19.6053Z",
                    fill: "hsl(var(--bg-500))",
                }),
                a.jsx("path", {
                    d: "M0.721235 51.5865C0.717916 50.4591 0.714597 49.3317 0.711278 48.2043C0.711278 46.512 0.591797 46.512 0.591797 44.8209C0.591797 43.1298 0.761062 43.1298 0.761062 41.4375C0.758573 40.3101 0.755669 39.1823 0.75235 38.0541C0.756084 37.1849 0.769775 36.741 0.792177 36.2971C0.804623 36.0746 0.822048 35.8507 0.858141 35.571C0.897968 35.2912 0.953975 34.9542 1.07968 34.5078C1.20663 34.0614 1.34478 33.7319 1.47795 33.4646C1.61112 33.196 1.73932 32.9883 1.88245 32.7894C2.02309 32.5892 2.18364 32.3989 2.39771 32.1726C2.61925 31.9538 2.90302 31.6976 3.33863 31.4427C3.77673 31.1903 4.13766 31.0809 4.43388 31.0038C4.58198 30.9615 4.7164 30.9379 4.84459 30.9155C4.96905 30.8882 5.09725 30.8807 5.22046 30.867C5.46938 30.8421 5.73075 30.8434 6.06306 30.8869C6.22983 30.9192 6.41528 30.9541 6.62064 31.0349C6.826 31.1082 7.05003 31.2276 7.27903 31.3967C7.32882 31.4378 7.37611 31.4775 7.42341 31.5161L7.45825 31.5447L7.47568 31.5596L7.50306 31.587C7.51675 31.6006 7.53044 31.6143 7.54289 31.6268L7.55658 31.6417C7.57276 31.6591 7.5852 31.674 7.59516 31.6852C7.61383 31.7076 7.62379 31.715 7.62876 31.7138C7.6325 31.7126 7.62876 31.7138 7.63872 31.7039C7.64868 31.6952 7.64992 31.669 7.64743 31.6516C7.64619 31.6143 7.64494 31.587 7.64619 31.5671C7.64619 31.5621 7.64619 31.5546 7.64868 31.5472C7.67481 31.4688 7.69846 31.4005 7.71962 31.3395C7.77936 31.1704 7.83661 31.0237 7.89386 30.8894C8.00712 30.6233 8.10794 30.4119 8.22244 30.2055C8.33694 29.9991 8.45767 29.7939 8.63191 29.5452C8.8074 29.299 9.03267 29.0031 9.41228 28.6624C9.79561 28.3229 10.1516 28.1314 10.454 28.0059C10.7602 27.8828 11.0178 27.8169 11.2754 27.782L11.3725 27.7671L11.4621 27.7597C11.5219 27.7547 11.5841 27.7497 11.6463 27.7435C11.7098 27.7385 11.7745 27.7335 11.8417 27.7273C11.9114 27.7273 11.9849 27.7248 12.0608 27.7236C12.1379 27.7236 12.2164 27.7186 12.3047 27.7236C12.3931 27.7298 12.4852 27.736 12.5848 27.7435C12.6818 27.746 12.7926 27.7721 12.9059 27.7895C12.9631 27.8007 13.0216 27.8082 13.0826 27.8243C13.1448 27.843 13.2083 27.8616 13.273 27.8803C13.8007 28.0419 14.1679 28.318 14.4181 28.5642C14.4492 28.5965 14.479 28.6276 14.5077 28.6574L14.5512 28.7034L14.5624 28.7146C14.5624 28.7146 14.5599 28.7109 14.5599 28.7096C14.5562 28.7047 14.5512 28.6997 14.5462 28.6947C14.5512 28.6985 14.5587 28.7022 14.5637 28.7047C14.5749 28.7096 14.5836 28.7146 14.5911 28.7159C14.6197 28.7246 14.6222 28.6848 14.6247 28.7072C14.6334 28.6935 14.6383 28.7096 14.657 28.7022C14.6657 28.6985 14.6769 28.6885 14.6906 28.6649L14.6981 28.6512L14.7018 28.6437L14.7043 28.64L14.7155 28.6139C14.7479 28.5381 14.7777 28.4585 14.8163 28.3739C14.8898 28.2048 14.9819 28.0158 15.0976 27.8032C15.3366 27.3792 15.5793 27.0795 15.8108 26.8544C16.0435 26.6294 16.2576 26.4702 16.4903 26.3396C16.7231 26.2103 16.9695 26.0997 17.2893 26.0139C17.4487 25.9716 17.6266 25.9343 17.8283 25.9144C18.0262 25.8883 18.2651 25.8833 18.5352 25.9107C18.8065 25.9393 19.0455 26.0039 19.2471 26.0823C19.4512 26.1581 19.6192 26.2476 19.7649 26.3372C20.0548 26.5175 20.259 26.6915 20.4444 26.8743C20.4892 26.9203 20.5378 26.9663 20.5788 27.0161C20.6 27.0409 20.6224 27.0646 20.6448 27.0894L20.6771 27.1255H20.6821C20.6958 27.1317 20.7045 27.1317 20.712 27.1305C20.7269 27.1305 20.7319 27.123 20.7356 27.1342C20.7394 27.1454 20.7431 27.1653 20.7481 27.1976C20.7556 27.2275 20.7531 27.2784 20.7717 27.3195C20.7941 27.3667 20.8041 27.3692 20.8128 27.271C20.8165 27.2225 20.824 27.1951 20.8327 27.1665C20.8389 27.1516 20.8439 27.1379 20.8489 27.1243L20.8576 27.1019L20.8601 27.0957L20.8651 27.0584L20.875 26.98C20.9273 26.5597 20.9808 26.1382 21.0518 25.2964C21.2011 23.6078 21.0754 23.5966 21.2484 21.9043C21.3368 21.0575 21.4115 20.6347 21.4824 20.2132C21.521 20.0006 21.5583 19.788 21.6056 19.5231C21.6305 19.3876 21.6579 19.2396 21.6878 19.0705C21.7164 18.9014 21.7624 18.7111 21.8048 18.4935C21.9977 17.6231 22.1508 17.1817 22.3262 16.7378C22.376 16.6271 22.4134 16.5165 22.4793 16.3983C22.5428 16.2814 22.6001 16.1559 22.6946 16.0203C22.7419 15.9519 22.783 15.8798 22.8428 15.8065C22.9037 15.7318 22.9672 15.6548 23.0382 15.5727C23.1215 15.4931 23.2024 15.4086 23.3082 15.3252C23.4178 15.2432 23.5323 15.1574 23.6841 15.0853C23.9778 14.936 24.2927 14.8726 24.569 14.8826C24.7034 14.8913 24.8478 14.9099 24.9187 14.9286C25.0059 14.946 25.0855 14.9684 25.1627 14.9895C25.4701 15.079 25.7078 15.1897 25.9356 15.319C26.1633 15.4483 26.3799 15.61 26.6226 15.84C26.8603 16.0713 27.1292 16.3934 27.3358 16.8758C27.5436 17.3595 27.5847 17.7325 27.6332 18.0359C27.6469 18.1876 27.6594 18.3232 27.6706 18.4513C27.6768 18.5632 27.6818 18.6689 27.6867 18.7745C27.7091 19.1973 27.7315 19.6201 27.7166 20.4669C27.6855 22.1592 27.571 22.1592 27.5399 23.8503C27.515 24.9785 27.4905 26.1071 27.4664 27.2362C27.4353 28.9285 27.4565 28.9285 27.4241 30.6208C27.3967 31.749 27.3694 32.8777 27.342 34.0067C27.3345 34.4295 27.3333 34.7478 27.3358 35.0114C27.3358 35.0413 27.3358 35.0711 27.3358 35.0997L27.3382 35.1196C27.3407 35.132 27.342 35.1432 27.3445 35.1556C27.3482 35.178 27.3532 35.1967 27.3582 35.2128C27.3768 35.2812 27.3955 35.3074 27.3943 35.423C27.3943 35.4528 27.3918 35.4827 27.3893 35.5138C27.3868 35.5473 27.4191 35.5685 27.4303 35.5635C27.444 35.5535 27.4515 35.5498 27.4652 35.5424C27.4913 35.5274 27.5312 35.474 27.6257 35.2924C27.637 35.27 27.6482 35.2489 27.6581 35.229C27.6706 35.2029 27.6631 35.2166 27.7179 35.1146C27.8 34.9642 27.8709 34.8311 27.9369 34.7117C28.0688 34.4705 28.1759 34.2778 28.2879 34.0838C28.3999 33.8911 28.5169 33.6996 28.6774 33.4671C28.7583 33.3527 28.8542 33.2221 28.96 33.0878C29.067 32.956 29.1827 32.8068 29.3271 32.6414C29.8984 31.9787 30.2033 31.6479 30.5219 31.3221C30.6812 31.1592 30.8493 31.0001 31.0745 30.8123C31.3023 30.627 31.5886 30.4094 32.0229 30.1757C32.4585 29.9431 32.8244 29.8225 33.1294 29.7479C33.2825 29.7069 33.4219 29.6845 33.5538 29.6634C33.6857 29.6385 33.8102 29.6335 33.9334 29.6211C34.1848 29.6024 34.4636 29.6037 34.8096 29.6534C34.8979 29.6733 34.99 29.6932 35.0871 29.7156C35.1842 29.7355 35.2875 29.7815 35.3958 29.8188C35.6123 29.9021 35.8488 30.0364 36.089 30.2291C36.1998 30.3336 36.3081 30.4331 36.3915 30.5375C36.4699 30.6444 36.5533 30.7427 36.6068 30.8434C36.6615 30.9441 36.7163 31.0386 36.7574 31.1294C36.7922 31.2214 36.8258 31.3084 36.8582 31.3918C36.8918 31.4751 36.9042 31.5534 36.9254 31.6292C36.9428 31.7051 36.9652 31.7785 36.9752 31.8481C36.9939 31.9861 37.0163 32.1192 37.0237 32.2472C37.0275 32.3741 37.0362 32.5034 37.0337 32.6377C37.0262 32.7695 37.0237 32.9112 37.0075 33.0629C36.9976 33.1375 36.9876 33.2171 36.9764 33.3004C36.9665 33.385 36.954 33.472 36.9341 33.5628C36.9154 33.6536 36.8955 33.7506 36.8756 33.8538C36.8681 33.901 36.8457 33.9706 36.8296 34.0303C36.8109 34.0925 36.7947 34.1584 36.7698 34.2206C36.5819 34.7291 36.3666 35.0313 36.1923 35.27C36.0131 35.5075 35.86 35.6767 35.7057 35.8395C35.3983 36.1653 35.0809 36.4675 34.5146 37.0855C33.9533 37.7022 33.7031 38.0181 33.4604 38.3401C33.3397 38.5018 33.224 38.6646 33.0871 38.8698C32.9526 39.0775 32.7896 39.3262 32.6116 39.6718C32.4336 40.0187 32.3303 40.2898 32.2606 40.5199C32.1909 40.7499 32.1524 40.9377 32.1212 41.1254C32.1026 41.2187 32.0926 41.3132 32.0802 41.4139C32.0739 41.4636 32.0665 41.5146 32.059 41.5681C32.054 41.6215 32.0491 41.6775 32.0441 41.7372C32.0379 41.7969 32.0316 41.859 32.0242 41.9249C32.0179 41.9971 32.0105 42.0742 32.003 42.155C31.9856 42.3179 31.9657 42.5007 31.9433 42.7083C31.7553 44.382 31.6545 44.3733 31.4803 46.0532C31.3098 47.7355 31.3421 47.7393 31.1778 49.4217C31.0957 50.2635 31.0372 50.6813 30.9787 51.1003C30.9501 51.3092 30.9202 51.5193 30.8878 51.7817C30.8804 51.8476 30.8717 51.916 30.863 51.9894C30.853 52.0851 30.8418 52.1871 30.8306 52.2952C30.8169 52.4432 30.7933 52.5962 30.731 52.7392C30.67 52.8846 30.573 53.0264 30.4373 53.1445C30.2817 53.2801 30.1013 53.3584 29.9594 53.3907C29.8175 53.4255 29.7067 53.423 29.6769 53.4268C29.4814 53.4305 29.306 53.433 29.1454 53.4367C29.0185 53.4405 28.9015 53.4429 28.7932 53.4467C28.5766 53.4541 28.3887 53.4604 28.1933 53.4678C27.805 53.4815 27.3893 53.4939 26.6637 53.5001C24.9698 53.5126 24.9685 53.4355 23.2746 53.4479C21.5807 53.4591 21.5807 53.5263 19.8868 53.5362C18.1917 53.5461 18.1917 53.5225 16.4965 53.5312C15.3673 53.5412 14.238 53.5507 13.1087 53.5598C11.4136 53.5648 11.4136 53.6394 9.7172 53.6406C8.01957 53.6406 8.01957 53.5325 6.32193 53.5263C4.62306 53.5163 4.62554 53.4977 2.92044 53.4703C2.26205 53.4579 1.87125 53.3895 1.63602 53.2713C1.57752 53.2415 1.53023 53.2092 1.49413 53.1756C1.48044 53.1594 1.44933 53.1383 1.42817 53.1172C1.40701 53.096 1.39083 53.0749 1.37838 53.0537C1.32984 52.9679 1.34851 52.8846 1.38461 52.7951C1.4207 52.7056 1.47048 52.6248 1.50907 52.5477C1.51902 52.529 1.52774 52.5104 1.5352 52.493C1.54267 52.4755 1.54392 52.4594 1.56756 52.4432C1.6049 52.4109 1.64971 52.3835 1.70322 52.3587C1.91481 52.2592 2.2969 52.2082 2.94658 52.2206C4.62928 52.248 4.63177 52.2766 6.32193 52.2865C7.45037 52.2915 8.57839 52.2961 9.706 52.3002C11.3987 52.299 11.3974 52.197 13.0901 52.192C14.7827 52.1858 14.7827 52.2841 16.4754 52.2766C18.168 52.2679 18.1668 52.1025 19.8594 52.0926C21.5521 52.0826 21.5521 52.11 23.2448 52.0975C24.9374 52.0851 24.9374 52.1634 26.6301 52.151C27.3607 52.1485 27.7763 52.1473 28.1672 52.146C28.5256 52.146 28.8616 52.146 29.4429 52.146C29.4478 52.1448 29.4902 52.1547 29.5263 52.1274C29.5599 52.1025 29.5636 52.0627 29.5648 52.0329C29.5773 51.9036 29.5897 51.7904 29.5997 51.686C29.6271 51.4223 29.6482 51.2122 29.6706 51.0021C29.7129 50.5805 29.7553 50.1603 29.8411 49.3172C30.0067 47.6323 30.049 47.6373 30.2195 45.9525C30.3937 44.2676 30.3639 44.2651 30.553 42.5778C30.5779 42.3664 30.5991 42.1811 30.6178 42.0157C30.6364 41.8503 30.6526 41.7061 30.6763 41.5606C30.6962 41.4176 30.7148 41.2895 30.741 41.1702C30.7659 41.0508 30.7845 40.9364 30.8144 40.8257C30.8679 40.6019 30.9314 40.3793 31.0248 40.107C31.1218 39.836 31.2488 39.5152 31.4566 39.1073C31.886 38.3028 32.1449 37.936 32.3913 37.563C32.6427 37.1961 32.9091 36.8318 33.4878 36.1952C34.0666 35.5635 34.3354 35.2576 34.5818 34.9455C34.7063 34.7901 34.822 34.6346 34.954 34.4444C35.0834 34.2542 35.229 34.0241 35.3348 33.7406C35.3659 33.6685 35.3746 33.6063 35.3958 33.5454C35.412 33.4658 35.4269 33.3912 35.4418 33.3203C35.4767 33.1786 35.4829 33.058 35.5016 32.9473C35.5265 32.7272 35.5327 32.5556 35.5265 32.3915C35.5277 32.3492 35.524 32.3094 35.5178 32.2696C35.5128 32.2298 35.509 32.1888 35.5041 32.1478C35.5016 32.1042 35.4904 32.0657 35.4804 32.0247C35.4705 31.9836 35.4618 31.9389 35.4505 31.8953C35.3945 31.7262 35.3099 31.5422 35.1394 31.3843C35.1182 31.3632 35.0921 31.3507 35.0709 31.3333C35.0473 31.3184 35.0311 31.2972 35.0062 31.2861C34.9564 31.2649 34.9179 31.2338 34.8706 31.2177C34.822 31.2027 34.781 31.1841 34.7361 31.1692C34.6889 31.1605 34.6453 31.1505 34.603 31.1406C34.5631 31.1269 34.5146 31.1306 34.4748 31.1244C34.4325 31.1219 34.3939 31.112 34.3516 31.1132C34.2657 31.117 34.1935 31.1107 34.1064 31.1194C33.9296 31.1344 33.7554 31.1543 33.5438 31.2077C33.331 31.2562 33.0821 31.3408 32.7622 31.5061C32.4448 31.6765 32.2121 31.8344 32.0229 31.9774C31.8325 32.1192 31.6807 32.241 31.5325 32.3703C31.2363 32.629 30.9414 32.8988 30.4062 33.518C30.2718 33.671 30.1585 33.814 30.0565 33.9371C29.9519 34.0627 29.8772 34.1671 29.8013 34.2653C29.6569 34.4655 29.5462 34.6309 29.4379 34.8C29.3321 34.9704 29.2276 35.142 29.0994 35.3596C29.0371 35.4702 28.9662 35.5896 28.8903 35.7289C28.8703 35.7649 28.8504 35.801 28.8293 35.8383C28.7882 35.9129 28.7471 35.9863 28.7073 36.0658C28.6252 36.2225 28.5393 36.3904 28.4472 36.5682C28.3576 36.7535 28.2742 36.9276 28.1945 37.0904C28.1161 37.2558 28.0427 37.4237 27.9742 37.5741C27.9058 37.7296 27.8398 37.8651 27.7776 37.9932C27.7465 38.0578 27.7166 38.12 27.6867 38.1809C27.6718 38.2108 27.6581 38.2406 27.6432 38.2705C27.6357 38.2841 27.6282 38.3016 27.622 38.3127L27.6021 38.3314C27.5498 38.3811 27.5013 38.4284 27.454 38.4744C27.4303 38.4968 27.4079 38.5192 27.3843 38.5415C27.3656 38.5515 27.3482 38.5627 27.3308 38.5726C27.2611 38.6124 27.1914 38.6559 27.1441 38.6709C27.118 38.682 27.0918 38.6932 27.0657 38.7044C27.0445 38.7119 27.0234 38.7206 27.001 38.7293C26.9611 38.7455 26.9201 38.7616 26.8728 38.7803C26.8454 38.789 26.7682 38.7927 26.6799 38.7766C26.594 38.7604 26.4957 38.7181 26.4558 38.6845C26.4023 38.6323 26.3525 38.5614 26.2841 38.4732C26.2654 38.4458 26.248 38.4197 26.2306 38.3936C26.2131 38.3662 26.1969 38.3476 26.1783 38.3115C26.1434 38.2431 26.1098 38.1971 26.0824 38.1113C26.0688 38.0703 26.0526 38.0417 26.0414 37.9957C26.0314 37.9484 26.0202 37.9024 26.0115 37.8576C26.0053 37.8054 26.004 37.7445 25.9991 37.6898C25.9991 37.6264 26.0003 37.5654 26.0015 37.5058C26.009 37.0233 26.0152 36.6366 26.0215 36.2499C26.0302 35.6941 26.0401 35.137 26.0588 34.0254C26.0899 32.3355 26.0352 32.3355 26.0663 30.6457C26.0974 28.9558 26.1994 28.9571 26.2306 27.2673C26.2617 25.5762 26.0899 25.5749 26.121 23.8851C26.1434 22.7585 26.1658 21.6324 26.1882 20.5067C26.2044 19.6611 26.2119 19.2396 26.2206 18.8168C26.2231 18.7111 26.2243 18.6054 26.2268 18.4935C26.2293 18.4326 26.2243 18.3953 26.2218 18.3431C26.2194 18.2946 26.2181 18.2436 26.2156 18.1901C26.2156 18.1354 26.2057 18.0832 26.1982 18.026C26.1907 17.97 26.182 17.9104 26.1721 17.8469C26.1571 17.7873 26.1409 17.7251 26.1248 17.6579C26.1098 17.5896 26.0775 17.5299 26.0551 17.4577C25.9431 17.1854 25.8074 17.03 25.6804 16.9094C25.5522 16.79 25.4328 16.7079 25.2971 16.6408C25.1639 16.5724 25.0196 16.5102 24.8229 16.4593C24.7731 16.4493 24.7221 16.4344 24.6648 16.4232C24.6362 16.4182 24.6076 16.412 24.5777 16.407C24.5653 16.407 24.5553 16.407 24.5441 16.4045C24.4993 16.4045 24.4533 16.4083 24.3811 16.4406C24.233 16.5115 24.0687 16.6756 23.9504 16.8298C23.9206 16.8696 23.8882 16.9032 23.8608 16.943C23.8335 16.984 23.8073 17.0225 23.7812 17.0598C23.7264 17.132 23.6816 17.2115 23.6356 17.2911C23.4563 17.6094 23.2746 17.9576 23.0991 18.7397C23.0606 18.9374 23.022 19.109 22.9958 19.2645C22.9722 19.4211 22.951 19.5592 22.9311 19.6847C22.8925 19.9359 22.8739 20.1473 22.849 20.3525C22.8054 20.769 22.7606 21.1856 22.6735 22.0199C22.5017 23.6936 22.5727 23.7011 22.4246 25.381C22.3536 26.2215 22.3287 26.643 22.3051 27.0646C22.2503 27.8678 22.1943 28.6723 22.0835 30.2801C22.0835 30.2963 22.0811 30.3137 22.0798 30.3236L22.0711 30.392C22.0674 30.4132 22.0661 30.443 22.0587 30.448C22.0462 30.4691 22.035 30.489 22.0238 30.5089C22.0002 30.5487 21.9778 30.5872 21.9566 30.6245C21.913 30.6967 21.8707 30.7651 21.8321 30.8297C21.7911 30.9105 21.76 30.9081 21.7276 30.9279C21.6965 30.9441 21.6666 30.959 21.638 30.9727C21.6106 30.9851 21.5807 31.005 21.5596 31.0075C21.5397 31.0113 21.5197 31.015 21.5011 31.0187C21.4824 31.0224 21.465 31.0274 21.4476 31.0324C21.4276 31.0374 21.4264 31.0423 21.3579 31.0523C21.2982 31.061 21.2185 31.0548 21.2123 31.0399C21.2049 31.0249 21.1999 31.01 21.1924 30.9926C21.1775 30.959 21.1601 30.9205 21.1314 30.877C21.104 30.8322 21.0692 30.7837 21.0119 30.7265C20.9559 30.6681 20.8813 30.6071 20.7419 30.4853C20.712 30.4629 20.6684 30.4132 20.6323 30.3746C20.6137 30.3535 20.595 30.3361 20.5763 30.3137C20.5552 30.2789 20.5353 30.2441 20.5154 30.2105C20.4954 30.1769 20.4755 30.1433 20.4569 30.111C20.4469 30.0936 20.4369 30.0799 20.4282 30.06C20.4208 30.0277 20.4121 29.9941 20.4046 29.9618C20.3735 29.8325 20.3424 29.7069 20.3125 29.585C20.1942 29.1536 20.0897 28.8502 19.9802 28.6201C19.9528 28.5617 19.9267 28.5032 19.9005 28.4473C19.8719 28.3963 19.8445 28.3478 19.8171 28.2993C19.7897 28.2521 19.7649 28.2023 19.7362 28.1588C19.7076 28.1165 19.679 28.0742 19.6504 28.0332L19.608 27.9723L19.5869 27.9424C19.5794 27.9313 19.5719 27.9213 19.5707 27.9201L19.5271 27.8691C19.4985 27.8355 19.4699 27.8032 19.44 27.7733C19.323 27.6515 19.1998 27.5445 19.0405 27.4438C18.8799 27.3443 18.6895 27.2486 18.4008 27.2113C18.2552 27.1939 18.1232 27.1964 17.9975 27.2138C17.9664 27.2175 17.9353 27.2212 17.9067 27.225C17.878 27.2312 17.8507 27.2374 17.8233 27.2424C17.7685 27.2523 17.7187 27.266 17.6727 27.2809C17.486 27.3381 17.3503 27.4102 17.2197 27.4923C17.0915 27.5794 16.9707 27.6788 16.8301 27.8256C16.6907 27.9735 16.5301 28.17 16.3534 28.4809C16.2663 28.6375 16.1953 28.7805 16.1381 28.9148C16.1082 28.9807 16.0833 29.0454 16.0584 29.1051C16.0522 29.12 16.046 29.1349 16.0398 29.1498C16.0286 29.1809 16.0186 29.212 16.0074 29.2431C15.9863 29.304 15.9651 29.3637 15.9452 29.4221C15.7908 29.9009 15.7 30.3199 15.6278 30.8061L15.5905 31.0921C15.5855 31.1219 15.5842 31.1617 15.5743 31.1791C15.5432 31.2687 15.5133 31.3594 15.4809 31.4539C15.4735 31.4825 15.4635 31.49 15.4536 31.5037L15.4249 31.5422C15.405 31.5683 15.3851 31.5957 15.3652 31.623C15.344 31.6554 15.3266 31.6653 15.3067 31.6852C15.288 31.7026 15.2681 31.7213 15.2482 31.7399C15.2096 31.7735 15.176 31.7946 15.1387 31.8245C15.1088 31.8444 15.0764 31.8643 15.0428 31.8866C15.0167 31.9028 14.9881 31.9215 14.9582 31.9401C14.947 31.9476 14.9346 31.955 14.9221 31.9637C14.9184 31.9675 14.9047 31.9737 14.8711 31.9774C14.84 31.9811 14.8026 31.9811 14.784 31.9787C14.7192 31.9264 14.6496 31.8929 14.4952 31.8332L14.4716 31.8245C14.4616 31.8195 14.4467 31.8083 14.4342 31.8008C14.4093 31.7847 14.3845 31.7685 14.3596 31.7523C14.311 31.7213 14.2637 31.6914 14.2189 31.6628C14.1679 31.5447 14.1181 31.4291 14.0683 31.3159C14.0434 31.2587 14.0185 31.2015 13.9949 31.1455C13.97 31.0884 13.9439 31.0374 13.9277 30.9565C13.8903 30.8073 13.853 30.6569 13.8157 30.5052C13.797 30.4281 13.7783 30.351 13.7584 30.2727C13.751 30.2266 13.7335 30.213 13.7211 30.1831L13.68 30.1048C13.6252 29.9979 13.5692 29.8884 13.5107 29.7728L13.4883 29.7293C13.4796 29.7143 13.4622 29.692 13.4485 29.6746L13.4274 29.646C13.4211 29.6373 13.4224 29.641 13.4199 29.6373L13.4087 29.6273C13.395 29.6136 13.3801 29.5987 13.3664 29.585C13.2469 29.4719 13.1087 29.3587 12.8474 29.2742C12.5823 29.1909 12.3296 29.1685 12.1118 29.1635C12.0023 29.1598 11.904 29.1536 11.8044 29.1598C11.7098 29.1635 11.6077 29.1598 11.5269 29.1672C11.3626 29.1747 11.2008 29.202 11.0041 29.2667C10.81 29.3339 10.5822 29.4458 10.3196 29.6733C10.0595 29.9058 9.89269 30.1247 9.76699 30.3174C9.64128 30.5114 9.55665 30.6793 9.47451 30.8496C9.39361 31.0212 9.32142 31.199 9.23554 31.4241C9.19323 31.5372 9.14718 31.6616 9.09864 31.8071C9.08619 31.8431 9.07374 31.8804 9.0613 31.919C9.04387 31.9737 9.02645 32.0296 9.00778 32.0868C8.95924 32.2572 8.90448 32.435 8.85594 32.6352C8.83727 32.7148 8.8186 32.7919 8.79993 32.8652C8.78251 32.9398 8.76882 33.0157 8.75513 33.0841C8.7265 33.2196 8.70534 33.3365 8.69165 33.421C8.67049 33.4932 8.65058 33.5703 8.62942 33.6337C8.60204 33.6809 8.5759 33.7282 8.55101 33.7729C8.53857 33.7953 8.52612 33.8177 8.51367 33.8401C8.50123 33.86 8.48878 33.8699 8.47634 33.8848C8.45145 33.9134 8.4278 33.9408 8.40415 33.9682C8.3581 34.0167 8.32076 34.044 8.28093 34.0801C8.24733 34.1037 8.21373 34.1298 8.1851 34.1485C8.15648 34.1659 8.13532 34.182 8.10296 34.197C8.06437 34.2144 7.98596 34.2343 7.92125 34.2405C7.88889 34.2442 7.85902 34.2442 7.84035 34.2442C7.82043 34.2442 7.81421 34.2442 7.80674 34.243L7.76318 34.2405C7.72086 34.2355 7.68228 34.2355 7.60387 34.2144C7.5852 34.2094 7.56902 34.2069 7.54911 34.2019C7.52297 34.1907 7.49684 34.1783 7.46946 34.1659C7.44207 34.1534 7.41469 34.141 7.38731 34.1286L7.36615 34.1186L7.33877 34.0938C7.3201 34.0763 7.30143 34.0602 7.28277 34.0428C7.24543 34.008 7.20685 33.9719 7.16702 33.9358L7.13715 33.9085C7.13715 33.9085 7.12719 33.901 7.12221 33.8923L7.10977 33.86C7.09234 33.8165 7.07492 33.7729 7.05749 33.7282C6.98655 33.5529 6.91188 33.3477 6.83222 33.196C6.79239 33.1127 6.75132 33.0281 6.71025 32.9398C6.70527 32.9299 6.70029 32.9162 6.69407 32.9088L6.64553 32.8491C6.62313 32.8217 6.60073 32.7944 6.57832 32.767C6.55592 32.7396 6.53227 32.711 6.50987 32.6824L6.47502 32.6389C6.46631 32.629 6.46382 32.629 6.4576 32.624C6.43644 32.6078 6.41528 32.5892 6.39288 32.5705C6.19623 32.4163 6.00456 32.3666 5.83281 32.3305C5.65358 32.3082 5.5005 32.302 5.33621 32.3169C5.17566 32.3306 4.99893 32.3529 4.79357 32.4064C4.58696 32.4561 4.348 32.532 4.06423 32.6899C3.78544 32.8528 3.60248 33.0157 3.45935 33.1637C3.31996 33.3166 3.21292 33.4459 3.12082 33.5926C3.02499 33.7344 2.93787 33.8886 2.84203 34.09C2.7462 34.2927 2.64041 34.5464 2.53711 34.9094C2.33673 35.6406 2.26578 36.036 2.18364 36.4264C2.10896 36.8194 2.04051 37.2198 2.03553 38.0417C2.03553 39.7315 2.00442 39.7328 2.00442 41.4251C2.00442 43.1186 2.05545 43.1186 2.05545 44.8122C2.05545 46.5058 2.09527 46.507 2.09527 48.2018C2.09527 49.8966 2.01935 49.8966 2.01935 51.5915C2.01935 52.8983 1.75799 52.7939 1.37092 52.7939C0.983846 52.7939 0.713768 52.8983 0.713768 51.5915L0.721235 51.5865Z",
                    fill: "hsl(var(--text-100))",
                }),
                a.jsx("path", {
                    d: "M27.8162 22.5869C28.1398 22.6678 28.309 22.6901 28.4733 22.72C28.6401 22.7436 28.8069 22.7722 29.1429 22.8095C29.4802 22.8443 29.652 22.8282 29.8225 22.8058C29.993 22.7871 30.1622 22.7623 30.4995 22.766C30.6688 22.7635 30.7957 22.7735 30.9015 22.7871C31.0073 22.7983 31.0932 22.8157 31.1791 22.8331C31.3508 22.8692 31.5251 22.8978 31.8673 22.868C32.2084 22.8331 32.3776 22.8058 32.5469 22.7797C32.6315 22.7672 32.7162 22.7523 32.8207 22.7324C32.9253 22.7113 33.0535 22.6939 33.2202 22.6578C33.5563 22.5907 33.7168 22.526 33.8774 22.4651C33.957 22.434 34.0379 22.4042 34.1375 22.3656C34.2371 22.3271 34.3603 22.2935 34.5208 22.24C34.8444 22.1393 35.0087 22.097 35.1755 22.056C35.2589 22.0373 35.341 22.015 35.4418 21.9801C35.5414 21.9453 35.6646 21.9068 35.8189 21.8359C36.1301 21.6991 36.2782 21.6158 36.4263 21.535C36.501 21.4952 36.5744 21.4542 36.6653 21.3995C36.7549 21.3447 36.8681 21.2875 37.0113 21.1993C37.1544 21.111 37.2602 21.0426 37.3436 20.9779C37.4257 20.912 37.488 20.8561 37.5514 20.7989C37.6149 20.7429 37.6771 20.687 37.7543 20.6161C37.8315 20.5452 37.931 20.4718 38.0592 20.3674C38.1887 20.2642 38.2845 20.1859 38.3654 20.1212C38.4451 20.0553 38.5073 20.0018 38.5708 19.9496C38.7002 19.8464 38.8209 19.7332 39.0512 19.497C39.1607 19.3739 39.2466 19.2856 39.32 19.2122C39.3885 19.1351 39.4457 19.0755 39.5042 19.017C39.6225 18.9001 39.7282 18.7733 39.9212 18.5022C40.1029 18.2138 40.1738 18.0558 40.2423 17.8992C40.3132 17.7425 40.3642 17.5784 40.5298 17.2849C40.6144 17.1394 40.6692 17.0263 40.7202 16.933C40.7712 16.841 40.8135 16.7689 40.8571 16.6955C40.8994 16.6222 40.9467 16.5513 40.9927 16.4568C41.0376 16.361 41.0873 16.2454 41.1496 16.09C41.2803 15.7791 41.3363 15.6224 41.4097 15.4682C41.4445 15.3911 41.4794 15.3141 41.5192 15.2158C41.5528 15.1163 41.5877 14.9945 41.63 14.8316C41.7196 14.5058 41.7022 14.3305 41.7009 14.1601C41.6984 14.0743 41.6972 13.9898 41.7009 13.8853C41.7009 13.7796 41.7059 13.6553 41.7258 13.4912C41.737 13.4091 41.7457 13.337 41.7544 13.2723C41.7594 13.2077 41.7656 13.1517 41.7719 13.0995C41.7843 12.9963 41.7968 12.9142 41.8105 12.8309C41.8428 12.6655 41.8503 12.4989 41.849 12.1657C41.8378 11.8324 41.8366 11.6645 41.8478 11.4954C41.8478 11.3276 41.8478 11.1572 41.798 10.824C41.732 10.4932 41.681 10.3316 41.6051 10.1762C41.5703 10.0978 41.5354 10.0207 41.4993 9.92249C41.4806 9.87275 41.4632 9.81804 41.4433 9.75587C41.4209 9.69494 41.3973 9.62531 41.3724 9.54448C41.3226 9.38532 41.2939 9.26222 41.2653 9.1615C41.2367 9.06078 41.2168 8.97872 41.1969 8.89665C41.177 8.81458 41.1595 8.73127 41.1272 8.63055C41.0923 8.53108 41.0475 8.41171 40.9828 8.25628C40.7015 7.64077 40.6505 7.66564 40.3219 7.07625C40.2348 6.93077 40.1763 6.81886 40.1315 6.72187C40.0854 6.62613 40.0493 6.54779 40.0157 6.46821C39.9821 6.38863 39.9473 6.30905 39.8975 6.2133C39.8465 6.1188 39.7755 6.01187 39.676 5.8726C39.2628 5.32797 39.1682 5.40382 38.7189 4.90023C38.4911 4.6503 38.389 4.51476 38.2882 4.3755C38.2385 4.30462 38.1874 4.23623 38.1152 4.15789C38.043 4.07956 37.9572 3.98506 37.8277 3.87563C37.6983 3.76621 37.6012 3.68539 37.5203 3.617C37.4382 3.55234 37.371 3.50011 37.305 3.44789C37.239 3.39442 37.1731 3.34344 37.0872 3.28375C37.0013 3.22531 36.9017 3.14573 36.7599 3.06118C36.4798 2.88088 36.3317 2.81622 36.1849 2.74037C36.0293 2.67447 35.8787 2.59738 35.5688 2.46433C35.4132 2.39842 35.2962 2.34869 35.1991 2.30765C35.1021 2.26662 35.0212 2.23926 34.9428 2.20818C34.8631 2.17834 34.7847 2.14849 34.6851 2.10995C34.5856 2.07264 34.4623 2.04031 34.3005 1.99182C33.6459 1.81525 33.6272 1.89732 32.9663 1.77795C32.2992 1.69464 32.3054 1.61381 31.6271 1.5877C31.2874 1.57651 31.1181 1.61257 30.9513 1.6449C30.8679 1.66231 30.7833 1.67474 30.68 1.69215C30.5755 1.7108 30.451 1.72821 30.283 1.74313C29.9482 1.7767 29.7864 1.83017 29.6233 1.86996C29.4628 1.92219 29.3022 1.96944 28.9761 2.04156C28.6525 2.12238 28.487 2.14725 28.3252 2.18828C28.1634 2.22807 27.9954 2.25419 27.683 2.3748C27.3669 2.48422 27.215 2.55759 27.0595 2.61727C26.9026 2.67571 26.752 2.75032 26.4508 2.89829C26.1546 3.05372 25.9978 3.11838 25.836 3.17433C25.6804 3.24148 25.5199 3.30489 25.2386 3.4939C24.966 3.69409 24.8254 3.78984 24.6997 3.90423C24.635 3.95894 24.5703 4.01365 24.4906 4.08204C24.4495 4.11562 24.4047 4.15292 24.3537 4.1952C24.3052 4.23996 24.2504 4.2897 24.1882 4.3469C24.0625 4.46005 23.9741 4.55082 23.9044 4.63165C23.8384 4.7162 23.7911 4.78708 23.7438 4.8592C23.6493 5.00219 23.5522 5.14021 23.3344 5.39512C23.1091 5.64256 22.9933 5.76442 22.8664 5.88006C22.8042 5.9385 22.7407 5.9957 22.6698 6.07404C22.6013 6.15486 22.5229 6.25558 22.4258 6.3936C22.3773 6.46323 22.335 6.52416 22.2976 6.57887C22.264 6.63607 22.2341 6.68581 22.2068 6.73182C22.1545 6.82383 22.1122 6.89844 22.0711 6.9718C22.0313 7.04641 21.9852 7.11853 21.9379 7.21303C21.8894 7.30753 21.8309 7.42068 21.7488 7.56865C21.7077 7.64202 21.6703 7.70668 21.638 7.76512C21.6081 7.82356 21.5795 7.87578 21.5546 7.92179C21.5023 8.01505 21.4575 8.08717 21.4127 8.16053C21.3679 8.2339 21.3206 8.30602 21.2721 8.40052C21.2248 8.49626 21.1713 8.61314 21.1065 8.77106C20.9709 9.08565 20.936 9.256 20.8887 9.42014C20.8427 9.58427 20.7966 9.74841 20.7045 10.0767C20.6572 10.2396 20.6162 10.3614 20.5801 10.4609C20.5465 10.5616 20.5191 10.6424 20.4917 10.7233C20.4631 10.8041 20.4357 10.8849 20.4046 10.9869C20.3735 11.0888 20.3386 11.2119 20.315 11.381C20.2042 12.0525 20.2801 12.0612 20.2291 12.7314C20.2092 13.4029 20.1893 13.4041 20.2316 14.0731C20.2714 14.4063 20.2826 14.573 20.3224 14.7359C20.3386 14.8179 20.3548 14.9 20.376 15.0019C20.3946 15.1052 20.4158 15.2283 20.4606 15.3887C20.5017 15.5503 20.5365 15.6709 20.5676 15.7704C20.6025 15.8686 20.6398 15.9445 20.6734 16.0216C20.7444 16.1733 20.8016 16.3287 20.931 16.6346C21.048 16.9454 21.1028 17.1021 21.1489 17.265C21.1737 17.3458 21.1949 17.4291 21.2335 17.5261C21.2758 17.6219 21.3318 17.735 21.414 17.8818C21.7612 18.4575 21.745 18.4687 22.147 19.012C22.4781 19.4112 22.3822 19.6263 22.0923 19.8849C21.8035 20.1423 21.5359 20.2381 21.1601 19.783C20.707 19.1712 20.7319 19.1538 20.3399 18.5047C20.2478 18.3381 20.1781 18.2138 20.1208 18.1106C20.0661 18.0049 20.0287 17.9178 19.9876 17.832C19.9092 17.6592 19.8209 17.4901 19.6852 17.1344C19.5383 16.7838 19.4662 16.6072 19.3815 16.4344C19.3404 16.3474 19.2969 16.2603 19.2546 16.1484C19.216 16.0352 19.1749 15.8972 19.1289 15.7107C19.1065 15.6174 19.0853 15.5366 19.0729 15.462C19.0617 15.3874 19.0542 15.3228 19.048 15.2631C19.0355 15.1437 19.0305 15.048 19.0268 14.951C19.0119 14.7595 19.0231 14.5667 18.9808 14.19C18.9322 13.4352 18.7617 13.4377 18.7841 12.6693C18.7841 12.4765 18.8115 12.3348 18.8215 12.2166C18.8364 12.0985 18.8476 12.0028 18.86 11.9083C18.8787 11.718 18.926 11.5327 18.9832 11.156C19.0094 10.967 19.0467 10.8302 19.0816 10.7158C19.1152 10.6014 19.145 10.5119 19.1749 10.4211C19.206 10.3316 19.2347 10.2408 19.2695 10.1289C19.3093 10.0182 19.3529 9.88394 19.4064 9.70364C19.4599 9.52334 19.4973 9.38781 19.5371 9.27714C19.5782 9.16772 19.6118 9.08068 19.6441 8.99239C19.7138 8.81831 19.7686 8.6405 19.9167 8.29607C19.9889 8.12323 20.0436 7.99391 20.0885 7.88573C20.1357 7.7788 20.1806 7.69673 20.2216 7.61217C20.2639 7.52886 20.305 7.44431 20.3573 7.33986C20.3834 7.28764 20.412 7.22919 20.4432 7.16329C20.478 7.09863 20.5178 7.02651 20.5626 6.94445C20.7419 6.61493 20.8402 6.45453 20.9522 6.30283C21.0057 6.22574 21.0592 6.14864 21.1252 6.05166C21.1576 6.00316 21.1924 5.94845 21.2335 5.88752C21.2758 5.82784 21.3231 5.76069 21.3779 5.6836C21.4837 5.52941 21.5633 5.41253 21.6305 5.31678C21.699 5.22228 21.755 5.14643 21.8097 5.06934C21.923 4.91888 22.0238 4.75972 22.2777 4.47995C22.4034 4.33944 22.493 4.23001 22.5739 4.14422C22.6548 4.05842 22.7195 3.99003 22.7843 3.92164C22.849 3.85325 22.9137 3.78486 22.9946 3.69906C23.0792 3.617 23.1838 3.52125 23.3244 3.39442C23.3941 3.33101 23.4551 3.27505 23.5086 3.22283C23.5634 3.17433 23.6119 3.13081 23.6555 3.08978C23.7414 3.00895 23.8086 2.93932 23.8745 2.87093C24.004 2.72918 24.1496 2.60484 24.4582 2.38102C24.7731 2.16714 24.9324 2.06145 25.088 1.9483C25.2498 1.84758 25.4079 1.73691 25.7464 1.5591C26.0899 1.38999 26.2629 1.30917 26.4434 1.24451C26.6238 1.17985 26.7968 1.10027 27.1578 0.974684C27.515 0.839149 27.7017 0.796872 27.8859 0.744647C28.0688 0.689936 28.2555 0.651389 28.6252 0.560618C28.9961 0.477307 29.1877 0.461143 29.3757 0.43503C29.5661 0.423839 29.754 0.400214 30.1311 0.361667C30.3203 0.345503 30.4609 0.330581 30.5792 0.318147C30.6974 0.304469 30.792 0.301982 30.8866 0.292035C31.0758 0.277113 31.2662 0.255975 31.6458 0.268409C31.7404 0.270896 31.8238 0.273383 31.8985 0.27587C31.9731 0.280844 32.0379 0.288304 32.0964 0.294521C32.2146 0.308199 32.3092 0.31939 32.4038 0.330581C32.5929 0.350476 32.7784 0.393997 33.1555 0.437517C33.9023 0.569322 33.906 0.556888 34.6403 0.753351C35.0062 0.856557 35.1892 0.907538 35.3734 0.958519C35.4655 0.984631 35.5588 1.00701 35.6721 1.04556C35.7841 1.08659 35.9173 1.13757 36.094 1.21094C36.272 1.28057 36.3952 1.35518 36.4997 1.41362C36.6031 1.4733 36.6839 1.52677 36.7636 1.579C36.8433 1.63246 36.9242 1.69464 37.0262 1.76054C37.1283 1.82644 37.2502 1.90478 37.412 2.01047C37.5776 2.10995 37.6971 2.18828 37.8053 2.24175C37.9136 2.29646 38.0045 2.33501 38.0916 2.37729C38.18 2.41832 38.2696 2.45935 38.3754 2.52028C38.4799 2.58245 38.5957 2.66825 38.7425 2.79135C38.8894 2.91445 38.9914 3.01517 39.0798 3.09475C39.1682 3.17558 39.2379 3.24023 39.3038 3.30862C39.4382 3.44416 39.5764 3.57472 39.8328 3.85574C40.1705 4.23374 40.492 4.6246 40.7973 5.0283C40.9081 5.18249 40.9915 5.29689 41.0612 5.39388C41.1272 5.49211 41.1794 5.57169 41.2317 5.65002C41.284 5.7296 41.3363 5.80794 41.401 5.90742C41.462 6.00938 41.5354 6.13124 41.6337 6.29413C41.8254 6.6224 41.8752 6.81264 41.9337 6.99418C41.981 7.18319 42.0357 7.36473 42.1876 7.70916C42.261 7.88324 42.3183 8.01256 42.3668 8.1195C42.4153 8.22768 42.4477 8.31596 42.485 8.403C42.5572 8.57833 42.6356 8.75117 42.7427 9.1155C42.7713 9.20627 42.7962 9.2846 42.8186 9.35548C42.8397 9.42635 42.8584 9.48977 42.8758 9.54573C42.9107 9.65888 42.9418 9.74965 42.9729 9.84042C43.0401 10.0207 43.0849 10.2072 43.1571 10.5828C43.2144 10.9608 43.2442 11.151 43.2778 11.34C43.2978 11.5303 43.3289 11.7217 43.3438 12.106C43.3438 12.4914 43.3077 12.6842 43.2442 12.8719C43.2156 12.9664 43.187 13.0597 43.1621 13.1778C43.1496 13.2363 43.1384 13.3009 43.1297 13.3743C43.1185 13.4476 43.1036 13.5297 43.0936 13.623C43.0712 13.8107 43.0588 13.9525 43.0513 14.0706C43.0401 14.1887 43.0314 14.2832 43.0227 14.3777C43.0028 14.5667 43.0015 14.762 42.902 15.1288C42.8547 15.3128 42.8223 15.4521 42.7974 15.569C42.7651 15.6834 42.7427 15.7754 42.719 15.8674C42.668 16.0502 42.6369 16.2429 42.49 16.5936C42.4178 16.7701 42.3643 16.9019 42.3195 17.0113C42.2722 17.1208 42.2249 17.2028 42.1838 17.2874C42.1415 17.3719 42.098 17.4565 42.0444 17.5622C41.9909 17.6679 41.9324 17.7972 41.8378 17.9613C41.6536 18.2909 41.5852 18.4687 41.5005 18.6378C41.4159 18.8069 41.3313 18.9772 41.1284 19.2956C40.9056 19.6126 40.7625 19.7519 40.6107 19.8775C40.536 19.9409 40.4613 20.0056 40.3754 20.0901C40.2858 20.1722 40.1825 20.2717 40.0543 20.4146C39.9249 20.5564 39.8241 20.6571 39.7457 20.7479C39.6673 20.8387 39.6038 20.9108 39.5378 20.9817C39.4731 21.0525 39.4084 21.1247 39.3237 21.2104C39.2379 21.295 39.1283 21.3883 38.9802 21.5101C38.8321 21.632 38.7164 21.7165 38.6255 21.7961C38.5347 21.8744 38.4625 21.9379 38.3878 22C38.3144 22.0622 38.2397 22.1244 38.1451 22.1977C38.0493 22.2711 37.9273 22.347 37.7643 22.4477C37.6012 22.5484 37.4718 22.6131 37.3685 22.6727C37.2639 22.7324 37.1805 22.7784 37.0947 22.8207C36.9242 22.909 36.7561 22.9985 36.4064 23.1515C36.2334 23.2323 36.0977 23.2795 35.9882 23.3255C35.8774 23.3703 35.7891 23.4064 35.6995 23.4375C35.5202 23.5021 35.3423 23.5705 34.9801 23.6824C34.7996 23.7433 34.659 23.767 34.542 23.7881C34.425 23.808 34.3292 23.8167 34.2321 23.8204C34.0404 23.8304 33.85 23.8441 33.4828 23.9174C33.2999 23.9585 33.1592 23.9746 33.0447 23.9933C32.929 24.0107 32.8356 24.0231 32.7423 24.0306C32.5556 24.0492 32.3702 24.0691 31.998 24.1077C31.6259 24.1412 31.4392 24.1686 31.2525 24.1885C31.1592 24.1984 31.0658 24.2096 30.9488 24.2196C30.8318 24.2258 30.69 24.2308 30.502 24.2333C30.1249 24.232 29.9357 24.2308 29.7478 24.2308C29.5586 24.2308 29.3682 24.2283 28.9911 24.1885C28.6127 24.1462 28.4273 24.0927 28.2431 24.0443C28.0589 23.9883 27.8747 23.9423 27.5038 23.8503C26.93 23.6998 27.0557 23.4561 27.1677 23.088C27.281 22.715 27.3208 22.4539 27.8162 22.5845V22.5869Z",
                    fill: "hsl(var(--text-100))",
                }),
                a.jsx("path", {
                    d: "M35.5078 17.1108C34.9813 16.6607 35.0448 16.5873 34.5183 16.136C33.9919 15.6846 34.0143 15.6597 33.4878 15.2084C32.9614 14.757 32.8966 14.8328 32.3702 14.3815C31.8437 13.9301 31.8163 13.9612 31.2899 13.5111C30.7634 13.0597 30.8617 12.9453 30.3352 12.4939C29.8088 12.0426 29.7777 12.0799 29.2512 11.6285C28.7247 11.1771 28.7135 11.1896 28.1871 10.7382C27.6594 10.2868 27.6992 10.2408 27.1715 9.78944C26.6438 9.33807 26.6039 9.38532 26.0762 8.93395C25.6867 8.60071 25.8173 8.34207 26.0538 8.06727C26.2903 7.79247 26.4932 7.66067 26.8827 7.99515C27.4092 8.44528 27.4901 8.35202 28.0166 8.80215C28.543 9.25352 28.4522 9.35921 28.9786 9.80934C29.5051 10.2607 29.4889 10.2794 30.0154 10.7295C30.5418 11.1809 30.6414 11.0652 31.1679 11.5166C31.6943 11.968 31.6197 12.0537 32.1474 12.5051C32.6738 12.9565 32.6664 12.9652 33.1928 13.4153C33.7193 13.8667 33.7305 13.8543 34.257 14.3056C34.7847 14.757 34.8531 14.6774 35.3796 15.1288C35.9073 15.5801 35.9272 15.5578 36.4537 16.0091C36.8433 16.3424 36.5794 16.6023 36.3429 16.8771C36.1065 17.1519 35.8986 17.4428 35.5103 17.1096L35.5078 17.1108Z",
                    fill: "hsl(var(--text-100))",
                }),
                a.jsx("path", {
                    d: "M26.5044 16.7216C26.9624 16.2019 27.0346 16.2653 27.4913 15.7443C27.9493 15.2233 27.9742 15.2457 28.4323 14.7259C28.8903 14.2049 28.8156 14.1402 29.2724 13.6192C29.7304 13.0982 29.6993 13.0721 30.1573 12.5511C30.6153 12.0301 30.7285 12.1296 31.1866 11.6086C31.6446 11.0876 31.6085 11.0565 32.0652 10.5367C32.5233 10.0157 32.5108 10.0046 32.9688 9.48355C33.4268 8.96255 33.4729 9.00234 33.9309 8.48134C34.3889 7.96034 34.3416 7.91806 34.7996 7.39706C35.1382 7.01159 35.3945 7.14588 35.6671 7.38462C35.9397 7.62337 36.0679 7.82853 35.7293 8.21276C35.2713 8.73252 35.3647 8.81458 34.9079 9.33558C34.4499 9.85659 34.3453 9.76457 33.8873 10.2843C33.4293 10.8053 33.4107 10.7892 32.9539 11.3089C32.4959 11.8299 32.6104 11.9294 32.1524 12.4504C31.6943 12.9714 31.6085 12.8956 31.1505 13.4166C30.6924 13.9376 30.6837 13.9289 30.227 14.4499C29.769 14.9709 29.7814 14.9821 29.3234 15.5018C28.8654 16.0228 28.9438 16.0924 28.4858 16.6134C28.0278 17.1345 28.0502 17.1543 27.5921 17.6766C27.2536 18.0621 26.9972 17.7947 26.7247 17.556C26.4521 17.3172 26.1646 17.1059 26.5031 16.7204L26.5044 16.7216Z",
                    fill: "hsl(var(--text-100))",
                }),
            ],
        }),
    vy = ({ isOpen: e, onClose: t, onConfirm: n }) => {
        if (!e) return null;
        return a.jsx("div", {
            className:
                "w-full h-screen bg-bg-100 flex items-center justify-center p-5 absolute inset-0 z-50",
            children: a.jsxs("div", {
                className: "max-w-[520px] w-full",
                children: [
                    a.jsx("div", {
                        className: "flex justify-start mb-4",
                        children: a.jsx(xy, {}),
                    }),
                    a.jsx("h2", {
                        className:
                            "text-text-100 font-styrene font-medium text-[20px] leading-[140%] mb-4",
                        style: { letterSpacing: "-0.6px" },
                        children: "Skip all permissions across the internet?",
                    }),
                    a.jsxs("div", {
                        className:
                            "bg-danger-900 border-[0.5px] border-danger-200 rounded-lg p-4 mb-4",
                        children: [
                            a.jsxs("h3", {
                                className:
                                    "text-[14px] font-styrene font-medium text-danger-000 leading-[140%] mb-2.5 flex items-center gap-1",
                                children: [
                                    a.jsx(ji, {
                                        size: 16,
                                        className: "text-danger-000",
                                    }),
                                    "WARNING",
                                ],
                            }),
                            a.jsxs("ul", {
                                className:
                                    "text-[14px] font-styrene font-normal text-danger-000 leading-[140%] ml-4 list-disc space-y-2",
                                children: [
                                    a.jsx("li", {
                                        style: { letterSpacing: "-0.36px" },
                                        children:
                                            "This allows Claude to take any action on the internet.",
                                    }),
                                    a.jsx("li", {
                                        style: { letterSpacing: "-0.36px" },
                                        children:
                                            "This mode puts your data and the data of others at risk from malicious code.",
                                    }),
                                    a.jsx("li", {
                                        style: { letterSpacing: "-0.36px" },
                                        children:
                                            "You should oversee Claude when it is in this mode. You are fully responsible for all risks associated with permission-less Claude.",
                                    }),
                                    a.jsxs("li", {
                                        style: { letterSpacing: "-0.36px" },
                                        children: [
                                            "Review",
                                            " ",
                                            a.jsx("button", {
                                                onClick: () =>
                                                    chrome.tabs.create({
                                                        url: cy,
                                                    }),
                                                className:
                                                    "text-danger-000 underline hover:no-underline focus:outline-none",
                                                children: "risks",
                                            }),
                                            " ",
                                            "before you begin.",
                                        ],
                                    }),
                                ],
                            }),
                        ],
                    }),
                    a.jsxs("div", {
                        className: "flex justify-end gap-3",
                        children: [
                            a.jsx("button", {
                                onClick: t,
                                className:
                                    "px-[14px] py-2 border border-border-300 text-text-200 rounded-[14px] hover:bg-bg-200 transition-colors font-styrene font-medium text-[14px]",
                                children: "Cancel",
                            }),
                            a.jsx("button", {
                                onClick: async () => {
                                    await n(), t();
                                },
                                className:
                                    "px-[14px] py-2 bg-text-100 text-bg-100 rounded-[14px] hover:bg-text-200 transition-colors font-styrene font-medium text-[14px]",
                                children: "Skip permissions",
                            }),
                        ],
                    }),
                ],
            }),
        });
    },
    Cy = [
        { value: "ui_bug", label: "UI bug" },
        { value: "incorrect_assumptions", label: "Made incorrect assumptions" },
        { value: "incomplete_request", label: "Incomplete request" },
        { value: "too_much_input", label: "Asked for too much input" },
        { value: "ui_misunderstanding", label: "Didn't understand the UI" },
        {
            value: "unauthorized_action",
            label: "Did something it shouldn't have done",
        },
        {
            value: "navigation_error",
            label: "Navigation, clicking, typing, scrolling error",
        },
        { value: "other", label: "Other" },
    ],
    wy = ({ onClose: e, onSubmit: t, feedbackType: n, message: o }) => {
        const [i, s] = r.useState(""),
            [l, c] = r.useState(""),
            [u, d] = r.useState(!1);
        return a.jsxs("div", {
            className: "bg-bg-000 rounded-[14px]",
            children: [
                a.jsxs("div", {
                    className:
                        "flex items-center justify-between py-[10px] px-4",
                    children: [
                        a.jsxs("div", {
                            className: "flex items-center gap-2",
                            children: [
                                "positive" === n
                                    ? a.jsx(Mi, {
                                          size: 20,
                                          className: "text-text-100",
                                      })
                                    : a.jsx(Ti, {
                                          size: 20,
                                          className: "text-text-100",
                                      }),
                                a.jsxs("h3", {
                                    className:
                                        "font-styrene text-[14px] font-normal leading-[140%] text-text-100",
                                    children: ["Share ", n, " feedback"],
                                }),
                            ],
                        }),
                        a.jsx("button", {
                            onClick: e,
                            className:
                                "p-1 text-text-300 hover:bg-bg-100 rounded transition-colors",
                            "aria-label": "Close",
                            children: a.jsx(g, { size: 16 }),
                        }),
                    ],
                }),
                a.jsx("div", { className: "border-t border-border-300 mb-4" }),
                a.jsxs("div", {
                    className: "space-y-4 px-4",
                    children: [
                        "negative" === n &&
                            a.jsxs(a.Fragment, {
                                children: [
                                    a.jsxs("div", {
                                        children: [
                                            a.jsx("p", {
                                                className:
                                                    "font-base-bold text-text-100 mb-2",
                                                children:
                                                    "What type of issue do you wish to report? (optional)",
                                            }),
                                            a.jsxs("div", {
                                                className: "relative",
                                                children: [
                                                    a.jsxs("select", {
                                                        value: i,
                                                        onChange: (e) =>
                                                            s(e.target.value),
                                                        className:
                                                            "w-full h-10 px-3 bg-bg-100 border border-border-200 rounded-lg text-text-100 text-sm font-normal font-styrene leading-tight focus:outline-none focus:ring-2 focus:ring-accent-main-200 focus:border-transparent appearance-none",
                                                        children: [
                                                            a.jsx("option", {
                                                                value: "",
                                                                children:
                                                                    "Select",
                                                            }),
                                                            Cy.map((e) =>
                                                                a.jsx(
                                                                    "option",
                                                                    {
                                                                        value: e.value,
                                                                        children:
                                                                            e.label,
                                                                    },
                                                                    e.value
                                                                )
                                                            ),
                                                        ],
                                                    }),
                                                    a.jsx(Ii, {
                                                        className:
                                                            "absolute right-3 top-3 w-4 h-4 text-text-300 pointer-events-none",
                                                    }),
                                                ],
                                            }),
                                        ],
                                    }),
                                    a.jsxs("div", {
                                        children: [
                                            a.jsx("p", {
                                                className:
                                                    "font-base-bold text-text-100 mb-2",
                                                children:
                                                    "Please provide details: (optional)",
                                            }),
                                            a.jsx("textarea", {
                                                value: l,
                                                onChange: (e) =>
                                                    c(e.target.value),
                                                placeholder:
                                                    "What was unsatisfying about this response?",
                                                className:
                                                    "w-full h-28 p-3 bg-bg-100 border border-border-200 rounded-lg text-text-100 placeholder-text-400 text-sm font-normal font-styrene leading-tight resize-none focus:outline-none focus:ring-2 focus:ring-accent-main-200 focus:border-transparent",
                                            }),
                                        ],
                                    }),
                                ],
                            }),
                        "positive" === n &&
                            a.jsx(a.Fragment, {
                                children: a.jsxs("div", {
                                    children: [
                                        a.jsx("p", {
                                            className:
                                                "font-base-bold text-text-100 mb-2",
                                            children:
                                                "Please provide details: (optional)",
                                        }),
                                        a.jsx("textarea", {
                                            value: l,
                                            onChange: (e) => c(e.target.value),
                                            placeholder:
                                                "What was satisfying about this response?",
                                            className:
                                                "w-full h-28 p-3 bg-bg-100 border border-border-200 rounded-lg text-text-100 placeholder-text-400 text-sm font-normal font-styrene leading-tight resize-none focus:outline-none focus:ring-2 focus:ring-accent-main-200 focus:border-transparent",
                                        }),
                                    ],
                                }),
                            }),
                        a.jsx("div", {
                            className: "text-text-300",
                            children: a.jsxs("p", {
                                className: "text-xs font-small font-styrene",
                                children: [
                                    "Submitting this report will send the entire current conversation to Anthropic for future improvements to our models.",
                                    " ",
                                    a.jsx("a", {
                                        href: "https://privacy.anthropic.com/en/articles/10023548-how-long-do-you-store-my-data",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className:
                                            "underline cursor-pointer hover:text-text-200",
                                        children: "Learn more",
                                    }),
                                ],
                            }),
                        }),
                    ],
                }),
                a.jsx("div", {
                    className: "px-3 py-[10px] space-y-[5px] mt-[10px] mb-0.5",
                    children: a.jsxs("div", {
                        className: "flex justify-end gap-2",
                        children: [
                            a.jsx("button", {
                                onClick: e,
                                className:
                                    "h-8 min-w-20 px-3.5 py-[3px] rounded-lg outline outline-[0.50px] outline-offset-[-0.50px] outline-border-200/30 flex justify-center items-center gap-2 overflow-hidden hover:bg-bg-100 transition-colors",
                                children: a.jsx("div", {
                                    className:
                                        "flex-1 text-center justify-start text-text-100 text-sm font-medium font-styrene leading-tight",
                                    children: "Cancel",
                                }),
                            }),
                            a.jsx("button", {
                                onClick: () => {
                                    d(!0);
                                    try {
                                        if (!o?.id) return;
                                        t({
                                            thumbs: n,
                                            type: i,
                                            message: l,
                                            messageId: o.id,
                                        });
                                    } finally {
                                        d(!1), e();
                                    }
                                },
                                className:
                                    "h-8 min-w-20 px-3.5 py-[3px] bg-text-100 rounded-lg flex justify-center items-center gap-2 overflow-hidden hover:bg-text-200 transition-colors",
                                children: a.jsx("div", {
                                    className:
                                        "flex-1 text-center justify-start text-bg-100 text-sm font-medium font-styrene leading-tight",
                                    children: u ? "Submitting..." : "Submit",
                                }),
                            }),
                        ],
                    }),
                }),
            ],
        });
    },
    by = ({
        strokeColor: e,
        strokeWidth: t = 2,
        dashLength: n = 10,
        gapLength: o = 10,
        borderRadius: i = 16,
    }) => {
        const s = r.useRef(null),
            [l, c] = r.useState({ width: 0, height: 0 });
        r.useEffect(() => {
            const e = () => {
                if (s.current) {
                    const e = s.current.getBoundingClientRect();
                    c({ width: e.width, height: e.height });
                }
            };
            return (
                e(),
                window.addEventListener("resize", e),
                () => window.removeEventListener("resize", e)
            );
        }, []);
        const { width: u, height: d } = l,
            h = Math.min(i, Math.min(u, d) / 2),
            p = 2 * (u + d - 4 * h) + 2 * Math.PI * h,
            f = n + o,
            m = p / Math.round(p / f),
            g = (n / f) * m,
            y = m - g;
        return a.jsx("div", {
            ref: s,
            className: "absolute inset-0 pointer-events-none",
            style: { zIndex: 41 },
            children:
                l.width > 0 &&
                l.height > 0 &&
                a.jsx("svg", {
                    width: l.width,
                    height: l.height,
                    style: { position: "absolute", top: 0, left: 0 },
                    children: a.jsx("rect", {
                        x: t / 2,
                        y: t / 2,
                        width: l.width - t,
                        height: l.height - t,
                        rx: h,
                        ry: h,
                        fill: "none",
                        stroke: e,
                        strokeWidth: t,
                        strokeDasharray: `${g} ${y}`,
                        strokeDashoffset: g / 2,
                        pathLength: p,
                    }),
                }),
        });
    },
    ky = ({ isActive: e }) =>
        e
            ? a.jsxs(a.Fragment, {
                  children: [
                      a.jsx("div", {
                          className:
                              "absolute inset-0 pointer-events-none z-40",
                          style: {
                              border: "2px solid #F7CE46",
                              borderRadius: "16px",
                              boxSizing: "border-box",
                          },
                      }),
                      a.jsx(by, {
                          strokeColor: "#31290E",
                          strokeWidth: 2,
                          dashLength: 9,
                          gapLength: 9,
                          borderRadius: 16,
                      }),
                  ],
              })
            : null;
function Ey({ domainConfig: e, onPromptClick: t }) {
    return a.jsxs("div", {
        className: "flex flex-col items-center justify-center h-full px-4 py-8",
        children: [
            a.jsx("div", {
                className:
                    "w-12 h-12 rounded-xl border-[0.5px] border-border-300 bg-bg-000 shadow-sm mb-4 overflow-hidden",
                children: a.jsx("img", {
                    src: e.logo_url,
                    alt: "",
                    className: "w-full h-full object-cover",
                }),
            }),
            a.jsx("h2", {
                className: "font-ui-sm text-text-500 mb-[22px]",
                children: e.header_text,
            }),
            a.jsx("div", {
                className: "flex flex-col items-center gap-2 w-full max-w-sm",
                children: e.prompts.map((e, n) =>
                    a.jsx(
                        "button",
                        {
                            onClick: () => t(e.prompt),
                            className:
                                "min-w-[75px] h-8 px-[14px] py-[3px] font-base text-text-100 border-[0.5px] border-border-300 bg-white/30 hover:bg-bg-200 transition-colors text-center",
                            style: { borderRadius: "38px" },
                            children: e.prompt_title,
                        },
                        n
                    )
                ),
            }),
        ],
    });
}
async function Sy() {
    try {
        if (!chrome.action || !chrome.action.getUserSettings) return !1;
        return (await chrome.action.getUserSettings()).isOnToolbar ?? !1;
    } catch (e) {
        return !1;
    }
}
function Ay({ lightImage: e, darkImage: t, title: n, subtitle: r }) {
    const o = hy();
    return a.jsxs("div", {
        className: "flex flex-col items-center",
        children: [
            a.jsx("img", {
                src: o ? t : e,
                alt: n,
                className: "w-[188px] h-[122px] rounded-[14px]",
            }),
            a.jsxs("div", {
                className: "mt-4 flex flex-col items-center gap-1 w-[188px]",
                children: [
                    a.jsx("p", {
                        className:
                            "text-text-300 text-center font-styrene text-xs font-medium leading-[140%] tracking-[-0.24px]",
                        children: n,
                    }),
                    a.jsx("p", {
                        className:
                            "text-text-500 text-center font-styrene text-xs font-normal leading-[140%] tracking-[-0.24px]",
                        children: r,
                    }),
                ],
            }),
        ],
    });
}
const Ty = () =>
    a.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "22",
        height: "21",
        viewBox: "0 0 22 21",
        fill: "none",
        children: a.jsx("path", {
            d: "M0.917459 19.4057C0.589239 19.4513 0.360118 19.7543 0.405705 20.0825C0.451291 20.4108 0.754321 20.6399 1.08254 20.5943L1 20L0.917459 19.4057ZM19 0L14.836 5.53725L21.7134 6.37475L19 0ZM1 20L1.08254 20.5943C6.35588 19.8619 16.2596 15.8487 18.9284 5.50894L18.3474 5.35899L17.7664 5.20904C15.2735 14.8674 5.96892 18.7041 0.917459 19.4057L1 20Z",
            className: "fill-text-300",
        }),
    });
function Ly() {
    const [e, t] = r.useState(!0);
    return (
        r.useEffect(() => {
            const e = (e) => {
                e[A.SKIP_ALL_PERMISSIONS_CLICKED] &&
                    !0 === e[A.SKIP_ALL_PERMISSIONS_CLICKED].newValue &&
                    t(!1);
            };
            return (
                chrome.storage.local.onChanged.addListener(e),
                () => {
                    chrome.storage.local.onChanged.removeListener(e);
                }
            );
        }, []),
        e
            ? a.jsx("div", {
                  className: "relative h-full",
                  children: a.jsxs("div", {
                      className:
                          "absolute top-0 right-2.5 flex flex-col items-end",
                      children: [
                          a.jsx(Ty, {}),
                          a.jsxs("div", {
                              className: "w-[145px] -mt-0.5",
                              children: [
                                  a.jsx("p", {
                                      className:
                                          "text-text-300 font-styrene text-xs font-bold leading-[140%] tracking-[-0.24px] mb-1",
                                      children: "Skip all permissions",
                                  }),
                                  a.jsxs("p", {
                                      className:
                                          "text-text-300 font-styrene text-xs font-normal leading-[140%] tracking-[-0.24px]",
                                      children: [
                                          "Allow Claude to take any actions on the internet.",
                                          " ",
                                          a.jsx("button", {
                                              onClick: () =>
                                                  chrome.tabs.create({
                                                      url: cy,
                                                  }),
                                              className:
                                                  "underline hover:no-underline focus:outline-none",
                                              children: "Review risks",
                                          }),
                                          " ",
                                          "first.",
                                      ],
                                  }),
                              ],
                          }),
                      ],
                  }),
              })
            : null
    );
}
const My = {
        pin_extension: { maxDisplays: 1, requiresGate: !1 },
        skip_permissions: {
            maxDisplays: 1,
            requiresGate: !0,
            gateName: "crochet_can_see_skip_permissions_tip",
        },
    },
    Py = (e, t) => {
        const [n, o] = r.useState(!1),
            [i, s] = r.useState(!1);
        r.useEffect(() => {
            (async () => {
                if (t)
                    try {
                        const n = My[e],
                            r =
                                ((await S(A.TIP_DISPLAY_COUNTS)) || {})[e] ||
                                [],
                            i = r.includes(String(t)),
                            a = r.length >= n.maxDisplays;
                        s(a), o(!i && !a);
                    } catch (n) {
                        o(!1), s(!1);
                    }
                else o(!1);
            })();
        }, [e, t]);
        return {
            canShow: n,
            limitReached: i,
            markAsShown: r.useCallback(async () => {
                if (t)
                    try {
                        const n = (await S(A.TIP_DISPLAY_COUNTS)) || {},
                            r = n[e] || [];
                        r.includes(String(t)) ||
                            (r.push(String(t)),
                            (n[e] = r),
                            await L(A.TIP_DISPLAY_COUNTS, n));
                    } catch (n) {}
            }, [e, t]),
        };
    },
    jy = ({ children: e, onMount: t }) => (
        r.useEffect(() => {
            t();
        }, [t]),
        a.jsx(a.Fragment, { children: e })
    );
function Ny({
    tabId: e,
    onPromptClick: t,
    shouldDisableSkipPermissions: o = !1,
}) {
    const [i, s] = r.useState(""),
        [l, c] = r.useState(null),
        [u, d] = r.useState(!0),
        h = (() => {
            const { value: e } = n.useDynamicConfig("crochet_chips");
            return e || {};
        })(),
        { value: p } = n.useFeatureGate("crochet_can_see_skip_permissions_tip"),
        f = Py("pin_extension", e),
        m = Py("skip_permissions", e);
    r.useEffect(() => {
        (async () => {
            const [e, t] = await Promise.all([
                Sy(),
                S(A.SKIP_ALL_PERMISSIONS_CLICKED),
            ]);
            c(e), d(t ?? !1);
        })();
    }, []),
        r.useEffect(() => {
            const t = (e) => {
                if (e.url)
                    try {
                        const t = new URL(e.url).hostname.replace(/^www\./, "");
                        s(t);
                    } catch (t) {
                        s("");
                    }
                else s("");
            };
            e &&
                chrome.tabs
                    .get(e)
                    .then(t)
                    .catch((e) => {
                        s("");
                    });
            const n = (n, r, o) => {
                n === e && r.url && t(o);
            };
            return (
                chrome.tabs.onUpdated.addListener(n),
                () => {
                    chrome.tabs.onUpdated.removeListener(n);
                }
            );
        }, [e]);
    const g = h[i];
    return g
        ? a.jsx(Ey, { domainConfig: g, onPromptClick: t })
        : null === l
        ? null
        : !l && f.canShow
        ? a.jsx(jy, {
              onMount: f.markAsShown,
              children: a.jsx("div", {
                  className: "flex flex-col items-center justify-center h-full",
                  children: a.jsx(Ay, {
                      lightImage: "/assets/extension-light-min-CwWd0kAK.svg",
                      darkImage: "/assets/extension-dark-min-Ctxo0Z8w.svg",
                      title: "Pin Claude for quick access",
                      subtitle:
                          "Click the pin icon in the top right corner of the extension window",
                  }),
              }),
          })
        : p && !u && m.canShow && !o
        ? a.jsx(jy, { onMount: m.markAsShown, children: a.jsx(Ly, {}) })
        : null;
}
function Iy() {
    const [i, s] = r.useState(""),
        [l, c] = r.useState(!1),
        [u, d] = r.useState("negative"),
        [h, f] = r.useState(null),
        [m, g] = r.useState(new Map()),
        {
            anthropicApiKey: C,
            authToken: w,
            needsOAuth: b,
            isLoading: k,
            refreshTokenIfNeeded: E,
        } = y(),
        [T, M] = r.useState("claude-sonnet-4-20250514"),
        [P, j] = r.useState(() => crypto.randomUUID()),
        [N, D] = r.useState(null),
        [V, R] = r.useState(!0),
        [_, O] = r.useState(!1),
        [H, F] = r.useState(!1),
        [B, U] = r.useState(!1),
        [Z, z] = r.useState(!1),
        [$, W] = r.useState(void 0),
        [q, K] = r.useState(void 0),
        [Y, X] = r.useState(!1),
        [G, Q] = r.useState(null),
        [ee, re] = r.useState(null),
        oe = r.useRef(null),
        ie = r.useRef(null),
        se = r.useRef(null),
        ae = r.useRef(null),
        { value: le } = n.useFeatureGate("crochet_can_skip_permissions"),
        { value: ce } = n.useFeatureGate(
            "chrome_ext_domain_transition_prompts"
        ),
        { value: ue } = n.useFeatureGate("crochet_can_submit_feedback"),
        { value: de } = n.useFeatureGate("crochet_can_see_browser_indicator"),
        { analytics: he } = o(),
        pe = chrome.runtime.getURL("blocked.html"),
        [fe, me] = r.useState(!1),
        ge = "category0" !== G && null !== G,
        ye = "category1" === G || "category2" === G || fe,
        xe = "category3" === G;
    e.setForcePrompt(xe),
        r.useEffect(() => {
            !(async function () {
                const e = new URLSearchParams(window.location.search),
                    t = e.get("tabId");
                let n;
                if (t) n = parseInt(t);
                else if ("window" === e.get("mode")) {
                    const e = await S(A.TARGET_TAB_ID);
                    e && (n = e);
                }
                if ((W(n), n))
                    try {
                        const e = await chrome.tabs.get(n);
                        if (e.url) {
                            const t = await I.getCategory(e.url);
                            Q(t || null), me(e.url.startsWith(pe));
                            try {
                                const t = new URL(e.url);
                                K(t.hostname);
                            } catch (r) {
                                K(void 0);
                            }
                        }
                    } catch (r) {}
            })();
        }, [pe]);
    const ve = te();
    r.useEffect(() => {
        S(A.BROWSER_CONTROL_PERMISSION_ACCEPTED).then((e) => {
            X(!0 === e);
        });
    }, []),
        r.useEffect(() => {
            e.setCanSkipPermissions(le);
        }, [le]),
        r.useEffect(() => {
            fy().then((e) => {
                ge ? (F(!1), my(!1)) : F(e);
            });
            return (function (e) {
                const t = (t) => {
                    t[A.SKIP_ALL_PERMISSIONS] &&
                        e(!0 === t[A.SKIP_ALL_PERMISSIONS].newValue);
                };
                return (
                    chrome.storage.onChanged.addListener(t),
                    () => chrome.storage.onChanged.removeListener(t)
                );
            })((e) => {
                ge ? (F(!1), my(!1)) : F(e);
            });
        }, [ge]);
    const {
        messages: Ce,
        sendMessage: we,
        cancel: be,
        clearMessages: ke,
        isLoading: Ee,
        error: Se,
    } = J_useChat({
        apiKey: C,
        authToken: w,
        refreshTokenIfNeeded: E,
        model: T,
        sessionId: P,
        tabId: $,
        currentDomain: q,
        skipAllPermissions: H,
        onPermissionRequired: async (e) => {
            D(e);
            try {
                const t = e.url ? new URL(e.url).hostname : "this page";
                chrome.runtime.sendMessage(
                    {
                        type: "SHOW_PERMISSION_NOTIFICATION",
                        action: "browser_automation",
                        domain: t,
                    },
                    () => {
                        chrome.runtime.lastError;
                    }
                );
            } catch (t) {}
            return new Promise((e) => {
                oe.current = e;
            });
        },
    });
    r.useEffect(() => {
        if (!de) return;
        if (!$) return;
        const n = (e, t) => {
                if (e === $) {
                    if (t.url)
                        try {
                            const e = new URL(t.url);
                            K(e.hostname);
                        } catch (n) {
                            K(void 0);
                        }
                    "complete" === t.status &&
                        Ee &&
                        de &&
                        chrome.tabs
                            .sendMessage($, { type: "SHOW_AGENT_INDICATORS" })
                            .catch((e) => {});
                }
            },
            r = async (n) => {
                if (0 === n.frameId && n.tabId === $)
                    try {
                        let o = n.url,
                            i = new URL(n.url).hostname;
                        const s = await I.getCategory(n.url);
                        if ((Q(s || null), "category1" === s)) {
                            const e = chrome.runtime.getURL(
                                `blocked.html?url=${encodeURIComponent(n.url)}`
                            );
                            chrome.tabs.update($, { url: e }),
                                (o = e),
                                (i = new URL(o).hostname);
                        }
                        me(o.startsWith(pe));
                        const a = (await chrome.tabs.get($)).url;
                        if (a)
                            try {
                                const n = new URL(a).hostname;
                                if (n !== i && Ee && ce) {
                                    if (
                                        (await e.checkDomainTransition(n, i))
                                            .needsPrompt
                                    ) {
                                        be();
                                        const e = {
                                            type: "permission_required",
                                            tool: t.DOMAIN_TRANSITION,
                                            url: o,
                                            toolUseId: crypto.randomUUID(),
                                            actionData: {
                                                fromDomain: n,
                                                toDomain: i,
                                            },
                                        };
                                        D(e);
                                        (await new Promise((e) => {
                                            oe.current = e;
                                        })) && z(!0);
                                    }
                                }
                            } catch (r) {}
                    } catch (r) {}
            };
        return (
            (async () => {
                if (Ee)
                    setTimeout(async () => {
                        try {
                            await chrome.tabs.sendMessage($, {
                                type: "SHOW_AGENT_INDICATORS",
                            });
                        } catch (e) {}
                    }, 300);
                else
                    try {
                        await chrome.tabs.sendMessage($, {
                            type: "HIDE_AGENT_INDICATORS",
                        });
                    } catch (e) {}
            })(),
            chrome.tabs.onUpdated.addListener(n),
            chrome.webNavigation.onBeforeNavigate.addListener(r),
            () => {
                chrome.tabs.onUpdated.removeListener(n),
                    chrome.webNavigation.onBeforeNavigate.removeListener(r);
            }
        );
    }, [$, Ee, de, he, ce, be, pe]);
    const Ae = r.useCallback(() => {
        V && ie.current?.scrollIntoView({ behavior: "smooth" });
    }, [V]);
    r.useEffect(() => {
        "window" === new URLSearchParams(window.location.search).get("mode") &&
            chrome.windows.getCurrent((e) => {
                chrome.runtime.sendMessage({
                    type: "resize_window",
                    windowId: e.id,
                });
            });
    }, []),
        r.useEffect(() => {
            const e = (e) => {
                    if (e.selectedModel?.newValue) {
                        M(e.selectedModel.newValue), ke();
                        const t = crypto.randomUUID();
                        j(t), g(new Map());
                    }
                },
                t = () => {
                    "hidden" === document.visibilityState &&
                        ($ &&
                            de &&
                            chrome.tabs
                                .sendMessage($, {
                                    type: "HIDE_AGENT_INDICATORS",
                                })
                                .catch((e) => {}),
                        chrome.runtime.sendMessage({
                            type: "side_panel_closed",
                            tabId: $,
                        }));
                };
            return (
                chrome.storage.onChanged.addListener(e),
                document.addEventListener("visibilitychange", t),
                (async () => {
                    try {
                        const e =
                            (await S(A.SELECTED_MODEL)) ||
                            "claude-sonnet-4-20250514";
                        e && M(e);
                    } catch (e) {}
                })(),
                () => {
                    chrome.storage.onChanged.removeListener(e),
                        document.removeEventListener("visibilitychange", t);
                }
            );
        }, [ke, $, de]);
    const Te =
        Ce.length > 0
            ? (() => {
                  const e = Ce[Ce.length - 1];
                  return "string" == typeof e.content
                      ? e.content
                      : Array.isArray(e.content)
                      ? e.content
                            .filter((e) => "text" === e.type)
                            .map((e) => e.text)
                            .join("")
                      : "";
              })()
            : "";
    r.useEffect(() => {
        Ae();
    }, [Ce.length, Te, Ee, N, Ae]),
        r.useEffect(() => {
            const e = se.current;
            if (!e) return;
            const t = () => {
                const { scrollTop: t, scrollHeight: n, clientHeight: r } = e,
                    o = n - t - r < 100;
                O(t > 10), !o && V ? R(!1) : o && !V && R(!0);
            };
            return (
                e.addEventListener("scroll", t, { passive: !0 }),
                () => e.removeEventListener("scroll", t)
            );
        }, [V, k, ve.isBlocked, b, Y]),
        r.useEffect(() => {
            !i && ae.current && (ae.current.style.height = "auto");
        }, [i]),
        r.useEffect(() => {
            ee &&
                ae.current &&
                ((ae.current.style.height = "auto"),
                (ae.current.style.height = `${ae.current.scrollHeight}px`));
        }, [ee]),
        r.useEffect(() => {
            const e = (e) => {
                "Escape" === e.key && Ee && be();
            };
            return (
                document.addEventListener("keydown", e),
                () => document.removeEventListener("keydown", e)
            );
        }, [Ee, be]);
    const handleClickSend = async () => {
            if (i.trim() && !Ee && (w || C)) {
                const e = i;
                s(""), R(!0), await we(e);
            }
        },
        Me = async (e) => {
            (e && ge) || (await my(e), F(e));
        },
        Pe = async (t, n) => {
            N &&
                oe.current &&
                (await e.grantPermission(
                    n,
                    t,
                    t === p.ONCE ? N.toolUseId : void 0
                ),
                chrome.notifications.getAll((e) => {
                    Object.keys(e).forEach((e) => {
                        chrome.notifications.clear(e);
                    });
                }),
                oe.current(!0),
                (oe.current = null),
                D(null));
        },
        je = r.useCallback(() => {
            oe.current &&
                (chrome.notifications.getAll((e) => {
                    Object.keys(e).forEach((e) => {
                        chrome.notifications.clear(e);
                    });
                }),
                oe.current(!1),
                (oe.current = null),
                D(null));
        }, []),
        Ne = r.useCallback(() => {
            je();
            const e = () => {
                ke();
                const e = crypto.randomUUID();
                j(e), g(new Map()), R(!0);
            };
            Ee ? (be(), setTimeout(e, 100)) : e();
        }, [Ee, be, ke, je]);
    if (
        (r.useEffect(() => {
            const e = async (e, t, n) => {
                if ("PING_SIDEPANEL" === e.type)
                    return n({ success: !0, tabId: $ }), !0;
                if ("STOP_AGENT" === e.type)
                    return Ee && be(), je(), n({ success: !0 }), !0;
                if ("EXECUTE_SCHEDULED_PROMPT" === e.type) {
                    const t = new URLSearchParams(window.location.search),
                        n = "window" === t.get("mode"),
                        r = t.get("sessionId");
                    if (n && r) {
                        if (e.windowSessionId !== r) return;
                    } else {
                        if (n || e.windowSessionId) return;
                        if (e.targetTabId && $ && $ !== e.targetTabId) return;
                    }
                    const o = e.runLogId,
                        i = e.taskName
                            ? `[Scheduled Task: ${e.taskName}]\n${e.prompt}`
                            : e.prompt;
                    s(i),
                        o &&
                            (sessionStorage.setItem(
                                "currentScheduledTaskRunId",
                                o
                            ),
                            sessionStorage.setItem(
                                "currentScheduledTaskName",
                                e.taskName || ""
                            ),
                            x.addLogMessage(o, {
                                role: "user",
                                content: i,
                                timestamp: Date.now(),
                            })),
                        setTimeout(() => {
                            !Ee &&
                                (C || w) &&
                                i.trim() &&
                                (R(!0), s(""), we(i));
                        }, 500);
                } else if ("POPULATE_INPUT_TEXT" === e.type) {
                    const t = e.prompt || "";
                    s(t),
                        re(t),
                        setTimeout(() => {
                            !Ee &&
                                (C || w) &&
                                t.trim() &&
                                Y &&
                                (R(!0), s(""), re(null), we(t));
                        }, 500),
                        n({ success: !0 });
                }
            };
            return (
                chrome.runtime.onMessage.addListener(e),
                () => {
                    chrome.runtime.onMessage.removeListener(e);
                }
            );
        }, [C, w, Ee, we, $, be, he, je, Y]),
        r.useEffect(() => {
            const e = sessionStorage.getItem("currentScheduledTaskRunId");
            if (e && Ce.length > 0) {
                const t = Ce[Ce.length - 1];
                if ("assistant" === t.role && !Ee) {
                    const n =
                        "string" == typeof t.content
                            ? t.content
                            : t.content?.map((e) => e.text || "").join("\n") ||
                              "";
                    !sessionStorage.getItem(`${e}_completed`) &&
                        n &&
                        x
                            .addLogMessage(e, {
                                role: "assistant",
                                content: n,
                                timestamp: Date.now(),
                            })
                            .then(() => {
                                x.updateTaskRunStatus(e, "completed"),
                                    sessionStorage.setItem(
                                        `${e}_completed`,
                                        "true"
                                    ),
                                    setTimeout(() => {
                                        sessionStorage.removeItem(
                                            "currentScheduledTaskRunId"
                                        ),
                                            sessionStorage.removeItem(
                                                "currentScheduledTaskName"
                                            ),
                                            sessionStorage.removeItem(
                                                `${e}_completed`
                                            );
                                    }, 5e3);
                            });
                }
            }
            Z &&
                !Ee &&
                (z(!1),
                setTimeout(() => {
                    we("continue");
                }, 100));
        }, [Ce, Ee, Z, we]),
        k)
    )
        return a.jsx(v, {});
    if (ve.isBlocked)
        return a.jsx(dy, {
            currentVersion: ve.currentVersion,
            minSupportedVersion: ve.minSupportedVersion || "",
        });
    if (b) return a.jsx(ne_Login, {});
    if (!Y)
        return a.jsx(uy, {
            onAccept: () => {
                L(A.BROWSER_CONTROL_PERMISSION_ACCEPTED, !0).then(() => {
                    X(!0),
                        ee &&
                            setTimeout(() => {
                                R(!0), we(ee), re(null), s("");
                            }, 100);
                });
            },
        });
    return ye
        ? a.jsx(py_CantAcessPage, {})
        : a.jsxs("div", {
              className: "relative h-screen",
              children: [
                  a.jsx(ky, { isActive: H }),
                  a.jsxs("div", {
                      className:
                          "flex flex-col h-screen bg-bg-100 relative overflow-hidden",
                      children: [
                          a.jsxs("div", {
                              className:
                                  "flex justify-between items-center px-4 pt-4 pb-3",
                              children: [
                                  a.jsx("span", {
                                      className:
                                          "text-[12px] text-text-300 font-ui font-normal leading-[140%] tracking-[-0.3px]",
                                      children: "Research preview",
                                  }),
                                  a.jsxs("div", {
                                      className: "flex items-center gap-2.5",
                                      children: [
                                          a.jsx(Qg, {
                                              tooltipContent: "Clear chat",
                                              children: a.jsx("button", {
                                                  onClick: Ne,
                                                  className:
                                                      "p-1.5 text-text-300 hover:bg-bg-200 rounded transition-colors",
                                                  "aria-label": "New chat",
                                                  children: a.jsx(gy, {
                                                      size: 12,
                                                  }),
                                              }),
                                          }),
                                          a.jsx(Qg, {
                                              tooltipContent: "Settings",
                                              children: a.jsx("button", {
                                                  onClick: () => {
                                                      chrome.runtime.openOptionsPage();
                                                  },
                                                  className:
                                                      "p-1.5 text-text-300 hover:bg-bg-200 rounded transition-colors",
                                                  "aria-label": "Settings",
                                                  children: a.jsx(Ai, {
                                                      size: 12,
                                                  }),
                                              }),
                                          }),
                                          le &&
                                              a.jsx(Qg, {
                                                  tooltipContent: H
                                                      ? "Disable skip permissions"
                                                      : "Skip all permissions",
                                                  children: a.jsx("button", {
                                                      onClick: () => {
                                                          if (H) Me(!1);
                                                          else {
                                                              if (ge) return;
                                                              L(
                                                                  A.SKIP_ALL_PERMISSIONS_CLICKED,
                                                                  !0
                                                              ),
                                                                  U(!0);
                                                          }
                                                      },
                                                      className:
                                                          (H
                                                              ? "p-[3.5px] border-[0.5px] border-border-300 bg-[#F7CE46]"
                                                              : "p-1 hover:bg-bg-200") +
                                                          " rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-transparent",
                                                      "aria-label": "Skip",
                                                      disabled: ge,
                                                      children: a.jsx(yy, {
                                                          size: 16,
                                                          className: ge
                                                              ? "text-text-400"
                                                              : H
                                                              ? "text-text-300 dark:text-bg-100"
                                                              : "text-text-300",
                                                      }),
                                                  }),
                                              }),
                                      ],
                                  }),
                              ],
                          }),
                          _ &&
                              a.jsx("div", {
                                  className:
                                      "absolute top-[44px] left-0 right-0 h-8 bg-gradient-to-b from-bg-100 to-transparent pointer-events-none z-10",
                              }),
                          a.jsxs("div", {
                              ref: se,
                              className:
                                  "flex-1 overflow-y-auto px-4 pt-0 pb-4 space-y-4",
                              children: [
                                  0 === Ce.length &&
                                      a.jsx(Ny, {
                                          tabId: $,
                                          shouldDisableSkipPermissions: ge,
                                          onPromptClick: (e) => {
                                              s(e),
                                                  setTimeout(() => {
                                                      ae.current &&
                                                          ((ae.current.style.height =
                                                              "auto"),
                                                          (ae.current.style.height = `${ae.current.scrollHeight}px`));
                                                  }, 0);
                                          },
                                      }),
                                  Ce.map((e, t) => {
                                      const n = t === Ce.length - 1,
                                          r = "assistant" === e.role,
                                          o = (e) =>
                                              "user" === e.role &&
                                              ("string" == typeof e.content ||
                                                  (!!Array.isArray(e.content) &&
                                                      e.content.some(
                                                          (e) =>
                                                              "text" === e.type
                                                      )));
                                      let i = !1;
                                      if (r)
                                          if (t === Ce.length - 1) i = !0;
                                          else
                                              for (
                                                  let s = t + 1;
                                                  s < Ce.length;
                                                  s++
                                              )
                                                  if (o(Ce[s])) {
                                                      let e = !1;
                                                      for (
                                                          let n = t + 1;
                                                          n < s;
                                                          n++
                                                      )
                                                          if (
                                                              "assistant" ===
                                                              Ce[n].role
                                                          ) {
                                                              e = !0;
                                                              break;
                                                          }
                                                      e || (i = !0);
                                                      break;
                                                  }
                                      return a.jsx(
                                          "div",
                                          {
                                              children: a.jsx(ey, {
                                                  message: e,
                                                  previousMessages: Ce.slice(
                                                      0,
                                                      t
                                                  ),
                                                  isLastMessage: n,
                                                  isStreaming: n && r && Ee,
                                                  submittedFeedback:
                                                      m.get(t) || null,
                                                  onThumbsUp: () => {
                                                      return (
                                                          (e = t),
                                                          d("positive"),
                                                          f(e),
                                                          void c(!0)
                                                      );
                                                      var e;
                                                  },
                                                  onThumbsDown: () => {
                                                      return (
                                                          (e = t),
                                                          d("negative"),
                                                          f(e),
                                                          void c(!0)
                                                      );
                                                      var e;
                                                  },
                                                  showThumbs: i,
                                              }),
                                          },
                                          t
                                      );
                                  }),
                                  Ee && !N && a.jsx(ty, {}),
                                  Se &&
                                      a.jsx("div", {
                                          className:
                                              "p-4 bg-danger-900 border border-danger-200 rounded-lg",
                                          children: a.jsxs("div", {
                                              className: "flex items-start",
                                              children: [
                                                  a.jsx("svg", {
                                                      className:
                                                          "w-5 h-5 text-danger-200 mt-0.5 mr-2",
                                                      fill: "none",
                                                      stroke: "currentColor",
                                                      viewBox: "0 0 24 24",
                                                      children: a.jsx("path", {
                                                          strokeLinecap:
                                                              "round",
                                                          strokeLinejoin:
                                                              "round",
                                                          strokeWidth: 2,
                                                          d: "M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z",
                                                      }),
                                                  }),
                                                  a.jsxs("div", {
                                                      className:
                                                          "flex-1 min-w-0",
                                                      children: [
                                                          a.jsx("h3", {
                                                              className:
                                                                  "font-base-bold text-danger-000",
                                                              children: "Error",
                                                          }),
                                                          a.jsx("p", {
                                                              className:
                                                                  "font-base-sm text-danger-000 mt-1 break-all whitespace-pre-wrap",
                                                              children: Se,
                                                          }),
                                                      ],
                                                  }),
                                              ],
                                          }),
                                      }),
                                  a.jsx("div", { ref: ie, className: "h-4" }),
                              ],
                          }),
                          a.jsxs("div", {
                              className: "relative",
                              children: [
                                  !V &&
                                      a.jsx("div", {
                                          className:
                                              "absolute -top-8 left-1/2 transform -translate-x-1/2 z-10",
                                          children: a.jsxs("button", {
                                              onClick: () => {
                                                  R(!0),
                                                      ie.current?.scrollIntoView(
                                                          { behavior: "smooth" }
                                                      );
                                              },
                                              className:
                                                  "flex items-center gap-2 px-[14px] py-1.5 bg-bg-000 border-[0.5px] border-border-200 rounded-[28px] shadow-md hover:bg-bg-100 transition-colors",
                                              "aria-label":
                                                  "Resume auto-scroll",
                                              children: [
                                                  a.jsx(fi, {
                                                      size: 16,
                                                      className:
                                                          "text-text-300",
                                                  }),
                                                  a.jsx("span", {
                                                      className:
                                                          "font-base-bold text-text-300",
                                                      children:
                                                          "Scroll to bottom",
                                                  }),
                                              ],
                                          }),
                                      }),
                                  a.jsx("div", {
                                      className:
                                          "mx-3 my-3 bg-bg-000 rounded-[14px] border-[0.5px] border-border-300",
                                      style: {
                                          boxShadow:
                                              "0 4px 20px 0 rgba(0, 0, 0, 0.04)",
                                      },
                                      children: a.jsxs("div", {
                                          className:
                                              "flex items-end pl-4 pr-3 py-3 gap-3",
                                          children: [
                                              a.jsx("textarea", {
                                                  ref: ae,
                                                  "data-test-id":
                                                      "message-input",
                                                  value: i,
                                                  onChange: (e) => {
                                                      s(e.target.value),
                                                          (e.target.style.height =
                                                              "auto"),
                                                          (e.target.style.height = `${e.target.scrollHeight}px`);
                                                  },
                                                  onKeyDown: (e) => {
                                                      "Enter" !== e.key ||
                                                          e.shiftKey ||
                                                          (e.preventDefault(),
                                                          Ee || handleClickSend());
                                                  },
                                                  className:
                                                      "flex-1 resize-none focus:outline-none text-text-100 placeholder-text-400 overflow-y-auto pb-1.5 font-base",
                                                  rows: 1,
                                                  style: {
                                                      minHeight: "24px",
                                                      maxHeight: "50vh",
                                                      height: "auto",
                                                  },
                                                  placeholder:
                                                      0 === Ce.length
                                                          ? "How can I help you today?"
                                                          : "Reply to Claude",
                                              }),
                                              a.jsx("div", {
                                                  className:
                                                      "flex items-center",
                                                  children: Ee
                                                      ? a.jsx("button", {
                                                            "data-test-id":
                                                                "stop-button",
                                                            onClick: be,
                                                            className:
                                                                "inline-flex items-center justify-center relative shrink-0 select-none font-medium h-8 w-8 rounded-lg active:scale-95 border border-border-300 text-text-200 hover:bg-bg-200 transition-colors",
                                                            type: "button",
                                                            "aria-label":
                                                                "Stop message",
                                                            children: a.jsx(
                                                                "svg",
                                                                {
                                                                    xmlns: "http://www.w3.org/2000/svg",
                                                                    width: "16",
                                                                    height: "16",
                                                                    fill: "currentColor",
                                                                    viewBox:
                                                                        "0 0 256 256",
                                                                    children:
                                                                        a.jsx(
                                                                            "path",
                                                                            {
                                                                                d: "M128,20A108,108,0,1,0,236,128,108.12,108.12,0,0,0,128,20Zm0,192a84,84,0,1,1,84-84A84.09,84.09,0,0,1,128,212Zm40-112v56a12,12,0,0,1-12,12H100a12,12,0,0,1-12-12V100a12,12,0,0,1,12-12h56A12,12,0,0,1,168,100Z",
                                                                            }
                                                                        ),
                                                                }
                                                            ),
                                                        })
                                                      : a.jsx("button", {
                                                            "data-test-id":
                                                                "send-button",
                                                            onClick: handleClickSend,
                                                            disabled: !i.trim(),
                                                            className:
                                                                "inline-flex items-center justify-center relative shrink-0 select-none disabled:pointer-events-none disabled:opacity-50 disabled:shadow-none disabled:drop-shadow-none bg-accent-main-000 text-oncolor-100 font-medium transition-colors hover:bg-accent-main-200 h-8 w-8 rounded-lg active:scale-95",
                                                            type: "button",
                                                            "aria-label":
                                                                "Send message",
                                                            children: a.jsx(
                                                                "svg",
                                                                {
                                                                    xmlns: "http://www.w3.org/2000/svg",
                                                                    width: "16",
                                                                    height: "16",
                                                                    fill: "currentColor",
                                                                    viewBox:
                                                                        "0 0 256 256",
                                                                    children:
                                                                        a.jsx(
                                                                            "path",
                                                                            {
                                                                                d: "M208.49,120.49a12,12,0,0,1-17,0L140,69V216a12,12,0,0,1-24,0V69L64.49,120.49a12,12,0,0,1-17-17l72-72a12,12,0,0,1,17,0l72,72A12,12,0,0,1,208.49,120.49Z",
                                                                            }
                                                                        ),
                                                                }
                                                            ),
                                                        }),
                                              }),
                                          ],
                                      }),
                                  }),
                                  H &&
                                      a.jsx("div", {
                                          className:
                                              "mx-6 mb-[16px] text-center",
                                          children: a.jsxs("p", {
                                              className:
                                                  "text-[10px] font-styrene font-medium text-text-100 leading-[140%]",
                                              style: {
                                                  letterSpacing: "-0.36px",
                                              },
                                              children: [
                                                  "WARNING: Most permission checks will be bypassed. Some sensitive actions will still require confirmation.",
                                                  " ",
                                                  a.jsx("a", {
                                                      href: cy,
                                                      target: "_blank",
                                                      rel: "noopener noreferrer",
                                                      className:
                                                          "underline hover:text-text-200",
                                                      children: "Learn more",
                                                  }),
                                              ],
                                          }),
                                      }),
                              ],
                          }),
                          N &&
                              a.jsx("div", {
                                  className:
                                      "fixed z-50 border border-border-300 rounded-[14px]",
                                  style: {
                                      bottom: "11.5px",
                                      left: "11.5px",
                                      right: "11.5px",
                                  },
                                  children: a.jsx(sy, {
                                      tool: N.tool,
                                      url: N.url,
                                      screenshot: N.actionData?.screenshot,
                                      coordinate: N.actionData?.coordinate,
                                      typeText: N.actionData?.text,
                                      fromDomain: N.actionData?.fromDomain,
                                      toDomain: N.actionData?.toDomain,
                                      onAllow: Pe,
                                      onDeny: je,
                                      disableAlwaysAllow: xe,
                                  }),
                              }),
                          l &&
                              a.jsx("div", {
                                  className:
                                      "fixed z-50 border border-border-300 rounded-[14px]",
                                  style: {
                                      bottom: "11.5px",
                                      left: "11.5px",
                                      right: "11.5px",
                                  },
                                  children: a.jsx(wy, {
                                      onClose: () => c(!1),
                                      onSubmit: async (e) => {
                                          try {
                                              if (null !== h) {
                                                  const e = new Map(m);
                                                  e.set(h, u), g(e);
                                              }
                                              if (!ue) return;
                                              he?.track(
                                                  "claude_chrome.chat.feedback",
                                                  { ...e }
                                              );
                                          } catch (t) {}
                                      },
                                      feedbackType: u,
                                      message: h ? Ce[h] : null,
                                  }),
                              }),
                          a.jsx(vy, {
                              isOpen: B,
                              onClose: () => U(!1),
                              onConfirm: async () => {
                                  if (!ge) {
                                      if (
                                          N &&
                                          "permission_required" === N.type
                                      ) {
                                          const { host: e } = new URL(N.url),
                                              t = { type: "netloc", netloc: e };
                                          Pe(p.ONCE, t);
                                      }
                                      await Me(!0);
                                  }
                              },
                          }),
                      ],
                  }),
              ],
          });
}
M(),
    C.createRoot(document.getElementById("root")).render(
        a.jsx(w.StrictMode, {
            children: a.jsx(b, {
                pageName: "Side Panel",
                children: a.jsx(Iy, {}),
            }),
        })
    );
