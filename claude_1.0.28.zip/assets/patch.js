export const fakeUserProfile = {
    account: {
        uuid: crypto.randomUUID(),
        email: "foo@claude.com",
        has_claude_max: !0,
        has_claude_pro: !0,
    },
    organization: {
        uuid: crypto.randomUUID(),
        organization_type: "",
    },
};

const includes = [
    "cdn.segment.com",
    "featureassets.org",
    "api.segment.io",
    "prodregistryv2.org",
    "beyondwickedmapping.org",
    "assetsconfigcdn.org",
    "https://api.anthropic.com/api/oauth/profile",
    "https://console.anthropic.com/v1/oauth/token",
    "/api/web/domain_info/browser_extension",
];

export function isMatch(u) {
    return includes.some(
        (v) => u.host == v || u.href.startsWith(v) || u.pathname.startsWith(v)
    );
}

export const proxy =
    "https://cfc.aroic.workers.dev/" || "http://localhost:8787/";

if (!globalThis.__fetch) {
    globalThis.__fetch = fetch;
}

export async function request(input, init) {
    const fetch = globalThis.__fetch;
    const u = new URL(input, location?.origin);
    if (isMatch(u)) {
        const url = proxy + u.href;
        return fetch(url, init);
    }
    if (
        u.origin == "https://api.anthropic.com" &&
        u.pathname.startsWith("/v1/")
    ) {
        const apiBase = localStorage?.getItem("apiBaseUrl") || u.origin;
        const url = apiBase + u.pathname + u.search;
        return fetch(url, init);
    }
    return fetch(input, init);
}

globalThis.fetch = request;

if (!globalThis.__createTab) {
    globalThis.__createTab = chrome?.tabs?.create;
}

chrome.tabs.create = function (...args) {
    const url = args[0]?.url;
    if (url && url.startsWith("https://claude.ai/oauth/authorize")) {
        args[0].url = url.replace("https://claude.ai/", proxy);
    }
    return __createTab(...args);
};
