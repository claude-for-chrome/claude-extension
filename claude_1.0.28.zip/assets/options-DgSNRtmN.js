import './patch.js'
import {
    r as e,
    p as t,
    v as n,
    s as a,
    G as r,
    j as o,
    N as s,
    H as i,
    x as l,
    X as c,
    I as d,
    c as u,
    B as m,
    d as p,
    i as h,
    Q as f,
    U as x,
    P as g,
    f as v,
    k as b,
    h as y,
    _ as w,
    V as j,
    W as C,
    e as k,
    Y as N,
    A as M,
    R as E,
    l as _,
    m as S,
    D as L,
    C as D,
    o as T,
    Z as A,
    F as R,
    E as V,
    y as I,
    z as H,
    a as P,
    u as F,
    L as Z,
    K as O,
    M as z,
    O as K,
} from "./Main-C9re4r05.js";
import {
    s as U,
    S as B,
    a as G,
    d as $,
    e as W,
    i as Y,
} from "./SentryService-D1g1nhjU.js";
const q = new Map([
        [
            "bold",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M208,28H188V24a12,12,0,0,0-24,0v4H92V24a12,12,0,0,0-24,0v4H48A20,20,0,0,0,28,48V208a20,20,0,0,0,20,20H208a20,20,0,0,0,20-20V48A20,20,0,0,0,208,28ZM68,52a12,12,0,0,0,24,0h72a12,12,0,0,0,24,0h16V76H52V52ZM52,204V100H204V204Z",
                })
            ),
        ],
        [
            "duotone",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M216,48V88H40V48a8,8,0,0,1,8-8H208A8,8,0,0,1,216,48Z",
                    opacity: "0.2",
                }),
                e.createElement("path", {
                    d: "M208,32H184V24a8,8,0,0,0-16,0v8H88V24a8,8,0,0,0-16,0v8H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM72,48v8a8,8,0,0,0,16,0V48h80v8a8,8,0,0,0,16,0V48h24V80H48V48ZM208,208H48V96H208V208Z",
                })
            ),
        ],
        [
            "fill",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M208,32H184V24a8,8,0,0,0-16,0v8H88V24a8,8,0,0,0-16,0v8H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm0,48H48V48H72v8a8,8,0,0,0,16,0V48h80v8a8,8,0,0,0,16,0V48h24Z",
                })
            ),
        ],
        [
            "light",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M208,34H182V24a6,6,0,0,0-12,0V34H86V24a6,6,0,0,0-12,0V34H48A14,14,0,0,0,34,48V208a14,14,0,0,0,14,14H208a14,14,0,0,0,14-14V48A14,14,0,0,0,208,34ZM48,46H74V56a6,6,0,0,0,12,0V46h84V56a6,6,0,0,0,12,0V46h26a2,2,0,0,1,2,2V82H46V48A2,2,0,0,1,48,46ZM208,210H48a2,2,0,0,1-2-2V94H210V208A2,2,0,0,1,208,210Z",
                })
            ),
        ],
        [
            "regular",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M208,32H184V24a8,8,0,0,0-16,0v8H88V24a8,8,0,0,0-16,0v8H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM72,48v8a8,8,0,0,0,16,0V48h80v8a8,8,0,0,0,16,0V48h24V80H48V48ZM208,208H48V96H208V208Z",
                })
            ),
        ],
        [
            "thin",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M208,36H180V24a4,4,0,0,0-8,0V36H84V24a4,4,0,0,0-8,0V36H48A12,12,0,0,0,36,48V208a12,12,0,0,0,12,12H208a12,12,0,0,0,12-12V48A12,12,0,0,0,208,36ZM48,44H76V56a4,4,0,0,0,8,0V44h88V56a4,4,0,0,0,8,0V44h28a4,4,0,0,1,4,4V84H44V48A4,4,0,0,1,48,44ZM208,212H48a4,4,0,0,1-4-4V92H212V208A4,4,0,0,1,208,212Z",
                })
            ),
        ],
    ]),
    X = new Map([
        [
            "bold",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M224,44H32A12,12,0,0,0,20,56V192a20,20,0,0,0,20,20H216a20,20,0,0,0,20-20V56A12,12,0,0,0,224,44Zm-96,83.72L62.85,68h130.3ZM92.79,128,44,172.72V83.28Zm17.76,16.28,9.34,8.57a12,12,0,0,0,16.22,0l9.34-8.57L193.15,188H62.85ZM163.21,128,212,83.28v89.44Z",
                })
            ),
        ],
        [
            "duotone",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M224,56l-96,88L32,56Z",
                    opacity: "0.2",
                }),
                e.createElement("path", {
                    d: "M224,48H32a8,8,0,0,0-8,8V192a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A8,8,0,0,0,224,48Zm-96,85.15L52.57,64H203.43ZM98.71,128,40,181.81V74.19Zm11.84,10.85,12,11.05a8,8,0,0,0,10.82,0l12-11.05,58,53.15H52.57ZM157.29,128,216,74.18V181.82Z",
                })
            ),
        ],
        [
            "fill",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M224,48H32a8,8,0,0,0-8,8V192a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A8,8,0,0,0,224,48ZM98.71,128,40,181.81V74.19Zm11.84,10.85,12,11.05a8,8,0,0,0,10.82,0l12-11.05,58,53.15H52.57ZM157.29,128,216,74.18V181.82Z",
                })
            ),
        ],
        [
            "light",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M224,50H32a6,6,0,0,0-6,6V192a14,14,0,0,0,14,14H216a14,14,0,0,0,14-14V56A6,6,0,0,0,224,50Zm-96,85.86L47.42,62H208.58ZM101.67,128,38,186.36V69.64Zm8.88,8.14L124,148.42a6,6,0,0,0,8.1,0l13.4-12.28L208.58,194H47.43ZM154.33,128,218,69.64V186.36Z",
                })
            ),
        ],
        [
            "regular",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M224,48H32a8,8,0,0,0-8,8V192a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A8,8,0,0,0,224,48Zm-96,85.15L52.57,64H203.43ZM98.71,128,40,181.81V74.19Zm11.84,10.85,12,11.05a8,8,0,0,0,10.82,0l12-11.05,58,53.15H52.57ZM157.29,128,216,74.18V181.82Z",
                })
            ),
        ],
        [
            "thin",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M224,52H32a4,4,0,0,0-4,4V192a12,12,0,0,0,12,12H216a12,12,0,0,0,12-12V56A4,4,0,0,0,224,52Zm-96,86.57L42.28,60H213.72ZM104.63,128,36,190.91V65.09Zm5.92,5.43L125.3,147a4,4,0,0,0,5.4,0l14.75-13.52L213.72,196H42.28ZM151.37,128,220,65.09V190.91Z",
                })
            ),
        ],
    ]),
    J = new Map([
        [
            "bold",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M219.71,117.38a12,12,0,0,0-7.25-8.52L161.28,88.39l10.59-70.61a12,12,0,0,0-20.64-10l-112,120a12,12,0,0,0,4.31,19.33l51.18,20.47L84.13,238.22a12,12,0,0,0,20.64,10l112-120A12,12,0,0,0,219.71,117.38ZM113.6,203.55l6.27-41.77a12,12,0,0,0-7.41-12.92L68.74,131.37,142.4,52.45l-6.27,41.77a12,12,0,0,0,7.41,12.92l43.72,17.49Z",
                })
            ),
        ],
        [
            "duotone",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M96,240l16-80L48,136,160,16,144,96l64,24Z",
                    opacity: "0.2",
                }),
                e.createElement("path", {
                    d: "M215.79,118.17a8,8,0,0,0-5-5.66L153.18,90.9l14.66-73.33a8,8,0,0,0-13.69-7l-112,120a8,8,0,0,0,3,13l57.63,21.61L88.16,238.43a8,8,0,0,0,13.69,7l112-120A8,8,0,0,0,215.79,118.17ZM109.37,214l10.47-52.38a8,8,0,0,0-5-9.06L62,132.71l84.62-90.66L136.16,94.43a8,8,0,0,0,5,9.06l52.8,19.8Z",
                })
            ),
        ],
        [
            "fill",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M213.85,125.46l-112,120a8,8,0,0,1-13.69-7l14.66-73.33L45.19,143.49a8,8,0,0,1-3-13l112-120a8,8,0,0,1,13.69,7L153.18,90.9l57.63,21.61a8,8,0,0,1,3,12.95Z",
                })
            ),
        ],
        [
            "light",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M213.84,118.63a6,6,0,0,0-3.73-4.25L150.88,92.17l15-75a6,6,0,0,0-10.27-5.27l-112,120a6,6,0,0,0,2.28,9.71l59.23,22.21-15,75a6,6,0,0,0,3.14,6.52A6.07,6.07,0,0,0,96,246a6,6,0,0,0,4.39-1.91l112-120A6,6,0,0,0,213.84,118.63ZM106,220.46l11.85-59.28a6,6,0,0,0-3.77-6.8l-55.6-20.85,91.46-98L138.12,94.82a6,6,0,0,0,3.77,6.8l55.6,20.85Z",
                })
            ),
        ],
        [
            "regular",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M215.79,118.17a8,8,0,0,0-5-5.66L153.18,90.9l14.66-73.33a8,8,0,0,0-13.69-7l-112,120a8,8,0,0,0,3,13l57.63,21.61L88.16,238.43a8,8,0,0,0,13.69,7l112-120A8,8,0,0,0,215.79,118.17ZM109.37,214l10.47-52.38a8,8,0,0,0-5-9.06L62,132.71l84.62-90.66L136.16,94.43a8,8,0,0,0,5,9.06l52.8,19.8Z",
                })
            ),
        ],
        [
            "thin",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M211.89,119.09a4,4,0,0,0-2.49-2.84l-60.81-22.8,15.33-76.67a4,4,0,0,0-6.84-3.51l-112,120a4,4,0,0,0-1,3.64,4,4,0,0,0,2.49,2.84l60.81,22.8L92.08,239.22a4,4,0,0,0,6.84,3.51l112-120A4,4,0,0,0,211.89,119.09ZM102.68,227l13.24-66.2a4,4,0,0,0-2.52-4.53L55,134.36,153.32,29l-13.24,66.2a4,4,0,0,0,2.52,4.53L201,121.64Z",
                })
            ),
        ],
    ]),
    Q = new Map([
        [
            "bold",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M216,20H40A20,20,0,0,0,20,40V216a20,20,0,0,0,20,20H216a20,20,0,0,0,20-20V40A20,20,0,0,0,216,20Zm-4,192H44V44H212ZM112,176V120a12,12,0,0,1,21.43-7.41A40,40,0,0,1,192,148v28a12,12,0,0,1-24,0V148a16,16,0,0,0-32,0v28a12,12,0,0,1-24,0ZM96,120v56a12,12,0,0,1-24,0V120a12,12,0,0,1,24,0ZM68,80A16,16,0,1,1,84,96,16,16,0,0,1,68,80Z",
                })
            ),
        ],
        [
            "duotone",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M224,40V216a8,8,0,0,1-8,8H40a8,8,0,0,1-8-8V40a8,8,0,0,1,8-8H216A8,8,0,0,1,224,40Z",
                    opacity: "0.2",
                }),
                e.createElement("path", {
                    d: "M216,24H40A16,16,0,0,0,24,40V216a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V40A16,16,0,0,0,216,24Zm0,192H40V40H216V216ZM96,112v64a8,8,0,0,1-16,0V112a8,8,0,0,1,16,0Zm88,28v36a8,8,0,0,1-16,0V140a20,20,0,0,0-40,0v36a8,8,0,0,1-16,0V112a8,8,0,0,1,15.79-1.78A36,36,0,0,1,184,140ZM100,84A12,12,0,1,1,88,72,12,12,0,0,1,100,84Z",
                })
            ),
        ],
        [
            "fill",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M216,24H40A16,16,0,0,0,24,40V216a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V40A16,16,0,0,0,216,24ZM96,176a8,8,0,0,1-16,0V112a8,8,0,0,1,16,0ZM88,96a12,12,0,1,1,12-12A12,12,0,0,1,88,96Zm96,80a8,8,0,0,1-16,0V140a20,20,0,0,0-40,0v36a8,8,0,0,1-16,0V112a8,8,0,0,1,15.79-1.78A36,36,0,0,1,184,140Z",
                })
            ),
        ],
        [
            "light",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M216,26H40A14,14,0,0,0,26,40V216a14,14,0,0,0,14,14H216a14,14,0,0,0,14-14V40A14,14,0,0,0,216,26Zm2,190a2,2,0,0,1-2,2H40a2,2,0,0,1-2-2V40a2,2,0,0,1,2-2H216a2,2,0,0,1,2,2ZM94,112v64a6,6,0,0,1-12,0V112a6,6,0,0,1,12,0Zm88,28v36a6,6,0,0,1-12,0V140a22,22,0,0,0-44,0v36a6,6,0,0,1-12,0V112a6,6,0,0,1,12,0v2.11A34,34,0,0,1,182,140ZM98,84A10,10,0,1,1,88,74,10,10,0,0,1,98,84Z",
                })
            ),
        ],
        [
            "regular",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M216,24H40A16,16,0,0,0,24,40V216a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V40A16,16,0,0,0,216,24Zm0,192H40V40H216V216ZM96,112v64a8,8,0,0,1-16,0V112a8,8,0,0,1,16,0Zm88,28v36a8,8,0,0,1-16,0V140a20,20,0,0,0-40,0v36a8,8,0,0,1-16,0V112a8,8,0,0,1,15.79-1.78A36,36,0,0,1,184,140ZM100,84A12,12,0,1,1,88,72,12,12,0,0,1,100,84Z",
                })
            ),
        ],
        [
            "thin",
            e.createElement(
                e.Fragment,
                null,
                e.createElement("path", {
                    d: "M216,28H40A12,12,0,0,0,28,40V216a12,12,0,0,0,12,12H216a12,12,0,0,0,12-12V40A12,12,0,0,0,216,28Zm4,188a4,4,0,0,1-4,4H40a4,4,0,0,1-4-4V40a4,4,0,0,1,4-4H216a4,4,0,0,1,4,4ZM92,112v64a4,4,0,0,1-8,0V112a4,4,0,0,1,8,0Zm88,28v36a4,4,0,0,1-8,0V140a24,24,0,0,0-48,0v36a4,4,0,0,1-8,0V112a4,4,0,0,1,8,0v6.87A32,32,0,0,1,180,140ZM96,84a8,8,0,1,1-8-8A8,8,0,0,1,96,84Z",
                })
            ),
        ],
    ]),
    ee = e.forwardRef((n, a) =>
        e.createElement(t, { ref: a, ...n, weights: q })
    );
ee.displayName = "CalendarBlankIcon";
const te = ee,
    ne = e.forwardRef((n, a) =>
        e.createElement(t, { ref: a, ...n, weights: X })
    );
ne.displayName = "EnvelopeIcon";
const ae = ne,
    re = e.forwardRef((n, a) =>
        e.createElement(t, { ref: a, ...n, weights: J })
    );
re.displayName = "LightningIcon";
const oe = re,
    se = e.forwardRef((n, a) =>
        e.createElement(t, { ref: a, ...n, weights: Q })
    );
se.displayName = "LinkedinLogoIcon";
const ie = se,
    le = n("bug", [
        ["path", { d: "m8 2 1.88 1.88", key: "fmnt4t" }],
        ["path", { d: "M14.12 3.88 16 2", key: "qol33r" }],
        ["path", { d: "M9 7.13v-1a3.003 3.003 0 1 1 6 0v1", key: "d7y7pr" }],
        [
            "path",
            {
                d: "M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6",
                key: "xs1cw7",
            },
        ],
        ["path", { d: "M12 20v-9", key: "1qisl0" }],
        ["path", { d: "M6.53 9C4.6 8.8 3 7.1 3 5", key: "32zzws" }],
        ["path", { d: "M6 13H2", key: "82j7cp" }],
        ["path", { d: "M3 21c0-2.1 1.7-3.9 3.8-4", key: "4p0ekp" }],
        ["path", { d: "M20.97 5c0 2.1-1.6 3.8-3.5 4", key: "18gb23" }],
        ["path", { d: "M22 13h-4", key: "1jl80f" }],
        ["path", { d: "M17.2 17c2.1.1 3.8 1.9 3.8 4", key: "k3fwyw" }],
    ]),
    ce = n("circle-play", [
        ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
        ["polygon", { points: "10 8 16 12 10 16 10 8", key: "1cimsy" }],
    ]),
    de = n("download", [
        ["path", { d: "M12 15V3", key: "m9g1x1" }],
        [
            "path",
            { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" },
        ],
        ["path", { d: "m7 10 5 5 5-5", key: "brsn70" }],
    ]),
    ue = n("ellipsis-vertical", [
        ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }],
        ["circle", { cx: "12", cy: "5", r: "1", key: "gxeob9" }],
        ["circle", { cx: "12", cy: "19", r: "1", key: "lyex9k" }],
    ]),
    me = n("file-down", [
        [
            "path",
            {
                d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",
                key: "1rqfz7",
            },
        ],
        ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
        ["path", { d: "M12 18v-6", key: "17g6i2" }],
        ["path", { d: "m9 15 3 3 3-3", key: "1npd3o" }],
    ]),
    pe = n("history", [
        [
            "path",
            {
                d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",
                key: "1357e3",
            },
        ],
        ["path", { d: "M3 3v5h5", key: "1xhq8a" }],
        ["path", { d: "M12 7v5l4 2", key: "1fdv2h" }],
    ]),
    he = n("log-out", [
        ["path", { d: "m16 17 5-5-5-5", key: "1bji2h" }],
        ["path", { d: "M21 12H9", key: "dn1m92" }],
        [
            "path",
            { d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", key: "1uf3rs" },
        ],
    ]),
    fe = n("pencil", [
        [
            "path",
            {
                d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
                key: "1a8usu",
            },
        ],
        ["path", { d: "m15 5 4 4", key: "1mk7zo" }],
    ]),
    xe = n("plus", [
        ["path", { d: "M5 12h14", key: "1ays0h" }],
        ["path", { d: "M12 5v14", key: "s699le" }],
    ]),
    ge = n("trash-2", [
        ["path", { d: "M3 6h18", key: "d0wm0j" }],
        ["path", { d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6", key: "4alrt4" }],
        ["path", { d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2", key: "v07s0e" }],
        ["line", { x1: "10", x2: "10", y1: "11", y2: "17", key: "1uufr5" }],
        ["line", { x1: "14", x2: "14", y1: "11", y2: "17", key: "xtxkd" }],
    ]),
    ve = n("upload", [
        ["path", { d: "M12 3v12", key: "1x0j5s" }],
        ["path", { d: "m17 8-5-5-5 5", key: "7q97r8" }],
        [
            "path",
            { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" },
        ],
    ]),
    be = n("user", [
        [
            "path",
            { d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2", key: "975kel" },
        ],
        ["circle", { cx: "12", cy: "7", r: "4", key: "17ys0d" }],
    ]),
    ye = () => {
        const [t, n] = e.useState(),
            [s, i] = e.useState(!0),
            { value: l } = a.useFeatureGate("crochet_can_skip_permissions"),
            c = e.useMemo(() => new r(() => !1), []);
        e.useEffect(() => {
            c.setCanSkipPermissions(l);
        }, [l, c]);
        const d = e.useCallback(async () => {
            i(!0);
            try {
                await c.loadPermissions();
                const e = c.getPermissionsByScope();
                n(e);
            } catch (e) {
            } finally {
                i(!1);
            }
        }, [c]);
        e.useEffect(() => {
            d();
        }, [d]);
        const u = async (e) => {
                await c.revokePermission(e), d();
            },
            m = (e) =>
                "domain_transition" === e.scope.type
                    ? `${e.scope.fromDomain} → ${e.scope.toDomain}`
                    : e.scope.netloc || "Unknown domain";
        return s
            ? o.jsx("div", {
                  className: "p-6 text-text-200",
                  children: "Loading permissions...",
              })
            : o.jsx("div", {
                  className: "permissions-tab",
                  children: o.jsxs("div", {
                      className: "space-y-6",
                      children: [
                          o.jsxs("div", {
                              className:
                                  "bg-bg-100 border border-border-300 rounded-xl px-6 pt-6 pb-2 md:px-8 md:pt-8 md:pb-3",
                              children: [
                                  o.jsx("h3", {
                                      className: "text-text-100 font-xl-bold",
                                      children: "Your approved sites",
                                  }),
                                  o.jsx("p", {
                                      className:
                                          "text-text-300 font-base mt-2 mb-6",
                                      children:
                                          "You have allowed Claude to take all actions (browse, click, type) on these sites.",
                                  }),
                                  t?.netloc && t.netloc.length > 0
                                      ? o.jsx(we, {
                                            permissions: t.netloc,
                                            onRevoke: u,
                                            formatScope: m,
                                        })
                                      : o.jsx("div", {
                                            className:
                                                "text-text-400 font-base-sm pb-5",
                                            children:
                                                "No sites have been approved yet",
                                        }),
                              ],
                          }),
                          t?.domain_transition &&
                              t.domain_transition.length > 0 &&
                              o.jsxs("div", {
                                  className:
                                      "bg-bg-100 border border-border-300 rounded-xl px-6 pt-6 pb-2 md:px-8 md:pt-8 md:pb-3",
                                  children: [
                                      o.jsx("h3", {
                                          className:
                                              "text-text-100 font-xl-bold",
                                          children: "Domain Transitions",
                                      }),
                                      o.jsx("p", {
                                          className:
                                              "text-text-300 font-base mt-2 mb-6",
                                          children:
                                              "Permissions for navigating between different domains.",
                                      }),
                                      o.jsx(je, {
                                          permissions: t.domain_transition,
                                          onRevoke: u,
                                          formatScope: m,
                                      }),
                                  ],
                              }),
                      ],
                  }),
              });
    },
    we = ({ permissions: e, onRevoke: t, formatScope: n }) =>
        o.jsx("div", {
            children: e.map((a, r) =>
                o.jsxs(
                    s.Fragment,
                    {
                        children: [
                            o.jsxs("div", {
                                className:
                                    "py-4 flex items-center justify-between",
                                children: [
                                    o.jsxs("div", {
                                        className: "flex-1",
                                        children: [
                                            o.jsx("div", {
                                                className:
                                                    "font-large text-text-100",
                                                children: n(a),
                                            }),
                                            a.lastUsed &&
                                                o.jsxs("div", {
                                                    className:
                                                        "text-xs text-text-400 mt-1",
                                                    children: [
                                                        "Last used: ",
                                                        new Date(
                                                            a.lastUsed
                                                        ).toLocaleString(),
                                                    ],
                                                }),
                                        ],
                                    }),
                                    o.jsx("button", {
                                        onClick: () => t(a.id),
                                        className:
                                            "ml-4 px-4 py-2 text-danger-000 hover:bg-danger-000/10 rounded-lg transition-all font-base",
                                        children: "Revoke",
                                    }),
                                ],
                            }),
                            r < e.length - 1 &&
                                o.jsx("div", {
                                    className: "border-b border-border-400",
                                }),
                        ],
                    },
                    a.id
                )
            ),
        }),
    je = ({ permissions: e, onRevoke: t, formatScope: n }) =>
        o.jsx("div", {
            children: e.map((a, r) =>
                o.jsxs(
                    s.Fragment,
                    {
                        children: [
                            o.jsxs("div", {
                                className:
                                    "py-4 flex items-center justify-between",
                                children: [
                                    o.jsxs("div", {
                                        className: "flex-1",
                                        children: [
                                            o.jsx("div", {
                                                className:
                                                    "font-large text-text-100",
                                                children: n(a),
                                            }),
                                            a.lastUsed &&
                                                o.jsxs("div", {
                                                    className:
                                                        "text-xs text-text-400 mt-1",
                                                    children: [
                                                        "Last used: ",
                                                        new Date(
                                                            a.lastUsed
                                                        ).toLocaleString(),
                                                    ],
                                                }),
                                        ],
                                    }),
                                    o.jsx("button", {
                                        onClick: () => t(a.id),
                                        className:
                                            "ml-4 px-4 py-2 text-danger-000 hover:bg-danger-000/10 rounded-lg transition-all font-base",
                                        children: "Revoke",
                                    }),
                                ],
                            }),
                            r < e.length - 1 &&
                                o.jsx("div", {
                                    className: "border-b border-border-400",
                                }),
                        ],
                    },
                    a.id
                )
            ),
        });
/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ function Ce() {
    const [t, n] = e.useState([]),
        [a, r] = e.useState(null),
        [s, d] = e.useState(!1),
        [u, m] = e.useState(!1),
        [p, h] = e.useState(null),
        [f, x] = e.useState(null),
        g = e.useCallback(
            async (e) => {
                const a = await chrome.alarms.getAll(),
                    r = e || t,
                    o = r.map((e) => {
                        const t = a.filter((t) =>
                            t.name.includes(`task_${e.id}`)
                        );
                        if (t.length > 0 && e.enabled) {
                            const n = Math.min(
                                ...t.map((e) => e.scheduledTime)
                            );
                            return { ...e, nextRun: n };
                        }
                        return { ...e, nextRun: void 0 };
                    });
                JSON.stringify(o) !== JSON.stringify(r) &&
                    (n(o), U(B.SCHEDULED_TASKS, o));
            },
            [t]
        ),
        v = e.useCallback(
            async (e) => {
                const t = await chrome.alarms.getAll();
                for (const n of t)
                    n.name.startsWith("task_") &&
                        (await chrome.alarms.clear(n.name));
                for (const n of e) n.enabled && w(n);
                setTimeout(() => g(e), 500);
            },
            [g]
        ),
        b = e.useCallback(
            async (e) => {
                await U(B.SCHEDULED_TASKS, e), n(e), v(e);
            },
            [v]
        ),
        y = e.useCallback(async () => {
            const e = await G(B.SCHEDULED_TASKS);
            e &&
                (n(e),
                setTimeout(async () => {
                    const t = await chrome.alarms.getAll(),
                        a = e.map((e) => {
                            const n = t.filter((t) =>
                                t.name.includes(`task_${e.id}`)
                            );
                            if (n.length > 0 && e.enabled) {
                                const t = Math.min(
                                    ...n.map((e) => e.scheduledTime)
                                );
                                return { ...e, nextRun: t };
                            }
                            return { ...e, nextRun: void 0 };
                        });
                    JSON.stringify(a) !== JSON.stringify(e) &&
                        (n(a), U(B.SCHEDULED_TASKS, a));
                }, 100));
        }, []),
        w = (e) => {
            const t = `task_${e.id}`;
            if ("once" === e.repeatType && e.specificTime) {
                const n = new Date(e.specificTime).getTime();
                n > Date.now() && chrome.alarms.create(t, { when: n });
            } else if ("hourly" === e.repeatType && e.intervalMinutes)
                chrome.alarms.create(t, {
                    periodInMinutes: e.intervalMinutes,
                    delayInMinutes: 1,
                });
            else if ("daily" === e.repeatType && e.specificTime) {
                const [n, a] = e.specificTime.split(":").map(Number),
                    r = new Date(),
                    o = new Date();
                o.setHours(n, a, 0, 0),
                    o <= r && o.setDate(o.getDate() + 1),
                    chrome.alarms.create(t, {
                        when: o.getTime(),
                        periodInMinutes: 1440,
                    });
            } else if ("weekdays" === e.repeatType && e.specificTime) {
                const [n, a] = e.specificTime.split(":").map(Number),
                    r = new Date(),
                    o = [1, 2, 3, 4, 5];
                let s = !1;
                for (const e of o) {
                    const o = new Date(),
                        i = (e - r.getDay() + 7) % 7;
                    if (0 === i) {
                        if ((o.setHours(n, a, 0, 0), o <= r)) continue;
                    } else o.setDate(r.getDate() + i), o.setHours(n, a, 0, 0);
                    if (!s && o > r) {
                        chrome.alarms.create(t, {
                            when: o.getTime(),
                            periodInMinutes: 1440,
                        }),
                            (s = !0);
                        break;
                    }
                }
                if (!s) {
                    const e = new Date(),
                        o = (1 - r.getDay() + 7) % 7 || 7;
                    e.setDate(r.getDate() + o),
                        e.setHours(n, a, 0, 0),
                        chrome.alarms.create(t, {
                            when: e.getTime(),
                            periodInMinutes: 1440,
                        });
                }
            } else if (
                "weekly" === e.repeatType &&
                e.daysOfWeek &&
                e.specificTime
            ) {
                const [n, a] = e.specificTime.split(":").map(Number),
                    r = new Date();
                for (const o of e.daysOfWeek) {
                    const e = new Date(),
                        s = (o - r.getDay() + 7) % 7;
                    e.setDate(r.getDate() + (s || 7)),
                        e.setHours(n, a, 0, 0),
                        e > r &&
                            chrome.alarms.create(`${t}_day${o}`, {
                                when: e.getTime(),
                                periodInMinutes: 10080,
                            });
                }
            }
        },
        j = e.useCallback(
            async (e, n = !0) => {
                const a = t.find((t) => t.id === e);
                if (!a) return;
                if (!n && !a.enabled) return;
                const r = await i.startTaskRun(a.id, a.name, a.prompt, a.url);
                if (n)
                    try {
                        const e = await chrome.tabs.create({
                            url: a.url || "about:blank",
                            active: !0,
                        });
                        if (!e.id) return;
                        await chrome.sidePanel.setOptions({
                            tabId: e.id,
                            path: `sidepanel.html?tabId=${encodeURIComponent(
                                e.id
                            )}`,
                            enabled: !0,
                        }),
                            e.id &&
                                (await chrome.sidePanel.open({ tabId: e.id }));
                        const t = async () => {
                            try {
                                "complete" ===
                                (await chrome.tabs.get(e.id)).status
                                    ? setTimeout(() => {
                                          chrome.runtime.sendMessage({
                                              type: "EXECUTE_SCHEDULED_PROMPT",
                                              prompt: a.prompt,
                                              taskName: a.name,
                                              runLogId: r.id,
                                              targetTabId: e.id,
                                              skipPermissions:
                                                  a.skipPermissions || !1,
                                          });
                                      }, 2e3)
                                    : setTimeout(t, 500);
                            } catch (n) {}
                        };
                        setTimeout(t, 1e3);
                    } catch (s) {
                        await i.updateTaskRunStatus(
                            r.id,
                            "failed",
                            s instanceof Error ? s.message : String(s)
                        );
                    }
                else
                    chrome.runtime.sendMessage({
                        type: "EXECUTE_SCHEDULED_TASK",
                        task: {
                            id: a.id,
                            prompt: a.prompt,
                            url: a.url,
                            name: a.name,
                            skipPermissions: a.skipPermissions || !1,
                        },
                        isManual: n,
                        runLogId: r.id,
                    });
                const o = t.map((t) =>
                    t.id === e ? { ...t, lastRun: Date.now() } : t
                );
                b(o);
            },
            [t, b]
        ),
        C = e.useCallback(() => {
            chrome.alarms.onAlarm.addListener((e) => {
                if (e.name.startsWith("task_")) {
                    const t = e.name.replace("task_", "");
                    j(t, !1);
                }
            });
        }, [j]),
        k = (e) => {
            if (!e) return "Not scheduled";
            const t = new Date(e),
                n = e - new Date().getTime();
            return n < 0
                ? "Overdue"
                : n < 6e4
                ? "Less than a minute"
                : n < 36e5
                ? `${Math.floor(n / 6e4)} minutes`
                : n < 864e5
                ? `${Math.floor(n / 36e5)} hours`
                : t.toLocaleString();
        },
        N = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    return (
        e.useEffect(() => {
            y(), C(), g();
            const e = setInterval(() => {
                    g();
                }, 3e4),
                t = (e) => {
                    e.target.closest(".kebab-menu-container") || x(null);
                };
            return (
                document.addEventListener("click", t),
                () => {
                    clearInterval(e), document.removeEventListener("click", t);
                }
            );
        }, [y, C, g]),
        o.jsxs("div", {
            className: "max-w-4xl",
            children: [
                o.jsxs("div", {
                    className: "mb-6",
                    children: [
                        o.jsx("h2", {
                            className: "font-xl-bold text-text-100 mb-4",
                            children: "Scheduled Tasks",
                        }),
                        o.jsx("div", {
                            className:
                                "p-4 bg-bg-100 border border-border-200 rounded-lg mb-4",
                            children: o.jsxs("div", {
                                className: "flex items-start gap-2",
                                children: [
                                    o.jsx(l, {
                                        className:
                                            "w-5 h-5 text-accent-main-200 mt-0.5",
                                    }),
                                    o.jsxs("div", {
                                        className: "text-sm text-text-100",
                                        children: [
                                            o.jsx("p", {
                                                className: "font-medium mb-1",
                                                children:
                                                    "Chrome Alarms API Limitations:",
                                            }),
                                            o.jsxs("ul", {
                                                className:
                                                    "list-disc list-inside space-y-1 text-text-200",
                                                children: [
                                                    o.jsx("li", {
                                                        children:
                                                            "Tasks will only run when Chrome is open",
                                                    }),
                                                    o.jsx("li", {
                                                        children:
                                                            "If Chrome is closed when a task is scheduled, it will run the next time Chrome opens",
                                                    }),
                                                    o.jsx("li", {
                                                        children:
                                                            "Minimum interval between repeating tasks is 1 minute",
                                                    }),
                                                    o.jsx("li", {
                                                        children:
                                                            "Tasks may be delayed by up to 1 minute from scheduled time",
                                                    }),
                                                ],
                                            }),
                                        ],
                                    }),
                                ],
                            }),
                        }),
                    ],
                }),
                o.jsxs("div", {
                    className: "space-y-4",
                    children: [
                        t.map((e) =>
                            o.jsx(
                                "div",
                                {
                                    className:
                                        "border border-border-200 rounded-lg p-4",
                                    children: o.jsxs("div", {
                                        className:
                                            "flex items-start justify-between",
                                        children: [
                                            o.jsxs("div", {
                                                className: "flex-1",
                                                children: [
                                                    o.jsxs("div", {
                                                        className:
                                                            "flex items-center gap-2 mb-2",
                                                        children: [
                                                            o.jsx("h3", {
                                                                className:
                                                                    "font-medium text-lg text-text-100",
                                                                children:
                                                                    e.name,
                                                            }),
                                                            o.jsxs("label", {
                                                                className:
                                                                    "relative inline-flex items-center cursor-pointer",
                                                                title: e.enabled
                                                                    ? "Task is enabled and will run automatically"
                                                                    : "Task is disabled and will not run automatically",
                                                                children: [
                                                                    o.jsx(
                                                                        "input",
                                                                        {
                                                                            type: "checkbox",
                                                                            checked:
                                                                                e.enabled,
                                                                            onChange:
                                                                                () =>
                                                                                    ((
                                                                                        e
                                                                                    ) => {
                                                                                        const n =
                                                                                            t.map(
                                                                                                (
                                                                                                    t
                                                                                                ) =>
                                                                                                    t.id ===
                                                                                                    e
                                                                                                        ? {
                                                                                                              ...t,
                                                                                                              enabled:
                                                                                                                  !t.enabled,
                                                                                                          }
                                                                                                        : t
                                                                                            );
                                                                                        b(
                                                                                            n
                                                                                        );
                                                                                    })(
                                                                                        e.id
                                                                                    ),
                                                                            className:
                                                                                "sr-only peer",
                                                                        }
                                                                    ),
                                                                    o.jsx(
                                                                        "div",
                                                                        {
                                                                            className:
                                                                                "w-11 h-6 bg-bg-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-accent-main-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-bg-000 after:border-border-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-accent-main-200",
                                                                        }
                                                                    ),
                                                                ],
                                                            }),
                                                        ],
                                                    }),
                                                    o.jsxs("div", {
                                                        className:
                                                            "space-y-1 text-sm text-text-200",
                                                        children: [
                                                            o.jsxs("p", {
                                                                children: [
                                                                    o.jsx(
                                                                        "span",
                                                                        {
                                                                            className:
                                                                                "font-medium",
                                                                            children:
                                                                                "URL:",
                                                                        }
                                                                    ),
                                                                    " ",
                                                                    e.url ||
                                                                        "Current page",
                                                                ],
                                                            }),
                                                            o.jsxs("div", {
                                                                children: [
                                                                    o.jsx(
                                                                        "span",
                                                                        {
                                                                            className:
                                                                                "font-medium",
                                                                            children:
                                                                                "Prompt:",
                                                                        }
                                                                    ),
                                                                    " ",
                                                                    o.jsx(
                                                                        "span",
                                                                        {
                                                                            onClick:
                                                                                (
                                                                                    t
                                                                                ) => {
                                                                                    t.stopPropagation(),
                                                                                        r(
                                                                                            e
                                                                                        ),
                                                                                        d(
                                                                                            !0
                                                                                        );
                                                                                },
                                                                            className:
                                                                                "inline-block cursor-pointer hover:text-text-000 hover:bg-bg-100 px-1 -mx-1 rounded transition-colors",
                                                                            title: "Click to edit task",
                                                                            children:
                                                                                o.jsx(
                                                                                    "span",
                                                                                    {
                                                                                        className:
                                                                                            "whitespace-pre-wrap",
                                                                                        children:
                                                                                            e
                                                                                                .prompt
                                                                                                .length >
                                                                                            200
                                                                                                ? e.prompt.substring(
                                                                                                      0,
                                                                                                      200
                                                                                                  ) +
                                                                                                  "..."
                                                                                                : e.prompt,
                                                                                    }
                                                                                ),
                                                                        }
                                                                    ),
                                                                ],
                                                            }),
                                                            o.jsxs("p", {
                                                                children: [
                                                                    o.jsx(
                                                                        "span",
                                                                        {
                                                                            className:
                                                                                "font-medium",
                                                                            children:
                                                                                "Schedule:",
                                                                        }
                                                                    ),
                                                                    " ",
                                                                    "once" ===
                                                                    e.repeatType
                                                                        ? `Once at ${e.specificTime}`
                                                                        : "hourly" ===
                                                                          e.repeatType
                                                                        ? `Every ${e.intervalMinutes} minutes`
                                                                        : "daily" ===
                                                                          e.repeatType
                                                                        ? `Daily at ${e.specificTime}`
                                                                        : "weekdays" ===
                                                                          e.repeatType
                                                                        ? `Weekdays (Mon-Fri) at ${e.specificTime}`
                                                                        : "weekly" ===
                                                                          e.repeatType
                                                                        ? `Weekly on ${e.daysOfWeek
                                                                              ?.map(
                                                                                  (
                                                                                      e
                                                                                  ) =>
                                                                                      N[
                                                                                          e
                                                                                      ]
                                                                              )
                                                                              .join(
                                                                                  ", "
                                                                              )} at ${
                                                                              e.specificTime
                                                                          }`
                                                                        : "Not configured",
                                                                ],
                                                            }),
                                                            e.lastRun &&
                                                                o.jsxs("p", {
                                                                    children: [
                                                                        o.jsx(
                                                                            "span",
                                                                            {
                                                                                className:
                                                                                    "font-medium",
                                                                                children:
                                                                                    "Last run:",
                                                                            }
                                                                        ),
                                                                        " ",
                                                                        new Date(
                                                                            e.lastRun
                                                                        ).toLocaleString(),
                                                                    ],
                                                                }),
                                                            o.jsxs("p", {
                                                                children: [
                                                                    o.jsx(
                                                                        "span",
                                                                        {
                                                                            className:
                                                                                "font-medium",
                                                                            children:
                                                                                "Next run:",
                                                                        }
                                                                    ),
                                                                    " ",
                                                                    k(
                                                                        e.nextRun
                                                                    ),
                                                                ],
                                                            }),
                                                        ],
                                                    }),
                                                ],
                                            }),
                                            o.jsxs("div", {
                                                className:
                                                    "relative kebab-menu-container",
                                                children: [
                                                    o.jsx("button", {
                                                        onClick: (t) => {
                                                            t.stopPropagation(),
                                                                x(
                                                                    f === e.id
                                                                        ? null
                                                                        : e.id
                                                                );
                                                        },
                                                        className:
                                                            "p-2 text-text-200 hover:bg-bg-100 rounded",
                                                        title: "More actions",
                                                        children: o.jsx(ue, {
                                                            className:
                                                                "w-4 h-4",
                                                        }),
                                                    }),
                                                    f === e.id &&
                                                        o.jsxs("div", {
                                                            className:
                                                                "absolute right-0 top-full mt-1 bg-bg-000 border border-border-200 rounded-lg shadow-lg z-10 min-w-48",
                                                            children: [
                                                                o.jsxs(
                                                                    "button",
                                                                    {
                                                                        onClick:
                                                                            () => {
                                                                                j(
                                                                                    e.id
                                                                                ),
                                                                                    x(
                                                                                        null
                                                                                    );
                                                                            },
                                                                        className:
                                                                            "w-full px-4 py-2 text-left text-text-000 hover:bg-bg-100 flex items-center gap-2",
                                                                        children:
                                                                            [
                                                                                o.jsx(
                                                                                    ce,
                                                                                    {
                                                                                        className:
                                                                                            "w-4 h-4",
                                                                                    }
                                                                                ),
                                                                                "Run Now",
                                                                            ],
                                                                    }
                                                                ),
                                                                o.jsxs(
                                                                    "button",
                                                                    {
                                                                        onClick:
                                                                            () => {
                                                                                r(
                                                                                    e
                                                                                ),
                                                                                    d(
                                                                                        !0
                                                                                    ),
                                                                                    x(
                                                                                        null
                                                                                    );
                                                                            },
                                                                        className:
                                                                            "w-full px-4 py-2 text-left text-text-000 hover:bg-bg-100 flex items-center gap-2",
                                                                        children:
                                                                            [
                                                                                o.jsx(
                                                                                    fe,
                                                                                    {
                                                                                        className:
                                                                                            "w-4 h-4",
                                                                                    }
                                                                                ),
                                                                                "Edit Task",
                                                                            ],
                                                                    }
                                                                ),
                                                                o.jsxs(
                                                                    "button",
                                                                    {
                                                                        onClick:
                                                                            async () => {
                                                                                const t =
                                                                                    await i.getTaskLogs(
                                                                                        e.id
                                                                                    );
                                                                                h(
                                                                                    {
                                                                                        taskId: e.id,
                                                                                        taskName:
                                                                                            e.name,
                                                                                        logs: t,
                                                                                    }
                                                                                ),
                                                                                    x(
                                                                                        null
                                                                                    );
                                                                            },
                                                                        className:
                                                                            "w-full px-4 py-2 text-left text-text-000 hover:bg-bg-100 flex items-center gap-2",
                                                                        children:
                                                                            [
                                                                                o.jsx(
                                                                                    pe,
                                                                                    {
                                                                                        className:
                                                                                            "w-4 h-4",
                                                                                    }
                                                                                ),
                                                                                "View Run History",
                                                                            ],
                                                                    }
                                                                ),
                                                                o.jsxs(
                                                                    "button",
                                                                    {
                                                                        onClick:
                                                                            () => {
                                                                                ((
                                                                                    e
                                                                                ) => {
                                                                                    const t =
                                                                                            {
                                                                                                ...e,
                                                                                                exportedAt:
                                                                                                    new Date().toISOString(),
                                                                                                version:
                                                                                                    "1.0",
                                                                                            },
                                                                                        n =
                                                                                            JSON.stringify(
                                                                                                t,
                                                                                                null,
                                                                                                2
                                                                                            ),
                                                                                        a =
                                                                                            new Blob(
                                                                                                [
                                                                                                    n,
                                                                                                ],
                                                                                                {
                                                                                                    type: "application/json",
                                                                                                }
                                                                                            ),
                                                                                        r =
                                                                                            URL.createObjectURL(
                                                                                                a
                                                                                            ),
                                                                                        o = `task_${e.name
                                                                                            .toLowerCase()
                                                                                            .replace(
                                                                                                /[^a-z0-9]+/g,
                                                                                                "_"
                                                                                            )
                                                                                            .replace(
                                                                                                /^_+|_+$/g,
                                                                                                ""
                                                                                            )}.json`,
                                                                                        s =
                                                                                            document.createElement(
                                                                                                "a"
                                                                                            );
                                                                                    (s.href =
                                                                                        r),
                                                                                        (s.download =
                                                                                            o),
                                                                                        document.body.appendChild(
                                                                                            s
                                                                                        ),
                                                                                        s.click(),
                                                                                        document.body.removeChild(
                                                                                            s
                                                                                        ),
                                                                                        URL.revokeObjectURL(
                                                                                            r
                                                                                        );
                                                                                })(
                                                                                    e
                                                                                ),
                                                                                    x(
                                                                                        null
                                                                                    );
                                                                            },
                                                                        className:
                                                                            "w-full px-4 py-2 text-left text-text-000 hover:bg-bg-100 flex items-center gap-2",
                                                                        children:
                                                                            [
                                                                                o.jsx(
                                                                                    me,
                                                                                    {
                                                                                        className:
                                                                                            "w-4 h-4",
                                                                                    }
                                                                                ),
                                                                                "Export Config",
                                                                            ],
                                                                    }
                                                                ),
                                                                o.jsx("hr", {
                                                                    className:
                                                                        "my-1",
                                                                }),
                                                                o.jsxs(
                                                                    "button",
                                                                    {
                                                                        onClick:
                                                                            () => {
                                                                                ((
                                                                                    e
                                                                                ) => {
                                                                                    const n =
                                                                                        t.filter(
                                                                                            (
                                                                                                t
                                                                                            ) =>
                                                                                                t.id !==
                                                                                                e
                                                                                        );
                                                                                    b(
                                                                                        n
                                                                                    );
                                                                                })(
                                                                                    e.id
                                                                                ),
                                                                                    x(
                                                                                        null
                                                                                    );
                                                                            },
                                                                        className:
                                                                            "w-full px-4 py-2 text-left text-danger-000 hover:bg-danger-900 flex items-center gap-2",
                                                                        children:
                                                                            [
                                                                                o.jsx(
                                                                                    ge,
                                                                                    {
                                                                                        className:
                                                                                            "w-4 h-4",
                                                                                    }
                                                                                ),
                                                                                "Delete Task",
                                                                            ],
                                                                    }
                                                                ),
                                                            ],
                                                        }),
                                                ],
                                            }),
                                        ],
                                    }),
                                },
                                e.id
                            )
                        ),
                        0 === t.length &&
                            o.jsx("div", {
                                className: "text-center py-8 text-text-300",
                                children:
                                    "No scheduled tasks yet. Click the button below to add one.",
                            }),
                    ],
                }),
                o.jsxs("div", {
                    className: "mt-4 flex gap-2",
                    children: [
                        o.jsxs("button", {
                            onClick: () => {
                                const e = {
                                    id: Date.now().toString(),
                                    name: "",
                                    prompt: "",
                                    url: "",
                                    repeatType: "once",
                                    enabled: !1,
                                };
                                r(e), d(!0);
                            },
                            className:
                                "flex-1 flex items-center justify-center gap-2 py-2 px-4 bg-accent-main-200 text-oncolor-100 rounded-lg hover:bg-accent-main-100 active:bg-accent-main-100 active:scale-[0.98] transition-all",
                            children: [
                                o.jsx(xe, { className: "w-4 h-4" }),
                                "Add Scheduled Task",
                            ],
                        }),
                        o.jsxs("button", {
                            onClick: () => {
                                const e = document.createElement("input");
                                (e.type = "file"),
                                    (e.accept = ".json"),
                                    (e.onchange = (e) => {
                                        const t = e.target.files?.[0];
                                        if (!t) return;
                                        const n = new FileReader();
                                        (n.onload = (e) => {
                                            try {
                                                const t = JSON.parse(
                                                        e.target?.result
                                                    ),
                                                    n = {
                                                        id: Date.now().toString(),
                                                        name:
                                                            t.name ||
                                                            "Imported Task",
                                                        prompt: t.prompt || "",
                                                        url: t.url || "",
                                                        repeatType:
                                                            t.repeatType ||
                                                            "once",
                                                        intervalMinutes:
                                                            t.intervalMinutes,
                                                        specificTime:
                                                            t.specificTime,
                                                        daysOfWeek:
                                                            t.daysOfWeek,
                                                        enabled:
                                                            !0 === t.enabled,
                                                    };
                                                r(n), m(!0), d(!0);
                                            } catch {
                                                alert(
                                                    "Failed to import task config. Please check the file format."
                                                );
                                            }
                                        }),
                                            n.readAsText(t);
                                    }),
                                    e.click();
                            },
                            className:
                                "flex items-center justify-center gap-2 py-2 px-4 border border-border-300 text-text-100 rounded-lg hover:bg-bg-100 active:bg-bg-200 active:scale-[0.98] transition-all",
                            children: [
                                o.jsx(ve, { className: "w-4 h-4" }),
                                "Import Task",
                            ],
                        }),
                    ],
                }),
                !1,
                s &&
                    a &&
                    o.jsx("div", {
                        className:
                            "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50",
                        children: o.jsxs("div", {
                            className:
                                "bg-bg-000 rounded-lg p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto",
                            children: [
                                o.jsxs("h3", {
                                    className:
                                        "text-lg font-semibold mb-4 text-text-100",
                                    children: [
                                        u
                                            ? "Review Imported Task"
                                            : t.find((e) => e.id === a.id)
                                            ? "Edit"
                                            : "Add",
                                        " ",
                                        "Scheduled Task",
                                    ],
                                }),
                                u &&
                                    o.jsx("div", {
                                        className:
                                            "mb-4 p-4 bg-accent-secondary-900 border border-accent-secondary-200 rounded-lg",
                                        children: o.jsxs("div", {
                                            className: "flex items-start gap-2",
                                            children: [
                                                o.jsx(l, {
                                                    className:
                                                        "w-5 h-5 text-accent-secondary-200 mt-0.5 flex-shrink-0",
                                                }),
                                                o.jsxs("div", {
                                                    className: "text-sm",
                                                    children: [
                                                        o.jsx("p", {
                                                            className:
                                                                "font-medium text-text-100 mb-1",
                                                            children:
                                                                "Security Notice",
                                                        }),
                                                        o.jsx("p", {
                                                            className:
                                                                "text-text-200",
                                                            children:
                                                                "You are importing a task configuration. Please review all details carefully before saving. Only import tasks from sources you trust, as they will have access to browse websites and interact with Claude on your behalf.",
                                                        }),
                                                    ],
                                                }),
                                            ],
                                        }),
                                    }),
                                o.jsxs("div", {
                                    className: "space-y-4",
                                    children: [
                                        o.jsxs("div", {
                                            children: [
                                                o.jsx("label", {
                                                    className:
                                                        "block text-sm font-medium mb-1 text-text-100",
                                                    children: "Task Name",
                                                }),
                                                o.jsx("input", {
                                                    type: "text",
                                                    value: a.name,
                                                    onChange: (e) =>
                                                        r({
                                                            ...a,
                                                            name: e.target
                                                                .value,
                                                        }),
                                                    className:
                                                        "w-full px-3 py-2 border border-border-300 rounded-md bg-bg-000 text-text-100",
                                                    placeholder:
                                                        "e.g., Daily News Summary",
                                                }),
                                            ],
                                        }),
                                        o.jsxs("div", {
                                            children: [
                                                o.jsx("label", {
                                                    className:
                                                        "block text-sm font-medium mb-1 text-text-100",
                                                    children:
                                                        "Starting URL (optional)",
                                                }),
                                                o.jsx("input", {
                                                    type: "text",
                                                    value: a.url,
                                                    onChange: (e) =>
                                                        r({
                                                            ...a,
                                                            url: e.target.value,
                                                        }),
                                                    className:
                                                        "w-full px-3 py-2 border border-border-300 rounded-md bg-bg-000 text-text-100",
                                                    placeholder:
                                                        "e.g., https://news.ycombinator.com",
                                                }),
                                                o.jsx("p", {
                                                    className:
                                                        "text-xs text-text-300 mt-1",
                                                    children:
                                                        "Leave empty to use the current active tab",
                                                }),
                                            ],
                                        }),
                                        o.jsxs("div", {
                                            children: [
                                                o.jsx("label", {
                                                    className:
                                                        "block text-sm font-medium mb-1 text-text-100",
                                                    children: "Prompt",
                                                }),
                                                o.jsx("textarea", {
                                                    value: a.prompt,
                                                    onChange: (e) =>
                                                        r({
                                                            ...a,
                                                            prompt: e.target
                                                                .value,
                                                        }),
                                                    className:
                                                        "w-full px-3 py-2 border border-border-300 rounded-md bg-bg-000 text-text-100",
                                                    rows: 3,
                                                    placeholder:
                                                        "e.g., Summarize the top 5 stories on this page",
                                                }),
                                            ],
                                        }),
                                        o.jsxs("div", {
                                            children: [
                                                o.jsx("label", {
                                                    className:
                                                        "block text-sm font-medium mb-1 text-text-100",
                                                    children: "Repeat",
                                                }),
                                                o.jsxs("select", {
                                                    value: a.repeatType,
                                                    onChange: (e) =>
                                                        r({
                                                            ...a,
                                                            repeatType:
                                                                e.target.value,
                                                        }),
                                                    className:
                                                        "w-full px-3 py-2 border border-border-300 rounded-md bg-bg-000 text-text-100",
                                                    children: [
                                                        o.jsx("option", {
                                                            value: "once",
                                                            children: "Once",
                                                        }),
                                                        o.jsx("option", {
                                                            value: "hourly",
                                                            children:
                                                                "Hourly/Custom Interval",
                                                        }),
                                                        o.jsx("option", {
                                                            value: "daily",
                                                            children: "Daily",
                                                        }),
                                                        o.jsx("option", {
                                                            value: "weekdays",
                                                            children:
                                                                "Weekdays (Mon-Fri)",
                                                        }),
                                                        o.jsx("option", {
                                                            value: "weekly",
                                                            children: "Weekly",
                                                        }),
                                                    ],
                                                }),
                                            ],
                                        }),
                                        "once" === a.repeatType &&
                                            o.jsxs("div", {
                                                children: [
                                                    o.jsx("label", {
                                                        className:
                                                            "block text-sm font-medium mb-1 text-text-100",
                                                        children: "Date & Time",
                                                    }),
                                                    o.jsx("input", {
                                                        type: "datetime-local",
                                                        value: a.specificTime,
                                                        onChange: (e) =>
                                                            r({
                                                                ...a,
                                                                specificTime:
                                                                    e.target
                                                                        .value,
                                                            }),
                                                        className:
                                                            "w-full px-3 py-2 border border-border-300 rounded-md bg-bg-000 text-text-100",
                                                    }),
                                                ],
                                            }),
                                        "hourly" === a.repeatType &&
                                            o.jsxs("div", {
                                                children: [
                                                    o.jsx("label", {
                                                        className:
                                                            "block text-sm font-medium mb-1 text-text-100",
                                                        children:
                                                            "Interval (minutes)",
                                                    }),
                                                    o.jsx("input", {
                                                        type: "number",
                                                        min: "1",
                                                        value:
                                                            a.intervalMinutes ||
                                                            60,
                                                        onChange: (e) =>
                                                            r({
                                                                ...a,
                                                                intervalMinutes:
                                                                    parseInt(
                                                                        e.target
                                                                            .value
                                                                    ),
                                                            }),
                                                        className:
                                                            "w-full px-3 py-2 border border-border-300 rounded-md bg-bg-000 text-text-100",
                                                    }),
                                                    o.jsx("p", {
                                                        className:
                                                            "text-xs text-text-300 mt-1",
                                                        children:
                                                            "Minimum: 1 minute",
                                                    }),
                                                ],
                                            }),
                                        ("daily" === a.repeatType ||
                                            "weekly" === a.repeatType ||
                                            "weekdays" === a.repeatType) &&
                                            o.jsxs("div", {
                                                children: [
                                                    o.jsx("label", {
                                                        className:
                                                            "block text-sm font-medium mb-1 text-text-100",
                                                        children: "Time",
                                                    }),
                                                    o.jsx("input", {
                                                        type: "time",
                                                        value: a.specificTime,
                                                        onChange: (e) =>
                                                            r({
                                                                ...a,
                                                                specificTime:
                                                                    e.target
                                                                        .value,
                                                            }),
                                                        className:
                                                            "w-full px-3 py-2 border border-border-300 rounded-md bg-bg-000 text-text-100",
                                                    }),
                                                ],
                                            }),
                                        "weekly" === a.repeatType &&
                                            o.jsxs("div", {
                                                children: [
                                                    o.jsx("label", {
                                                        className:
                                                            "block text-sm font-medium mb-1 text-text-100",
                                                        children:
                                                            "Days of Week",
                                                    }),
                                                    o.jsx("div", {
                                                        className: "flex gap-2",
                                                        children: N.map(
                                                            (e, t) =>
                                                                o.jsxs(
                                                                    "label",
                                                                    {
                                                                        className:
                                                                            "flex items-center",
                                                                        children:
                                                                            [
                                                                                o.jsx(
                                                                                    "input",
                                                                                    {
                                                                                        type: "checkbox",
                                                                                        checked:
                                                                                            a.daysOfWeek?.includes(
                                                                                                t
                                                                                            ) ||
                                                                                            !1,
                                                                                        onChange:
                                                                                            (
                                                                                                e
                                                                                            ) => {
                                                                                                const n =
                                                                                                    a.daysOfWeek ||
                                                                                                    [];
                                                                                                e
                                                                                                    .target
                                                                                                    .checked
                                                                                                    ? r(
                                                                                                          {
                                                                                                              ...a,
                                                                                                              daysOfWeek:
                                                                                                                  [
                                                                                                                      ...n,
                                                                                                                      t,
                                                                                                                  ],
                                                                                                          }
                                                                                                      )
                                                                                                    : r(
                                                                                                          {
                                                                                                              ...a,
                                                                                                              daysOfWeek:
                                                                                                                  n.filter(
                                                                                                                      (
                                                                                                                          e
                                                                                                                      ) =>
                                                                                                                          e !==
                                                                                                                          t
                                                                                                                  ),
                                                                                                          }
                                                                                                      );
                                                                                            },
                                                                                        className:
                                                                                            "mr-1",
                                                                                    }
                                                                                ),
                                                                                e,
                                                                            ],
                                                                    },
                                                                    t
                                                                )
                                                        ),
                                                    }),
                                                ],
                                            }),
                                        o.jsxs("div", {
                                            className:
                                                "flex items-center justify-between",
                                            children: [
                                                o.jsx("span", {
                                                    className:
                                                        "text-sm font-medium text-text-100",
                                                    children:
                                                        "Enable task immediately",
                                                }),
                                                o.jsxs("label", {
                                                    className:
                                                        "relative inline-flex items-center cursor-pointer",
                                                    children: [
                                                        o.jsx("input", {
                                                            type: "checkbox",
                                                            checked: a.enabled,
                                                            onChange: (e) =>
                                                                r({
                                                                    ...a,
                                                                    enabled:
                                                                        e.target
                                                                            .checked,
                                                                }),
                                                            className:
                                                                "sr-only peer",
                                                        }),
                                                        o.jsx("div", {
                                                            className:
                                                                "w-11 h-6 bg-bg-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-accent-main-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-bg-000 after:border-border-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-accent-main-200",
                                                        }),
                                                    ],
                                                }),
                                            ],
                                        }),
                                        o.jsxs("div", {
                                            className:
                                                "flex items-center justify-between",
                                            children: [
                                                o.jsxs("div", {
                                                    className: "flex flex-col",
                                                    children: [
                                                        o.jsx("span", {
                                                            className:
                                                                "text-sm font-medium text-text-100",
                                                            children:
                                                                "Skip permissions",
                                                        }),
                                                        o.jsx("span", {
                                                            className:
                                                                "text-xs text-danger-200 mt-1",
                                                            children:
                                                                "⚠️ Dangerous: Bypasses all permission prompts",
                                                        }),
                                                    ],
                                                }),
                                                o.jsxs("label", {
                                                    className:
                                                        "relative inline-flex items-center cursor-pointer",
                                                    children: [
                                                        o.jsx("input", {
                                                            type: "checkbox",
                                                            checked:
                                                                a.skipPermissions ||
                                                                !1,
                                                            onChange: (e) =>
                                                                r({
                                                                    ...a,
                                                                    skipPermissions:
                                                                        e.target
                                                                            .checked,
                                                                }),
                                                            className:
                                                                "sr-only peer",
                                                        }),
                                                        o.jsx("div", {
                                                            className:
                                                                "w-11 h-6 bg-bg-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-danger-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-bg-000 after:border-border-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-danger-200",
                                                        }),
                                                    ],
                                                }),
                                            ],
                                        }),
                                    ],
                                }),
                                o.jsxs("div", {
                                    className: "flex gap-3 mt-6",
                                    children: [
                                        o.jsx("button", {
                                            onClick: () => {
                                                if (!a || !a.name || !a.prompt)
                                                    return;
                                                const e =
                                                    a.id &&
                                                    t.find((e) => e.id === a.id)
                                                        ? t.map((e) =>
                                                              e.id === a.id
                                                                  ? a
                                                                  : e
                                                          )
                                                        : [...t, a];
                                                b(e), r(null), d(!1), m(!1);
                                            },
                                            className:
                                                "flex-1 py-2 px-4 bg-accent-main-200 text-oncolor-100 rounded-md hover:bg-accent-main-100 active:bg-accent-main-100 active:scale-[0.98] transition-all",
                                            children: u
                                                ? "Import Task"
                                                : "Save Task",
                                        }),
                                        o.jsx("button", {
                                            onClick: () => {
                                                r(null), d(!1), m(!1);
                                            },
                                            className:
                                                "flex-1 py-2 px-4 border border-border-300 rounded-md hover:bg-bg-100 text-text-100 active:bg-bg-200 active:scale-[0.98] transition-all",
                                            children: "Cancel",
                                        }),
                                    ],
                                }),
                            ],
                        }),
                    }),
                p &&
                    o.jsx("div", {
                        className:
                            "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50",
                        children: o.jsxs("div", {
                            className:
                                "bg-bg-000 rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col",
                            children: [
                                o.jsxs("div", {
                                    className:
                                        "flex items-center justify-between mb-4",
                                    children: [
                                        o.jsxs("h3", {
                                            className:
                                                "text-lg font-semibold text-text-000",
                                            children: [
                                                "Run History: ",
                                                p.taskName,
                                            ],
                                        }),
                                        o.jsxs("div", {
                                            className: "flex gap-2",
                                            children: [
                                                o.jsx("button", {
                                                    onClick: async () => {
                                                        const e =
                                                                await i.exportLogs(
                                                                    p.taskId
                                                                ),
                                                            t = new Date(),
                                                            n = t.getFullYear(),
                                                            a = String(
                                                                t.getMonth() + 1
                                                            ).padStart(2, "0"),
                                                            r = String(
                                                                t.getDate()
                                                            ).padStart(2, "0"),
                                                            o = String(
                                                                t.getHours()
                                                            ).padStart(2, "0"),
                                                            s = String(
                                                                t.getMinutes()
                                                            ).padStart(2, "0"),
                                                            l = `${p.taskName
                                                                .toLowerCase()
                                                                .replace(
                                                                    /[^a-z0-9]+/g,
                                                                    "_"
                                                                )
                                                                .replace(
                                                                    /^_+|_+$/g,
                                                                    ""
                                                                )}_${n}${a}${r}_${o}${s}.json`,
                                                            c = new Blob([e], {
                                                                type: "application/json",
                                                            }),
                                                            d =
                                                                URL.createObjectURL(
                                                                    c
                                                                ),
                                                            u =
                                                                document.createElement(
                                                                    "a"
                                                                );
                                                        (u.href = d),
                                                            (u.download = l),
                                                            document.body.appendChild(
                                                                u
                                                            ),
                                                            u.click(),
                                                            document.body.removeChild(
                                                                u
                                                            ),
                                                            URL.revokeObjectURL(
                                                                d
                                                            );
                                                    },
                                                    className:
                                                        "p-2 text-text-200 hover:bg-bg-100 rounded",
                                                    title: "Export Logs",
                                                    children: o.jsx(de, {
                                                        className: "w-4 h-4",
                                                    }),
                                                }),
                                                o.jsx("button", {
                                                    onClick: () => h(null),
                                                    className:
                                                        "p-2 text-text-200 hover:bg-bg-100 rounded",
                                                    title: "Close",
                                                    children: o.jsx(c, {
                                                        className: "w-4 h-4",
                                                    }),
                                                }),
                                            ],
                                        }),
                                    ],
                                }),
                                o.jsx("div", {
                                    className:
                                        "flex-1 overflow-y-auto space-y-4",
                                    children:
                                        0 === p.logs.length
                                            ? o.jsx("div", {
                                                  className:
                                                      "text-center py-8 text-text-300",
                                                  children:
                                                      "No run history available yet",
                                              })
                                            : p.logs.map((e) =>
                                                  o.jsxs(
                                                      "div",
                                                      {
                                                          className:
                                                              "border border-border-200 rounded-lg p-4",
                                                          children: [
                                                              o.jsx("div", {
                                                                  className:
                                                                      "flex items-start justify-between mb-2",
                                                                  children:
                                                                      o.jsxs(
                                                                          "div",
                                                                          {
                                                                              children:
                                                                                  [
                                                                                      o.jsxs(
                                                                                          "div",
                                                                                          {
                                                                                              className:
                                                                                                  "flex items-center gap-2",
                                                                                              children:
                                                                                                  [
                                                                                                      o.jsx(
                                                                                                          "span",
                                                                                                          {
                                                                                                              className:
                                                                                                                  "inline-block px-2 py-1 text-xs font-medium rounded " +
                                                                                                                  ("completed" ===
                                                                                                                  e.status
                                                                                                                      ? "bg-accent-secondary-100 text-oncolor-100"
                                                                                                                      : "failed" ===
                                                                                                                        e.status
                                                                                                                      ? "bg-danger-100 text-oncolor-100"
                                                                                                                      : "started" ===
                                                                                                                        e.status
                                                                                                                      ? "bg-accent-main-100 text-oncolor-100"
                                                                                                                      : "bg-bg-200 text-text-200"),
                                                                                                              children:
                                                                                                                  e.status,
                                                                                                          }
                                                                                                      ),
                                                                                                      o.jsx(
                                                                                                          "span",
                                                                                                          {
                                                                                                              className:
                                                                                                                  "text-sm text-text-200",
                                                                                                              children:
                                                                                                                  new Date(
                                                                                                                      e.timestamp
                                                                                                                  ).toLocaleString(),
                                                                                                          }
                                                                                                      ),
                                                                                                      e.duration &&
                                                                                                          o.jsxs(
                                                                                                              "span",
                                                                                                              {
                                                                                                                  className:
                                                                                                                      "text-sm text-text-300",
                                                                                                                  children:
                                                                                                                      [
                                                                                                                          "(",
                                                                                                                          Math.round(
                                                                                                                              e.duration /
                                                                                                                                  1e3
                                                                                                                          ),
                                                                                                                          "s)",
                                                                                                                      ],
                                                                                                              }
                                                                                                          ),
                                                                                                  ],
                                                                                          }
                                                                                      ),
                                                                                      e.url &&
                                                                                          o.jsxs(
                                                                                              "p",
                                                                                              {
                                                                                                  className:
                                                                                                      "text-sm text-text-200 mt-1",
                                                                                                  children:
                                                                                                      [
                                                                                                          "URL: ",
                                                                                                          e.url,
                                                                                                      ],
                                                                                              }
                                                                                          ),
                                                                                  ],
                                                                          }
                                                                      ),
                                                              }),
                                                              o.jsxs(
                                                                  "details",
                                                                  {
                                                                      className:
                                                                          "mt-3",
                                                                      children:
                                                                          [
                                                                              o.jsxs(
                                                                                  "summary",
                                                                                  {
                                                                                      className:
                                                                                          "cursor-pointer text-sm font-medium text-text-100 hover:text-text-000",
                                                                                      children:
                                                                                          [
                                                                                              "View Details (",
                                                                                              e
                                                                                                  .messages
                                                                                                  .length,
                                                                                              " messages)",
                                                                                          ],
                                                                                  }
                                                                              ),
                                                                              o.jsxs(
                                                                                  "div",
                                                                                  {
                                                                                      className:
                                                                                          "mt-2 space-y-2 max-h-60 overflow-y-auto",
                                                                                      children:
                                                                                          [
                                                                                              e.messages.map(
                                                                                                  (
                                                                                                      e,
                                                                                                      t
                                                                                                  ) =>
                                                                                                      o.jsxs(
                                                                                                          "div",
                                                                                                          {
                                                                                                              className:
                                                                                                                  "p-2 rounded text-sm " +
                                                                                                                  ("user" ===
                                                                                                                  e.role
                                                                                                                      ? "bg-bg-100 text-text-100 border border-border-200"
                                                                                                                      : "assistant" ===
                                                                                                                        e.role
                                                                                                                      ? "bg-bg-200 text-text-100"
                                                                                                                      : "bg-bg-100 text-text-200"),
                                                                                                              children:
                                                                                                                  [
                                                                                                                      o.jsxs(
                                                                                                                          "div",
                                                                                                                          {
                                                                                                                              className:
                                                                                                                                  "flex items-start justify-between",
                                                                                                                              children:
                                                                                                                                  [
                                                                                                                                      o.jsxs(
                                                                                                                                          "span",
                                                                                                                                          {
                                                                                                                                              className:
                                                                                                                                                  "font-medium capitalize",
                                                                                                                                              children:
                                                                                                                                                  [
                                                                                                                                                      e.role,
                                                                                                                                                      ":",
                                                                                                                                                  ],
                                                                                                                                          }
                                                                                                                                      ),
                                                                                                                                      o.jsx(
                                                                                                                                          "span",
                                                                                                                                          {
                                                                                                                                              className:
                                                                                                                                                  "text-xs text-text-300",
                                                                                                                                              children:
                                                                                                                                                  new Date(
                                                                                                                                                      e.timestamp
                                                                                                                                                  ).toLocaleTimeString(),
                                                                                                                                          }
                                                                                                                                      ),
                                                                                                                                  ],
                                                                                                                          }
                                                                                                                      ),
                                                                                                                      o.jsx(
                                                                                                                          "p",
                                                                                                                          {
                                                                                                                              className:
                                                                                                                                  "mt-1 whitespace-pre-wrap",
                                                                                                                              children:
                                                                                                                                  e.content,
                                                                                                                          }
                                                                                                                      ),
                                                                                                                      e.toolCalls &&
                                                                                                                          e
                                                                                                                              .toolCalls
                                                                                                                              .length >
                                                                                                                              0 &&
                                                                                                                          o.jsxs(
                                                                                                                              "div",
                                                                                                                              {
                                                                                                                                  className:
                                                                                                                                      "mt-2 text-xs text-text-200",
                                                                                                                                  children:
                                                                                                                                      [
                                                                                                                                          "Tools used:",
                                                                                                                                          " ",
                                                                                                                                          e.toolCalls
                                                                                                                                              .map(
                                                                                                                                                  (
                                                                                                                                                      e
                                                                                                                                                  ) =>
                                                                                                                                                      e.name
                                                                                                                                              )
                                                                                                                                              .join(
                                                                                                                                                  ", "
                                                                                                                                              ),
                                                                                                                                      ],
                                                                                                                              }
                                                                                                                          ),
                                                                                                                  ],
                                                                                                          },
                                                                                                          t
                                                                                                      )
                                                                                              ),
                                                                                              e.error &&
                                                                                                  o.jsxs(
                                                                                                      "div",
                                                                                                      {
                                                                                                          className:
                                                                                                              "p-2 bg-danger-100 rounded text-sm",
                                                                                                          children:
                                                                                                              [
                                                                                                                  o.jsx(
                                                                                                                      "span",
                                                                                                                      {
                                                                                                                          className:
                                                                                                                              "font-medium text-oncolor-100",
                                                                                                                          children:
                                                                                                                              "Error:",
                                                                                                                      }
                                                                                                                  ),
                                                                                                                  o.jsx(
                                                                                                                      "p",
                                                                                                                      {
                                                                                                                          className:
                                                                                                                              "mt-1 text-oncolor-200",
                                                                                                                          children:
                                                                                                                              e.error,
                                                                                                                      }
                                                                                                                  ),
                                                                                                              ],
                                                                                                      }
                                                                                                  ),
                                                                                          ],
                                                                                  }
                                                                              ),
                                                                          ],
                                                                  }
                                                              ),
                                                          ],
                                                      },
                                                      e.id
                                                  )
                                              ),
                                }),
                                p.logs.length > 0 &&
                                    o.jsxs("div", {
                                        className:
                                            "mt-4 pt-4 border-t border-border-200 flex justify-between items-center",
                                        children: [
                                            o.jsxs("div", {
                                                className:
                                                    "text-sm text-text-200",
                                                children: [
                                                    "Showing ",
                                                    p.logs.length,
                                                    " run(s)",
                                                ],
                                            }),
                                            o.jsx("button", {
                                                onClick: async () => {
                                                    confirm(
                                                        "Are you sure you want to clear all logs for this task?"
                                                    ) &&
                                                        (await i.clearTaskLogs(
                                                            p.taskId
                                                        ),
                                                        h(null));
                                                },
                                                className:
                                                    "text-sm text-danger-200 hover:text-danger-100",
                                                children: "Clear All Logs",
                                            }),
                                        ],
                                    }),
                            ],
                        }),
                    }),
            ],
        })
    );
}
const ke = (e) =>
        o.jsx(d, {
            ...e,
            children: o.jsx("path", {
                d: "M9.72821 2.87934C10.0318 2.10869 10.9028 1.72933 11.6735 2.03266L14.4655 3.13226C15.236 3.43593 15.6145 4.30697 15.3112 5.07758L11.3903 15.0307C11.2954 15.2717 11.1394 15.4835 10.9391 15.6459L10.8513 15.7123L7.7077 17.8979C7.29581 18.1843 6.73463 17.9917 6.57294 17.5356L6.54657 17.4409L5.737 13.6987C5.67447 13.4092 5.69977 13.107 5.80829 12.8315L9.72821 2.87934ZM6.73798 13.1987C6.70201 13.2903 6.69385 13.3906 6.71454 13.4868L7.44501 16.8627L10.28 14.892L10.3376 14.8452C10.3909 14.7949 10.4325 14.7332 10.4597 14.6645L13.0974 7.96723L9.37567 6.50141L6.73798 13.1987ZM11.3073 2.96332C11.0504 2.86217 10.7601 2.98864 10.6589 3.24555L9.74188 5.57074L13.4636 7.03754L14.3806 4.71137C14.4817 4.45445 14.3552 4.16413 14.0983 4.06293L11.3073 2.96332Z",
            }),
        }),
    Ne = (e) =>
        o.jsx(d, {
            ...e,
            children: o.jsx("path", {
                d: "M11.3232 1.5C11.9365 1.50011 12.4881 1.87396 12.7158 2.44336L13.3379 4H17.5L17.6006 4.00977C17.8285 4.0563 18 4.25829 18 4.5C18 4.7417 17.8285 4.94371 17.6006 4.99023L17.5 5H15.9629L15.0693 16.6152C15.0091 17.3965 14.3578 17.9999 13.5742 18H6.42578C5.6912 17.9999 5.07237 17.4697 4.94824 16.7598L4.93066 16.6152L4.03711 5H2.5C2.22387 5 2.00002 4.77613 2 4.5C2 4.22386 2.22386 4 2.5 4H6.66211L7.28418 2.44336L7.33105 2.33887C7.58152 1.82857 8.10177 1.5001 8.67676 1.5H11.3232ZM5.92773 16.5381C5.94778 16.7985 6.16464 16.9999 6.42578 17H13.5742C13.8354 16.9999 14.0522 16.7985 14.0723 16.5381L14.9609 5H5.03906L5.92773 16.5381ZM8.5 8C8.77613 8 8.99998 8.22388 9 8.5V13.5C9 13.7761 8.77614 14 8.5 14C8.22386 14 8 13.7761 8 13.5V8.5C8.00002 8.22388 8.22387 8 8.5 8ZM11.5 8C11.7761 8 12 8.22386 12 8.5V13.5C12 13.7761 11.7761 14 11.5 14C11.2239 14 11 13.7761 11 13.5V8.5C11 8.22386 11.2239 8 11.5 8ZM8.67676 2.5C8.49802 2.5001 8.33492 2.59525 8.24609 2.74609L8.21289 2.81445L7.73828 4H12.2617L11.7871 2.81445C11.7112 2.62471 11.5276 2.50011 11.3232 2.5H8.67676Z",
            }),
        }),
    Me = (e) =>
        o.jsx(d, {
            ...e,
            children: o.jsx("path", {
                d: "M10 14C10.5523 14 11 14.4477 11 15C11 15.5523 10.5523 16 10 16C9.44772 16 9 15.5523 9 15C9 14.4477 9.44772 14 10 14ZM10 9C10.5523 9 11 9.44772 11 10C11 10.5523 10.5523 11 10 11C9.44772 11 9 10.5523 9 10C9 9.44772 9.44772 9 10 9ZM10 4C10.5523 4 11 4.44772 11 5C11 5.55228 10.5523 6 10 6C9.44772 6 9 5.55228 9 5C9 4.44772 9.44772 4 10 4Z",
            }),
        }),
    Ee = (e) =>
        o.jsx(d, {
            ...e,
            children: o.jsx("path", {
                d: "M11.5859 2C11.9837 2.00004 12.3652 2.15818 12.6465 2.43945L15.5605 5.35352C15.8418 5.63478 16 6.01629 16 6.41406V16.5C16 17.3284 15.3284 18 14.5 18H5.5C4.72334 18 4.08461 17.4097 4.00781 16.6533L4 16.5V3.5C4 2.67157 4.67157 2 5.5 2H11.5859ZM5.5 3C5.22386 3 5 3.22386 5 3.5V16.5C5 16.7761 5.22386 17 5.5 17H14.5C14.7761 17 15 16.7761 15 16.5V7H12.5C11.6716 7 11 6.32843 11 5.5V3H5.5ZM12.54 13.3037C12.6486 13.05 12.9425 12.9317 13.1963 13.04C13.45 13.1486 13.5683 13.4425 13.46 13.6963C13.1651 14.3853 12.589 15 11.7998 15C11.3132 14.9999 10.908 14.7663 10.5996 14.4258C10.2913 14.7661 9.88667 14.9999 9.40039 15C8.91365 15 8.50769 14.7665 8.19922 14.4258C7.89083 14.7661 7.48636 15 7 15C6.72386 15 6.5 14.7761 6.5 14.5C6.5 14.2239 6.72386 14 7 14C7.21245 14 7.51918 13.8199 7.74023 13.3037L7.77441 13.2373C7.86451 13.0913 8.02513 13 8.2002 13C8.40022 13.0001 8.58145 13.1198 8.66016 13.3037C8.88121 13.8198 9.18796 14 9.40039 14C9.61284 13.9998 9.9197 13.8197 10.1406 13.3037L10.1748 13.2373C10.2649 13.0915 10.4248 13.0001 10.5996 13C10.7997 13 10.9808 13.1198 11.0596 13.3037C11.2806 13.8198 11.5874 13.9999 11.7998 14C12.0122 14 12.319 13.8198 12.54 13.3037ZM12.54 9.30371C12.6486 9.05001 12.9425 8.93174 13.1963 9.04004C13.45 9.14863 13.5683 9.44253 13.46 9.69629C13.1651 10.3853 12.589 11 11.7998 11C11.3132 10.9999 10.908 10.7663 10.5996 10.4258C10.2913 10.7661 9.88667 10.9999 9.40039 11C8.91365 11 8.50769 10.7665 8.19922 10.4258C7.89083 10.7661 7.48636 11 7 11C6.72386 11 6.5 10.7761 6.5 10.5C6.5 10.2239 6.72386 10 7 10C7.21245 10 7.51918 9.8199 7.74023 9.30371L7.77441 9.2373C7.86451 9.09126 8.02513 9 8.2002 9C8.40022 9.00008 8.58145 9.11981 8.66016 9.30371C8.88121 9.8198 9.18796 10 9.40039 10C9.61284 9.99978 9.9197 9.81969 10.1406 9.30371L10.1748 9.2373C10.2649 9.09147 10.4248 9.00014 10.5996 9C10.7997 9 10.9808 9.11975 11.0596 9.30371C11.2806 9.8198 11.5874 9.99989 11.7998 10C12.0122 10 12.319 9.81985 12.54 9.30371ZM12 5.5C12 5.77614 12.2239 6 12.5 6H14.793L12 3.20703V5.5Z",
            }),
        }),
    _e = [
        {
            category: "general",
            label: "General",
            prompts: [
                {
                    prompt: "Summarize this page and extract the key insights, main arguments, and important data points.",
                    command: "summarize",
                },
                {
                    prompt: "Research this topic by visiting multiple authoritative websites and gathering key information. Open each source in a new tab, read through the content, and summarize the main findings from each source.",
                    command: "research",
                },
                {
                    prompt: "Compare prices and features for this product across at least 5 different websites. Create a comparison table showing: price, shipping costs, delivery time, return policy, and any special features or bundles. Highlight the best overall value and explain why.",
                    command: "compare-prices",
                },
                {
                    prompt: "Fill out this form or application with the information I provide. Before submitting, show me a screenshot of the completed form for review. If there are multiple steps, take a screenshot at each step so I can verify the information is correct.",
                    command: "fill-form",
                },
                {
                    prompt: "Extract all the important data from this page (tables, lists, contact info, prices, etc.) and organize it in a clear, structured format that I can easily copy.",
                    command: "extract",
                },
                {
                    prompt: "Find and click through all the links on this page to discover what's available. Create a summary of what each major section or link leads to.",
                    command: "explore",
                },
            ],
        },
        {
            category: "email",
            label: "Email",
            prompts: [
                {
                    prompt: "Go through my recent emails and help me unsubscribe from promotional/marketing emails. \n\nFocus on: retail promotions, marketing newsletters, sales emails, and automated promotional content. DO NOT unsubscribe from: transactional emails (receipts, shipping notifications), account security emails, or emails that appear to be personal/conversational. \n\nStart with emails from the last 2 weeks. Before unsubscribing from anything, give me a full list of the different emails you plan to unsubscribe from so I can confirm you're identifying the right types of emails. When you do this, make sure to ask me if there's any of those emails you should not unsubscribe from.\n\nFor each promotional email you find: (1) Look for and click the native \"unsubscribe\" button from google (top of the email, next to sender email address); (2) Keep a running list of what you've unsubscribed from.",
                    command: "unsubscribe",
                },
                {
                    prompt: "Go through my email inbox and archive all emails where: (A) I don't need to take any actions; AND (B) where the email does not appear to be from an actual human (personal tone, specific to me, conversational).\n\nIf an email only meets one of those two criteria, don't archive it.\n\nEmails to archive covers things like general notifications, calendar invitations / acceptances, promotions etc.\n\nRemember – the archive button is the one that is second on the left. It has a down arrow sign within a folder. Make sure that you are not clicking the 'labels' button (second from the right, rectangular type of button that points right), and don't press \"move to\" as well (third from the right, folder icon with right arrow). DO NOT MARK AS SPAM (which is third button from left, the exclamation mark (\"report spam\" button).\n\nBefore you click to archive the first time, take a screenshot when you hover on the \"archive\" button to confirm that you are taking the action intended.\n\nAfter you click to archive, make sure to take a screenshot before taking any further actions so that you don't get lost.\n\nAlso archive any google automatic reminder emails for following up on emails I've sent in the past that haven't gotten a response.",
                    command: "archive",
                },
                {
                    prompt: "Go through my inbox and draft thoughtful responses to emails that require my attention. For each email that needs a response: \n\n1) Read the full context and any previous thread messages within that same email chain; (2) Draft a response that maintains my professional tone while being warm and helpful; (3) Save as a draft but DO NOT send. Once you've written the draft, Click on the \"back\" button in the top bar, which is the far left button and directly on left of the archive button, which takes you back to inbox and automatically saves the draft. Focus on emails from the last 3 days.\n\nOnly click into emails that you think need a response when looking at the sender and subject line – don't click into automated notifications, calendar invites etc.\n\nFor an email that needs a response, make sure you click in and expand each of the previous emails within the chain. You can see the collapsed preview state in the middle / top side of the email chain, with the number of how many previous emails are in the thread. Make sure to click into each one to get all the context, don't skip out on this.\n\nAfter you've drafted the email, click on the \"back to inbox\" button (left pointing arrow) that is the far left button on the top bar (the button is on the left of the archive button). This will take you back to inbox, and you can then go onto the next email.",
                    command: "draft-responses",
                },
                {
                    prompt: "Extract action items and deadlines from all unread emails and create a prioritized task list.",
                    command: "actions",
                },
                {
                    prompt: "Go through my sent emails from the last week and identify any that haven't received a response. Create a list of who I'm waiting to hear back from and what about.",
                    command: "follow-ups",
                },
                {
                    prompt: "Review my email drafts folder and help me finish or send any drafts that have been sitting there. Show me each draft and ask what action to take.",
                    command: "review-drafts",
                },
            ],
        },
        {
            category: "docs",
            label: "Docs",
            prompts: [
                {
                    prompt: "Create a comprehensive document from my outline, researching and writing each section with proper formatting.",
                    command: "create-doc",
                },
                {
                    prompt: "Review this document for clarity, grammar, structure, and factual accuracy, then implement improvements.",
                    command: "review",
                },
                {
                    prompt: "Generate an executive summary and key takeaways from this long document.",
                    command: "summarize-doc",
                },
                {
                    prompt: "Convert this document to different formats while preserving all formatting, images, and data.",
                    command: "convert",
                },
                {
                    prompt: "Merge multiple documents into one cohesive file, removing duplicates and organizing content logically.",
                    command: "merge",
                },
                {
                    prompt: "Create a presentation from this document with slides, speaker notes, and visual elements.",
                    command: "present",
                },
            ],
        },
        {
            category: "calendar",
            label: "Calendar",
            prompts: [
                {
                    prompt: "Find the optimal meeting time for all participants across different time zones and schedule it.",
                    command: "schedule",
                },
                {
                    prompt: "Analyze my calendar patterns and suggest ways to optimize for productivity and work-life balance.",
                    command: "optimize",
                },
                {
                    prompt: "Resolve all scheduling conflicts by proposing alternative times and notifying affected parties.",
                    command: "conflicts",
                },
                {
                    prompt: "Block focus time for deep work based on my priorities and energy patterns throughout the day.",
                    command: "focus",
                },
                {
                    prompt: "Plan a multi-day event with sessions, breaks, and logistics, sending invites to all participants.",
                    command: "event",
                },
                {
                    prompt: "Create recurring meetings with smart scheduling that avoids holidays and conflicts.",
                    command: "recurring",
                },
            ],
        },
        {
            category: "linkedin",
            label: "LinkedIn",
            prompts: [
                {
                    prompt: "Write an engaging LinkedIn post about this topic that will resonate with my professional network.",
                    command: "post",
                },
                {
                    prompt: "Optimize my entire LinkedIn profile with keywords, compelling descriptions, and strategic positioning.",
                    command: "profile",
                },
                {
                    prompt: "Identify and connect with relevant professionals in my industry with personalized messages.",
                    command: "network",
                },
                {
                    prompt: "Search for jobs matching my skills, apply with tailored resumes, and track application status.",
                    command: "jobs",
                },
                {
                    prompt: "Research this company's culture, recent news, and key employees to prepare for outreach or interviews.",
                    command: "company",
                },
                {
                    prompt: "Analyze my LinkedIn analytics and suggest content strategies to increase engagement and reach.",
                    command: "analytics",
                },
            ],
        },
    ];
function Se({
    isOpen: t,
    onClose: n,
    title: a,
    subtitle: r,
    children: s,
    modalSize: i = "md",
    hasCloseButton: l = !0,
    closeOnEscapeKeydown: d = !0,
    closeOnClickOutside: p = !0,
    className: h,
    fullWidth: f = !0,
    fullHeight: x = !1,
}) {
    const [g, v] = e.useState(!1),
        b = e.useRef(null),
        y = e.useRef(null);
    if (
        (e.useEffect(() => {
            if (!t) {
                const e = setTimeout(() => {
                    v(!1), y.current && (y.current.focus(), (y.current = null));
                }, 125);
                return () => clearTimeout(e);
            }
            v(!0), (y.current = document.activeElement);
        }, [t]),
        e.useEffect(() => {
            if (!t || !d) return;
            const e = (e) => {
                "Escape" === e.key && (e.stopPropagation(), n());
            };
            return (
                document.addEventListener("keydown", e),
                () => document.removeEventListener("keydown", e)
            );
        }, [t, n, d]),
        e.useEffect(() => {
            if (!t || !p) return;
            const e = (e) => {
                    b.current && !b.current.contains(e.target) && n();
                },
                a = setTimeout(() => {
                    document.addEventListener("mousedown", e);
                }, 100);
            return () => {
                clearTimeout(a), document.removeEventListener("mousedown", e);
            };
        }, [t, n, p]),
        !g)
    )
        return null;
    return o.jsx("div", {
        className: u(
            "fixed inset-0 z-50 grid items-center justify-items-center",
            "overflow-y-auto p-4 md:p-10",
            t && "animate-[fade_250ms_ease-in_forwards]",
            !t && "animate-[fade_125ms_ease-out_reverse_forwards]"
        ),
        style: {
            backgroundColor: "rgba(0, 0, 0, 0.5)",
            backdropFilter: "brightness(0.75)",
        },
        children: o.jsxs("div", {
            ref: b,
            className: u(
                "flex flex-col focus:outline-none relative",
                "text-text-100 text-left shadow-xl",
                "border-[0.5px] border-border-300 rounded-2xl",
                "p-4 md:p-6 align-middle bg-bg-000",
                "min-w-0",
                f && "w-full",
                x && "h-full",
                {
                    sm: "max-w-sm",
                    md: "max-w-md",
                    lg: "max-w-lg",
                    xl: "max-w-3xl",
                    "2xl": "max-w-5xl",
                    "3xl": "max-w-6xl",
                }[i],
                t && "animate-[zoom_250ms_ease-in_forwards]",
                !t && "animate-[zoom_125ms_ease-out_reverse_forwards]",
                h
            ),
            children: [
                (a || l) &&
                    o.jsxs("div", {
                        className: u(
                            "flex items-center gap-4",
                            a ? "justify-between" : "justify-end"
                        ),
                        children: [
                            a &&
                                o.jsx("h2", {
                                    className:
                                        "font-xl-bold text-text-100 flex w-full min-w-0 items-center leading-6 break-words",
                                    children: o.jsx("span", {
                                        className: "[overflow-wrap:anywhere]",
                                        children: a,
                                    }),
                                }),
                            l &&
                                o.jsx(m, {
                                    size: "icon_sm",
                                    variant: "ghost",
                                    className:
                                        "!text-text-500 hover:!text-text-400 -mx-2",
                                    onClick: n,
                                    children: o.jsx(c, { size: 16 }),
                                }),
                        ],
                    }),
                r &&
                    o.jsx("p", {
                        className: "text-text-300 mb-2 text-sm",
                        children: r,
                    }),
                o.jsx("div", {
                    className: u(
                        "min-h-full",
                        (a || r) && "mt-4",
                        x && "flex-1"
                    ),
                    children: s,
                }),
            ],
        }),
    });
}
function Le({ children: e, layout: t = "right", className: n }) {
    return o.jsx("div", {
        className: u(
            "mt-4 flex flex-col gap-2",
            "left" === t && "sm:flex-row",
            "center" === t && "justify-center sm:flex-row",
            "right" === t && "sm:flex-row justify-end",
            "between" === t && "justify-between sm:flex-row",
            n
        ),
        children: e,
    });
}
_e.flatMap((e) => e.prompts);
if ("undefined" != typeof document) {
    const e = document.createElement("style");
    (e.textContent =
        "\n@keyframes zoom {\n  from {\n    opacity: 0;\n    transform: scale(0.95);\n  }\n  to {\n    opacity: 1;\n    transform: scale(1);\n  }\n}\n\n@keyframes fade {\n  from {\n    opacity: 0;\n  }\n  to {\n    opacity: 1;\n  }\n}\n"),
        document.head.appendChild(e);
}
function De({
    options: t,
    onSelect: n,
    value: a,
    initialKey: r,
    testId: s,
    itemClassName: i,
}) {
    const [l, c] = e.useState(a || r),
        d = e.useRef(null),
        m = e.useRef(null),
        [p, h] = e.useState(!1),
        f = e.useRef(!1);
    e.useEffect(() => {
        void 0 !== a && c(a);
    }, [a]),
        e.useEffect(() => {
            const e = d.current,
                t = e?.parentElement;
            if (e && t) {
                const n = window.getComputedStyle(t),
                    a = parseFloat(n.paddingLeft),
                    r = parseFloat(n.borderRadius),
                    o = Math.max(0, r - a),
                    s = m.current;
                if (l && s) {
                    const { offsetLeft: t, offsetWidth: n } = s,
                        r = e.offsetWidth;
                    if (r > 0) {
                        const s = 100 - ((t + n - a) / r) * 100,
                            i = ((t - a) / r) * 100;
                        (e.style.clipPath = `inset(0 ${s > 0 ? s : 0}% 0 ${
                            i <= 100 ? i : 100
                        }% round ${o}px)`),
                            f.current ||
                                ((f.current = !0),
                                requestAnimationFrame(() => {
                                    h(!0);
                                }));
                    }
                } else
                    e.style.clipPath = `rect(0% ${
                        2 * o
                    }px 100% 0% round ${o}px)`;
            }
        }, [l]);
    const x =
        "flex items-center justify-center h-[28px] min-w-7 gap-1.5 px-3 rounded-lg cursor-pointer";
    return o.jsxs("div", {
        className:
            "group/segmented-control relative inline-flex w-fit h-8 text-sm font-medium bg-bg-300 p-0.5 rounded-[.625rem]",
        children: [
            t.map((e) =>
                o.jsx(
                    "button",
                    {
                        ref: l === e.key ? m : null,
                        onClick: () => {
                            return (t = e.key), c(t), void n?.(t);
                            var t;
                        },
                        "aria-label": e.ariaLabel,
                        className: u(
                            x,
                            "relative z-10 text-text-500 hover:text-text-300 transition-colors duration-[250ms]",
                            l === e.key && "!text-text-100",
                            i
                        ),
                        "data-testid": `${s}-${e.key}`,
                        children: e.label,
                    },
                    e.key
                )
            ),
            o.jsx("div", {
                "aria-hidden": !0,
                className: u(
                    "pointer-events-none absolute inset-0 p-0.5 rounded-[.625rem] transition-[opacity] duration-[250ms]",
                    !l && "opacity-0"
                ),
                style: {
                    filter: "drop-shadow(0px 0px 0.5px hsl(var(--border-300)/30%))",
                },
                children: o.jsx("div", {
                    ref: d,
                    className: u(
                        "flex bg-bg-000",
                        p && "transition-[clip-path] duration-[250ms] ease"
                    ),
                    style: { clipPath: "rect(0% 0% 100% 0%)" },
                    children: t.map((e) =>
                        o.jsx(
                            "div",
                            {
                                className: u(x, "text-text-100", i),
                                children: e.label,
                            },
                            e.key
                        )
                    ),
                }),
            }),
        ],
    });
}
function Te(e) {
    const t = e + "CollectionProvider",
        [n, a] = p(t),
        [r, i] = n(t, { collectionRef: { current: null }, itemMap: new Map() }),
        l = (e) => {
            const { scope: t, children: n } = e,
                a = s.useRef(null),
                i = s.useRef(new Map()).current;
            return o.jsx(r, {
                scope: t,
                itemMap: i,
                collectionRef: a,
                children: n,
            });
        };
    l.displayName = t;
    const c = e + "CollectionSlot",
        d = f(c),
        u = s.forwardRef((e, t) => {
            const { scope: n, children: a } = e,
                r = i(c, n),
                s = h(t, r.collectionRef);
            return o.jsx(d, { ref: s, children: a });
        });
    u.displayName = c;
    const m = e + "CollectionItemSlot",
        x = "data-radix-collection-item",
        g = f(m),
        v = s.forwardRef((e, t) => {
            const { scope: n, children: a, ...r } = e,
                l = s.useRef(null),
                c = h(t, l),
                d = i(m, n);
            return (
                s.useEffect(
                    () => (
                        d.itemMap.set(l, { ref: l, ...r }),
                        () => {
                            d.itemMap.delete(l);
                        }
                    )
                ),
                o.jsx(g, { [x]: "", ref: c, children: a })
            );
        });
    return (
        (v.displayName = m),
        [
            { Provider: l, Slot: u, ItemSlot: v },
            function (t) {
                const n = i(e + "CollectionConsumer", t);
                return s.useCallback(() => {
                    const e = n.collectionRef.current;
                    if (!e) return [];
                    const t = Array.from(e.querySelectorAll(`[${x}]`));
                    return Array.from(n.itemMap.values()).sort(
                        (e, n) =>
                            t.indexOf(e.ref.current) - t.indexOf(n.ref.current)
                    );
                }, [n.collectionRef, n.itemMap]);
            },
            a,
        ]
    );
}
var Ae = e.createContext(void 0);
function Re(t) {
    const n = e.useContext(Ae);
    return t || n || "ltr";
}
var Ve = 0;
function Ie() {
    const e = document.createElement("span");
    return (
        e.setAttribute("data-radix-focus-guard", ""),
        (e.tabIndex = 0),
        (e.style.outline = "none"),
        (e.style.opacity = "0"),
        (e.style.position = "fixed"),
        (e.style.pointerEvents = "none"),
        e
    );
}
var He = "focusScope.autoFocusOnMount",
    Pe = "focusScope.autoFocusOnUnmount",
    Fe = { bubbles: !1, cancelable: !0 },
    Ze = e.forwardRef((t, n) => {
        const {
                loop: a = !1,
                trapped: r = !1,
                onMountAutoFocus: s,
                onUnmountAutoFocus: i,
                ...l
            } = t,
            [c, d] = e.useState(null),
            u = x(s),
            m = x(i),
            p = e.useRef(null),
            f = h(n, (e) => d(e)),
            v = e.useRef({
                paused: !1,
                pause() {
                    this.paused = !0;
                },
                resume() {
                    this.paused = !1;
                },
            }).current;
        e.useEffect(() => {
            if (r) {
                let e = function (e) {
                        if (v.paused || !c) return;
                        const t = e.target;
                        c.contains(t)
                            ? (p.current = t)
                            : Ue(p.current, { select: !0 });
                    },
                    t = function (e) {
                        if (v.paused || !c) return;
                        const t = e.relatedTarget;
                        null !== t &&
                            (c.contains(t) || Ue(p.current, { select: !0 }));
                    },
                    n = function (e) {
                        if (document.activeElement === document.body)
                            for (const t of e)
                                t.removedNodes.length > 0 && Ue(c);
                    };
                document.addEventListener("focusin", e),
                    document.addEventListener("focusout", t);
                const a = new MutationObserver(n);
                return (
                    c && a.observe(c, { childList: !0, subtree: !0 }),
                    () => {
                        document.removeEventListener("focusin", e),
                            document.removeEventListener("focusout", t),
                            a.disconnect();
                    }
                );
            }
        }, [r, c, v.paused]),
            e.useEffect(() => {
                if (c) {
                    Be.add(v);
                    const t = document.activeElement;
                    if (!c.contains(t)) {
                        const n = new CustomEvent(He, Fe);
                        c.addEventListener(He, u),
                            c.dispatchEvent(n),
                            n.defaultPrevented ||
                                (!(function (e, { select: t = !1 } = {}) {
                                    const n = document.activeElement;
                                    for (const a of e)
                                        if (
                                            (Ue(a, { select: t }),
                                            document.activeElement !== n)
                                        )
                                            return;
                                })(
                                    ((e = Oe(c)),
                                    e.filter((e) => "A" !== e.tagName)),
                                    { select: !0 }
                                ),
                                document.activeElement === t && Ue(c));
                    }
                    return () => {
                        c.removeEventListener(He, u),
                            setTimeout(() => {
                                const e = new CustomEvent(Pe, Fe);
                                c.addEventListener(Pe, m),
                                    c.dispatchEvent(e),
                                    e.defaultPrevented ||
                                        Ue(t ?? document.body, { select: !0 }),
                                    c.removeEventListener(Pe, m),
                                    Be.remove(v);
                            }, 0);
                    };
                }
                var e;
            }, [c, u, m, v]);
        const b = e.useCallback(
            (e) => {
                if (!a && !r) return;
                if (v.paused) return;
                const t =
                        "Tab" === e.key &&
                        !e.altKey &&
                        !e.ctrlKey &&
                        !e.metaKey,
                    n = document.activeElement;
                if (t && n) {
                    const t = e.currentTarget,
                        [r, o] = (function (e) {
                            const t = Oe(e),
                                n = ze(t, e),
                                a = ze(t.reverse(), e);
                            return [n, a];
                        })(t);
                    r && o
                        ? e.shiftKey || n !== o
                            ? e.shiftKey &&
                              n === r &&
                              (e.preventDefault(), a && Ue(o, { select: !0 }))
                            : (e.preventDefault(), a && Ue(r, { select: !0 }))
                        : n === t && e.preventDefault();
                }
            },
            [a, r, v.paused]
        );
        return o.jsx(g.div, { tabIndex: -1, ...l, ref: f, onKeyDown: b });
    });
function Oe(e) {
    const t = [],
        n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
            acceptNode: (e) => {
                const t = "INPUT" === e.tagName && "hidden" === e.type;
                return e.disabled || e.hidden || t
                    ? NodeFilter.FILTER_SKIP
                    : e.tabIndex >= 0
                    ? NodeFilter.FILTER_ACCEPT
                    : NodeFilter.FILTER_SKIP;
            },
        });
    for (; n.nextNode(); ) t.push(n.currentNode);
    return t;
}
function ze(e, t) {
    for (const n of e) if (!Ke(n, { upTo: t })) return n;
}
function Ke(e, { upTo: t }) {
    if ("hidden" === getComputedStyle(e).visibility) return !0;
    for (; e; ) {
        if (void 0 !== t && e === t) return !1;
        if ("none" === getComputedStyle(e).display) return !0;
        e = e.parentElement;
    }
    return !1;
}
function Ue(e, { select: t = !1 } = {}) {
    if (e && e.focus) {
        const n = document.activeElement;
        e.focus({ preventScroll: !0 }),
            e !== n &&
                (function (e) {
                    return e instanceof HTMLInputElement && "select" in e;
                })(e) &&
                t &&
                e.select();
    }
}
Ze.displayName = "FocusScope";
var Be = (function () {
    let e = [];
    return {
        add(t) {
            const n = e[0];
            t !== n && n?.pause(), (e = Ge(e, t)), e.unshift(t);
        },
        remove(t) {
            (e = Ge(e, t)), e[0]?.resume();
        },
    };
})();
function Ge(e, t) {
    const n = [...e],
        a = n.indexOf(t);
    return -1 !== a && n.splice(a, 1), n;
}
var $e = "rovingFocusGroup.onEntryFocus",
    We = { bubbles: !1, cancelable: !0 },
    Ye = "RovingFocusGroup",
    [qe, Xe, Je] = Te(Ye),
    [Qe, et] = p(Ye, [Je]),
    [tt, nt] = Qe(Ye),
    at = e.forwardRef((e, t) =>
        o.jsx(qe.Provider, {
            scope: e.__scopeRovingFocusGroup,
            children: o.jsx(qe.Slot, {
                scope: e.__scopeRovingFocusGroup,
                children: o.jsx(rt, { ...e, ref: t }),
            }),
        })
    );
at.displayName = Ye;
var rt = e.forwardRef((t, n) => {
        const {
                __scopeRovingFocusGroup: a,
                orientation: r,
                loop: s = !1,
                dir: i,
                currentTabStopId: l,
                defaultCurrentTabStopId: c,
                onCurrentTabStopIdChange: d,
                onEntryFocus: u,
                preventScrollOnEntryFocus: m = !1,
                ...p
            } = t,
            f = e.useRef(null),
            v = h(n, f),
            w = Re(i),
            [j, C] = y({
                prop: l,
                defaultProp: c ?? null,
                onChange: d,
                caller: Ye,
            }),
            [k, N] = e.useState(!1),
            M = x(u),
            E = Xe(a),
            _ = e.useRef(!1),
            [S, L] = e.useState(0);
        return (
            e.useEffect(() => {
                const e = f.current;
                if (e)
                    return (
                        e.addEventListener($e, M),
                        () => e.removeEventListener($e, M)
                    );
            }, [M]),
            o.jsx(tt, {
                scope: a,
                orientation: r,
                dir: w,
                loop: s,
                currentTabStopId: j,
                onItemFocus: e.useCallback((e) => C(e), [C]),
                onItemShiftTab: e.useCallback(() => N(!0), []),
                onFocusableItemAdd: e.useCallback(() => L((e) => e + 1), []),
                onFocusableItemRemove: e.useCallback(() => L((e) => e - 1), []),
                children: o.jsx(g.div, {
                    tabIndex: k || 0 === S ? -1 : 0,
                    "data-orientation": r,
                    ...p,
                    ref: v,
                    style: { outline: "none", ...t.style },
                    onMouseDown: b(t.onMouseDown, () => {
                        _.current = !0;
                    }),
                    onFocus: b(t.onFocus, (e) => {
                        const t = !_.current;
                        if (e.target === e.currentTarget && t && !k) {
                            const t = new CustomEvent($e, We);
                            if (
                                (e.currentTarget.dispatchEvent(t),
                                !t.defaultPrevented)
                            ) {
                                const e = E().filter((e) => e.focusable);
                                lt(
                                    [
                                        e.find((e) => e.active),
                                        e.find((e) => e.id === j),
                                        ...e,
                                    ]
                                        .filter(Boolean)
                                        .map((e) => e.ref.current),
                                    m
                                );
                            }
                        }
                        _.current = !1;
                    }),
                    onBlur: b(t.onBlur, () => N(!1)),
                }),
            })
        );
    }),
    ot = "RovingFocusGroupItem",
    st = e.forwardRef((t, n) => {
        const {
                __scopeRovingFocusGroup: a,
                focusable: r = !0,
                active: s = !1,
                tabStopId: i,
                children: l,
                ...c
            } = t,
            d = v(),
            u = i || d,
            m = nt(ot, a),
            p = m.currentTabStopId === u,
            h = Xe(a),
            {
                onFocusableItemAdd: f,
                onFocusableItemRemove: x,
                currentTabStopId: y,
            } = m;
        return (
            e.useEffect(() => {
                if (r) return f(), () => x();
            }, [r, f, x]),
            o.jsx(qe.ItemSlot, {
                scope: a,
                id: u,
                focusable: r,
                active: s,
                children: o.jsx(g.span, {
                    tabIndex: p ? 0 : -1,
                    "data-orientation": m.orientation,
                    ...c,
                    ref: n,
                    onMouseDown: b(t.onMouseDown, (e) => {
                        r ? m.onItemFocus(u) : e.preventDefault();
                    }),
                    onFocus: b(t.onFocus, () => m.onItemFocus(u)),
                    onKeyDown: b(t.onKeyDown, (e) => {
                        if ("Tab" === e.key && e.shiftKey)
                            return void m.onItemShiftTab();
                        if (e.target !== e.currentTarget) return;
                        const t = (function (e, t, n) {
                            const a = (function (e, t) {
                                return "rtl" !== t
                                    ? e
                                    : "ArrowLeft" === e
                                    ? "ArrowRight"
                                    : "ArrowRight" === e
                                    ? "ArrowLeft"
                                    : e;
                            })(e.key, n);
                            return ("vertical" === t &&
                                ["ArrowLeft", "ArrowRight"].includes(a)) ||
                                ("horizontal" === t &&
                                    ["ArrowUp", "ArrowDown"].includes(a))
                                ? void 0
                                : it[a];
                        })(e, m.orientation, m.dir);
                        if (void 0 !== t) {
                            if (
                                e.metaKey ||
                                e.ctrlKey ||
                                e.altKey ||
                                e.shiftKey
                            )
                                return;
                            e.preventDefault();
                            let r = h()
                                .filter((e) => e.focusable)
                                .map((e) => e.ref.current);
                            if ("last" === t) r.reverse();
                            else if ("prev" === t || "next" === t) {
                                "prev" === t && r.reverse();
                                const o = r.indexOf(e.currentTarget);
                                r = m.loop
                                    ? ((a = o + 1),
                                      (n = r).map(
                                          (e, t) => n[(a + t) % n.length]
                                      ))
                                    : r.slice(o + 1);
                            }
                            setTimeout(() => lt(r));
                        }
                        var n, a;
                    }),
                    children:
                        "function" == typeof l
                            ? l({ isCurrentTabStop: p, hasTabStop: null != y })
                            : l,
                }),
            })
        );
    });
st.displayName = ot;
var it = {
    ArrowLeft: "prev",
    ArrowUp: "prev",
    ArrowRight: "next",
    ArrowDown: "next",
    PageUp: "first",
    Home: "first",
    PageDown: "last",
    End: "last",
};
function lt(e, t = !1) {
    const n = document.activeElement;
    for (const a of e) {
        if (a === n) return;
        if ((a.focus({ preventScroll: t }), document.activeElement !== n))
            return;
    }
}
var ct = at,
    dt = st,
    ut = new WeakMap(),
    mt = new WeakMap(),
    pt = {},
    ht = 0,
    ft = function (e) {
        return e && (e.host || ft(e.parentNode));
    },
    xt = function (e, t, n, a) {
        var r = (function (e, t) {
            return t
                .map(function (t) {
                    if (e.contains(t)) return t;
                    var n = ft(t);
                    return n && e.contains(n) ? n : null;
                })
                .filter(function (e) {
                    return Boolean(e);
                });
        })(t, Array.isArray(e) ? e : [e]);
        pt[n] || (pt[n] = new WeakMap());
        var o = pt[n],
            s = [],
            i = new Set(),
            l = new Set(r),
            c = function (e) {
                e && !i.has(e) && (i.add(e), c(e.parentNode));
            };
        r.forEach(c);
        var d = function (e) {
            e &&
                !l.has(e) &&
                Array.prototype.forEach.call(e.children, function (e) {
                    if (i.has(e)) d(e);
                    else
                        try {
                            var t = e.getAttribute(a),
                                r = null !== t && "false" !== t,
                                l = (ut.get(e) || 0) + 1,
                                c = (o.get(e) || 0) + 1;
                            ut.set(e, l),
                                o.set(e, c),
                                s.push(e),
                                1 === l && r && mt.set(e, !0),
                                1 === c && e.setAttribute(n, "true"),
                                r || e.setAttribute(a, "true");
                        } catch (u) {}
                });
        };
        return (
            d(t),
            i.clear(),
            ht++,
            function () {
                s.forEach(function (e) {
                    var t = ut.get(e) - 1,
                        r = o.get(e) - 1;
                    ut.set(e, t),
                        o.set(e, r),
                        t || (mt.has(e) || e.removeAttribute(a), mt.delete(e)),
                        r || e.removeAttribute(n);
                }),
                    --ht ||
                        ((ut = new WeakMap()),
                        (ut = new WeakMap()),
                        (mt = new WeakMap()),
                        (pt = {}));
            }
        );
    },
    gt = function (e, t, n) {
        void 0 === n && (n = "data-aria-hidden");
        var a = Array.from(Array.isArray(e) ? e : [e]),
            r = (function (e) {
                return "undefined" == typeof document
                    ? null
                    : (Array.isArray(e) ? e[0] : e).ownerDocument.body;
            })(e);
        return r
            ? (a.push.apply(
                  a,
                  Array.from(r.querySelectorAll("[aria-live], script"))
              ),
              xt(a, r, n, "aria-hidden"))
            : function () {
                  return null;
              };
    },
    vt = "right-scroll-bar-position",
    bt = "width-before-scroll-bar";
function yt(e, t) {
    return "function" == typeof e ? e(t) : e && (e.current = t), e;
}
var wt = "undefined" != typeof window ? e.useLayoutEffect : e.useEffect,
    jt = new WeakMap();
function Ct(t, n) {
    var a,
        r,
        o,
        s =
            ((a = null),
            (r = function (e) {
                return t.forEach(function (t) {
                    return yt(t, e);
                });
            }),
            ((o = e.useState(function () {
                return {
                    value: a,
                    callback: r,
                    facade: {
                        get current() {
                            return o.value;
                        },
                        set current(e) {
                            var t = o.value;
                            t !== e && ((o.value = e), o.callback(e, t));
                        },
                    },
                };
            })[0]).callback = r),
            o.facade);
    return (
        wt(
            function () {
                var e = jt.get(s);
                if (e) {
                    var n = new Set(e),
                        a = new Set(t),
                        r = s.current;
                    n.forEach(function (e) {
                        a.has(e) || yt(e, null);
                    }),
                        a.forEach(function (e) {
                            n.has(e) || yt(e, r);
                        });
                }
                jt.set(s, t);
            },
            [t]
        ),
        s
    );
}
function kt(e) {
    return e;
}
var Nt = function (t) {
    var n = t.sideCar,
        a = j(t, ["sideCar"]);
    if (!n)
        throw new Error(
            "Sidecar: please provide `sideCar` property to import the right car"
        );
    var r = n.read();
    if (!r) throw new Error("Sidecar medium not found");
    return e.createElement(r, w({}, a));
};
Nt.isSideCarExport = !0;
var Mt = (function (e) {
        void 0 === e && (e = {});
        var t = (function (e, t) {
            void 0 === t && (t = kt);
            var n = [],
                a = !1;
            return {
                read: function () {
                    if (a)
                        throw new Error(
                            "Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`."
                        );
                    return n.length ? n[n.length - 1] : e;
                },
                useMedium: function (e) {
                    var r = t(e, a);
                    return (
                        n.push(r),
                        function () {
                            n = n.filter(function (e) {
                                return e !== r;
                            });
                        }
                    );
                },
                assignSyncMedium: function (e) {
                    for (a = !0; n.length; ) {
                        var t = n;
                        (n = []), t.forEach(e);
                    }
                    n = {
                        push: function (t) {
                            return e(t);
                        },
                        filter: function () {
                            return n;
                        },
                    };
                },
                assignMedium: function (e) {
                    a = !0;
                    var t = [];
                    if (n.length) {
                        var r = n;
                        (n = []), r.forEach(e), (t = n);
                    }
                    var o = function () {
                            var n = t;
                            (t = []), n.forEach(e);
                        },
                        s = function () {
                            return Promise.resolve().then(o);
                        };
                    s(),
                        (n = {
                            push: function (e) {
                                t.push(e), s();
                            },
                            filter: function (e) {
                                return (t = t.filter(e)), n;
                            },
                        });
                },
            };
        })(null);
        return (t.options = w({ async: !0, ssr: !1 }, e)), t;
    })(),
    Et = function () {},
    _t = e.forwardRef(function (t, n) {
        var a = e.useRef(null),
            r = e.useState({
                onScrollCapture: Et,
                onWheelCapture: Et,
                onTouchMoveCapture: Et,
            }),
            o = r[0],
            s = r[1],
            i = t.forwardProps,
            l = t.children,
            c = t.className,
            d = t.removeScrollBar,
            u = t.enabled,
            m = t.shards,
            p = t.sideCar,
            h = t.noRelative,
            f = t.noIsolation,
            x = t.inert,
            g = t.allowPinchZoom,
            v = t.as,
            b = void 0 === v ? "div" : v,
            y = t.gapMode,
            C = j(t, [
                "forwardProps",
                "children",
                "className",
                "removeScrollBar",
                "enabled",
                "shards",
                "sideCar",
                "noRelative",
                "noIsolation",
                "inert",
                "allowPinchZoom",
                "as",
                "gapMode",
            ]),
            k = p,
            N = Ct([a, n]),
            M = w(w({}, C), o);
        return e.createElement(
            e.Fragment,
            null,
            u &&
                e.createElement(k, {
                    sideCar: Mt,
                    removeScrollBar: d,
                    shards: m,
                    noRelative: h,
                    noIsolation: f,
                    inert: x,
                    setCallbacks: s,
                    allowPinchZoom: !!g,
                    lockRef: a,
                    gapMode: y,
                }),
            i
                ? e.cloneElement(e.Children.only(l), w(w({}, M), { ref: N }))
                : e.createElement(b, w({}, M, { className: c, ref: N }), l)
        );
    });
(_t.defaultProps = { enabled: !0, removeScrollBar: !0, inert: !1 }),
    (_t.classNames = { fullWidth: bt, zeroRight: vt });
function St() {
    if (!document) return null;
    var e = document.createElement("style");
    e.type = "text/css";
    var t = (function () {
        if ("undefined" != typeof __webpack_nonce__) return __webpack_nonce__;
    })();
    return t && e.setAttribute("nonce", t), e;
}
var Lt = function () {
        var e = 0,
            t = null;
        return {
            add: function (n) {
                var a, r;
                0 == e &&
                    (t = St()) &&
                    ((r = n),
                    (a = t).styleSheet
                        ? (a.styleSheet.cssText = r)
                        : a.appendChild(document.createTextNode(r)),
                    (function (e) {
                        (
                            document.head ||
                            document.getElementsByTagName("head")[0]
                        ).appendChild(e);
                    })(t)),
                    e++;
            },
            remove: function () {
                !--e &&
                    t &&
                    (t.parentNode && t.parentNode.removeChild(t), (t = null));
            },
        };
    },
    Dt = function () {
        var t,
            n =
                ((t = Lt()),
                function (n, a) {
                    e.useEffect(
                        function () {
                            return (
                                t.add(n),
                                function () {
                                    t.remove();
                                }
                            );
                        },
                        [n && a]
                    );
                });
        return function (e) {
            var t = e.styles,
                a = e.dynamic;
            return n(t, a), null;
        };
    },
    Tt = { left: 0, top: 0, right: 0, gap: 0 },
    At = function (e) {
        return parseInt(e || "", 10) || 0;
    },
    Rt = function (e) {
        if ((void 0 === e && (e = "margin"), "undefined" == typeof window))
            return Tt;
        var t = (function (e) {
                var t = window.getComputedStyle(document.body),
                    n = t["padding" === e ? "paddingLeft" : "marginLeft"],
                    a = t["padding" === e ? "paddingTop" : "marginTop"],
                    r = t["padding" === e ? "paddingRight" : "marginRight"];
                return [At(n), At(a), At(r)];
            })(e),
            n = document.documentElement.clientWidth,
            a = window.innerWidth;
        return {
            left: t[0],
            top: t[1],
            right: t[2],
            gap: Math.max(0, a - n + t[2] - t[0]),
        };
    },
    Vt = Dt(),
    It = "data-scroll-locked",
    Ht = function (e, t, n, a) {
        var r = e.left,
            o = e.top,
            s = e.right,
            i = e.gap;
        return (
            void 0 === n && (n = "margin"),
            "\n  ."
                .concat("with-scroll-bars-hidden", " {\n   overflow: hidden ")
                .concat(a, ";\n   padding-right: ")
                .concat(i, "px ")
                .concat(a, ";\n  }\n  body[")
                .concat(It, "] {\n    overflow: hidden ")
                .concat(a, ";\n    overscroll-behavior: contain;\n    ")
                .concat(
                    [
                        t && "position: relative ".concat(a, ";"),
                        "margin" === n &&
                            "\n    padding-left: "
                                .concat(r, "px;\n    padding-top: ")
                                .concat(o, "px;\n    padding-right: ")
                                .concat(
                                    s,
                                    "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: "
                                )
                                .concat(i, "px ")
                                .concat(a, ";\n    "),
                        "padding" === n &&
                            "padding-right: ".concat(i, "px ").concat(a, ";"),
                    ]
                        .filter(Boolean)
                        .join(""),
                    "\n  }\n  \n  ."
                )
                .concat(vt, " {\n    right: ")
                .concat(i, "px ")
                .concat(a, ";\n  }\n  \n  .")
                .concat(bt, " {\n    margin-right: ")
                .concat(i, "px ")
                .concat(a, ";\n  }\n  \n  .")
                .concat(vt, " .")
                .concat(vt, " {\n    right: 0 ")
                .concat(a, ";\n  }\n  \n  .")
                .concat(bt, " .")
                .concat(bt, " {\n    margin-right: 0 ")
                .concat(a, ";\n  }\n  \n  body[")
                .concat(It, "] {\n    ")
                .concat("--removed-body-scroll-bar-size", ": ")
                .concat(i, "px;\n  }\n")
        );
    },
    Pt = function () {
        var e = parseInt(document.body.getAttribute(It) || "0", 10);
        return isFinite(e) ? e : 0;
    },
    Ft = function (t) {
        var n = t.noRelative,
            a = t.noImportant,
            r = t.gapMode,
            o = void 0 === r ? "margin" : r;
        e.useEffect(function () {
            return (
                document.body.setAttribute(It, (Pt() + 1).toString()),
                function () {
                    var e = Pt() - 1;
                    e <= 0
                        ? document.body.removeAttribute(It)
                        : document.body.setAttribute(It, e.toString());
                }
            );
        }, []);
        var s = e.useMemo(
            function () {
                return Rt(o);
            },
            [o]
        );
        return e.createElement(Vt, {
            styles: Ht(s, !n, o, a ? "" : "!important"),
        });
    },
    Zt = !1;
if ("undefined" != typeof window)
    try {
        var Ot = Object.defineProperty({}, "passive", {
            get: function () {
                return (Zt = !0), !0;
            },
        });
        window.addEventListener("test", Ot, Ot),
            window.removeEventListener("test", Ot, Ot);
    } catch (ir) {
        Zt = !1;
    }
var zt = !!Zt && { passive: !1 },
    Kt = function (e, t) {
        if (!(e instanceof Element)) return !1;
        var n = window.getComputedStyle(e);
        return (
            "hidden" !== n[t] &&
            !(
                n.overflowY === n.overflowX &&
                !(function (e) {
                    return "TEXTAREA" === e.tagName;
                })(e) &&
                "visible" === n[t]
            )
        );
    },
    Ut = function (e, t) {
        var n = t.ownerDocument,
            a = t;
        do {
            if (
                ("undefined" != typeof ShadowRoot &&
                    a instanceof ShadowRoot &&
                    (a = a.host),
                Bt(e, a))
            ) {
                var r = Gt(e, a);
                if (r[1] > r[2]) return !0;
            }
            a = a.parentNode;
        } while (a && a !== n.body);
        return !1;
    },
    Bt = function (e, t) {
        return "v" === e
            ? (function (e) {
                  return Kt(e, "overflowY");
              })(t)
            : (function (e) {
                  return Kt(e, "overflowX");
              })(t);
    },
    Gt = function (e, t) {
        return "v" === e
            ? [(n = t).scrollTop, n.scrollHeight, n.clientHeight]
            : (function (e) {
                  return [e.scrollLeft, e.scrollWidth, e.clientWidth];
              })(t);
        var n;
    },
    $t = function (e) {
        return "changedTouches" in e
            ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY]
            : [0, 0];
    },
    Wt = function (e) {
        return [e.deltaX, e.deltaY];
    },
    Yt = function (e) {
        return e && "current" in e ? e.current : e;
    },
    qt = function (e) {
        return "\n  .block-interactivity-"
            .concat(e, " {pointer-events: none;}\n  .allow-interactivity-")
            .concat(e, " {pointer-events: all;}\n");
    },
    Xt = 0,
    Jt = [];
function Qt(e) {
    for (var t = null; null !== e; )
        e instanceof ShadowRoot && ((t = e.host), (e = e.host)),
            (e = e.parentNode);
    return t;
}
const en =
    ((tn = function (t) {
        var n = e.useRef([]),
            a = e.useRef([0, 0]),
            r = e.useRef(),
            o = e.useState(Xt++)[0],
            s = e.useState(Dt)[0],
            i = e.useRef(t);
        e.useEffect(
            function () {
                i.current = t;
            },
            [t]
        ),
            e.useEffect(
                function () {
                    if (t.inert) {
                        document.body.classList.add(
                            "block-interactivity-".concat(o)
                        );
                        var e = C(
                            [t.lockRef.current],
                            (t.shards || []).map(Yt),
                            !0
                        ).filter(Boolean);
                        return (
                            e.forEach(function (e) {
                                return e.classList.add(
                                    "allow-interactivity-".concat(o)
                                );
                            }),
                            function () {
                                document.body.classList.remove(
                                    "block-interactivity-".concat(o)
                                ),
                                    e.forEach(function (e) {
                                        return e.classList.remove(
                                            "allow-interactivity-".concat(o)
                                        );
                                    });
                            }
                        );
                    }
                },
                [t.inert, t.lockRef.current, t.shards]
            );
        var l = e.useCallback(function (e, t) {
                if (
                    ("touches" in e && 2 === e.touches.length) ||
                    ("wheel" === e.type && e.ctrlKey)
                )
                    return !i.current.allowPinchZoom;
                var n,
                    o = $t(e),
                    s = a.current,
                    l = "deltaX" in e ? e.deltaX : s[0] - o[0],
                    c = "deltaY" in e ? e.deltaY : s[1] - o[1],
                    d = e.target,
                    u = Math.abs(l) > Math.abs(c) ? "h" : "v";
                if ("touches" in e && "h" === u && "range" === d.type)
                    return !1;
                var m = Ut(u, d);
                if (!m) return !0;
                if (
                    (m
                        ? (n = u)
                        : ((n = "v" === u ? "h" : "v"), (m = Ut(u, d))),
                    !m)
                )
                    return !1;
                if (
                    (!r.current &&
                        "changedTouches" in e &&
                        (l || c) &&
                        (r.current = n),
                    !n)
                )
                    return !0;
                var p = r.current || n;
                return (function (e, t, n, a) {
                    var r = (function (e, t) {
                            return "h" === e && "rtl" === t ? -1 : 1;
                        })(e, window.getComputedStyle(t).direction),
                        o = r * a,
                        s = n.target,
                        i = t.contains(s),
                        l = !1,
                        c = o > 0,
                        d = 0,
                        u = 0;
                    do {
                        if (!s) break;
                        var m = Gt(e, s),
                            p = m[0],
                            h = m[1] - m[2] - r * p;
                        (p || h) && Bt(e, s) && ((d += h), (u += p));
                        var f = s.parentNode;
                        s =
                            f && f.nodeType === Node.DOCUMENT_FRAGMENT_NODE
                                ? f.host
                                : f;
                    } while ((!i && s !== document.body) || (i && (t.contains(s) || t === s)));
                    return (
                        ((c && Math.abs(d) < 1) || (!c && Math.abs(u) < 1)) &&
                            (l = !0),
                        l
                    );
                })(p, t, e, "h" === p ? l : c);
            }, []),
            c = e.useCallback(function (e) {
                var t = e;
                if (Jt.length && Jt[Jt.length - 1] === s) {
                    var a = "deltaY" in t ? Wt(t) : $t(t),
                        r = n.current.filter(function (e) {
                            return (
                                e.name === t.type &&
                                (e.target === t.target ||
                                    t.target === e.shadowParent) &&
                                ((n = e.delta),
                                (r = a),
                                n[0] === r[0] && n[1] === r[1])
                            );
                            var n, r;
                        })[0];
                    if (r && r.should) t.cancelable && t.preventDefault();
                    else if (!r) {
                        var o = (i.current.shards || [])
                            .map(Yt)
                            .filter(Boolean)
                            .filter(function (e) {
                                return e.contains(t.target);
                            });
                        (o.length > 0 ? l(t, o[0]) : !i.current.noIsolation) &&
                            t.cancelable &&
                            t.preventDefault();
                    }
                }
            }, []),
            d = e.useCallback(function (e, t, a, r) {
                var o = {
                    name: e,
                    delta: t,
                    target: a,
                    should: r,
                    shadowParent: Qt(a),
                };
                n.current.push(o),
                    setTimeout(function () {
                        n.current = n.current.filter(function (e) {
                            return e !== o;
                        });
                    }, 1);
            }, []),
            u = e.useCallback(function (e) {
                (a.current = $t(e)), (r.current = void 0);
            }, []),
            m = e.useCallback(function (e) {
                d(e.type, Wt(e), e.target, l(e, t.lockRef.current));
            }, []),
            p = e.useCallback(function (e) {
                d(e.type, $t(e), e.target, l(e, t.lockRef.current));
            }, []);
        e.useEffect(function () {
            return (
                Jt.push(s),
                t.setCallbacks({
                    onScrollCapture: m,
                    onWheelCapture: m,
                    onTouchMoveCapture: p,
                }),
                document.addEventListener("wheel", c, zt),
                document.addEventListener("touchmove", c, zt),
                document.addEventListener("touchstart", u, zt),
                function () {
                    (Jt = Jt.filter(function (e) {
                        return e !== s;
                    })),
                        document.removeEventListener("wheel", c, zt),
                        document.removeEventListener("touchmove", c, zt),
                        document.removeEventListener("touchstart", u, zt);
                }
            );
        }, []);
        var h = t.removeScrollBar,
            f = t.inert;
        return e.createElement(
            e.Fragment,
            null,
            f ? e.createElement(s, { styles: qt(o) }) : null,
            h
                ? e.createElement(Ft, {
                      noRelative: t.noRelative,
                      gapMode: t.gapMode,
                  })
                : null
        );
    }),
    Mt.useMedium(tn),
    Nt);
var tn,
    nn = e.forwardRef(function (t, n) {
        return e.createElement(_t, w({}, t, { ref: n, sideCar: en }));
    });
nn.classNames = _t.classNames;
var an = ["Enter", " "],
    rn = ["ArrowUp", "PageDown", "End"],
    on = ["ArrowDown", "PageUp", "Home", ...rn],
    sn = { ltr: [...an, "ArrowRight"], rtl: [...an, "ArrowLeft"] },
    ln = { ltr: ["ArrowLeft"], rtl: ["ArrowRight"] },
    cn = "Menu",
    [dn, un, mn] = Te(cn),
    [pn, hn] = p(cn, [mn, k, et]),
    fn = k(),
    xn = et(),
    [gn, vn] = pn(cn),
    [bn, yn] = pn(cn),
    wn = (t) => {
        const {
                __scopeMenu: n,
                open: a = !1,
                children: r,
                dir: s,
                onOpenChange: i,
                modal: l = !0,
            } = t,
            c = fn(n),
            [d, u] = e.useState(null),
            m = e.useRef(!1),
            p = x(i),
            h = Re(s);
        return (
            e.useEffect(() => {
                const e = () => {
                        (m.current = !0),
                            document.addEventListener("pointerdown", t, {
                                capture: !0,
                                once: !0,
                            }),
                            document.addEventListener("pointermove", t, {
                                capture: !0,
                                once: !0,
                            });
                    },
                    t = () => (m.current = !1);
                return (
                    document.addEventListener("keydown", e, { capture: !0 }),
                    () => {
                        document.removeEventListener("keydown", e, {
                            capture: !0,
                        }),
                            document.removeEventListener("pointerdown", t, {
                                capture: !0,
                            }),
                            document.removeEventListener("pointermove", t, {
                                capture: !0,
                            });
                    }
                );
            }, []),
            o.jsx(E, {
                ...c,
                children: o.jsx(gn, {
                    scope: n,
                    open: a,
                    onOpenChange: p,
                    content: d,
                    onContentChange: u,
                    children: o.jsx(bn, {
                        scope: n,
                        onClose: e.useCallback(() => p(!1), [p]),
                        isUsingKeyboardRef: m,
                        dir: h,
                        modal: l,
                        children: r,
                    }),
                }),
            })
        );
    };
wn.displayName = cn;
var jn = e.forwardRef((e, t) => {
    const { __scopeMenu: n, ...a } = e,
        r = fn(n);
    return o.jsx(M, { ...r, ...a, ref: t });
});
jn.displayName = "MenuAnchor";
var Cn = "MenuPortal",
    [kn, Nn] = pn(Cn, { forceMount: void 0 }),
    Mn = (e) => {
        const { __scopeMenu: t, forceMount: n, children: a, container: r } = e,
            s = vn(Cn, t);
        return o.jsx(kn, {
            scope: t,
            forceMount: n,
            children: o.jsx(_, {
                present: n || s.open,
                children: o.jsx(S, { asChild: !0, container: r, children: a }),
            }),
        });
    };
Mn.displayName = Cn;
var En = "MenuContent",
    [_n, Sn] = pn(En),
    Ln = e.forwardRef((e, t) => {
        const n = Nn(En, e.__scopeMenu),
            { forceMount: a = n.forceMount, ...r } = e,
            s = vn(En, e.__scopeMenu),
            i = yn(En, e.__scopeMenu);
        return o.jsx(dn.Provider, {
            scope: e.__scopeMenu,
            children: o.jsx(_, {
                present: a || s.open,
                children: o.jsx(dn.Slot, {
                    scope: e.__scopeMenu,
                    children: i.modal
                        ? o.jsx(Dn, { ...r, ref: t })
                        : o.jsx(Tn, { ...r, ref: t }),
                }),
            }),
        });
    }),
    Dn = e.forwardRef((t, n) => {
        const a = vn(En, t.__scopeMenu),
            r = e.useRef(null),
            s = h(n, r);
        return (
            e.useEffect(() => {
                const e = r.current;
                if (e) return gt(e);
            }, []),
            o.jsx(Rn, {
                ...t,
                ref: s,
                trapFocus: a.open,
                disableOutsidePointerEvents: a.open,
                disableOutsideScroll: !0,
                onFocusOutside: b(t.onFocusOutside, (e) => e.preventDefault(), {
                    checkForDefaultPrevented: !1,
                }),
                onDismiss: () => a.onOpenChange(!1),
            })
        );
    }),
    Tn = e.forwardRef((e, t) => {
        const n = vn(En, e.__scopeMenu);
        return o.jsx(Rn, {
            ...e,
            ref: t,
            trapFocus: !1,
            disableOutsidePointerEvents: !1,
            disableOutsideScroll: !1,
            onDismiss: () => n.onOpenChange(!1),
        });
    }),
    An = f("MenuContent.ScrollLock"),
    Rn = e.forwardRef((t, n) => {
        const {
                __scopeMenu: a,
                loop: r = !1,
                trapFocus: s,
                onOpenAutoFocus: i,
                onCloseAutoFocus: l,
                disableOutsidePointerEvents: c,
                onEntryFocus: d,
                onEscapeKeyDown: u,
                onPointerDownOutside: m,
                onFocusOutside: p,
                onInteractOutside: f,
                onDismiss: x,
                disableOutsideScroll: g,
                ...v
            } = t,
            y = vn(En, a),
            w = yn(En, a),
            j = fn(a),
            C = xn(a),
            k = un(a),
            [N, M] = e.useState(null),
            E = e.useRef(null),
            _ = h(n, E, y.onContentChange),
            S = e.useRef(0),
            T = e.useRef(""),
            A = e.useRef(0),
            R = e.useRef(null),
            V = e.useRef("right"),
            I = e.useRef(0),
            H = g ? nn : e.Fragment,
            P = g ? { as: An, allowPinchZoom: !0 } : void 0,
            F = (e) => {
                const t = T.current + e,
                    n = k().filter((e) => !e.disabled),
                    a = document.activeElement,
                    r = n.find((e) => e.ref.current === a)?.textValue,
                    o = (function (e, t, n) {
                        const a =
                                t.length > 1 &&
                                Array.from(t).every((e) => e === t[0]),
                            r = a ? t[0] : t,
                            o = n ? e.indexOf(n) : -1;
                        let s =
                            ((i = e),
                            (l = Math.max(o, 0)),
                            i.map((e, t) => i[(l + t) % i.length]));
                        var i, l;
                        1 === r.length && (s = s.filter((e) => e !== n));
                        const c = s.find((e) =>
                            e.toLowerCase().startsWith(r.toLowerCase())
                        );
                        return c !== n ? c : void 0;
                    })(
                        n.map((e) => e.textValue),
                        t,
                        r
                    ),
                    s = n.find((e) => e.textValue === o)?.ref.current;
                !(function e(t) {
                    (T.current = t),
                        window.clearTimeout(S.current),
                        "" !== t &&
                            (S.current = window.setTimeout(() => e(""), 1e3));
                })(t),
                    s && setTimeout(() => s.focus());
            };
        e.useEffect(() => () => window.clearTimeout(S.current), []),
            e.useEffect(() => {
                const e = document.querySelectorAll("[data-radix-focus-guard]");
                return (
                    document.body.insertAdjacentElement(
                        "afterbegin",
                        e[0] ?? Ie()
                    ),
                    document.body.insertAdjacentElement(
                        "beforeend",
                        e[1] ?? Ie()
                    ),
                    Ve++,
                    () => {
                        1 === Ve &&
                            document
                                .querySelectorAll("[data-radix-focus-guard]")
                                .forEach((e) => e.remove()),
                            Ve--;
                    }
                );
            }, []);
        const Z = e.useCallback(
            (e) =>
                V.current === R.current?.side &&
                (function (e, t) {
                    if (!t) return !1;
                    const n = { x: e.clientX, y: e.clientY };
                    return (function (e, t) {
                        const { x: n, y: a } = e;
                        let r = !1;
                        for (
                            let o = 0, s = t.length - 1;
                            o < t.length;
                            s = o++
                        ) {
                            const e = t[o],
                                i = t[s],
                                l = e.x,
                                c = e.y,
                                d = i.x,
                                u = i.y;
                            c > a != u > a &&
                                n < ((d - l) * (a - c)) / (u - c) + l &&
                                (r = !r);
                        }
                        return r;
                    })(n, t);
                })(e, R.current?.area),
            []
        );
        return o.jsx(_n, {
            scope: a,
            searchRef: T,
            onItemEnter: e.useCallback(
                (e) => {
                    Z(e) && e.preventDefault();
                },
                [Z]
            ),
            onItemLeave: e.useCallback(
                (e) => {
                    Z(e) || (E.current?.focus(), M(null));
                },
                [Z]
            ),
            onTriggerLeave: e.useCallback(
                (e) => {
                    Z(e) && e.preventDefault();
                },
                [Z]
            ),
            pointerGraceTimerRef: A,
            onPointerGraceIntentChange: e.useCallback((e) => {
                R.current = e;
            }, []),
            children: o.jsx(H, {
                ...P,
                children: o.jsx(Ze, {
                    asChild: !0,
                    trapped: s,
                    onMountAutoFocus: b(i, (e) => {
                        e.preventDefault(),
                            E.current?.focus({ preventScroll: !0 });
                    }),
                    onUnmountAutoFocus: l,
                    children: o.jsx(L, {
                        asChild: !0,
                        disableOutsidePointerEvents: c,
                        onEscapeKeyDown: u,
                        onPointerDownOutside: m,
                        onFocusOutside: p,
                        onInteractOutside: f,
                        onDismiss: x,
                        children: o.jsx(ct, {
                            asChild: !0,
                            ...C,
                            dir: w.dir,
                            orientation: "vertical",
                            loop: r,
                            currentTabStopId: N,
                            onCurrentTabStopIdChange: M,
                            onEntryFocus: b(d, (e) => {
                                w.isUsingKeyboardRef.current ||
                                    e.preventDefault();
                            }),
                            preventScrollOnEntryFocus: !0,
                            children: o.jsx(D, {
                                role: "menu",
                                "aria-orientation": "vertical",
                                "data-state": sa(y.open),
                                "data-radix-menu-content": "",
                                dir: w.dir,
                                ...j,
                                ...v,
                                ref: _,
                                style: { outline: "none", ...v.style },
                                onKeyDown: b(v.onKeyDown, (e) => {
                                    const t =
                                            e.target.closest(
                                                "[data-radix-menu-content]"
                                            ) === e.currentTarget,
                                        n = e.ctrlKey || e.altKey || e.metaKey,
                                        a = 1 === e.key.length;
                                    t &&
                                        ("Tab" === e.key && e.preventDefault(),
                                        !n && a && F(e.key));
                                    const r = E.current;
                                    if (e.target !== r) return;
                                    if (!on.includes(e.key)) return;
                                    e.preventDefault();
                                    const o = k()
                                        .filter((e) => !e.disabled)
                                        .map((e) => e.ref.current);
                                    rn.includes(e.key) && o.reverse(),
                                        (function (e) {
                                            const t = document.activeElement;
                                            for (const n of e) {
                                                if (n === t) return;
                                                if (
                                                    (n.focus(),
                                                    document.activeElement !==
                                                        t)
                                                )
                                                    return;
                                            }
                                        })(o);
                                }),
                                onBlur: b(t.onBlur, (e) => {
                                    e.currentTarget.contains(e.target) ||
                                        (window.clearTimeout(S.current),
                                        (T.current = ""));
                                }),
                                onPointerMove: b(
                                    t.onPointerMove,
                                    ca((e) => {
                                        const t = e.target,
                                            n = I.current !== e.clientX;
                                        if (e.currentTarget.contains(t) && n) {
                                            const t =
                                                e.clientX > I.current
                                                    ? "right"
                                                    : "left";
                                            (V.current = t),
                                                (I.current = e.clientX);
                                        }
                                    })
                                ),
                            }),
                        }),
                    }),
                }),
            }),
        });
    });
Ln.displayName = En;
var Vn = e.forwardRef((e, t) => {
    const { __scopeMenu: n, ...a } = e;
    return o.jsx(g.div, { role: "group", ...a, ref: t });
});
Vn.displayName = "MenuGroup";
var In = e.forwardRef((e, t) => {
    const { __scopeMenu: n, ...a } = e;
    return o.jsx(g.div, { ...a, ref: t });
});
In.displayName = "MenuLabel";
var Hn = "MenuItem",
    Pn = "menu.itemSelect",
    Fn = e.forwardRef((t, n) => {
        const { disabled: a = !1, onSelect: r, ...s } = t,
            i = e.useRef(null),
            l = yn(Hn, t.__scopeMenu),
            c = Sn(Hn, t.__scopeMenu),
            d = h(n, i),
            u = e.useRef(!1);
        return o.jsx(Zn, {
            ...s,
            ref: d,
            disabled: a,
            onClick: b(t.onClick, () => {
                const e = i.current;
                if (!a && e) {
                    const t = new CustomEvent(Pn, {
                        bubbles: !0,
                        cancelable: !0,
                    });
                    e.addEventListener(Pn, (e) => r?.(e), { once: !0 }),
                        N(e, t),
                        t.defaultPrevented ? (u.current = !1) : l.onClose();
                }
            }),
            onPointerDown: (e) => {
                t.onPointerDown?.(e), (u.current = !0);
            },
            onPointerUp: b(t.onPointerUp, (e) => {
                u.current || e.currentTarget?.click();
            }),
            onKeyDown: b(t.onKeyDown, (e) => {
                const t = "" !== c.searchRef.current;
                a ||
                    (t && " " === e.key) ||
                    (an.includes(e.key) &&
                        (e.currentTarget.click(), e.preventDefault()));
            }),
        });
    });
Fn.displayName = Hn;
var Zn = e.forwardRef((t, n) => {
        const { __scopeMenu: a, disabled: r = !1, textValue: s, ...i } = t,
            l = Sn(Hn, a),
            c = xn(a),
            d = e.useRef(null),
            u = h(n, d),
            [m, p] = e.useState(!1),
            [f, x] = e.useState("");
        return (
            e.useEffect(() => {
                const e = d.current;
                e && x((e.textContent ?? "").trim());
            }, [i.children]),
            o.jsx(dn.ItemSlot, {
                scope: a,
                disabled: r,
                textValue: s ?? f,
                children: o.jsx(dt, {
                    asChild: !0,
                    ...c,
                    focusable: !r,
                    children: o.jsx(g.div, {
                        role: "menuitem",
                        "data-highlighted": m ? "" : void 0,
                        "aria-disabled": r || void 0,
                        "data-disabled": r ? "" : void 0,
                        ...i,
                        ref: u,
                        onPointerMove: b(
                            t.onPointerMove,
                            ca((e) => {
                                if (r) l.onItemLeave(e);
                                else if (
                                    (l.onItemEnter(e), !e.defaultPrevented)
                                ) {
                                    e.currentTarget.focus({
                                        preventScroll: !0,
                                    });
                                }
                            })
                        ),
                        onPointerLeave: b(
                            t.onPointerLeave,
                            ca((e) => l.onItemLeave(e))
                        ),
                        onFocus: b(t.onFocus, () => p(!0)),
                        onBlur: b(t.onBlur, () => p(!1)),
                    }),
                }),
            })
        );
    }),
    On = e.forwardRef((e, t) => {
        const { checked: n = !1, onCheckedChange: a, ...r } = e;
        return o.jsx(Yn, {
            scope: e.__scopeMenu,
            checked: n,
            children: o.jsx(Fn, {
                role: "menuitemcheckbox",
                "aria-checked": ia(n) ? "mixed" : n,
                ...r,
                ref: t,
                "data-state": la(n),
                onSelect: b(r.onSelect, () => a?.(!!ia(n) || !n), {
                    checkForDefaultPrevented: !1,
                }),
            }),
        });
    });
On.displayName = "MenuCheckboxItem";
var zn = "MenuRadioGroup",
    [Kn, Un] = pn(zn, { value: void 0, onValueChange: () => {} }),
    Bn = e.forwardRef((e, t) => {
        const { value: n, onValueChange: a, ...r } = e,
            s = x(a);
        return o.jsx(Kn, {
            scope: e.__scopeMenu,
            value: n,
            onValueChange: s,
            children: o.jsx(Vn, { ...r, ref: t }),
        });
    });
Bn.displayName = zn;
var Gn = "MenuRadioItem",
    $n = e.forwardRef((e, t) => {
        const { value: n, ...a } = e,
            r = Un(Gn, e.__scopeMenu),
            s = n === r.value;
        return o.jsx(Yn, {
            scope: e.__scopeMenu,
            checked: s,
            children: o.jsx(Fn, {
                role: "menuitemradio",
                "aria-checked": s,
                ...a,
                ref: t,
                "data-state": la(s),
                onSelect: b(a.onSelect, () => r.onValueChange?.(n), {
                    checkForDefaultPrevented: !1,
                }),
            }),
        });
    });
$n.displayName = Gn;
var Wn = "MenuItemIndicator",
    [Yn, qn] = pn(Wn, { checked: !1 }),
    Xn = e.forwardRef((e, t) => {
        const { __scopeMenu: n, forceMount: a, ...r } = e,
            s = qn(Wn, n);
        return o.jsx(_, {
            present: a || ia(s.checked) || !0 === s.checked,
            children: o.jsx(g.span, {
                ...r,
                ref: t,
                "data-state": la(s.checked),
            }),
        });
    });
Xn.displayName = Wn;
var Jn = e.forwardRef((e, t) => {
    const { __scopeMenu: n, ...a } = e;
    return o.jsx(g.div, {
        role: "separator",
        "aria-orientation": "horizontal",
        ...a,
        ref: t,
    });
});
Jn.displayName = "MenuSeparator";
var Qn = e.forwardRef((e, t) => {
    const { __scopeMenu: n, ...a } = e,
        r = fn(n);
    return o.jsx(T, { ...r, ...a, ref: t });
});
Qn.displayName = "MenuArrow";
var [ea, ta] = pn("MenuSub"),
    na = "MenuSubTrigger",
    aa = e.forwardRef((t, n) => {
        const a = vn(na, t.__scopeMenu),
            r = yn(na, t.__scopeMenu),
            s = ta(na, t.__scopeMenu),
            i = Sn(na, t.__scopeMenu),
            l = e.useRef(null),
            { pointerGraceTimerRef: c, onPointerGraceIntentChange: d } = i,
            u = { __scopeMenu: t.__scopeMenu },
            m = e.useCallback(() => {
                l.current && window.clearTimeout(l.current), (l.current = null);
            }, []);
        return (
            e.useEffect(() => m, [m]),
            e.useEffect(() => {
                const e = c.current;
                return () => {
                    window.clearTimeout(e), d(null);
                };
            }, [c, d]),
            o.jsx(jn, {
                asChild: !0,
                ...u,
                children: o.jsx(Zn, {
                    id: s.triggerId,
                    "aria-haspopup": "menu",
                    "aria-expanded": a.open,
                    "aria-controls": s.contentId,
                    "data-state": sa(a.open),
                    ...t,
                    ref: A(n, s.onTriggerChange),
                    onClick: (e) => {
                        t.onClick?.(e),
                            t.disabled ||
                                e.defaultPrevented ||
                                (e.currentTarget.focus(),
                                a.open || a.onOpenChange(!0));
                    },
                    onPointerMove: b(
                        t.onPointerMove,
                        ca((e) => {
                            i.onItemEnter(e),
                                e.defaultPrevented ||
                                    t.disabled ||
                                    a.open ||
                                    l.current ||
                                    (i.onPointerGraceIntentChange(null),
                                    (l.current = window.setTimeout(() => {
                                        a.onOpenChange(!0), m();
                                    }, 100)));
                        })
                    ),
                    onPointerLeave: b(
                        t.onPointerLeave,
                        ca((e) => {
                            m();
                            const t = a.content?.getBoundingClientRect();
                            if (t) {
                                const n = a.content?.dataset.side,
                                    r = "right" === n,
                                    o = r ? -5 : 5,
                                    s = t[r ? "left" : "right"],
                                    l = t[r ? "right" : "left"];
                                i.onPointerGraceIntentChange({
                                    area: [
                                        { x: e.clientX + o, y: e.clientY },
                                        { x: s, y: t.top },
                                        { x: l, y: t.top },
                                        { x: l, y: t.bottom },
                                        { x: s, y: t.bottom },
                                    ],
                                    side: n,
                                }),
                                    window.clearTimeout(c.current),
                                    (c.current = window.setTimeout(
                                        () =>
                                            i.onPointerGraceIntentChange(null),
                                        300
                                    ));
                            } else {
                                if ((i.onTriggerLeave(e), e.defaultPrevented))
                                    return;
                                i.onPointerGraceIntentChange(null);
                            }
                        })
                    ),
                    onKeyDown: b(t.onKeyDown, (e) => {
                        const n = "" !== i.searchRef.current;
                        t.disabled ||
                            (n && " " === e.key) ||
                            (sn[r.dir].includes(e.key) &&
                                (a.onOpenChange(!0),
                                a.content?.focus(),
                                e.preventDefault()));
                    }),
                }),
            })
        );
    });
aa.displayName = na;
var ra = "MenuSubContent",
    oa = e.forwardRef((t, n) => {
        const a = Nn(En, t.__scopeMenu),
            { forceMount: r = a.forceMount, ...s } = t,
            i = vn(En, t.__scopeMenu),
            l = yn(En, t.__scopeMenu),
            c = ta(ra, t.__scopeMenu),
            d = e.useRef(null),
            u = h(n, d);
        return o.jsx(dn.Provider, {
            scope: t.__scopeMenu,
            children: o.jsx(_, {
                present: r || i.open,
                children: o.jsx(dn.Slot, {
                    scope: t.__scopeMenu,
                    children: o.jsx(Rn, {
                        id: c.contentId,
                        "aria-labelledby": c.triggerId,
                        ...s,
                        ref: u,
                        align: "start",
                        side: "rtl" === l.dir ? "left" : "right",
                        disableOutsidePointerEvents: !1,
                        disableOutsideScroll: !1,
                        trapFocus: !1,
                        onOpenAutoFocus: (e) => {
                            l.isUsingKeyboardRef.current && d.current?.focus(),
                                e.preventDefault();
                        },
                        onCloseAutoFocus: (e) => e.preventDefault(),
                        onFocusOutside: b(t.onFocusOutside, (e) => {
                            e.target !== c.trigger && i.onOpenChange(!1);
                        }),
                        onEscapeKeyDown: b(t.onEscapeKeyDown, (e) => {
                            l.onClose(), e.preventDefault();
                        }),
                        onKeyDown: b(t.onKeyDown, (e) => {
                            const t = e.currentTarget.contains(e.target),
                                n = ln[l.dir].includes(e.key);
                            t &&
                                n &&
                                (i.onOpenChange(!1),
                                c.trigger?.focus(),
                                e.preventDefault());
                        }),
                    }),
                }),
            }),
        });
    });
function sa(e) {
    return e ? "open" : "closed";
}
function ia(e) {
    return "indeterminate" === e;
}
function la(e) {
    return ia(e) ? "indeterminate" : e ? "checked" : "unchecked";
}
function ca(e) {
    return (t) => ("mouse" === t.pointerType ? e(t) : void 0);
}
oa.displayName = ra;
var da = wn,
    ua = jn,
    ma = Mn,
    pa = Ln,
    ha = Vn,
    fa = In,
    xa = Fn,
    ga = On,
    va = Bn,
    ba = $n,
    ya = Xn,
    wa = Jn,
    ja = Qn,
    Ca = aa,
    ka = oa,
    Na = "DropdownMenu",
    [Ma, Ea] = p(Na, [hn]),
    _a = hn(),
    [Sa, La] = Ma(Na),
    Da = (t) => {
        const {
                __scopeDropdownMenu: n,
                children: a,
                dir: r,
                open: s,
                defaultOpen: i,
                onOpenChange: l,
                modal: c = !0,
            } = t,
            d = _a(n),
            u = e.useRef(null),
            [m, p] = y({
                prop: s,
                defaultProp: i ?? !1,
                onChange: l,
                caller: Na,
            });
        return o.jsx(Sa, {
            scope: n,
            triggerId: v(),
            triggerRef: u,
            contentId: v(),
            open: m,
            onOpenChange: p,
            onOpenToggle: e.useCallback(() => p((e) => !e), [p]),
            modal: c,
            children: o.jsx(da, {
                ...d,
                open: m,
                onOpenChange: p,
                dir: r,
                modal: c,
                children: a,
            }),
        });
    };
Da.displayName = Na;
var Ta = "DropdownMenuTrigger",
    Aa = e.forwardRef((e, t) => {
        const { __scopeDropdownMenu: n, disabled: a = !1, ...r } = e,
            s = La(Ta, n),
            i = _a(n);
        return o.jsx(ua, {
            asChild: !0,
            ...i,
            children: o.jsx(g.button, {
                type: "button",
                id: s.triggerId,
                "aria-haspopup": "menu",
                "aria-expanded": s.open,
                "aria-controls": s.open ? s.contentId : void 0,
                "data-state": s.open ? "open" : "closed",
                "data-disabled": a ? "" : void 0,
                disabled: a,
                ...r,
                ref: A(t, s.triggerRef),
                onPointerDown: b(e.onPointerDown, (e) => {
                    a ||
                        0 !== e.button ||
                        !1 !== e.ctrlKey ||
                        (s.onOpenToggle(), s.open || e.preventDefault());
                }),
                onKeyDown: b(e.onKeyDown, (e) => {
                    a ||
                        (["Enter", " "].includes(e.key) && s.onOpenToggle(),
                        "ArrowDown" === e.key && s.onOpenChange(!0),
                        ["Enter", " ", "ArrowDown"].includes(e.key) &&
                            e.preventDefault());
                }),
            }),
        });
    });
Aa.displayName = Ta;
var Ra = (e) => {
    const { __scopeDropdownMenu: t, ...n } = e,
        a = _a(t);
    return o.jsx(ma, { ...a, ...n });
};
Ra.displayName = "DropdownMenuPortal";
var Va = "DropdownMenuContent",
    Ia = e.forwardRef((t, n) => {
        const { __scopeDropdownMenu: a, ...r } = t,
            s = La(Va, a),
            i = _a(a),
            l = e.useRef(!1);
        return o.jsx(pa, {
            id: s.contentId,
            "aria-labelledby": s.triggerId,
            ...i,
            ...r,
            ref: n,
            onCloseAutoFocus: b(t.onCloseAutoFocus, (e) => {
                l.current || s.triggerRef.current?.focus(),
                    (l.current = !1),
                    e.preventDefault();
            }),
            onInteractOutside: b(t.onInteractOutside, (e) => {
                const t = e.detail.originalEvent,
                    n = 0 === t.button && !0 === t.ctrlKey,
                    a = 2 === t.button || n;
                (s.modal && !a) || (l.current = !0);
            }),
            style: {
                ...t.style,
                "--radix-dropdown-menu-content-transform-origin":
                    "var(--radix-popper-transform-origin)",
                "--radix-dropdown-menu-content-available-width":
                    "var(--radix-popper-available-width)",
                "--radix-dropdown-menu-content-available-height":
                    "var(--radix-popper-available-height)",
                "--radix-dropdown-menu-trigger-width":
                    "var(--radix-popper-anchor-width)",
                "--radix-dropdown-menu-trigger-height":
                    "var(--radix-popper-anchor-height)",
            },
        });
    });
Ia.displayName = Va;
e.forwardRef((e, t) => {
    const { __scopeDropdownMenu: n, ...a } = e,
        r = _a(n);
    return o.jsx(ha, { ...r, ...a, ref: t });
}).displayName = "DropdownMenuGroup";
e.forwardRef((e, t) => {
    const { __scopeDropdownMenu: n, ...a } = e,
        r = _a(n);
    return o.jsx(fa, { ...r, ...a, ref: t });
}).displayName = "DropdownMenuLabel";
var Ha = e.forwardRef((e, t) => {
    const { __scopeDropdownMenu: n, ...a } = e,
        r = _a(n);
    return o.jsx(xa, { ...r, ...a, ref: t });
});
Ha.displayName = "DropdownMenuItem";
e.forwardRef((e, t) => {
    const { __scopeDropdownMenu: n, ...a } = e,
        r = _a(n);
    return o.jsx(ga, { ...r, ...a, ref: t });
}).displayName = "DropdownMenuCheckboxItem";
e.forwardRef((e, t) => {
    const { __scopeDropdownMenu: n, ...a } = e,
        r = _a(n);
    return o.jsx(va, { ...r, ...a, ref: t });
}).displayName = "DropdownMenuRadioGroup";
e.forwardRef((e, t) => {
    const { __scopeDropdownMenu: n, ...a } = e,
        r = _a(n);
    return o.jsx(ba, { ...r, ...a, ref: t });
}).displayName = "DropdownMenuRadioItem";
e.forwardRef((e, t) => {
    const { __scopeDropdownMenu: n, ...a } = e,
        r = _a(n);
    return o.jsx(ya, { ...r, ...a, ref: t });
}).displayName = "DropdownMenuItemIndicator";
e.forwardRef((e, t) => {
    const { __scopeDropdownMenu: n, ...a } = e,
        r = _a(n);
    return o.jsx(wa, { ...r, ...a, ref: t });
}).displayName = "DropdownMenuSeparator";
e.forwardRef((e, t) => {
    const { __scopeDropdownMenu: n, ...a } = e,
        r = _a(n);
    return o.jsx(ja, { ...r, ...a, ref: t });
}).displayName = "DropdownMenuArrow";
e.forwardRef((e, t) => {
    const { __scopeDropdownMenu: n, ...a } = e,
        r = _a(n);
    return o.jsx(Ca, { ...r, ...a, ref: t });
}).displayName = "DropdownMenuSubTrigger";
e.forwardRef((e, t) => {
    const { __scopeDropdownMenu: n, ...a } = e,
        r = _a(n);
    return o.jsx(ka, {
        ...r,
        ...a,
        ref: t,
        style: {
            ...e.style,
            "--radix-dropdown-menu-content-transform-origin":
                "var(--radix-popper-transform-origin)",
            "--radix-dropdown-menu-content-available-width":
                "var(--radix-popper-available-width)",
            "--radix-dropdown-menu-content-available-height":
                "var(--radix-popper-available-height)",
            "--radix-dropdown-menu-trigger-width":
                "var(--radix-popper-anchor-width)",
            "--radix-dropdown-menu-trigger-height":
                "var(--radix-popper-anchor-height)",
        },
    });
}).displayName = "DropdownMenuSubContent";
var Pa = Da,
    Fa = Aa,
    Za = Ra,
    Oa = Ia,
    za = Ha;
function Ka({ trigger: e, children: t, unstyledTrigger: n = !1, ...a }) {
    return o.jsx(Ua, {
        ...a,
        trigger: e
            ? n
                ? o.jsx(Fa, { asChild: !0, children: e })
                : o.jsx(Ba, { children: e })
            : o.jsx(Ba, {}),
        children: t,
    });
}
function Ua({
    matchTriggerWidth: e = !1,
    children: t,
    open: n,
    onOpenChange: a,
    trigger: r,
    ...s
}) {
    const i = e
        ? { width: "var(--radix-dropdown-menu-trigger-width)" }
        : void 0;
    return o.jsxs(Pa, {
        open: n,
        onOpenChange: a,
        children: [
            r,
            o.jsx(Za, {
                children: o.jsx(Oa, {
                    ...s,
                    style: i,
                    className: u(
                        "z-50 bg-bg-000 border-[0.5px] border-border-300 rounded-xl shadow-lg",
                        "p-1.5 min-w-40",
                        "animate-in fade-in-0 zoom-in-95",
                        s.className
                    ),
                    children: t,
                }),
            }),
        ],
    });
}
const Ba = ({ children: e }) =>
        o.jsx(Fa, {
            asChild: !0,
            children: o.jsx("button", {
                className:
                    "opacity-0 group-hover:opacity-100 p-1 text-text-300 hover:bg-bg-100 rounded transition-all",
                children: e || o.jsx(Me, { size: 16 }),
            }),
        }),
    Ga = s.forwardRef(
        (
            {
                children: e,
                icon: t,
                danger: n,
                disabled: a,
                className: r,
                ...s
            },
            i
        ) =>
            o.jsx(za, {
                ref: i,
                disabled: a,
                className: u(
                    "font-base py-1.5 px-2 rounded-lg cursor-pointer",
                    "whitespace-nowrap overflow-hidden text-ellipsis",
                    "outline-none select-none",
                    "text-sm",
                    "data-[highlighted]:bg-bg-200",
                    "data-[highlighted]:text-text-000",
                    "text-text-300",
                    n && "!text-danger-000 data-[highlighted]:bg-danger-900",
                    a && "opacity-50 pointer-events-none",
                    r
                ),
                ...s,
                children: o.jsxs("div", {
                    className: "flex items-center gap-2.5 py-0.5",
                    children: [t, o.jsx("span", { children: e })],
                }),
            })
    );
Ga.displayName = "DropdownItem";
const $a = (e) =>
    o.jsx(d, {
        ...e,
        children: o.jsx("path", {
            d: "M10 2.5C14.1421 2.5 17.5 5.85786 17.5 10C17.5 14.1421 14.1421 17.5 10 17.5C5.85786 17.5 2.5 14.1421 2.5 10C2.5 5.85786 5.85786 2.5 10 2.5ZM10 3.5C6.41015 3.5 3.5 6.41015 3.5 10C3.5 13.5899 6.41015 16.5 10 16.5C13.5899 16.5 16.5 13.5899 16.5 10C16.5 6.41015 13.5899 3.5 10 3.5ZM12.6094 7.1875C12.7819 6.97187 13.0969 6.93687 13.3125 7.10938C13.5281 7.28188 13.5631 7.59687 13.3906 7.8125L9.39062 12.8125C9.30178 12.9236 9.16935 12.9912 9.02734 12.999C8.92097 13.0049 8.81649 12.9768 8.72852 12.9199L8.64648 12.8535L6.64648 10.8535L6.58203 10.7754C6.45387 10.5813 6.47562 10.3173 6.64648 10.1465C6.81735 9.97562 7.08131 9.95387 7.27539 10.082L7.35352 10.1465L8.95801 11.751L12.6094 7.1875Z",
        }),
    });
function Wa({ toast: t, onClose: n }) {
    const [a, r] = e.useState(!1);
    e.useEffect(() => {
        const e = setTimeout(() => {
            s();
        }, 3e3);
        return () => clearTimeout(e);
    }, [t.id]);
    const s = () => {
        r(!0),
            setTimeout(() => {
                n(t.id);
            }, 200);
    };
    return o.jsxs("div", {
        className: u(
            "flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg",
            "bg-bg-000 border-[0.5px] border-border-300",
            "min-w-[300px] transition-all duration-200 ease-out",
            a
                ? ["opacity-0 translate-x-full"]
                : ["animate-toast-slide-in", "opacity-100 translate-x-0"]
        ),
        style: { animation: a ? void 0 : "toast-slide-in 0.3s ease-out" },
        children: [
            "success" === t.type &&
                o.jsx($a, {
                    size: 16,
                    className: "text-accent-secondary-100 flex-shrink-0",
                }),
            o.jsx("p", {
                className: "text-text-200 font-base flex-1",
                children: t.message,
            }),
            o.jsx("button", {
                onClick: s,
                className:
                    "p-1 hover:bg-bg-100 rounded transition-colors flex-shrink-0",
                children: o.jsx(c, { size: 14, className: "text-text-300" }),
            }),
        ],
    });
}
function Ya() {
    const [t, n] = e.useState([]),
        a = (e, t = "success") => {
            const a = Date.now().toString();
            n((n) => [...n, { id: a, message: e, type: t }]);
        },
        r = (e) => {
            n((t) => t.filter((t) => t.id !== e));
        };
    return (
        e.useEffect(
            () => (
                (window.showToast = a),
                () => {
                    delete window.showToast;
                }
            ),
            []
        ),
        0 === t.length
            ? null
            : o.jsx("div", {
                  className: "fixed top-4 right-4 z-50 flex flex-col gap-2",
                  children: t.map((e) =>
                      o.jsx(Wa, { toast: e, onClose: r }, e.id)
                  ),
              })
    );
}
function qa() {
    const [t, n] = e.useState([]),
        [r, s] = e.useState(null),
        [i, l] = e.useState(!1),
        [c, d] = e.useState("my-tasks"),
        { showToast: u } = {
            showToast: (e, t = "success") => {
                const n = window;
                n.showToast && n.showToast(e, t);
            },
        },
        { value: p } = a.useFeatureGate("crochet_browse_shortcuts"),
        h = (e) => {
            switch (e) {
                case "general":
                default:
                    return o.jsx(oe, {
                        size: 18,
                        weight: "light",
                        className: "text-text-300",
                    });
                case "email":
                    return o.jsx(ae, {
                        size: 18,
                        weight: "light",
                        className: "text-text-300",
                    });
                case "docs":
                    return o.jsx(Ee, { size: 16, className: "text-text-300" });
                case "calendar":
                    return o.jsx(te, {
                        size: 18,
                        weight: "light",
                        className: "text-text-300",
                    });
                case "linkedin":
                    return o.jsx(ie, {
                        size: 18,
                        weight: "light",
                        className: "text-text-300",
                    });
            }
        },
        f = async () => {
            const e = await V.getAllPrompts();
            n(e.sort((e, t) => t.createdAt - e.createdAt));
        };
    e.useEffect(() => {
        f();
    }, []);
    return o.jsxs(o.Fragment, {
        children: [
            o.jsx(Ya, {}),
            o.jsxs("div", {
                className: "space-y-6",
                children: [
                    o.jsxs("div", {
                        className:
                            "bg-bg-100 border-[0.5px] border-border-300 rounded-xl px-6 pt-6 pb-6 md:px-8 md:pt-8 md:pb-8",
                        children: [
                            o.jsxs("div", {
                                className:
                                    "flex items-start justify-between mb-2",
                                children: [
                                    o.jsxs("div", {
                                        children: [
                                            o.jsx("h3", {
                                                className:
                                                    "text-text-100 font-xl-bold",
                                                children: "Shortcuts",
                                            }),
                                            o.jsx("p", {
                                                className:
                                                    "text-text-300 font-base mt-1",
                                                children:
                                                    "Create shortcuts to use in chat or schedule for tasks you repeat",
                                            }),
                                        ],
                                    }),
                                    o.jsx(m, {
                                        onClick: () => {
                                            s(null), l(!0);
                                        },
                                        prepend: o.jsx(R, { size: 16 }),
                                        size: "sm",
                                        className: "ml-2",
                                        children: "Create shortcut",
                                    }),
                                ],
                            }),
                            p &&
                                o.jsx("div", {
                                    className: "mt-6",
                                    children: o.jsx(De, {
                                        value: c,
                                        onSelect: (e) => d(e),
                                        options: [
                                            {
                                                key: "my-tasks",
                                                label: "My shortcuts",
                                            },
                                            { key: "browse", label: "Browse" },
                                        ],
                                    }),
                                }),
                            "my-tasks" !== c && p
                                ? "browse" === c && p
                                    ? o.jsx("div", {
                                          className: "space-y-8 mt-6",
                                          children: _e.map((e) =>
                                              o.jsxs(
                                                  "div",
                                                  {
                                                      children: [
                                                          o.jsxs("div", {
                                                              className:
                                                                  "flex items-center gap-2 mb-4",
                                                              children: [
                                                                  h(e.category),
                                                                  o.jsx("h4", {
                                                                      className:
                                                                          "text-text-200 font-base-bold",
                                                                      children:
                                                                          e.label,
                                                                  }),
                                                              ],
                                                          }),
                                                          o.jsx("div", {
                                                              className:
                                                                  "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
                                                              children:
                                                                  e.prompts.map(
                                                                      (t, n) =>
                                                                          o.jsx(
                                                                              Xa,
                                                                              {
                                                                                  template:
                                                                                      t,
                                                                                  onUse: () => {
                                                                                      s(
                                                                                          {
                                                                                              id: "",
                                                                                              ...t,
                                                                                              createdAt:
                                                                                                  Date.now(),
                                                                                              lastUsedAt:
                                                                                                  void 0,
                                                                                              usageCount: 0,
                                                                                          }
                                                                                      ),
                                                                                          l(
                                                                                              !0
                                                                                          );
                                                                                  },
                                                                              },
                                                                              `${e.category}-${n}`
                                                                          )
                                                                  ),
                                                          }),
                                                      ],
                                                  },
                                                  e.category
                                              )
                                          ),
                                      })
                                    : null
                                : o.jsxs("div", {
                                      className:
                                          "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6",
                                      children: [
                                          t.map((e) =>
                                              o.jsx(
                                                  Ja,
                                                  {
                                                      prompt: e,
                                                      onEdit: () => {
                                                          s(e), l(!0);
                                                      },
                                                      onDelete: () =>
                                                          (async (e) => {
                                                              confirm(
                                                                  "Are you sure you want to delete this prompt?"
                                                              ) &&
                                                                  (await V.deletePrompt(
                                                                      e
                                                                  ),
                                                                  f(),
                                                                  u(
                                                                      "Shortcut deleted successfully"
                                                                  ));
                                                          })(e.id),
                                                  },
                                                  e.id
                                              )
                                          ),
                                          0 === t.length &&
                                              o.jsxs("div", {
                                                  className:
                                                      "col-span-full bg-bg-200 rounded-xl p-12 text-center",
                                                  children: [
                                                      o.jsxs("picture", {
                                                          children: [
                                                              o.jsx("source", {
                                                                  srcSet: "data:image/svg+xml,%3csvg%20width='80'%20height='69'%20viewBox='0%200%2080%2069'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cg%20filter='url(%23filter0_d_5136_3558)'%3e%3cpath%20d='M5%2019C5%2013.3995%205%2010.5992%206.08993%208.46009C7.04867%206.57847%208.57847%205.04867%2010.4601%204.08993C12.5992%203%2015.3995%203%2021%203H59.0648C64.6654%203%2067.4656%203%2069.6047%204.08993C71.4864%205.04867%2073.0162%206.57847%2073.9749%208.46009C75.0648%2010.5992%2075.0648%2013.3995%2075.0648%2019V46C75.0648%2051.6005%2075.0648%2054.4008%2073.9749%2056.5399C73.0162%2058.4215%2071.4864%2059.9513%2069.6047%2060.9101C67.4656%2062%2064.6654%2062%2059.0648%2062H21C15.3995%2062%2012.5992%2062%2010.4601%2060.9101C8.57847%2059.9513%207.04867%2058.4215%206.08993%2056.5399C5%2054.4008%205%2051.6005%205%2046V19Z'%20fill='%2330302E'%20shape-rendering='crispEdges'/%3e%3cpath%20d='M59.0645%202.75C61.8606%202.75%2063.9733%202.74945%2065.6533%202.88672C67.3361%203.02421%2068.6072%203.30141%2069.7178%203.86719C71.6464%204.84987%2073.2146%206.41806%2074.1973%208.34668C74.7632%209.45736%2075.0402%2010.7291%2075.1777%2012.4121C75.315%2014.0921%2075.3145%2016.2041%2075.3145%2019V46C75.3145%2048.7959%2075.315%2050.9079%2075.1777%2052.5879C75.0402%2054.2709%2074.7632%2055.5426%2074.1973%2056.6533C73.2146%2058.5819%2071.6464%2060.1501%2069.7178%2061.1328C68.6072%2061.6986%2067.3361%2061.9758%2065.6533%2062.1133C63.9733%2062.2505%2061.8606%2062.25%2059.0645%2062.25H21C18.2041%2062.25%2016.0921%2062.2505%2014.4121%2062.1133C12.7292%2061.9758%2011.4573%2061.6987%2010.3467%2061.1328C8.41802%2060.1501%206.84989%2058.582%205.86719%2056.6533C5.30129%2055.5427%205.02422%2054.2708%204.88672%2052.5879C4.74949%2050.9079%204.75%2048.7959%204.75%2046V19C4.75%2016.2041%204.74949%2014.0921%204.88672%2012.4121C5.02422%2010.7292%205.30129%209.45734%205.86719%208.34668C6.84989%206.41802%208.41802%204.84989%2010.3467%203.86719C11.4573%203.30129%2012.7292%203.02422%2014.4121%202.88672C16.0921%202.74949%2018.2041%202.75%2021%202.75H59.0645Z'%20stroke='%23DEDCD1'%20stroke-opacity='0.3'%20stroke-width='0.5'%20shape-rendering='crispEdges'/%3e%3cpath%20d='M14.4844%2019.2899L16.6109%2012.6917L17.5147%2012.7101L15.3882%2019.3083L14.4844%2019.2899Z'%20fill='%23C2C0B6'/%3e%3crect%20x='22.9209'%20y='15'%20width='32.0373'%20height='2'%20rx='1'%20fill='%23DEDCD1'%20fill-opacity='0.15'/%3e%3cpath%20d='M14.4844%2030.2899L16.6109%2023.6917L17.5147%2023.7101L15.3882%2030.3083L14.4844%2030.2899Z'%20fill='%23C2C0B6'/%3e%3crect%20x='22.9209'%20y='26'%20width='44.1435'%20height='2'%20rx='1'%20fill='%23DEDCD1'%20fill-opacity='0.15'/%3e%3cpath%20d='M14.4844%2041.2899L16.6109%2034.6917L17.5147%2034.7101L15.3882%2041.3083L14.4844%2041.2899Z'%20fill='%23C2C0B6'/%3e%3crect%20x='22.9209'%20y='37'%20width='38.9607'%20height='2'%20rx='1'%20fill='%23DEDCD1'%20fill-opacity='0.15'/%3e%3cpath%20d='M14.4844%2052.2899L16.6109%2045.6917L17.5147%2045.7101L15.3882%2052.3083L14.4844%2052.2899Z'%20fill='%23C2C0B6'/%3e%3crect%20x='22.9209'%20y='48'%20width='34.6778'%20height='2'%20rx='1'%20fill='%23DEDCD1'%20fill-opacity='0.15'/%3e%3c/g%3e%3cdefs%3e%3cfilter%20id='filter0_d_5136_3558'%20x='0.5'%20y='0.5'%20width='79.0645'%20height='68'%20filterUnits='userSpaceOnUse'%20color-interpolation-filters='sRGB'%3e%3cfeFlood%20flood-opacity='0'%20result='BackgroundImageFix'/%3e%3cfeColorMatrix%20in='SourceAlpha'%20type='matrix'%20values='0%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%20127%200'%20result='hardAlpha'/%3e%3cfeOffset%20dy='2'/%3e%3cfeGaussianBlur%20stdDeviation='2'/%3e%3cfeComposite%20in2='hardAlpha'%20operator='out'/%3e%3cfeColorMatrix%20type='matrix'%20values='0%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200.05%200'/%3e%3cfeBlend%20mode='normal'%20in2='BackgroundImageFix'%20result='effect1_dropShadow_5136_3558'/%3e%3cfeBlend%20mode='normal'%20in='SourceGraphic'%20in2='effect1_dropShadow_5136_3558'%20result='shape'/%3e%3c/filter%3e%3c/defs%3e%3c/svg%3e",
                                                                  media: "(prefers-color-scheme: dark)",
                                                              }),
                                                              o.jsx("img", {
                                                                  src: "data:image/svg+xml,%3csvg%20width='80'%20height='69'%20viewBox='0%200%2080%2069'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cg%20filter='url(%23filter0_d_5136_3446)'%3e%3cpath%20d='M5%2019C5%2013.3995%205%2010.5992%206.08993%208.46009C7.04867%206.57847%208.57847%205.04867%2010.4601%204.08993C12.5992%203%2015.3995%203%2021%203H59.0648C64.6654%203%2067.4656%203%2069.6047%204.08993C71.4864%205.04867%2073.0162%206.57847%2073.9749%208.46009C75.0648%2010.5992%2075.0648%2013.3995%2075.0648%2019V46C75.0648%2051.6005%2075.0648%2054.4008%2073.9749%2056.5399C73.0162%2058.4215%2071.4864%2059.9513%2069.6047%2060.9101C67.4656%2062%2064.6654%2062%2059.0648%2062H21C15.3995%2062%2012.5992%2062%2010.4601%2060.9101C8.57847%2059.9513%207.04867%2058.4215%206.08993%2056.5399C5%2054.4008%205%2051.6005%205%2046V19Z'%20fill='white'%20shape-rendering='crispEdges'/%3e%3cpath%20d='M59.0645%202.75C61.8606%202.75%2063.9733%202.74945%2065.6533%202.88672C67.3361%203.02421%2068.6072%203.30141%2069.7178%203.86719C71.6464%204.84987%2073.2146%206.41806%2074.1973%208.34668C74.7632%209.45736%2075.0402%2010.7291%2075.1777%2012.4121C75.315%2014.0921%2075.3145%2016.2041%2075.3145%2019V46C75.3145%2048.7959%2075.315%2050.9079%2075.1777%2052.5879C75.0402%2054.2709%2074.7632%2055.5426%2074.1973%2056.6533C73.2146%2058.5819%2071.6464%2060.1501%2069.7178%2061.1328C68.6072%2061.6986%2067.3361%2061.9758%2065.6533%2062.1133C63.9733%2062.2505%2061.8606%2062.25%2059.0645%2062.25H21C18.2041%2062.25%2016.0921%2062.2505%2014.4121%2062.1133C12.7292%2061.9758%2011.4573%2061.6987%2010.3467%2061.1328C8.41802%2060.1501%206.84989%2058.582%205.86719%2056.6533C5.30129%2055.5427%205.02422%2054.2708%204.88672%2052.5879C4.74949%2050.9079%204.75%2048.7959%204.75%2046V19C4.75%2016.2041%204.74949%2014.0921%204.88672%2012.4121C5.02422%2010.7292%205.30129%209.45734%205.86719%208.34668C6.84989%206.41802%208.41802%204.84989%2010.3467%203.86719C11.4573%203.30129%2012.7292%203.02422%2014.4121%202.88672C16.0921%202.74949%2018.2041%202.75%2021%202.75H59.0645Z'%20stroke='%231F1E1D'%20stroke-opacity='0.3'%20stroke-width='0.5'%20shape-rendering='crispEdges'/%3e%3cpath%20d='M14.4844%2019.2899L16.6109%2012.6917L17.5147%2012.7101L15.3882%2019.3083L14.4844%2019.2899Z'%20fill='%233D3D3A'/%3e%3crect%20x='22.9209'%20y='15'%20width='32.0373'%20height='2'%20rx='1'%20fill='%231F1E1D'%20fill-opacity='0.15'/%3e%3cpath%20d='M14.4844%2030.2899L16.6109%2023.6917L17.5147%2023.7101L15.3882%2030.3083L14.4844%2030.2899Z'%20fill='%233D3D3A'/%3e%3crect%20x='22.9209'%20y='26'%20width='44.1435'%20height='2'%20rx='1'%20fill='%231F1E1D'%20fill-opacity='0.15'/%3e%3cpath%20d='M14.4844%2041.2899L16.6109%2034.6917L17.5147%2034.7101L15.3882%2041.3083L14.4844%2041.2899Z'%20fill='%233D3D3A'/%3e%3crect%20x='22.9209'%20y='37'%20width='38.9607'%20height='2'%20rx='1'%20fill='%231F1E1D'%20fill-opacity='0.15'/%3e%3cpath%20d='M14.4844%2052.2899L16.6109%2045.6917L17.5147%2045.7101L15.3882%2052.3083L14.4844%2052.2899Z'%20fill='%233D3D3A'/%3e%3crect%20x='22.9209'%20y='48'%20width='34.6778'%20height='2'%20rx='1'%20fill='%231F1E1D'%20fill-opacity='0.15'/%3e%3c/g%3e%3cdefs%3e%3cfilter%20id='filter0_d_5136_3446'%20x='0.5'%20y='0.5'%20width='79.0645'%20height='68'%20filterUnits='userSpaceOnUse'%20color-interpolation-filters='sRGB'%3e%3cfeFlood%20flood-opacity='0'%20result='BackgroundImageFix'/%3e%3cfeColorMatrix%20in='SourceAlpha'%20type='matrix'%20values='0%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%20127%200'%20result='hardAlpha'/%3e%3cfeOffset%20dy='2'/%3e%3cfeGaussianBlur%20stdDeviation='2'/%3e%3cfeComposite%20in2='hardAlpha'%20operator='out'/%3e%3cfeColorMatrix%20type='matrix'%20values='0%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200.05%200'/%3e%3cfeBlend%20mode='normal'%20in2='BackgroundImageFix'%20result='effect1_dropShadow_5136_3446'/%3e%3cfeBlend%20mode='normal'%20in='SourceGraphic'%20in2='effect1_dropShadow_5136_3446'%20result='shape'/%3e%3c/filter%3e%3c/defs%3e%3c/svg%3e",
                                                                  alt: "Tasks illustration",
                                                                  className:
                                                                      "w-24 h-24 mx-auto mb-1",
                                                              }),
                                                          ],
                                                      }),
                                                      o.jsx("p", {
                                                          className:
                                                              "text-text-300 max-w-[200px] mx-auto",
                                                          children: p
                                                              ? o.jsxs(
                                                                    o.Fragment,
                                                                    {
                                                                        children:
                                                                            [
                                                                                "Create your first shortcut or",
                                                                                " ",
                                                                                o.jsx(
                                                                                    "button",
                                                                                    {
                                                                                        onClick:
                                                                                            () =>
                                                                                                d(
                                                                                                    "browse"
                                                                                                ),
                                                                                        className:
                                                                                            "text-text-200 underline hover:text-text-100 transition-colors cursor-pointer",
                                                                                        children:
                                                                                            "explore examples",
                                                                                    }
                                                                                ),
                                                                                " ",
                                                                                "to get started",
                                                                            ],
                                                                    }
                                                                )
                                                              : "Create your first shortcut to get started",
                                                      }),
                                                  ],
                                              }),
                                      ],
                                  }),
                        ],
                    }),
                    i &&
                        o.jsx(Qa, {
                            prompt: r,
                            onClose: () => {
                                l(!1), s(null);
                            },
                            onSave: (e) => {
                                f(),
                                    l(!1),
                                    s(null),
                                    u(
                                        e
                                            ? "Shortcut updated successfully"
                                            : "Shortcut added successfully"
                                    );
                            },
                        }),
                ],
            }),
        ],
    });
}
function Xa({ template: e, onUse: t }) {
    return o.jsxs("button", {
        onClick: t,
        className:
            "relative group bg-bg-000 border-[0.5px] border-border-300 rounded-2xl p-4 hover:border-border-200 transition-all shadow-[0_2px_4px_0_rgba(0,0,0,0.04)] hover:shadow-[0_4px_20px_0_rgba(0,0,0,0.08)] w-full text-left cursor-pointer",
        children: [
            o.jsxs("div", {
                className: "flex items-start justify-between gap-2 mb-2",
                children: [
                    o.jsx("div", {
                        className: "flex-1 min-w-0",
                        children:
                            e.command &&
                            o.jsxs("div", {
                                className:
                                    "font-large-bold text-text-200 relative overflow-hidden",
                                children: [
                                    o.jsxs("div", {
                                        className: "whitespace-nowrap",
                                        children: [
                                            o.jsx("span", {
                                                className:
                                                    "text-text-500/50 font-mono",
                                                children: "/",
                                            }),
                                            o.jsx("span", {
                                                className: "ml-0.5",
                                                children: e.command,
                                            }),
                                        ],
                                    }),
                                    o.jsx("div", {
                                        className:
                                            "absolute inset-y-0 right-0 w-12 bg-gradient-to-l from-bg-000 to-transparent pointer-events-none",
                                    }),
                                ],
                            }),
                    }),
                    o.jsx("button", {
                        onClick: (e) => {
                            e.stopPropagation(), t();
                        },
                        className:
                            "opacity-0 group-hover:opacity-100 p-1 text-text-300 hover:bg-bg-100 rounded-lg transition-all border-[0.5px] border-border-300",
                        children: o.jsx(R, { size: 16 }),
                    }),
                ],
            }),
            o.jsx("div", {
                className: "bg-bg-100 rounded-lg p-3",
                children: o.jsx("div", {
                    className:
                        "text-sm text-text-300 h-24 overflow-y-auto whitespace-pre-wrap",
                    children: e.prompt,
                }),
            }),
        ],
    });
}
function Ja({ prompt: e, onEdit: t, onDelete: n }) {
    return o.jsxs("div", {
        className:
            "relative group bg-bg-000 border-[0.5px] border-border-300 rounded-2xl p-4 hover:border-border-200 transition-all shadow-[0_2px_4px_0_rgba(0,0,0,0.04)] hover:shadow-[0_4px_20px_0_rgba(0,0,0,0.08)] w-full",
        children: [
            o.jsxs("div", {
                className: "flex items-start justify-between gap-2 mb-2",
                children: [
                    o.jsx("button", {
                        onClick: t,
                        className: "flex-1 min-w-0 text-left",
                        children:
                            e.command &&
                            o.jsxs("div", {
                                className:
                                    "font-large-bold text-text-200 relative overflow-hidden",
                                children: [
                                    o.jsxs("div", {
                                        className: "whitespace-nowrap",
                                        children: [
                                            o.jsx("span", {
                                                className:
                                                    "text-text-500/50 font-mono",
                                                children: "/",
                                            }),
                                            o.jsx("span", {
                                                className: "ml-0.5",
                                                children: e.command,
                                            }),
                                        ],
                                    }),
                                    o.jsx("div", {
                                        className:
                                            "absolute inset-y-0 right-0 w-12 bg-gradient-to-l from-bg-000 to-transparent pointer-events-none",
                                    }),
                                ],
                            }),
                    }),
                    o.jsxs(Ka, {
                        unstyledTrigger: !0,
                        trigger: o.jsx("button", {
                            className:
                                "p-1 hover:bg-bg-200 rounded transition-colors",
                            children: o.jsx(Me, {
                                size: 16,
                                className: "text-text-300",
                            }),
                        }),
                        children: [
                            o.jsx(Ga, {
                                icon: o.jsx(ke, { size: 14 }),
                                onSelect: () => {
                                    t();
                                },
                                children: "Edit",
                            }),
                            o.jsx(Ga, {
                                icon: o.jsx(Ne, { size: 14 }),
                                danger: !0,
                                onSelect: () => {
                                    n();
                                },
                                children: "Delete",
                            }),
                        ],
                    }),
                ],
            }),
            o.jsx("button", {
                onClick: t,
                className:
                    "bg-bg-100 rounded-lg p-3 w-full text-left cursor-pointer hover:bg-bg-200 transition-colors",
                children: o.jsx("div", {
                    className:
                        "text-sm text-text-300 h-24 overflow-y-auto whitespace-pre-wrap",
                    children: e.prompt,
                }),
            }),
        ],
    });
}
function Qa({ prompt: t, onClose: n, onSave: a }) {
    const [r, s] = e.useState(t?.command || ""),
        [i, l] = e.useState(t?.prompt || ""),
        [c, d] = e.useState(""),
        [u, p] = e.useState(!1),
        h = "" === t?.id,
        f = e.useRef(null);
    e.useEffect(() => {
        setTimeout(() => {
            f.current?.focus();
        }, 100);
    }, []),
        e.useEffect(() => {
            const e = (e) => {
                if ("Enter" === e.key) {
                    const t = document.activeElement;
                    "INPUT" === t?.tagName ||
                        "TEXTAREA" === t?.tagName ||
                        (e.preventDefault(), x());
                }
            };
            return (
                document.addEventListener("keydown", e),
                () => document.removeEventListener("keydown", e)
            );
        }, [r, i]);
    const x = async () => {
        if ((p(!0), r.trim() && i.trim()))
            try {
                t && !h
                    ? await V.updatePrompt(t.id, {
                          prompt: i.trim(),
                          command: r.trim(),
                      })
                    : await V.savePrompt({
                          prompt: i.trim(),
                          command: r.trim(),
                          createdAt: Date.now(),
                          usageCount: 0,
                      }),
                    a(!(!t || h));
            } catch (ir) {
                d(ir instanceof Error ? ir.message : "Failed to save");
            }
    };
    return o.jsxs(Se, {
        isOpen: !0,
        onClose: n,
        title: t && !h ? "Edit shortcut" : "Create shortcut",
        children: [
            o.jsxs("div", {
                className: "space-y-4",
                children: [
                    o.jsx(I, {
                        ref: f,
                        label: "Name",
                        type: "text",
                        value: r,
                        onChange: (e) => {
                            const t = e.target.value
                                .replace(/\s/g, "-")
                                .replace(/[^a-zA-Z0-9-_]/g, "");
                            s(t), c && d("");
                        },
                        prepend: o.jsx("span", {
                            className: "text-text-300",
                            children: "/",
                        }),
                        placeholder: "e.g., summarize",
                        error:
                            u && !r.trim()
                                ? "Name is required"
                                : c?.includes("already in use")
                                ? c
                                : void 0,
                    }),
                    o.jsx(H, {
                        label: "Prompt",
                        required: !0,
                        value: i,
                        onChange: (e) => l(e.target.value),
                        className: "min-h-32 max-h-64 overflow-y-auto",
                        placeholder: "Enter your prompt text...",
                        error: u && !i.trim() ? "Prompt is required" : void 0,
                    }),
                    c &&
                        !c.includes("already in use") &&
                        o.jsx("div", {
                            className: "text-danger-000 text-sm",
                            children: c,
                        }),
                ],
            }),
            o.jsxs(Le, {
                children: [
                    o.jsx(m, {
                        onClick: n,
                        variant: "ghost",
                        children: "Cancel",
                    }),
                    o.jsx(m, {
                        onClick: x,
                        children: t && !h ? "Save changes" : "Create shortcut",
                    }),
                ],
            }),
        ],
    });
}
const er = ({ apiKey: e, setApiKey: t, onSave: n, saved: a, apiBaseUrl, setApiBaseUrl }) =>
        o.jsxs("div", {
            className: "max-w-md",
            children: [
                o.jsx("h2", {
                    className: "font-xl-bold text-text-100 mb-4",
                    children: "API configuration (internal)",
                }),
                o.jsxs("div", {
                    className: "space-y-4",
                    children: [
                        o.jsxs("div", {
                            children: [
                                o.jsx("label", {
                                    htmlFor: "apiBaseUrl",
                                    className:
                                        "font-label block mb-2 text-text-200",
                                    children: "Anthropic API base URL",
                                }),
                                o.jsx("input", {
                                    id: "apiBaseUrl",
                                    type: "text",
                                    value: apiBaseUrl,
                                    onChange: (e) => setApiBaseUrl(e.target.value),
                                    placeholder: "Enter your Anthropic API base URL",
                                    className:
                                        "w-full px-3 py-2 mb-4 border border-border-200 rounded-md focus:outline-none focus:ring-2 focus:ring-accent-main-200 bg-bg-000 text-text-100 font-base",
                                }),
                                o.jsx("label", {
                                    htmlFor: "apiKey",
                                    className:
                                        "font-label block mb-2 text-text-200",
                                    children: "Anthropic API Key",
                                }),
                                o.jsx("input", {
                                    id: "apiKey",
                                    type: "password",
                                    value: e,
                                    onChange: (e) => t(e.target.value),
                                    placeholder: "Enter your Anthropic API key",
                                    className:
                                        "w-full px-3 py-2 border border-border-200 rounded-md focus:outline-none focus:ring-2 focus:ring-accent-main-200 bg-bg-000 text-text-100 font-base",
                                }),
                                o.jsxs("p", {
                                    className:
                                        "mt-2 font-caption text-text-300",
                                    children: [
                                        "Get your API key from",
                                        " ",
                                        o.jsx("a", {
                                            href: "https://console.anthropic.com/account/keys",
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            className:
                                                "text-accent-main-200 hover:underline",
                                            children: "console.anthropic.com",
                                        }),
                                    ],
                                }),
                            ],
                        }),
                        o.jsx("button", {
                            onClick: n,
                            className:
                                "w-full bg-accent-main-200 text-oncolor-100 py-2 px-4 rounded-md hover:bg-accent-main-100 focus:outline-none focus:ring-2 focus:ring-accent-main-200 font-button-lg",
                            children: "Save API Key",
                        }),
                        a &&
                            o.jsx("div", {
                                className: "font-base-sm text-text-200",
                                children: "Settings saved successfully!",
                            }),
                    ],
                }),
            ],
        }),
    tr = ({
        selectedModel: t,
        setSelectedModel: n,
        availableModels: a,
        systemPrompt: r,
        setSystemPrompt: s,
        debugMode: i,
        setDebugMode: l,
        onModelSave: c,
        onPromptSave: d,
        onResetPrompt: u,
        saved: m,
        setSaved: p,
        allowEditSystemPrompt: h,
    }) => {
        const [f, x] = e.useState(!1);
        e.useEffect(() => {
            G(B.SHOW_TRACE_IDS).then((e) => {
                void 0 !== e && x(e);
            });
        }, []);
        return o.jsxs("div", {
            className: "max-w-2xl",
            children: [
                o.jsx("h2", {
                    className: "font-xl-bold text-text-100 mb-4",
                    children: "Model & Prompt Configuration",
                }),
                o.jsxs("div", {
                    className: "space-y-6",
                    children: [
                        o.jsxs("div", {
                            className: "space-y-4",
                            children: [
                                o.jsx("h3", {
                                    className: "font-large-bold text-text-100",
                                    children: "Model Selection",
                                }),
                                o.jsxs("div", {
                                    children: [
                                        o.jsx("div", {
                                            className: "mb-2",
                                            children: o.jsx("label", {
                                                htmlFor: "modelSelect",
                                                className:
                                                    "font-label block text-text-200",
                                                children: "Choose Claude Model",
                                            }),
                                        }),
                                        o.jsx("select", {
                                            id: "modelSelect",
                                            value: t,
                                            onChange: (e) => n(e.target.value),
                                            disabled: 0 === a.length,
                                            className:
                                                "w-full px-3 py-2 border border-border-200 rounded-md focus:outline-none focus:ring-2 focus:ring-accent-main-200 disabled:bg-bg-200 disabled:text-text-400 bg-bg-000 text-text-100 font-base",
                                            children:
                                                a.length > 0
                                                    ? a.map((e) =>
                                                          o.jsx(
                                                              "option",
                                                              {
                                                                  value: e,
                                                                  children: e,
                                                              },
                                                              e
                                                          )
                                                      )
                                                    : null,
                                        }),
                                        o.jsx("p", {
                                            className:
                                                "mt-2 font-caption text-text-300",
                                            children:
                                                "Select from models available to you",
                                        }),
                                    ],
                                }),
                                o.jsx("button", {
                                    onClick: c,
                                    disabled: !t,
                                    className:
                                        "w-full bg-accent-main-200 text-oncolor-100 py-2 px-4 rounded-md hover:bg-accent-main-100 focus:outline-none focus:ring-2 focus:ring-accent-main-200 disabled:bg-bg-400 disabled:cursor-not-allowed font-button-lg",
                                    children: "Save Model Selection",
                                }),
                            ],
                        }),
                        h &&
                            o.jsx("div", {
                                className: "border-t border-border-300",
                            }),
                        h &&
                            o.jsxs("div", {
                                className: "space-y-4",
                                children: [
                                    o.jsx("h3", {
                                        className:
                                            "font-large-bold text-text-100",
                                        children: "System Prompt",
                                    }),
                                    o.jsxs("div", {
                                        children: [
                                            o.jsx("label", {
                                                htmlFor: "systemPrompt",
                                                className:
                                                    "font-label block mb-2 text-text-200",
                                                children:
                                                    "Customize System Prompt",
                                            }),
                                            o.jsx("textarea", {
                                                id: "systemPrompt",
                                                value: r,
                                                onChange: (e) =>
                                                    s(e.target.value),
                                                placeholder:
                                                    "Enter custom system prompt...",
                                                className:
                                                    "w-full px-3 py-2 border border-border-200 rounded-md focus:outline-none focus:ring-2 focus:ring-accent-main-200 font-code bg-bg-000 text-text-100",
                                                rows: 12,
                                            }),
                                            o.jsx("p", {
                                                className:
                                                    "mt-2 font-caption text-text-300",
                                                children:
                                                    "Customize the instructions given to Claude for browser automation tasks.",
                                            }),
                                        ],
                                    }),
                                    o.jsxs("div", {
                                        className: "flex gap-3",
                                        children: [
                                            "``",
                                            o.jsx("button", {
                                                onClick: d,
                                                className:
                                                    "flex-1 bg-text-100 text-oncolor-100 py-2 px-4 rounded-md hover:bg-text-200 focus:outline-none focus:ring-2 focus:ring-accent-main-200 font-button-lg",
                                                children: "Save System Prompt",
                                            }),
                                            o.jsx("button", {
                                                onClick: u,
                                                className:
                                                    "px-4 py-2 border border-border-200 rounded-md hover:bg-bg-200 focus:outline-none focus:ring-2 focus:ring-border-100 text-text-200 font-button",
                                                children: "Reset to Default",
                                            }),
                                        ],
                                    }),
                                ],
                            }),
                        o.jsx("div", {
                            className: "border-t border-border-300",
                        }),
                        o.jsxs("div", {
                            className: "space-y-4",
                            children: [
                                o.jsxs("h3", {
                                    className:
                                        "font-large-bold text-text-100 flex items-center gap-2",
                                    children: [
                                        o.jsx(le, { className: "w-5 h-5" }),
                                        "(Ant-only) Debug Settings",
                                    ],
                                }),
                                o.jsxs("div", {
                                    className: "space-y-3",
                                    children: [
                                        o.jsxs("label", {
                                            className:
                                                "flex items-center gap-3 cursor-pointer",
                                            children: [
                                                o.jsx("input", {
                                                    type: "checkbox",
                                                    checked: i,
                                                    onChange: (e) =>
                                                        (async (e) => {
                                                            l(e),
                                                                await U(
                                                                    B.DEBUG_MODE,
                                                                    e
                                                                ),
                                                                p(!0),
                                                                setTimeout(
                                                                    () => p(!1),
                                                                    2e3
                                                                );
                                                        })(e.target.checked),
                                                    className:
                                                        "w-4 h-4 text-accent-main-200 bg-bg-000 border-border-200 rounded focus:ring-accent-main-200 focus:ring-2",
                                                }),
                                                o.jsxs("div", {
                                                    children: [
                                                        o.jsx("p", {
                                                            className:
                                                                "font-base text-text-100",
                                                            children:
                                                                "Show tool result details",
                                                        }),
                                                        o.jsx("p", {
                                                            className:
                                                                "font-caption text-text-300",
                                                            children:
                                                                "Enable expandable tool result blocks to view parameters and outputs",
                                                        }),
                                                    ],
                                                }),
                                            ],
                                        }),
                                        o.jsxs("label", {
                                            className:
                                                "flex items-center gap-3 cursor-pointer",
                                            children: [
                                                o.jsx("input", {
                                                    type: "checkbox",
                                                    checked: f,
                                                    onChange: (e) =>
                                                        (async (e) => {
                                                            x(e),
                                                                await U(
                                                                    B.SHOW_TRACE_IDS,
                                                                    e
                                                                ),
                                                                p(!0),
                                                                setTimeout(
                                                                    () => p(!1),
                                                                    2e3
                                                                );
                                                        })(e.target.checked),
                                                    className:
                                                        "w-4 h-4 text-accent-main-200 bg-bg-000 border-border-200 rounded focus:ring-accent-main-200 focus:ring-2",
                                                }),
                                                o.jsxs("div", {
                                                    children: [
                                                        o.jsx("p", {
                                                            className:
                                                                "font-base text-text-100",
                                                            children:
                                                                "Show trace IDs",
                                                        }),
                                                        o.jsx("p", {
                                                            className:
                                                                "font-caption text-text-300",
                                                            children:
                                                                "Display trace IDs at the beginning of each response stream",
                                                        }),
                                                    ],
                                                }),
                                            ],
                                        }),
                                    ],
                                }),
                            ],
                        }),
                        m &&
                            o.jsx("div", {
                                className: "font-base-sm text-text-200",
                                children: "Settings saved successfully!",
                            }),
                    ],
                }),
            ],
        });
    },
    nr = () => {
        const [t, n] = e.useState(""),
            a = (e, t, n) => ({
                role: "assistant",
                content: e,
                id: `msg_staging_${Math.random()
                    .toString(36)
                    .substring(2, 11)}`,
                model: "claude-sonnet-4-20250514",
                stop_reason: n ? "tool_use" : "end_turn",
                stop_sequence: null,
                type: "message",
                usage: {
                    input_tokens: t.input,
                    output_tokens: t.output,
                    cache_creation_input_tokens: t.cacheCreation || 0,
                    cache_read_input_tokens: t.cacheRead || 0,
                },
            }),
            r = async (e, t) => {
                try {
                    await U(B.TEST_DATA_MESSAGES, t),
                        n(`Loaded ${e} - Reload the side panel to use`),
                        setTimeout(() => n(""), 3e3);
                } catch (a) {
                    n(`Error loading test data: ${a}`);
                }
            };
        return o.jsxs("div", {
            className: "space-y-6",
            children: [
                o.jsxs("div", {
                    children: [
                        o.jsx("h2", {
                            className: "text-lg font-medium text-text-100 mb-4",
                            children: "Test Data Loader (Development Only)",
                        }),
                        o.jsx("p", {
                            className: "text-sm text-text-300 mb-6",
                            children:
                                "Load test conversations for development. Data is stored in chrome.storage.local and will be loaded when the side panel initializes.",
                        }),
                    ],
                }),
                o.jsxs("div", {
                    className: "space-y-4",
                    children: [
                        o.jsxs("div", {
                            className: "flex flex-wrap gap-3",
                            children: [
                                o.jsx("button", {
                                    onClick: () => {
                                        const e = [
                                            {
                                                role: "user",
                                                content: [
                                                    {
                                                        type: "text",
                                                        text: "what's on the screen?",
                                                    },
                                                ],
                                            },
                                            a(
                                                [
                                                    {
                                                        type: "text",
                                                        text: "I'll take a screenshot to see what's currently on the screen.",
                                                    },
                                                ],
                                                {
                                                    input: 147,
                                                    output: 66,
                                                    cacheCreation: 10234,
                                                }
                                            ),
                                        ];
                                        r("Simple Conversation", e);
                                    },
                                    className:
                                        "px-4 py-2 bg-accent-main-100 text-oncolor-100 rounded hover:bg-accent-main-200 transition-colors",
                                    children: "Load Simple Conversation",
                                }),
                                o.jsx("button", {
                                    onClick: () => {
                                        const e = [];
                                        for (let t = 0; t < 50; t++)
                                            e.push({
                                                role: "user",
                                                content: [
                                                    {
                                                        type: "text",
                                                        text: `Question ${
                                                            t + 1
                                                        }: Tell me about item ${
                                                            t + 1
                                                        }`,
                                                    },
                                                ],
                                            }),
                                                e.push(
                                                    a(
                                                        [
                                                            {
                                                                type: "text",
                                                                text: `Here's information about item ${
                                                                    t + 1
                                                                }. `.repeat(50),
                                                            },
                                                        ],
                                                        {
                                                            input:
                                                                2e3 + 100 * t,
                                                            output: 500,
                                                            cacheRead: 1e3,
                                                        }
                                                    )
                                                );
                                        r("Long Conversation", e);
                                    },
                                    className:
                                        "px-4 py-2 bg-accent-main-100 text-oncolor-100 rounded hover:bg-accent-main-200 transition-colors",
                                    children: "Load Long Conversation",
                                }),
                                o.jsx("button", {
                                    onClick: () => {
                                        const e = [],
                                            t =
                                                "This is a test message that simulates a long conversation. ".repeat(
                                                    1e3
                                                ),
                                            n = Math.floor(
                                                72e4 / (2 * t.length)
                                            );
                                        for (let r = 0; r < n; r++)
                                            e.push({
                                                role: "user",
                                                content: [
                                                    {
                                                        type: "text",
                                                        text: `Question ${
                                                            r + 1
                                                        }: ${t}`,
                                                    },
                                                ],
                                            }),
                                                e.push(
                                                    a(
                                                        [
                                                            {
                                                                type: "text",
                                                                text: `Response ${
                                                                    r + 1
                                                                }: ${t}`,
                                                            },
                                                        ],
                                                        {
                                                            input:
                                                                1e4 + 500 * r,
                                                            output:
                                                                5e3 + 100 * r,
                                                            cacheRead: 2e3,
                                                        }
                                                    )
                                                );
                                        const o = e[e.length - 1];
                                        o &&
                                            "usage" in o &&
                                            o.usage &&
                                            ((o.usage.input_tokens = 10),
                                            (o.usage.cache_creation_input_tokens = 15e4),
                                            (o.usage.cache_read_input_tokens = 3e4),
                                            (o.usage.output_tokens = 5e3)),
                                            r("Near Context Limit", e);
                                    },
                                    className:
                                        "px-4 py-2 bg-accent-main-100 text-oncolor-100 rounded hover:bg-accent-main-200 transition-colors",
                                    children: "Load Near Context Limit",
                                }),
                                o.jsx("button", {
                                    onClick: () => {
                                        const e = [
                                            {
                                                role: "user",
                                                content: [
                                                    {
                                                        type: "text",
                                                        text: "Navigate to google.com and search for 'weather'",
                                                    },
                                                ],
                                            },
                                            a(
                                                [
                                                    {
                                                        type: "text",
                                                        text: "I'll navigate to Google and search for weather information.",
                                                    },
                                                    {
                                                        type: "tool_use",
                                                        id: "toolu_01_navigate",
                                                        name: "navigate",
                                                        input: {
                                                            url: "https://google.com",
                                                        },
                                                    },
                                                ],
                                                {
                                                    input: 200,
                                                    output: 100,
                                                    cacheCreation: 5e3,
                                                },
                                                !0
                                            ),
                                            {
                                                role: "user",
                                                content: [
                                                    {
                                                        type: "tool_result",
                                                        tool_use_id:
                                                            "toolu_01_navigate",
                                                        content:
                                                            "Navigated to google.com",
                                                    },
                                                ],
                                            },
                                            a(
                                                [
                                                    {
                                                        type: "text",
                                                        text: "Now I'll search for 'weather' on Google.",
                                                    },
                                                    {
                                                        type: "tool_use",
                                                        id: "toolu_02_type",
                                                        name: "computer",
                                                        input: {
                                                            action: "type",
                                                            text: "weather",
                                                        },
                                                    },
                                                ],
                                                {
                                                    input: 300,
                                                    output: 150,
                                                    cacheRead: 4e3,
                                                },
                                                !0
                                            ),
                                        ];
                                        r("Tool Use Conversation", e);
                                    },
                                    className:
                                        "px-4 py-2 bg-accent-main-100 text-oncolor-100 rounded hover:bg-accent-main-200 transition-colors",
                                    children: "Load Tool Use Conversation",
                                }),
                                o.jsx("button", {
                                    onClick: async () => {
                                        try {
                                            await chrome.storage.local.remove(
                                                "test_data_messages"
                                            ),
                                                n("Test data cleared"),
                                                setTimeout(() => n(""), 3e3);
                                        } catch (e) {
                                            n(`Error clearing test data: ${e}`);
                                        }
                                    },
                                    className:
                                        "px-4 py-2 bg-danger-100 text-oncolor-100 rounded hover:bg-danger-200 transition-colors",
                                    children: "Clear Test Data",
                                }),
                            ],
                        }),
                        t &&
                            o.jsx("div", {
                                className:
                                    "mt-4 p-3 bg-bg-200 rounded text-sm text-text-200",
                                children: t,
                            }),
                    ],
                }),
                o.jsxs("div", {
                    className: "mt-6 p-4 bg-bg-200 rounded",
                    children: [
                        o.jsx("h3", {
                            className: "text-sm font-medium text-text-200 mb-2",
                            children: "How it works:",
                        }),
                        o.jsxs("ul", {
                            className: "text-sm text-text-300 space-y-1",
                            children: [
                                o.jsx("li", {
                                    children:
                                        "• Test data is saved to chrome.storage.local",
                                }),
                                o.jsx("li", {
                                    children:
                                        "• The side panel reads this data on initialization",
                                }),
                                o.jsx("li", {
                                    children:
                                        "• No direct manipulation of message state",
                                }),
                                o.jsx("li", {
                                    children:
                                        "• Reload the side panel after loading test data",
                                }),
                            ],
                        }),
                    ],
                }),
            ],
        });
    },
    ar = ({ children: e, isActive: t, onClick: n }) =>
        o.jsx("button", {
            onClick: n,
            className: u(
                "block w-full text-left whitespace-nowrap transition-all ease-in-out active:scale-95 cursor-pointer",
                "font-base rounded-lg px-3 py-3",
                t
                    ? "bg-bg-300 font-medium text-text-000"
                    : "text-text-200 hover:bg-bg-200 hover:text-text-100"
            ),
            children: e,
        }),
    rr = ({ children: e, className: t, narrow: n }) =>
        o.jsx("main", {
            className: u(
                "mx-auto mt-4 w-full flex-1 px-4 md:pl-8 lg:mt-6",
                n ? "max-w-4xl" : "max-w-7xl",
                t
            ),
            children: e,
        }),
    or = ({
        children: e,
        className: t,
        contentClassName: n,
        sticky: a,
        fixed: r,
        mdTitle: s,
        large: i,
        narrow: l,
    }) => {
        const c = !e && !s,
            d = i;
        return o.jsx("header", {
            className: u(
                "flex w-full bg-bg-100",
                a && "sticky top-0 z-50",
                r && "fixed top-0 z-50",
                "h-12",
                d && [
                    "mx-auto md:h-24 md:items-end",
                    l ? "max-w-4xl" : "max-w-7xl",
                ],
                t
            ),
            "aria-hidden": c,
            children: o.jsx("div", {
                className: u(
                    "flex w-full items-center justify-between gap-4",
                    "pl-11 lg:pl-8",
                    n,
                    d ? "px-4 md:pl-8" : "pr-3"
                ),
                children: s
                    ? o.jsxs(o.Fragment, {
                          children: [
                              o.jsx("h1", {
                                  className: u(
                                      "text-text-200 flex items-center gap-2 text-center max-md:hidden min-w-0",
                                      "font-heading",
                                      d ? "text-2xl" : "text-lg"
                                  ),
                                  children: o.jsx("span", {
                                      className: "truncate",
                                      children: s,
                                  }),
                              }),
                              o.jsx("div", {}),
                              e,
                          ],
                      })
                    : e,
            }),
        });
    };
function sr() {
    const { userProfile: t, isAuthenticated: n } = P(),
        { resetAnalytics: r } = F(),
        { value: s } = a.useFeatureGate("chrome_scheduled_tasks"),
        { value: i } = a.useFeatureGate("chrome_extension_show_user_email"),
        { value: l } = a.useFeatureGate("crochet_default_debug_mode"),
        { value: c } = a.useFeatureGate("chrome_ext_allow_api_key"),
        { value: d } = a.useFeatureGate("chrome_ext_edit_system_prompt"),
        [u, m] = e.useState(""),
        [apiBaseUrl, setApiBaseUrl] = e.useState(""),
        [p, h] = e.useState(""),
        [f, x] = e.useState(!1),
        [g, v] = e.useState("permissions"),
        [b, y] = e.useState([]),
        [w, j] = e.useState(""),
        [C, k] = e.useState(!1),
        N = a.useDynamicConfig("chrome_ext_models").value;
    e.useEffect(() => {
        $([
            B.ANTHROPIC_API_KEY,
            B.SELECTED_MODEL,
            B.SYSTEM_PROMPT,
            B.DEBUG_MODE,
        ]).then((e) => {
            e[B.ANTHROPIC_API_KEY] && m(e[B.ANTHROPIC_API_KEY]),
                e[B.SELECTED_MODEL] && h(e[B.SELECTED_MODEL]),
                e[B.SYSTEM_PROMPT] && j(e[B.SYSTEM_PROMPT]),
                void 0 !== e[B.DEBUG_MODE] ? k(e[B.DEBUG_MODE]) : k(l || !1);
        });
        setApiBaseUrl(localStorage.getItem("apiBaseUrl"))
    }, [l]),
        e.useEffect(() => {
            v(
                (() => {
                    const e = window.location.hash.slice(1);
                    return [
                        "api",
                        "permissions",
                        "model",
                        "scheduled",
                        "prompts",
                        "testdata",
                    ].includes(e)
                        ? e
                        : "permissions";
                })()
            );
        }, []);
    const M = (e) => {
        v(e), (window.location.hash = e);
    };
    e.useEffect(() => {
        U(B.SCHEDULED_TASKS_ENABLED, s);
    }, [s]),
        e.useEffect(() => {
            N.options && y(N.options);
        }, [N.options]);
    return o.jsxs(o.Fragment, {
        children: [
            o.jsxs(or, {
                large: !0,
                mdTitle: n || u ? "Claude for Chrome settings" : void 0,
                sticky: !0,
                children: [
                    n &&
                        t &&
                        i &&
                        o.jsxs("div", {
                            className:
                                "flex items-center gap-2 px-3 py-2 bg-bg-000 border border-border-200 rounded-lg",
                            children: [
                                o.jsx(be, {
                                    className: "w-4 h-4 text-text-300",
                                }),
                                o.jsx("span", {
                                    className: "font-base-sm text-text-200",
                                    children: t.account.email,
                                }),
                            ],
                        }),
                    !n &&
                        u &&
                        o.jsxs("div", {
                            className: "flex items-center gap-3",
                            children: [
                                o.jsxs("div", {
                                    className:
                                        "flex items-center gap-2 px-3 py-2 bg-bg-000 border border-border-200 rounded-lg",
                                    children: [
                                        o.jsx(be, {
                                            className: "w-4 h-4 text-text-300",
                                        }),
                                        o.jsx("span", {
                                            className:
                                                "font-base-sm text-text-200",
                                            children: "API Key Mode",
                                        }),
                                    ],
                                }),
                                o.jsx("button", {
                                    onClick: async () => {
                                        try {
                                            await W();
                                        } catch (e) {}
                                    },
                                    className:
                                        "px-3 py-2 bg-accent-main-100 text-oncolor-100 rounded-lg font-base-sm hover:bg-accent-main-200 transition-colors",
                                    children: "Login",
                                }),
                            ],
                        }),
                ],
            }),
            o.jsxs(rr, {
                children: [
                    o.jsx("h1", {
                        className:
                            "font-heading text-text-200 mb-4 flex items-center gap-1.5 text-center md:hidden",
                        children: "Settings",
                    }),
                    n || u
                        ? o.jsxs("div", {
                              className:
                                  "grid md:grid-cols-[220px_minmax(0px,_1fr)] gap-x-8 w-full max-w-6xl my-4 md:my-8",
                              children: [
                                  o.jsxs("nav", {
                                      className:
                                          "w-full overflow-x-auto -m-2 p-2 self-start md:sticky md:top-4 relative z-10 mb-4 md:mb-0",
                                      children: [
                                          o.jsxs("ul", {
                                              className:
                                                  "flex gap-1 md:flex-col mb-0",
                                              children: [
                                                  c &&
                                                      o.jsx("li", {
                                                          children: o.jsx(ar, {
                                                              href: "/settings/api",
                                                              isActive:
                                                                  "api" === g,
                                                              onClick: () =>
                                                                  M("api"),
                                                              children:
                                                                  "API configuration (internal)",
                                                          }),
                                                      }),
                                                  c &&
                                                      o.jsx("li", {
                                                          children: o.jsx(ar, {
                                                              href: "/settings/model",
                                                              isActive:
                                                                  "model" === g,
                                                              onClick: () =>
                                                                  M("model"),
                                                              children:
                                                                  "Model selection (internal)",
                                                          }),
                                                      }),
                                                  o.jsx("li", {
                                                      children: o.jsx(ar, {
                                                          href: "/settings/permissions",
                                                          isActive:
                                                              "permissions" ===
                                                              g,
                                                          onClick: () =>
                                                              M("permissions"),
                                                          children:
                                                              "Permissions",
                                                      }),
                                                  }),
                                                  o.jsx("li", {
                                                      children: o.jsx(ar, {
                                                          href: "/settings/prompts",
                                                          isActive:
                                                              "prompts" === g,
                                                          onClick: () =>
                                                              M("prompts"),
                                                          children: "Shortcuts",
                                                      }),
                                                  }),
                                                  s &&
                                                      o.jsx("li", {
                                                          children: o.jsx(ar, {
                                                              href: "/settings/scheduled",
                                                              isActive:
                                                                  "scheduled" ===
                                                                  g,
                                                              onClick: () =>
                                                                  M(
                                                                      "scheduled"
                                                                  ),
                                                              children:
                                                                  "Scheduled tasks (internal)",
                                                          }),
                                                      }),
                                                  c &&
                                                      o.jsx("li", {
                                                          children: o.jsx(ar, {
                                                              href: "/settings/testdata",
                                                              isActive:
                                                                  "testdata" ===
                                                                  g,
                                                              onClick: () =>
                                                                  M("testdata"),
                                                              children:
                                                                  "Test Data (Dev Only)",
                                                          }),
                                                      }),
                                              ],
                                          }),
                                          n &&
                                              o.jsx(o.Fragment, {
                                                  children: o.jsx("div", {
                                                      className:
                                                          "mt-8 pt-8 border-t border-border-200",
                                                      children: o.jsxs(
                                                          "button",
                                                          {
                                                              onClick:
                                                                  async () => {
                                                                      try {
                                                                          await chrome.runtime.sendMessage(
                                                                              {
                                                                                  type: "logout",
                                                                              }
                                                                          ),
                                                                              await r(),
                                                                              window.location.reload();
                                                                      } catch (e) {
                                                                          alert(
                                                                              "Failed to logout. Please try again."
                                                                          );
                                                                      }
                                                                  },
                                                              className:
                                                                  "w-full flex items-center gap-2 px-3 py-3 text-danger-000 hover:bg-danger-000/10 rounded-lg transition-all font-base",
                                                              children: [
                                                                  o.jsx(he, {
                                                                      className:
                                                                          "w-4 h-4",
                                                                  }),
                                                                  "Logout",
                                                              ],
                                                          }
                                                      ),
                                                  }),
                                              }),
                                      ],
                                  }),
                                  o.jsxs("div", {
                                      children: [
                                          "api" === g &&
                                              c &&
                                              o.jsx(er, {
                                                  apiKey: u,
                                                  setApiKey: m,
                                                  apiBaseUrl,
                                                  setApiBaseUrl,
                                                  onSave: async () => {
                                                      localStorage.setItem('apiBaseUrl', apiBaseUrl);
                                                      await U(
                                                          B.ANTHROPIC_API_KEY,
                                                          u
                                                      ),
                                                          x(!0),
                                                          setTimeout(
                                                              () => x(!1),
                                                              2e3
                                                          );
                                                  },
                                                  saved: f,
                                              }),
                                          "model" === g &&
                                              c &&
                                              o.jsx(tr, {
                                                  selectedModel: p,
                                                  setSelectedModel: h,
                                                  availableModels: b,
                                                  systemPrompt: w,
                                                  setSystemPrompt: j,
                                                  debugMode: C,
                                                  setDebugMode: k,
                                                  onModelSave: async () => {
                                                      await U(
                                                          B.SELECTED_MODEL,
                                                          p
                                                      ),
                                                          x(!0),
                                                          setTimeout(
                                                              () => x(!1),
                                                              2e3
                                                          );
                                                  },
                                                  onPromptSave: async () => {
                                                      await U(
                                                          B.SYSTEM_PROMPT,
                                                          w
                                                      ),
                                                          x(!0),
                                                          setTimeout(
                                                              () => x(!1),
                                                              2e3
                                                          );
                                                  },
                                                  onResetPrompt: () => {
                                                      j("");
                                                  },
                                                  saved: f,
                                                  setSaved: x,
                                                  allowEditSystemPrompt: d,
                                              }),
                                          "permissions" === g && o.jsx(ye, {}),
                                          "prompts" === g && o.jsx(qa, {}),
                                          "scheduled" === g &&
                                              s &&
                                              o.jsx(Ce, {}),
                                          "testdata" === g &&
                                              c &&
                                              o.jsx(nr, {}),
                                      ],
                                  }),
                              ],
                          })
                        : o.jsx("div", {
                              className:
                                  "flex flex-col items-center justify-center min-h-[400px]",
                              children: o.jsx(Z, {}),
                          }),
                ],
            }),
        ],
    });
}
Y(),
    O(),
    z
        .createRoot(document.getElementById("root"))
        .render(
            o.jsx(s.StrictMode, {
                children: o.jsx(K, {
                    pageName: "Options",
                    children: o.jsx(sr, {}),
                }),
            })
        );
