import "./patch.js";
import {
    b as e,
    i as t,
    f as a,
    e as s,
    s as r,
    S as i,
    h as o,
    j as n,
} from "./SentryService-D1g1nhjU.js";
async function c() {
    const t = e(),
        a = `${`claude-browser-extension/${
            chrome.runtime.getManifest().version
        } (external)`} ${navigator.userAgent} `,
        s = [
            {
                id: 1,
                priority: 1,
                action: {
                    type: chrome.declarativeNetRequest.RuleActionType
                        .MODIFY_HEADERS,
                    requestHeaders: [
                        {
                            header: "User-Agent",
                            operation:
                                chrome.declarativeNetRequest.HeaderOperation
                                    .SET,
                            value: a,
                        },
                    ],
                },
                condition: {
                    urlFilter: `${t.apiBaseUrl}/*`,
                    resourceTypes: [
                        chrome.declarativeNetRequest.ResourceType
                            .XMLHTTPREQUEST,
                        chrome.declarativeNetRequest.ResourceType.OTHER,
                    ],
                },
            },
        ];
    await chrome.declarativeNetRequest.updateSessionRules({
        removeRuleIds: [1],
        addRules: s,
    });
}
async function d(e) {
    chrome.sidePanel.setOptions({
        tabId: e,
        path: `sidepanel.html?tabId=${encodeURIComponent(e)}`,
        enabled: !0,
    }),
        chrome.sidePanel.open({ tabId: e });
}
async function m(e) {
    try {
        await chrome.tabs.sendMessage(e, { type: "HIDE_AGENT_INDICATORS" });
    } catch (t) {}
}
async function u(e) {
    const t = e.id;
    t && (await d(t));
}
async function h(e, t) {
    const a = `session_${Date.now()}_${Math.random()
            .toString(36)
            .substring(2, 11)}`,
        s = await chrome.tabs.create({
            url: e.url || "about:blank",
            active: !0,
        });
    if (!s.id) throw new Error("Failed to create tab for scheduled task");
    await r(i.TARGET_TAB_ID, s.id);
    const o = chrome.runtime.getURL(
        `sidepanel.html?mode=window&sessionId=${a}${
            e.skipPermissions ? "&skipPermissions=true" : ""
        }`
    );
    return (
        await chrome.windows.create({
            url: o,
            type: "popup",
            width: 500,
            height: 768,
            left: 100,
            top: 100,
            focused: !0,
        }),
        new Promise((r) => {
            const i = async () => {
                try {
                    "complete" === (await chrome.tabs.get(s.id)).status
                        ? setTimeout(() => {
                              chrome.runtime.sendMessage({
                                  type: "EXECUTE_SCHEDULED_PROMPT",
                                  prompt: e.prompt,
                                  taskName: e.name,
                                  runLogId: t,
                                  windowSessionId: a,
                              }),
                                  r();
                          }, 2e3)
                        : setTimeout(i, 500);
                } catch (o) {
                    r();
                }
            };
            setTimeout(i, 1e3);
        })
    );
}
t(),
    chrome.runtime.onInstalled.addListener(async (e) => {
        chrome.storage.local.remove(["updateAvailable"]),
            a(),
            await c(),
            e.reason === chrome.runtime.OnInstalledReason.INSTALL && s();
    }),
    chrome.runtime.onStartup.addListener(async () => {
        a(), await c();
    }),
    chrome.action.onClicked.addListener(u),
    chrome.commands.onCommand.addListener((e) => {
        "toggle-side-panel" === e &&
            chrome.tabs.query({ active: !0, currentWindow: !0 }, (e) => {
                const t = e[0];
                t && u(t);
            });
    }),
    chrome.runtime.onUpdateAvailable.addListener((e) => {
        r(i.UPDATE_AVAILABLE, !0);
    }),
    chrome.runtime.onMessage.addListener(
        (e, t, s) => (
            (async () => {
                if ("open_side_panel" === e.type) {
                    const a = e.tabId || t.tab?.id;
                    if (!a) return void s({ success: !1 });
                    if ((await d(a), e.prompt)) {
                        const t = async (a = 0) => {
                            try {
                                await new Promise((t, a) => {
                                    chrome.runtime.sendMessage(
                                        {
                                            type: "POPULATE_INPUT_TEXT",
                                            prompt: e.prompt,
                                        },
                                        () => {
                                            chrome.runtime.lastError
                                                ? a(
                                                      new Error(
                                                          chrome.runtime.lastError.message
                                                      )
                                                  )
                                                : t();
                                        }
                                    );
                                });
                            } catch (s) {
                                a < 3 &&
                                    (await new Promise((e) =>
                                        setTimeout(e, 500)
                                    ),
                                    await t(a + 1));
                            }
                        };
                        await t();
                    }
                    return void s({ success: !0 });
                }
                if ("resize_window" === e.type)
                    try {
                        const e = await chrome.windows.getCurrent(),
                            t = Math.min(e.width || 1366, 1366),
                            a = Math.min(e.height || 768, 768);
                        e.id &&
                            (await chrome.windows.update(e.id, {
                                width: t,
                                height: a,
                            })),
                            s({ success: !0 });
                    } catch (r) {
                        s({ success: !1, error: r.message });
                    }
                else if ("side_panel_closed" === e.type) {
                    const { tabId: t } = e;
                    await m(t), s({ success: !0 });
                } else if ("logout" === e.type)
                    try {
                        await o(), await a(), s({ success: !0 });
                    } catch (r) {}
                else if ("EXECUTE_SCHEDULED_TASK" === e.type)
                    try {
                        const { task: t, runLogId: a } = e;
                        await h(t, a), s({ success: !0 });
                    } catch (r) {
                        s({ success: !1, error: r.message });
                    }
            })(),
            !0
        )
    ),
    chrome.tabs.onRemoved.addListener(async (e) => {
        await m(e);
    }),
    chrome.alarms.onAlarm.addListener(async (e) => {
        if (e.name.startsWith("task_"))
            try {
                const a = e.name.replace(/^task_|_day\d+$/g, ""),
                    s = await chrome.storage.local.get(["scheduledTasks"]),
                    r = (s.scheduledTasks || []).find((e) => e.id === a);
                if (r && (r.enabled || "test-anthropic-news" === a)) {
                    const e = `${Date.now()}_${Math.random()
                        .toString(36)
                        .substring(2, 11)}`;
                    try {
                        await h(r, e);
                    } catch (t) {}
                }
            } catch (t) {}
    }),
    chrome.runtime.onMessageExternal.addListener(
        (e, t, a) => (
            (async () => {
                if ("oauth_redirect" === e.type) {
                    const s = await n(e.redirect_uri, t?.tab?.id);
                    a(s);
                } else
                    "ping" === e.type
                        ? a({ success: !0, exists: !0 })
                        : "onboarding_task" === e.type &&
                          (chrome.runtime.sendMessage({
                              type: "POPULATE_INPUT_TEXT",
                              prompt: e.payload?.prompt,
                          }),
                          a({ success: !0 }));
            })(),
            !0
        )
    );
