import{a2 as r}from"./Main-CWmOU7_i.js";import"./SentryService-B5QbSxHr.js";for(var n={},t={},e=[],u=0;u<64;)e[u]=0|4294967296*Math.sin(++u%Math.PI);const i=r(Object.freeze(Object.defineProperty({__proto__:null,default:function(r){var n,t,i,o=[n=1732584193,t=4023233417,~n,~t],f=[],a=unescape(encodeURI(r))+"",c=a.length;for(r=--c/4+2|15,f[--r]=8*c;~c;)f[c>>2]|=a.charCodeAt(c)<<8*c--;for(u=a=0;u<r;u+=16){for(c=o;a<64;c=[i=c[3],n+((i=c[0]+[n&t|~n&i,i&n|~i&t,n^t^i,t^(n|~i)][c=a>>4]+e[a]+~~f[u|15&[a,5*a+1,3*a+5,7*a][c]])<<(c=[7,12,17,22,5,9,14,20,4,11,16,23,6,10,15,21][4*c+a++%4])|i>>>-c),n,t])n=0|c[1],t=c[2];for(a=4;a;)o[--a]+=c[a]}for(r="";a<32;)r+=(o[a>>3]>>4*(1^a++)&15).toString(16);return r}},Symbol.toStringTag,{value:"Module"})));var o,f,a,c,l,s,v,p,y,d,h,b,g,m,_,w,j,A,O,k,S,N,E,U,I,P,M,F,T,x,C,H,J,G,L,D,R,V,W,B,Q,Y,q,z,K,X,Z,$,rr,nr,tr,er,ur,ir,or,fr,ar,cr,lr,sr,vr,pr,yr,dr,hr,br,gr,mr,_r,wr,jr,Ar,Or,kr,Sr,Nr,Er,Ur,Ir,Pr,Mr,Fr,Tr,xr,Cr,Hr,Jr,Gr,Lr,Dr,Rr,Vr,Wr,Br,Qr,Yr,qr,zr,Kr,Xr,Zr,$r,rn,nn,tn,en,un,on,fn,an,cn,ln,sn,vn,pn,yn,dn,hn,bn,gn,mn,_n,wn,jn,An,On,kn,Sn,Nn,En,Un,In,Pn,Mn,Fn,Tn,xn,Cn,Hn,Jn,Gn,Ln,Dn,Rn,Vn,Wn,Bn,Qn,Yn,qn,zn,Kn,Xn,Zn,$n,rt,nt,tt,et,ut,it,ot,ft,at,ct,lt,st,vt,pt,yt,dt,ht,bt,gt,mt,_t,wt,jt,At,Ot,kt,St,Nt,Et,Ut,It,Pt,Mt={exports:{}};function Ft(){return o||(o=1,Mt.exports=function(r,n,t,e,u){for(n=n.split?n.split("."):n,e=0;e<n.length;e++)r=r?r[n[e]]:u;return r===u?t:r}),Mt.exports}function Tt(){if(a)return f;a=1;
/**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
var r=Number.POSITIVE_INFINITY;return f=r}function xt(){if(v)return s;v=1;var r=l?c:(l=1,
/**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
c=Number);return s=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function Ct(){if(y)return p;y=1;var r=xt().NEGATIVE_INFINITY;return p=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function Ht(){if(h)return d;h=1;return d=1023}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function Jt(){if(S)return k;S=1;var r=O?A:(O=1,A=function(r){return r!=r});return k=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function Gt(){if(I)return U;I=1;var r=function(){if(E)return N;E=1;var r=Tt(),n=Ct();return N=function(t){return t===r||t===n}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return U=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2022 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function Lt(){if(J)return H;J=1;var r=function(){if(C)return x;C=1;var r="function"==typeof Object.defineProperty?Object.defineProperty:null;return x=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return H=function(){try{return r({},"x",{}),!0}catch(n){return!1}}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function Dt(){if(W)return V;W=1;var r,n=Lt(),t=function(){if(L)return G;L=1;var r=Object.defineProperty;return G=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/(),e=function(){if(R)return D;R=1;var r=Object.prototype,n=r.toString,t=r.__defineGetter__,e=r.__defineSetter__,u=r.__lookupGetter__,i=r.__lookupSetter__;return D=function(o,f,a){var c,l,s,v;if("object"!=typeof o||null===o||"[object Array]"===n.call(o))throw new TypeError("invalid argument. First argument must be an object. Value: `"+o+"`.");if("object"!=typeof a||null===a||"[object Array]"===n.call(a))throw new TypeError("invalid argument. Property descriptor must be an object. Value: `"+a+"`.");if((l="value"in a)&&(u.call(o,f)||i.call(o,f)?(c=o.__proto__,o.__proto__=r,delete o[f],o[f]=a.value,o.__proto__=c):o[f]=a.value),s="get"in a,v="set"in a,l&&(s||v))throw new Error("invalid argument. Cannot specify one or more accessors and a value or writable attribute in the property descriptor.");return s&&t&&t.call(o,f,a.get),v&&e&&e.call(o,f,a.set),o}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return r=n()?t:e,V=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function Rt(){if(q)return Y;q=1;var r=function(){if(Q)return B;Q=1;var r=Dt();return B=function(n,t,e){r(n,t,{configurable:!1,enumerable:!1,writable:!1,value:e})}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return Y=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function Vt(){if(Z)return X;Z=1;var r=K?z:(K=1,z=function(){return"function"==typeof Symbol&&"symbol"==typeof Symbol("foo")});return X=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function Wt(){if(tr)return nr;tr=1;var r=function(){if(rr)return $;rr=1;var r=Vt()();return $=function(){return r&&"symbol"==typeof Symbol.toStringTag}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return nr=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function Bt(){if(ur)return er;ur=1;var r=Object.prototype.toString;return er=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function Qt(){if(lr)return cr;lr=1;var r=function(){if(ar)return fr;ar=1;var r=Object.prototype.hasOwnProperty;return fr=function(n,t){return null!=n&&r.call(n,t)}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return cr=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function Yt(){if(yr)return pr;yr=1;var r=Qt(),n=function(){if(vr)return sr;vr=1;var r="function"==typeof Symbol?Symbol.toStringTag:"";return sr=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/(),t=Bt();return pr=function(e){var u,i,o;if(null==e)return t.call(e);i=e[n],u=r(e,n);try{e[n]=void 0}catch(f){return t.call(e)}return o=t.call(e),u?e[n]=i:delete e[n],o}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function qt(){if(hr)return dr;hr=1;var r,n=Wt(),t=function(){if(or)return ir;or=1;var r=Bt();return ir=function(n){return r.call(n)}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/(),e=Yt();return r=n()?e:t,dr=r}function zt(){if(_r)return mr;_r=1;var r=function(){if(gr)return br;gr=1;
/**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
var r=qt(),n="function"==typeof Uint32Array;return br=function(t){return n&&t instanceof Uint32Array||"[object Uint32Array]"===r(t)}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return mr=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function Kt(){if(Sr)return kr;Sr=1;var r=zt(),n=jr?wr:(jr=1,wr=4294967295),t=function(){if(Or)return Ar;Or=1;
/**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
var r="function"==typeof Uint32Array?Uint32Array:null;return Ar=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return kr=function(){var e,u;if("function"!=typeof t)return!1;try{u=new t(u=[1,3.14,-3.14,n+1,n+2]),e=r(u)&&1===u[0]&&3===u[1]&&u[2]===n-2&&0===u[3]&&1===u[4]}catch(i){e=!1}return e}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function Xt(){if(Tr)return Fr;Tr=1;var r,n=function(){if(Er)return Nr;Er=1;var r=Kt();return Nr=r}(),t=function(){if(Ir)return Ur;Ir=1;
/**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
var r="function"==typeof Uint32Array?Uint32Array:void 0;return Ur=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/(),e=Mr?Pr:(Mr=1,Pr=function(){throw new Error("not implemented")});return r=n()?t:e,Fr=r}function Zt(){if(Jr)return Hr;Jr=1;var r=function(){if(Cr)return xr;Cr=1;
/**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
var r=qt(),n="function"==typeof Float64Array;return xr=function(t){return n&&t instanceof Float64Array||"[object Float64Array]"===r(t)}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return Hr=r}function $t(){if(Rr)return Dr;Rr=1;var r=Zt(),n=function(){if(Lr)return Gr;Lr=1;
/**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
var r="function"==typeof Float64Array?Float64Array:null;return Gr=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return Dr=function(){var t,e;if("function"!=typeof n)return!1;try{e=new n([1,3.14,-3.14,NaN]),t=r(e)&&1===e[0]&&3.14===e[1]&&-3.14===e[2]&&e[3]!=e[3]}catch(u){t=!1}return t}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function re(){if(Kr)return zr;Kr=1;var r,n=function(){if(Wr)return Vr;Wr=1;var r=$t();return Vr=r}(),t=function(){if(Qr)return Br;Qr=1;
/**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
var r="function"==typeof Float64Array?Float64Array:void 0;return Br=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/(),e=qr?Yr:(qr=1,Yr=function(){throw new Error("not implemented")});return r=n()?t:e,zr=r}function ne(){if(rn)return $r;rn=1;var r=function(){if(Zr)return Xr;Zr=1;
/**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
var r=qt(),n="function"==typeof Uint8Array;return Xr=function(t){return n&&t instanceof Uint8Array||"[object Uint8Array]"===r(t)}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return $r=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function te(){if(fn)return on;fn=1;var r=ne(),n=tn?nn:(tn=1,nn=255),t=function(){if(un)return en;un=1;
/**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
var r="function"==typeof Uint8Array?Uint8Array:null;return en=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return on=function(){var e,u;if("function"!=typeof t)return!1;try{u=new t(u=[1,3.14,-3.14,n+1,n+2]),e=r(u)&&1===u[0]&&3===u[1]&&u[2]===n-2&&0===u[3]&&1===u[4]}catch(i){e=!1}return e}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function ee(){if(dn)return yn;dn=1;var r,n=function(){if(cn)return an;cn=1;var r=te();return an=r}(),t=function(){if(sn)return ln;sn=1;
/**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
var r="function"==typeof Uint8Array?Uint8Array:void 0;return ln=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/(),e=pn?vn:(pn=1,vn=function(){throw new Error("not implemented")});return r=n()?t:e,yn=r}function ue(){if(mn)return gn;mn=1;var r=function(){if(bn)return hn;bn=1;
/**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
var r=qt(),n="function"==typeof Uint16Array;return hn=function(t){return n&&t instanceof Uint16Array||"[object Uint16Array]"===r(t)}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return gn=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function ie(){if(kn)return On;kn=1;var r=ue(),n=wn?_n:(wn=1,_n=65535),t=function(){if(An)return jn;An=1;
/**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
var r="function"==typeof Uint16Array?Uint16Array:null;return jn=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return On=function(){var e,u;if("function"!=typeof t)return!1;try{u=new t(u=[1,3.14,-3.14,n+1,n+2]),e=r(u)&&1===u[0]&&3===u[1]&&u[2]===n-2&&0===u[3]&&1===u[4]}catch(i){e=!1}return e}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function oe(){if(Fn)return Mn;Fn=1;var r,n=function(){if(Nn)return Sn;Nn=1;var r=ie();return Sn=r}(),t=function(){if(Un)return En;Un=1;
/**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
var r="function"==typeof Uint16Array?Uint16Array:void 0;return En=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/(),e=Pn?In:(Pn=1,In=function(){throw new Error("not implemented")});return r=n()?t:e,Mn=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function fe(){if(Hn)return Cn;Hn=1;var r,n,t=function(){if(xn)return Tn;xn=1;var r=ee(),n=oe();return Tn={uint16:n,uint8:r}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return(n=new t.uint16(1))[0]=4660,r=52===new t.uint8(n.buffer)[0],Cn=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function ae(){if(Gn)return Jn;Gn=1;var r=fe();return Jn=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function ce(){if(Vn)return Rn;Vn=1;var r=Xt(),n=re(),t=function(){return Dn?Ln:(Dn=1,!0===ae()?(r=1,n=0):(r=0,n=1),Ln={HIGH:r,LOW:n});var r,n}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/(),e=new n(1),u=new r(e.buffer),i=t.HIGH,o=t.LOW;return Rn=function(r,n,t,f){return e[0]=r,n[f]=u[i],n[f+t]=u[o],n}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function le(){if(Yn)return Qn;Yn=1;var r=Rt(),n=function(){if(Bn)return Wn;Bn=1;var r=ce();return Wn=function(n){return r(n,[0,0],1,0)}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return r(n,"assign",ce()),Qn=n}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function se(){if(Xn)return Kn;Xn=1;var r=Xt(),n=re(),t=function(){if(zn)return qn;zn=1;var r=ae();return qn=!0===r?1:0}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/(),e=new n(1),u=new r(e.buffer);return Kn=function(r){return e[0]=r,u[t]}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function ve(){if($n)return Zn;$n=1;var r=se();return Zn=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function pe(){if(et)return tt;et=1;var r=Xt(),n=re(),t=function(){return nt?rt:(nt=1,!0===ae()?(r=1,n=0):(r=0,n=1),rt={HIGH:r,LOW:n});var r,n}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/(),e=new n(1),u=new r(e.buffer),i=t.HIGH,o=t.LOW;return tt=function(r,n){return u[i]=r,u[o]=n,e[0]}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function ye(){if(it)return ut;it=1;var r=pe();return ut=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function de(){if(ft)return ot;ft=1;var r=M?P:(M=1,P=2147483648),n=T?F:(T=1,F=2147483647),t=le(),e=ve(),u=ye(),i=[0,0];return ot=function(o,f){var a,c;return t.assign(o,i,1,0),a=i[0],a&=n,c=e(f),u(a|=c&=r,i[1])}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function he(){if(dt)return yt;dt=1;var r=pt?vt:(pt=1,vt=function(r){return Math.abs(r)});return yt=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function be(){if(bt)return ht;bt=1;var r=st?lt:(st=1,lt=22250738585072014e-324),n=Gt(),t=Jt(),e=he();return ht=function(u,i,o,f){return t(u)||n(u)?(i[f]=u,i[f+o]=0,i):0!==u&&e(u)<r?(i[f]=4503599627370496*u,i[f+o]=-52,i):(i[f]=u,i[f+o]=0,i)}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function ge(){if(wt)return _t;wt=1;var r=Rt(),n=function(){if(mt)return gt;mt=1;var r=be();return gt=function(n){return r(n,[0,0],1,0)}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/();return r(n,"assign",be()),_t=n}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function me(){if(kt)return Ot;kt=1;var r=ve(),n=At?jt:(At=1,jt=2146435072),t=Ht();return Ot=function(e){var u=r(e);return(u=(u&n)>>>20)-t|0}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/function _e(){if(Ut)return Et;Ut=1;var r=Tt(),n=Ct(),t=Ht(),e=g?b:(g=1,b=1023),u=_?m:(_=1,m=-1023),i=j?w:(j=1,w=-1074),o=Jt(),f=Gt(),a=function(){if(ct)return at;ct=1;var r=de();return at=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/(),c=ge(),l=function(){if(Nt)return St;Nt=1;var r=me();return St=r}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/(),s=le(),v=ye(),p=[0,0],y=[0,0];return Et=function(d,h){var b,g;return 0===d||o(d)||f(d)?d:(c(p,d),h+=p[1],(h+=l(d=p[0]))<i?a(0,d):h>e?d<0?n:r:(h<=u?(h+=52,g=2220446049250313e-31):g=1,s(y,d),b=y[0],b&=2148532223,g*v(b|=h+t<<20,y[1])))}}
/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/var we,je={};var Ae,Oe,ke={};function Se(){if(Oe)return t;Oe=1;var r=t&&t.__importDefault||function(r){return r&&r.__esModule?r:{default:r}};Object.defineProperty(t,"__esModule",{value:!0});var n=r(i),e=r(Ft()),u=r(function(){if(Pt)return It;Pt=1;var r=_e();return It=r}()),o=(we||(we=1,je.dset=function(r,n,t){n.split&&(n=n.split("."));for(var e,u,i=0,o=n.length,f=r;i<o&&"__proto__"!=(u=""+n[i++])&&"constructor"!==u&&"prototype"!==u;)f=f[u]=i===o?t:typeof(e=f[u])==typeof n?e:0*n[i]!=0||~(""+n[i]).indexOf(".")?{}:[]}),je),f=function(){if(Ae)return ke;Ae=1;var r=ke&&ke.__importDefault||function(r){return r&&r.__esModule?r:{default:r}};Object.defineProperty(ke,"__esModule",{value:!0}),ke.unset=void 0;var n=r(Ft());return ke.unset=function(r,t){if((0,n.default)(r,t)){for(var e=t.split("."),u=e.pop();e.length&&"\\"===e[e.length-1].slice(-1);)u=e.pop().slice(0,-1)+"."+u;for(;e.length;)r=r[t=e.shift()];return delete r[u]}return!0},ke}();function a(r,n){l(r,n.drop,function(r,n){n.forEach(function(n){return delete r[n]})})}function c(r,n){l(r,n.allow,function(r,n){Object.keys(r).forEach(function(t){n.includes(t)||delete r[t]})})}function l(r,n,t){Object.entries(n).forEach(function(n){var u=n[0],i=n[1],o=function(r){"object"==typeof r&&null!==r&&t(r,i)},f=""===u?r:(0,e.default)(r,u);Array.isArray(f)?f.forEach(o):o(f)})}function s(r,n){var t=JSON.parse(JSON.stringify(r));for(var u in n.map)if(n.map.hasOwnProperty(u)){var i=n.map[u],a=u.split("."),c=void 0;if(a.length>1?(a.pop(),c=(0,e.default)(t,a.join("."))):c=r,"object"==typeof c){if(i.copy){var l=(0,e.default)(t,i.copy);void 0!==l&&(0,o.dset)(r,u,l)}else if(i.move){var s=(0,e.default)(t,i.move);void 0!==s&&(0,o.dset)(r,u,s),(0,f.unset)(r,i.move)}else i.hasOwnProperty("set")&&(0,o.dset)(r,u,i.set);if(i.to_string){var v=(0,e.default)(r,u);if("string"==typeof v||"object"==typeof v&&null!==v)continue;void 0!==v?(0,o.dset)(r,u,JSON.stringify(v)):(0,o.dset)(r,u,"undefined")}}}}function v(r,t){return!(t.sample.percent<=0)&&(t.sample.percent>=1||(t.sample.path?function(r,t){var i=(0,e.default)(r,t.sample.path),o=(0,n.default)(JSON.stringify(i)),f=-64,a=[];p(o.slice(0,8),a);for(var c=0,l=0;l<64&&1!==a[l];l++)c++;if(0!==c){var s=[];p(o.slice(9,16),s),f-=c,a.splice(0,c),s.splice(64-c),a=a.concat(s)}return a[63]=0===a[63]?1:0,(0,u.default)(parseInt(a.join(""),2),f)<t.sample.percent}(r,t):(i=t.sample.percent,Math.random()<=i)));var i}function p(r,n){for(var t=0;t<8;t++)for(var e=r[t],u=128;u>=1;u/=2)e-u>=0?(e-=u,n.push(1)):n.push(0)}return t.default=function(r,n){for(var t=r,e=0,u=n;e<u.length;e++){var i=u[e];switch(i.type){case"drop":return null;case"drop_properties":a(t,i.config);break;case"allow_properties":c(t,i.config);break;case"sample_event":if(v(t,i.config))break;return null;case"map_properties":s(t,i.config);break;case"hash_properties":break;default:throw new Error('Transformer of type "'.concat(i.type,'" is unsupported.'))}}return t},t}var Ne,Ee={};function Ue(){if(Ne)return Ee;Ne=1;var r=Ee&&Ee.__importDefault||function(r){return r&&r.__esModule?r:{default:r}};Object.defineProperty(Ee,"__esModule",{value:!0});var n=r(Ft());function t(r,n){if(!Array.isArray(r))return!0===e(r,n);var f=r[0];switch(f){case"!":return!t(r[1],n);case"or":for(var a=1;a<r.length;a++)if(t(r[a],n))return!0;return!1;case"and":for(a=1;a<r.length;a++)if(!t(r[a],n))return!1;return!0;case"=":case"!=":return function(r,n,e,i){u(r)&&(r=t(r,i));u(n)&&(n=t(n,i));"object"==typeof r&&"object"==typeof n&&(r=JSON.stringify(r),n=JSON.stringify(n));switch(e){case"=":return r===n;case"!=":return r!==n;default:throw new Error("Invalid operator in compareItems: ".concat(e))}}(e(r[1],n),e(r[2],n),f,n);case"<=":case"<":case">":case">=":return function(r,n,e,i){u(r)&&(r=t(r,i));u(n)&&(n=t(n,i));if("number"!=typeof r||"number"!=typeof n)return!1;switch(e){case"<=":return r<=n;case">=":return r>=n;case"<":return r<n;case">":return r>n;default:throw new Error("Invalid operator in compareNumbers: ".concat(e))}}(e(r[1],n),e(r[2],n),f,n);case"in":return function(r,n,t){return void 0!==n.find(function(n){return e(n,t)===r})}(e(r[1],n),e(r[2],n),n);case"contains":return function(r,n){if("string"!=typeof r||"string"!=typeof n)return!1;return-1!==r.indexOf(n)}(e(r[1],n),e(r[2],n));case"match":return function(r,n){if("string"!=typeof r||"string"!=typeof n)return!1;return function(r,n){var t,e;r:for(;r.length>0;){var u=void 0,f=void 0;if(u=(t=i(r)).star,f=t.chunk,r=t.pattern,u&&""===f)return!0;var a=o(f,n),c=a.t,l=a.ok,s=a.err;if(s)return!1;if(!l||!(0===c.length||r.length>0)){if(u)for(var v=0;v<n.length;v++){if(c=(e=o(f,n.slice(v+1))).t,l=e.ok,s=e.err,l){if(0===r.length&&c.length>0)continue;n=c;continue r}if(s)return!1}return!1}n=c}return 0===n.length}(n,r)}(e(r[1],n),e(r[2],n));case"lowercase":var c=e(r[1],n);return"string"!=typeof c?null:c.toLowerCase();case"typeof":return typeof e(r[1],n);case"length":return function(r){if(null===r)return 0;if(!Array.isArray(r)&&"string"!=typeof r)return NaN;return r.length}(e(r[1],n));default:throw new Error("FQL IR could not evaluate for token: ".concat(f))}}function e(r,t){return Array.isArray(r)?r:"object"==typeof r?r.value:(0,n.default)(t,r)}function u(r){return!!Array.isArray(r)&&(("lowercase"===r[0]||"length"===r[0]||"typeof"===r[0])&&2===r.length||("contains"===r[0]||"match"===r[0])&&3===r.length)}function i(r){for(var n={star:!1,chunk:"",pattern:""};r.length>0&&"*"===r[0];)r=r.slice(1),n.star=!0;var t,e=!1;r:for(t=0;t<r.length;t++)switch(r[t]){case"\\":t+1<r.length&&t++;break;case"[":e=!0;break;case"]":e=!1;break;case"*":if(!e)break r}return n.chunk=r.slice(0,t),n.pattern=r.slice(t),n}function o(r,n){for(var t,e,u={t:"",ok:!1,err:!1};r.length>0;){if(0===n.length)return u;switch(r[0]){case"[":var i=n[0];n=n.slice(1);var o=!0;(r=r.slice(1)).length>0&&"^"===r[0]&&(o=!1,r=r.slice(1));for(var a=!1,c=0;;){if(r.length>0&&"]"===r[0]&&c>0){r=r.slice(1);break}var l,s="";if(l=(t=f(r)).char,r=t.newChunk,t.err)return u;if(s=l,"-"===r[0]&&(s=(e=f(r.slice(1))).char,r=e.newChunk,e.err))return u;l<=i&&i<=s&&(a=!0),c++}if(a!==o)return u;break;case"?":n=n.slice(1),r=r.slice(1);break;case"\\":if(0===(r=r.slice(1)).length)return u.err=!0,u;default:if(r[0]!==n[0])return u;n=n.slice(1),r=r.slice(1)}}return u.t=n,u.ok=!0,u.err=!1,u}function f(r){var n={char:"",newChunk:"",err:!1};return 0===r.length||"-"===r[0]||"]"===r[0]||"\\"===r[0]&&0===(r=r.slice(1)).length?(n.err=!0,n):(n.char=r[0],n.newChunk=r.slice(1),0===n.newChunk.length&&(n.err=!0),n)}return Ee.default=function(r,n){if(!n)throw new Error("No matcher supplied!");switch(n.type){case"all":return!0;case"fql":return function(r,n){if(!r)return!1;try{r=JSON.parse(r)}catch(u){throw new Error('Failed to JSON.parse FQL intermediate representation "'.concat(r,'": ').concat(u))}var e=t(r,n);if("boolean"!=typeof e)return!1;return e}(n.ir,r);default:throw new Error("Matcher of type ".concat(n.type," unsupported."))}},Ee}var Ie,Pe,Me={};var Fe=(Pe||(Pe=1,function(r){var t=n&&n.__importDefault||function(r){return r&&r.__esModule?r:{default:r}};Object.defineProperty(r,"__esModule",{value:!0}),r.Store=r.matches=r.transform=void 0;var e=Se();Object.defineProperty(r,"transform",{enumerable:!0,get:function(){return t(e).default}});var u=Ue();Object.defineProperty(r,"matches",{enumerable:!0,get:function(){return t(u).default}});var i=function(){if(Ie)return Me;Ie=1,Object.defineProperty(Me,"__esModule",{value:!0});var r=function(){function r(r){this.rules=[],this.rules=r||[]}return r.prototype.getRulesByDestinationName=function(r){for(var n=[],t=0,e=this.rules;t<e.length;t++){var u=e[t];u.destinationName!==r&&void 0!==u.destinationName||n.push(u)}return n},r}();return Me.default=r,Me}();Object.defineProperty(r,"Store",{enumerable:!0,get:function(){return t(i).default}})}(n)),n),Te=function(r){return function(n){var t=n.payload,e=n.integration,u=n.next;new Fe.Store(r).getRulesByDestinationName(e).forEach(function(r){for(var n=r.matchers,e=r.transformers,i=0;i<n.length;i++)if(Fe.matches(t.obj,n[i])&&(t.obj=Fe.transform(t.obj,e[i]),null===t.obj))return u(null)}),u(t)}};export{Te as tsubMiddleware};
